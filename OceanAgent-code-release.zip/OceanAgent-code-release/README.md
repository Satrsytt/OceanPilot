# OceanAgent code release

OceanAgent combines scientific dataset discovery, structured knowledge retrieval,
task compilation, workflow generation, and executable research tools. This
repository contains the application source, retrieval baseline adapters,
retrieval evaluation code, and the benchmark inputs needed to use those tools.

| Directory | Contents |
| --- | --- |
| [`oceanagent/`](oceanagent/README.md) | Agent, web application, tools, Python adapters, and application regression tests |
| [`benchmark/`](benchmark/README.md) | Knowledge cards, dataset corpus, queries, source splits, retrieval labels, and integrity checks |
| [`experiments/`](experiments/README.md) | Dataset retrieval runners, configurations, evaluation code, and tests |
| [`baselines/`](baselines/README.md) | Map of baseline implementations and adapter boundaries |
| [`third_party/KATS/`](third_party/KATS/README.md) | Pinned upstream KATS implementation with its original license |
| [`scripts/`](scripts/) | Code-release verification utilities |

## Run the application

Use Node.js >=22.19.0, npm, and Python 3.11 or later. From `oceanagent/`:

```bash
npm ci
python3 -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements-science.txt
npm run build
npm start
```

Open the local address printed by the server and configure a model provider in
Settings. The shared knowledge directory is `benchmark/knowledge_snapshot`.
The application creates new local settings, sessions, and retrieval indexes.
Model inference requires your own credentials and may incur provider charges.

## Retrieval evaluation

The retained metrics are **Recall@K, MRR, MAP, TRC@K, SCC@K, CSA@K, and
α-nDCG@K**. Evaluation reads only canonical dataset rankings and the
corresponding dataset, requirement, and configuration labels. Missing outcomes
retain their documented status; they are not silently converted to successful
predictions.

Use **CPython 3.11** for the inherited retrieval artifact. This artifact is
required by the historical BM25/context serializer; its original Python source
was unavailable in the recovered projects. The current retrieval adapters and
metric implementations are provided as source. See `experiments/README.md` for
commands, dependency requirements, and metric definitions.

## Check the release

```bash
python3.11 scripts/verify_release.py
python3.11 benchmark/verify_release.py
python3.11 scripts/check_retrieval.py
```

`FILE_MANIFEST.sha256` covers the released file bytes. `RELEASE_CHECKS.json`
records the code and data checks performed for this package. The combined
retrieval check writes new reports under `reproduced/` and makes no model calls.
Dependency folders,
virtual environments, build output, original Git history, application databases,
credentials, historical experiment results, and raw inference logs are excluded.

The default combined check uses the Python standard library. After installing
the dense/KATS dependencies documented under `experiments/`, add
`--with-optional-dependencies` to check those optional numerical/build adapters.

The included benchmark is a retrieval-focused projection of the saved source
snapshot. Its manifest records retained files and transformations. Knowledge
cards retain published source evidence and original provider identifiers.
Original publication PDFs, full extraction caches, physical ocean datasets,
and pretrained model weights must be obtained separately from their providers.

## License and attribution

OceanAgent retains its supplied **PolyForm Noncommercial 1.0.0** license in
[`oceanagent/LICENSE`](oceanagent/LICENSE) and its original copyright notice in
[`oceanagent/NOTICE`](oceanagent/NOTICE). KATS retains its **MIT** license and
third-party attribution. Dependencies and external publications, datasets, and
models retain their own license terms. This packaging does not relicense them.
