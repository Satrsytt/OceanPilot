# Baseline source map

The implementations stay under `experiments/` to preserve their relative imports.

| Baseline | Included source and scope |
|---|---|
| BM25 Retrieval | `experiments/paper_e1/scripts/retrieval.py` loads the hash-checked CPython 3.11 inherited runner from `benchmark/legacy/`. Its Python source is unavailable; this limitation is explicit. |
| Dense Retrieval | `experiments/paper_e1/scripts/dense_retrieval.py`: actual MiniLM ONNX embeddings, normalized cosine ranking. Model weights are external. |
| Direct LLM | `experiments/paper_e1/scripts/run.py`: catalog-free generation followed by fixed exact canonical mapping; unknown or ambiguous slots stay null. |
| Flat RAG Agent | Same runner and retrieval adapter: one ranking stage over projected fixed retrieval context. |
| StructuredRAG | Same runner and retrieval adapter: PSC to UBC to DatasetCard expansion. |
| GraphRAG | Same runner and retrieval adapter: local dataset co-usage graph traversal. This implementation has no community-summary pipeline. |
| TAAR | `experiments/agentic_baseline/`: generic scientific retrieval tool loop without TaskCompiler, with a shared candidate/metadata view and bounded retrieval protocol. |
| OceanAgent retrieval adapter | E1 runner and TAAR comparison adapter: existing ScientificTaskSpec compiler plus native retrieval tools and bounded ranking decisions. |
| KATS-Adapted | `third_party/KATS/` and `experiments/kats_comparison/`: upstream core plus explicit model/I/O/cache/closed-catalog adapters. PDF inputs and graph/index artifacts must be created locally. |

Retrieval metrics and runnable offline commands are in `experiments/README.md`. These labels describe the supplied implementations. The package contains source and input references, without historical result tables or prediction logs. KATS's upstream attribution and MIT license remain in `third_party/KATS/LICENSE`.
