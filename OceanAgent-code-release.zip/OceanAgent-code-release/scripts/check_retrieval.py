#!/usr/bin/env python3
"""Run the packaged offline retrieval and baseline tests without inference."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=ROOT / "reproduced/checks")
    parser.add_argument("--with-optional-dependencies", action="store_true",
                        help="Also run dense and KATS build tests; install their declared dependencies first")
    args = parser.parse_args()
    if sys.implementation.name != "cpython" or sys.version_info[:2] != (3, 11):
        parser.error("Use CPython 3.11 for the retained retrieval artifact")
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=True)
    commands = [
        ("package", ["scripts/verify_release.py"]),
        ("benchmark", ["benchmark/verify_release.py"]),
        ("metrics", ["-m", "unittest", "discover", "-s", "experiments/paper_e1/scripts", "-p", "test_evaluate.py", "-v"]),
        ("retrieval", ["-m", "unittest", "discover", "-s", "experiments/paper_e1/scripts", "-p", "test_retrieval.py", "-v"]),
        ("runner", ["-m", "unittest", "discover", "-s", "experiments/paper_e1/scripts", "-p", "test_run.py", "-v"]),
        ("tool_augmented_retrieval", ["-m", "unittest", "discover", "-s", "experiments/agentic_baseline", "-p", "test_*.py", "-v"]),
        ("kats_mapping", ["-m", "unittest", "discover", "-s", "experiments/kats_comparison", "-p", "test_mapping.py", "-v"]),
        ("kats_source_policy", ["-m", "unittest", "discover", "-s", "experiments/kats_comparison", "-p", "test_source_policy.py", "-v"]),
    ]
    if args.with_optional_dependencies:
        commands.extend([
            ("dense_math", ["-m", "unittest", "discover", "-s", "experiments/paper_e1/scripts", "-p", "test_dense_retrieval.py", "-v"]),
            ("kats_corpus", ["-m", "unittest", "discover", "-s", "experiments/kats_comparison", "-p", "test_corpus.py", "-v"]),
            ("kats_runtime", ["-m", "unittest", "discover", "-s", "experiments/kats_comparison", "-p", "test_runtime.py", "-v"]),
        ])
    report = {"python": sys.version.split()[0], "scope": "offline code and retrieval checks; no inference",
              "optional_dependency_tests": args.with_optional_dependencies, "checks": []}
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
    for name, arguments in commands:
        print(f"Running {name}...", flush=True)
        started = time.monotonic()
        result = subprocess.run([sys.executable, *arguments], cwd=ROOT, env=env, capture_output=True, text=True)
        text = (result.stdout + result.stderr).replace(str(output), "<output>").replace(str(ROOT), "<repository>")
        report["checks"].append({"check": name, "exit_code": result.returncode,
                                 "seconds": round(time.monotonic() - started, 3), "output": text})
        (output / "checks.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
        print(f"{name}: {'passed' if result.returncode == 0 else 'FAILED'}", flush=True)
        if result.returncode:
            print(text)
            return result.returncode
    print(f"All {len(commands)} checks passed. Report: {output / 'checks.json'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
