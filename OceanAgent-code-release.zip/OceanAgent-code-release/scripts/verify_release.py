#!/usr/bin/env python3
"""Verify packaged files, release scope, and common private-file patterns."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
MANIFEST = "FILE_MANIFEST.sha256"
GENERATED = {".git", "node_modules", "dist", ".venv", "venv", ".pytest_cache",
             ".mypy_cache", ".ruff_cache", ".cache", "cache", "reproduced", "runs", "outputs"}
ARTIFACT = "benchmark/legacy/benchmark/baselines/__pycache__/run_baseline.cpython-311.pyc"


def ignored(relative: Path) -> bool:
    return (any(part in GENERATED or part.startswith(".venv-") for part in relative.parts)
            or relative.parts[:2] == ("oceanagent", "data")
            or relative.name == ".DS_Store" or relative.name.startswith("._")
            or (relative.suffix in {".pyc", ".pyo"} and relative.as_posix() != ARTIFACT))


def release_files() -> list[Path]:
    result = []
    for path in ROOT.rglob("*"):
        relative = path.relative_to(ROOT)
        if ignored(relative):
            continue
        if path.is_symlink():
            raise ValueError(f"Symlink cannot be packaged: {relative}")
        if path.is_file() and relative.as_posix() != MANIFEST:
            result.append(path)
    return sorted(result, key=lambda p: p.relative_to(ROOT).as_posix())


def digest(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def check_scope(files: list[Path]) -> list[dict[str, str]]:
    findings = []
    removed_labels = re.compile(rb"(?i)(?<![A-Za-z])(?:step|edge)[ _-]?(?:f1|precision|recall)(?![A-Za-z0-9])")
    review_label = re.compile(b"(?i)" + b"fle" + b"iss")
    review_votes = b"V/" + b"I/" + b"D"
    match_label = re.compile(b"(?i)one[ _-]to[ _-]" + b"one")
    secrets = re.compile(rb"(?<![A-Za-z0-9_-])(?:sk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{24,}|gh[pousr]_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{30,}|AKIA[A-Z0-9]{16})")
    source_citations = {
        "benchmark/knowledge_snapshot/cards/usage_bundle_cards.jsonl",
        "benchmark/knowledge_snapshot/benchmark/splits/train.jsonl",
        "benchmark/knowledge_snapshot/benchmark/build/benchmark_instances.jsonl",
    }
    source_storage = {"benchmark/knowledge_snapshot/cards/dataset_cards.jsonl",
                      "benchmark/knowledge_snapshot/benchmark/corpus/dataset_corpus.jsonl",
                      "benchmark/README.md"}
    for path in files:
        relative = path.relative_to(ROOT).as_posix()
        data = path.read_bytes()
        if path.stat().st_size > 100 * 1024 * 1024:
            findings.append({"path": relative, "rule": "file_over_100_MiB"})
        if path.suffix.lower() in {".db", ".sqlite", ".sqlite3", ".pem", ".key", ".p12"} or (path.name.startswith(".env") and path.name != ".env.example"):
            findings.append({"path": relative, "rule": "private_runtime_file"})
        if removed_labels.search(data) or review_votes.lower() in data.lower() or match_label.search(data):
            findings.append({"path": relative, "rule": "outside_retrieval_evaluation_scope"})
        if review_label.search(data):
            # One third-party paper discusses inter-rater agreement as part of
            # its published scientific method. Preserve its source evidence.
            lines = [line for line in data.splitlines() if review_label.search(line)]
            if relative not in source_citations or any(b'"paper_0410"' not in line for line in lines):
                findings.append({"path": relative, "rule": "outside_release_review_scope"})
        private_data = data
        if relative in source_storage:
            private_data = private_data.replace(b"/" + b"home/bryan/johnsonb", b"<PUBLIC_ARCHIVE>")
        paths = [b"/" + b"Users/", b"-----BEGIN " + b"PRIVATE KEY-----", b"-----BEGIN " + b"RSA PRIVATE KEY-----"]
        if any(value in private_data for value in paths):
            findings.append({"path": relative, "rule": "private_path_or_key"})
        if (b"sk-" in data or b"ghp_" in data or b"github_pat_" in data or b"AKIA" in data) and secrets.search(data):
            findings.append({"path": relative, "rule": "credential_pattern"})
    return findings


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--write-manifest", action="store_true", help="Refresh fingerprints after a reviewed source edit")
    args = parser.parse_args()
    files = release_files()
    findings = check_scope(files)
    if findings:
        print(json.dumps({"status": "failed", "findings": findings}, indent=2))
        return 1
    actual = {p.relative_to(ROOT).as_posix(): digest(p) for p in files}
    manifest = ROOT / MANIFEST
    if args.write_manifest:
        manifest.write_text("".join(f"{value}  {name}\n" for name, value in actual.items()), encoding="utf-8")
    expected = {}
    for line in manifest.read_text(encoding="utf-8").splitlines():
        value, name = line.split("  ", 1)
        if not re.fullmatch(r"[a-f0-9]{64}", value) or Path(name).is_absolute() or ".." in Path(name).parts or name in expected:
            raise ValueError("Invalid or duplicate manifest entry")
        expected[name] = value
    missing = sorted(expected.keys() - actual.keys())
    extra = sorted(actual.keys() - expected.keys())
    changed = sorted(name for name in actual.keys() & expected.keys() if actual[name] != expected[name])
    ok = not (missing or extra or changed)
    print(json.dumps({"status": "passed" if ok else "failed", "files": len(files),
                      "bytes": sum(p.stat().st_size for p in files), "missing": missing,
                      "extra": extra, "changed": changed, "scope_findings": findings}, indent=2))
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
