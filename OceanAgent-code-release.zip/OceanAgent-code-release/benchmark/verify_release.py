"""Verify the dataset-retrieval release without network access or model calls."""
from pathlib import Path
from collections import Counter
import hashlib
import json
import marshal
import sys
import types


ROOT = Path(__file__).resolve().parent
SNAPSHOT = ROOT / "knowledge_snapshot"
BENCH = SNAPSHOT / "benchmark"


def rows(path):
    result = []
    for number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        item = json.loads(line)
        assert isinstance(item, dict), (path.name, number, "not an object")
        result.append(item)
    return result


def index(path, field):
    result = rows(path)
    counts = Counter(row[field] for row in result)
    assert all(count == 1 for count in counts.values()), (path.name, "duplicate IDs")
    return {row[field]: row for row in result}


def main():
    manifest = json.loads((ROOT / "release_data_manifest.json").read_text())
    for item in manifest["files"]:
        path = ROOT / item["path"]
        assert hashlib.sha256(path.read_bytes()).hexdigest() == item["sha256"], (path.name, "hash mismatch")
        assert path.stat().st_size == item["size_bytes"], (path.name, "size mismatch")
    artifacts = json.loads((ROOT / "legacy/artifact_manifest.json").read_text())["artifacts"]
    for item in artifacts:
        path = ROOT / "legacy" / item["path"]
        assert hashlib.sha256(path.read_bytes()).hexdigest() == item["sha256"], (path.name, "artifact hash mismatch")
        assert path.stat().st_size == item["size_bytes"], (path.name, "artifact size mismatch")
        if sys.implementation.name == "cpython" and sys.version_info[:2] == (3, 11):
            # Marshal code layouts are interpreter-specific. The hashes above
            # work on any Python version; metadata inspection uses CPython 3.11.
            pending = [marshal.loads(path.read_bytes()[16:])]
            while pending:
                code = pending.pop()
                filename = code.co_filename.replace("\\", "/")
                assert not filename.startswith("/") and ":" not in filename, (path.name, "absolute bytecode filename")
                pending.extend(value for value in code.co_consts if isinstance(value, types.CodeType))
    corpus = index(BENCH / "corpus/dataset_corpus.jsonl", "dataset_id")
    cards = index(SNAPSHOT / "cards/dataset_cards.jsonl", "dataset_id")
    psc = index(SNAPSHOT / "cards/problem_solution_cards.jsonl", "card_id")
    ubc = index(SNAPSHOT / "cards/usage_bundle_cards.jsonl", "bundle_id")
    assert set(corpus) == set(cards) and len(corpus) == 2260
    assert len(psc) == len(ubc) == 648
    papers = index(SNAPSHOT / "manifest/papers.jsonl", "paper_id")
    titles = index(SNAPSHOT / "manifest/paper_titles.jsonl", "paper_id")
    assert len(papers) == len(titles) == 3599 and set(papers) == set(titles)
    assert {card["paper_id"] for card in psc.values()} <= set(papers)
    for paper in papers.values():
        assert not Path(paper["source_path"]).is_absolute(), (paper["paper_id"], "nonportable paper metadata")
    split_rows = {name: index(BENCH / "splits" / (name + ".jsonl"), "query_id")
                  for name in ("train", "dev", "test")}
    assert {name: len(items) for name, items in split_rows.items()} == {"train": 762, "dev": 108, "test": 218}
    query_sets = {name: set(items) for name, items in split_rows.items()}
    sources = {name: {row["source_id"] for row in items.values()} for name, items in split_rows.items()}
    groups = {name: {row.get("source_group_id") or row["source_id"] for row in items.values()}
              for name, items in split_rows.items()}
    for left, right in (("train", "dev"), ("train", "test"), ("dev", "test")):
        assert not (query_sets[left] & query_sets[right])
        assert not (sources[left] & sources[right])
        assert not (groups[left] & groups[right])
    assert {name: len(items) for name, items in sources.items()} == {"train": 381, "dev": 54, "test": 109}
    all_queries = set().union(*query_sets.values())
    for name in ("dataset_gold", "paper_usage_gold"):
        gold = index(BENCH / "gold" / (name + ".jsonl"), "query_id")
        assert set(gold) == all_queries, (name, "query coverage mismatch")
        for query, row in gold.items():
            assert set(row["gold_dataset_ids"]) <= set(corpus), (name, query, "unknown dataset")
    for split, items in split_rows.items():
        task_counts = Counter(row["problem_solution_card_id"] for row in items.values())
        assert set(task_counts.values()) == {2}, (split, "expected two queries per task")
        for row in items.values():
            assert row["problem_solution_card_id"] in psc
            assert all(identity in ubc for identity in row["usage_bundle_card_ids"])
            assert set(row["gold_dataset_ids"]) <= set(corpus)
    eligible = index(BENCH / "build/eligible_tasks.jsonl", "problem_solution_card_id")
    assert len(eligible) == 544
    assert set(eligible) == {row["problem_solution_card_id"] for items in split_rows.values() for row in items.values()}
    requirements = index(BENCH / "gold/task_requirement_gold.jsonl", "query_id")
    routes = index(BENCH / "gold/valid_route_gold.jsonl", "query_id")
    assert set(requirements) == set(routes) and len(requirements) == 102
    assert set(requirements) <= query_sets["dev"]
    for query, row in requirements.items():
        req_ids = {req["requirement_id"] for req in row["requirements"]}
        for req in row["requirements"]:
            assert set(req["acceptable_dataset_ids"]) <= set(corpus), query
        for route in routes[query]["valid_routes"]:
            assert set(route["covers_requirement_ids"]) <= req_ids, query
            assert all(set(group) <= set(corpus) for group in route["dataset_groups"]), query
    leak = json.loads((BENCH / "reports/leakage_audit.json").read_text())
    assert leak["status"] == "pass" and all(leak["checks"].values())
    print(json.dumps({"status": "PASS", "snapshot_files_verified": len(manifest["files"]),
                      "legacy_artifacts_verified": len(artifacts),
                      "paper_bibliography_entries": len(papers),
                      "dataset_cards": len(cards), "eligible_tasks": len(eligible),
                      "query_count": len(all_queries), "scientific_gold_dev_queries": len(requirements),
                      "split_queries": {name: len(items) for name, items in split_rows.items()},
                      "split_sources": {name: len(items) for name, items in sources.items()}}, indent=2))


if __name__ == "__main__":
    main()
