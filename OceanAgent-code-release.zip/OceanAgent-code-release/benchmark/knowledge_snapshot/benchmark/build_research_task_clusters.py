from __future__ import annotations

import argparse
import hashlib
import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, Protocol, Sequence

import numpy as np

from common import BENCHMARK_ROOT, ROOT, read_jsonl, stable_id, write_json, write_jsonl


PSC_PATH = ROOT / "cards" / "problem_solution_cards.jsonl"
CLUSTERS_PATH = BENCHMARK_ROOT / "build" / "research_task_clusters.jsonl"
SUMMARY_PATH = BENCHMARK_ROOT / "reports" / "task_cluster_summary.json"

DEFAULT_EMBEDDING_BACKEND = "semantic-hash-v1"
DEFAULT_SENTENCE_TRANSFORMER_MODEL = "sentence-transformers/all-MiniLM-L6-v2"
DEFAULT_SENTENCE_TRANSFORMER_REVISION = "1110a243fdf4706b3f48f1d95db1a4f5529b4d41"
DEFAULT_TOP_K = 5
DEFAULT_CANDIDATE_THRESHOLD = 0.42

PAIR_LABELS = {
    "same_task",
    "related_but_different_task",
    "different_task",
}

TOKEN_RE = re.compile(r"[a-z0-9]+(?:['-][a-z0-9]+)?", re.IGNORECASE)
SPACE_RE = re.compile(r"\s+")

STOPWORDS = {
    "a", "about", "across", "after", "against", "all", "also", "an", "and", "are", "as", "at",
    "be", "been", "being", "between", "both", "by", "can", "could", "despite", "do", "does",
    "during", "each", "for", "from", "given", "how", "if", "in", "into", "is", "it", "its",
    "more", "most", "of", "on", "or", "over", "paper", "provide", "study", "such", "than", "that",
    "the", "their", "these", "they", "this", "through", "to", "under", "using", "vary", "was", "we",
    "what", "when", "where", "whether", "which", "while", "with", "within", "without", "would",
}


@dataclass(frozen=True)
class FacetRule:
    name: str
    pattern: re.Pattern[str]


def _rules(values: Mapping[str, str]) -> tuple[FacetRule, ...]:
    return tuple(
        FacetRule(name=name, pattern=re.compile(pattern, re.IGNORECASE))
        for name, pattern in values.items()
    )


TASK_TYPE_RULES = _rules(
    {
        "forecasting": r"\b(forecast|predict|prediction|nowcast|projection|projected|anticipat)[a-z-]*\b",
        "reconstruction": r"\b(reconstruct|interpolat|imput|gap[- ]?fill|super[- ]resolution|downscal)[a-z-]*\b",
        "estimation_retrieval": r"\b(estimate|estimation|retriev|infer|inversion|derive|quantif)[a-z-]*\b",
        "detection_tracking": r"\b(detect|detection|locat|localiz|track|tracking|count|counting)[a-z-]*\b",
        "classification": r"\b(classif|recogniz|identif|label)[a-z-]*\b",
        "segmentation": r"\b(segment|segmentation|delineat|extract)[a-z-]*\b",
        "control_navigation": r"\b(control|navigation|routing|path[- ]?planning|trajectory[- ]?planning)[a-z-]*\b",
        "simulation_modeling": r"\b(simulat|simulation|emulat|model(?:ing|ling)? dynamics)[a-z-]*\b",
        "process_analysis": r"\b(mechanism|driver|cause|impact|influence|effect|relationship|trend|variability|role)[a-z-]*\b",
        "mapping_monitoring": r"\b(map|mapping|monitor|monitoring|change detection|survey)[a-z-]*\b",
        "enhancement_correction": r"\b(enhanc|restor|dehaz|denois|correct|calibrat|bias correct)[a-z-]*\b",
        "generation": r"\b(generat|synthesi[sz]|synthetic)[a-z-]*\b",
        "benchmark_dataset": r"\b(benchmark|dataset|corpus|data set)[a-z-]*\b",
        "assimilation": r"\b(data assimilation|assimilate|assimilation)[a-z-]*\b",
    }
)

RESEARCH_OBJECT_RULES = _rules(
    {
        "tropical_cyclone": r"\b(tropical cyclone|hurricane|typhoon|storm track|storm surge)[a-z-]*\b",
        "ocean_surface": r"\b(ocean surface|sea surface|air[- ]sea interface)[a-z-]*\b",
        "ocean_interior": r"\b(ocean interior|subsurface ocean|water column|deep ocean|abyssal)[a-z-]*\b",
        "coastal_estuary": r"\b(coast|coastal|coastline|shoreline|estuar|lagoon)[a-z-]*\b",
        "river_stream": r"\b(river|stream|watershed|catchment)[a-z-]*\b",
        "seafloor_bathymetry": r"\b(seafloor|sea floor|seabed|bathymetr|bottom boundary|ocean bottom)[a-z-]*\b",
        "sea_ice": r"\b(sea ice|iceberg|ice sheet|ice shelf|glacier)[a-z-]*\b",
        "underwater_scene": r"\b(underwater|subsea|submersible)[a-z-]*\b",
        "ship_vessel": r"\b(ship|vessel|boat|maritime traffic|ais)[a-z-]*\b",
        "marine_ecosystem": r"\b(marine ecosystem|ocean ecosystem|food web|biodiversity)[a-z-]*\b",
        "fish_marine_animal": r"\b(fish|whale|dolphin|shark|marine animal|aquatic animal)[a-z-]*\b",
        "plankton_algae": r"\b(plankton|phytoplankton|zooplankton|alga|harmful algal)[a-z-]*\b",
        "coral_seagrass": r"\b(coral|reef|seagrass|mangrove)[a-z-]*\b",
        "atmosphere_weather": r"\b(atmospher|weather|meteorolog|tropospher|stratospher)[a-z-]*\b",
        "land_surface": r"\b(land surface|terrain|soil|vegetation|crop|forest|urban)[a-z-]*\b",
        "earth_observation_image": r"\b(remote sensing|satellite imagery|satellite image|earth observation)[a-z-]*\b",
    }
)

TARGET_VARIABLE_RULES = _rules(
    {
        "sea_surface_temperature": r"\b(sea surface temperature|sst|ocean surface temperature)[a-z-]*\b",
        "water_temperature": r"\b(water temperature|ocean temperature|thermal structure|marine heatwave)[a-z-]*\b",
        "air_temperature": r"\b(air temperature|surface temperature|near[- ]surface temperature)[a-z-]*\b",
        "salinity": r"\b(salinity|freshwater content)[a-z-]*\b",
        "ocean_current": r"\b(ocean current|surface current|current velocity|circulation|transport|flow field)[a-z-]*\b",
        "wave": r"\b(ocean wave|sea state|wave height|wave period|wave direction|significant wave)[a-z-]*\b",
        "wind": r"\b(wind|wind speed|wind direction|surface wind)[a-z-]*\b",
        "sea_level": r"\b(sea level|sea[- ]surface height|storm surge|water level|tide)[a-z-]*\b",
        "precipitation": r"\b(precipitation|rainfall|rain rate)[a-z-]*\b",
        "chlorophyll": r"\b(chlorophyll|ocean color|primary productivity)[a-z-]*\b",
        "oxygen": r"\b(oxygen|hypoxia|deoxygenation)[a-z-]*\b",
        "carbon": r"\b(carbon dioxide|co2|carbon flux|carbon cycle|pco2)[a-z-]*\b",
        "nutrient": r"\b(nutrient|nitrate|phosphate|silicate|nitrogen|phosphorus)[a-z-]*\b",
        "water_quality": r"\b(water quality|turbidity|pollut|contamin|oil spill)[a-z-]*\b",
        "bathymetry_depth": r"\b(bathymetr|water depth|ocean depth|seafloor depth|elevation model)[a-z-]*\b",
        "position_trajectory": r"\b(position|location|trajectory|track|path|drift)[a-z-]*\b",
        "image_quality": r"\b(image quality|visibility|color cast|contrast|illumination)[a-z-]*\b",
        "species_abundance": r"\b(species|abundance|biomass|distribution|habitat|population)[a-z-]*\b",
        "streamflow_discharge": r"\b(streamflow|river flow|discharge|runoff)[a-z-]*\b",
        "soil_moisture": r"\b(soil moisture)[a-z-]*\b",
        "ice_extent_thickness": r"\b(ice extent|ice concentration|ice thickness|ice cover)[a-z-]*\b",
    }
)

PROCESS_RULES = _rules(
    {
        "ocean_circulation": r"\b(ocean circulation|overturning|gyre|boundary current)[a-z-]*\b",
        "eddy_transport": r"\b(eddy|mesoscale|submesoscale|turbulen|mixing|transport)[a-z-]*\b",
        "air_sea_interaction": r"\b(air[- ]sea|ocean[- ]atmosphere|surface flux|heat flux)[a-z-]*\b",
        "wave_dynamics": r"\b(wave dynamics|wave propagation|wave breaking|sea state)[a-z-]*\b",
        "tides": r"\b(tide|tidal)[a-z-]*\b",
        "biogeochemistry": r"\b(biogeochem|carbon cycle|nutrient cycling|primary production)[a-z-]*\b",
        "ecosystem_dynamics": r"\b(ecosystem dynamics|food web|species interaction|population dynamics)[a-z-]*\b",
        "sediment_erosion": r"\b(sediment|erosion|deposition|shoreline change)[a-z-]*\b",
        "extreme_event": r"\b(extreme event|marine heatwave|storm|hurricane|cyclone|flood|drought)[a-z-]*\b",
        "climate_variability": r"\b(climate variability|climate change|global warming|enso|el ni[nñ]o|la ni[nñ]a)[a-z-]*\b",
        "advection_diffusion": r"\b(advection|diffusion|dispersion|tracer transport)[a-z-]*\b",
        "hydrologic_cycle": r"\b(hydrolog|precipitation|evaporation|runoff)[a-z-]*\b",
    }
)

REGION_RULES = _rules(
    {
        "global": r"\b(global|worldwide|world ocean)[a-z-]*\b",
        "arctic": r"\b(arctic|north pole)[a-z-]*\b",
        "antarctic_southern_ocean": r"\b(antarctic|southern ocean|south pole)[a-z-]*\b",
        "north_atlantic": r"\b(north atlantic)[a-z-]*\b",
        "south_atlantic": r"\b(south atlantic)[a-z-]*\b",
        "equatorial_atlantic": r"\b(equatorial atlantic|atlantic ni[nñ]o)[a-z-]*\b",
        "atlantic": r"\b(atlantic ocean|atlantic)[a-z-]*\b",
        "north_pacific": r"\b(north pacific)[a-z-]*\b",
        "south_pacific": r"\b(south pacific)[a-z-]*\b",
        "equatorial_pacific": r"\b(equatorial pacific)[a-z-]*\b",
        "pacific": r"\b(pacific ocean|pacific)[a-z-]*\b",
        "indian_ocean": r"\b(indian ocean)[a-z-]*\b",
        "mediterranean": r"\b(mediterranean)[a-z-]*\b",
        "coastal": r"\b(coast|coastal|shore|nearshore)[a-z-]*\b",
        "open_ocean": r"\b(open ocean|offshore)[a-z-]*\b",
        "inland_water": r"\b(river|lake|reservoir|stream|watershed)[a-z-]*\b",
    }
)

TEMPORAL_RULES = _rules(
    {
        "subdaily": r"\b(sub[- ]?daily|hourly|\d+[- ]?hour|minutes?|real[- ]time)[a-z-]*\b",
        "daily": r"\b(daily|day[- ]ahead|\d+[- ]?day)[a-z-]*\b",
        "weekly_subseasonal": r"\b(weekly|week|sub[- ]?seasonal|\d+[- ]?week)[a-z-]*\b",
        "seasonal": r"\b(seasonal|season|monsoon)[a-z-]*\b",
        "annual_interannual": r"\b(annual|yearly|interannual|year[- ]to[- ]year)[a-z-]*\b",
        "decadal_long_term": r"\b(decadal|multi[- ]decadal|long[- ]term|climatolog|future climate)[a-z-]*\b",
    }
)


@dataclass(frozen=True)
class TaskSignature:
    research_objective: str
    research_objects: tuple[str, ...]
    target_variables: tuple[str, ...]
    drivers_predictors: tuple[str, ...]
    scientific_processes: tuple[str, ...]
    task_types: tuple[str, ...]
    regions: tuple[str, ...]
    temporal_scales: tuple[str, ...]
    research_fields: tuple[str, ...]
    problem_tokens: tuple[str, ...]

    def compact_text(self) -> str:
        fields = (
            ("objective", (self.research_objective,)),
            ("object", self.research_objects),
            ("target", self.target_variables),
            ("drivers", self.drivers_predictors),
            ("process", self.scientific_processes),
            ("task_type", self.task_types),
            ("region", self.regions),
            ("temporal_scale", self.temporal_scales),
            ("research_field", self.research_fields),
        )
        return " | ".join(
            f"{name}={','.join(values)}"
            for name, values in fields
            if any(values)
        )


class EmbeddingBackend(Protocol):
    """Replaceable frozen embedding boundary used only for Top-k candidate retrieval."""

    name: str

    def encode(
        self,
        signatures: Sequence[TaskSignature],
        cards: Sequence[Mapping[str, Any]],
    ) -> np.ndarray:
        """Return a row-normalized embedding matrix in card order."""


def _normalize_text(value: Any) -> str:
    return SPACE_RE.sub(" ", str(value or "").strip()).casefold()


def _tokens(value: str) -> tuple[str, ...]:
    return tuple(
        token
        for token in TOKEN_RE.findall(value.casefold())
        if len(token) > 1 and token not in STOPWORDS
    )


def _matches(text: str, rules: Sequence[FacetRule]) -> tuple[str, ...]:
    return tuple(rule.name for rule in rules if rule.pattern.search(text))


def build_task_signature(card: Mapping[str, Any]) -> TaskSignature:
    problem = _normalize_text(card.get("problem"))
    solution = _normalize_text(card.get("solution_summary"))
    combined = f"{problem} {solution}"
    problem_tokens = _tokens(problem)

    target_variables = _matches(combined, TARGET_VARIABLE_RULES)
    research_objects = _matches(combined, RESEARCH_OBJECT_RULES)
    scientific_processes = _matches(combined, PROCESS_RULES)
    task_types = _matches(problem, TASK_TYPE_RULES) or _matches(combined, TASK_TYPE_RULES)
    regions = _matches(problem, REGION_RULES)
    temporal_scales = _matches(problem, TEMPORAL_RULES)

    target_terms = set(target_variables)
    driver_terms = tuple(
        sorted(
            (set(_matches(solution, TARGET_VARIABLE_RULES)) | set(_matches(solution, PROCESS_RULES)))
            - target_terms
        )
    )
    research_field = card.get("research_field") or {}
    field_values = []
    if isinstance(research_field, Mapping):
        primary = research_field.get("primary")
        if primary:
            field_values.append(str(primary))
        field_values.extend(str(value) for value in research_field.get("secondary") or [] if value)

    objective_tokens = [token for token in problem_tokens if token not in {"accurately", "effectively", "robust"}]
    objective = " ".join(objective_tokens[:42])
    return TaskSignature(
        research_objective=objective,
        research_objects=research_objects,
        target_variables=target_variables,
        drivers_predictors=driver_terms,
        scientific_processes=scientific_processes,
        task_types=task_types,
        regions=regions,
        temporal_scales=temporal_scales,
        research_fields=tuple(dict.fromkeys(field_values)),
        problem_tokens=problem_tokens,
    )


class FrozenSemanticHashEmbedding:
    """Dependency-light, frozen semantic feature embedding.

    Semantic facet rules and feature weights are versioned in this file. The
    transform never fits on PSC membership, so adding or reordering cards does
    not alter an existing card's vector.
    """

    name = "semantic-hash-v1"

    def __init__(self, dimensions: int = 4096) -> None:
        self.dimensions = dimensions

    def _add(self, vector: np.ndarray, feature: str, weight: float) -> None:
        digest = hashlib.sha256(feature.encode("utf-8")).digest()
        index = int.from_bytes(digest[:8], "big") % self.dimensions
        vector[index] += weight

    def encode(
        self,
        signatures: Sequence[TaskSignature],
        cards: Sequence[Mapping[str, Any]],
    ) -> np.ndarray:
        del cards
        matrix = np.zeros((len(signatures), self.dimensions), dtype=np.float32)
        for row_index, signature in enumerate(signatures):
            vector = matrix[row_index]
            for value in signature.task_types:
                self._add(vector, f"task:{value}", 5.0)
            for value in signature.target_variables:
                self._add(vector, f"target:{value}", 4.5)
                self._add(vector, f"subject:{value}", 2.0)
            for value in signature.research_objects:
                self._add(vector, f"object:{value}", 4.0)
                self._add(vector, f"subject:{value}", 2.0)
            for value in signature.scientific_processes:
                self._add(vector, f"process:{value}", 3.5)
                self._add(vector, f"subject:{value}", 1.5)
            for value in signature.drivers_predictors:
                self._add(vector, f"driver:{value}", 1.5)
            for value in signature.regions:
                self._add(vector, f"region:{value}", 1.5)
            for value in signature.temporal_scales:
                self._add(vector, f"time:{value}", 1.25)
            for position, value in enumerate(signature.research_fields):
                self._add(vector, f"field:{value}", 0.75 if position == 0 else 0.35)

            tokens = list(signature.problem_tokens)
            for token in tokens:
                self._add(vector, f"word:{token}", 0.65)
            for left, right in zip(tokens, tokens[1:]):
                self._add(vector, f"bigram:{left}:{right}", 0.9)

        norms = np.linalg.norm(matrix, axis=1, keepdims=True)
        if np.any(norms == 0):
            raise ValueError("cannot embed an empty task signature")
        return matrix / norms


class SentenceTransformerEmbedding:
    name = "sentence-transformers"

    def __init__(self, model: str, revision: str | None) -> None:
        self.model_name = model
        self.revision = revision

    def encode(
        self,
        signatures: Sequence[TaskSignature],
        cards: Sequence[Mapping[str, Any]],
    ) -> np.ndarray:
        del cards
        try:
            from sentence_transformers import SentenceTransformer
        except (ImportError, OSError) as exc:
            raise RuntimeError(
                "sentence-transformers backend is unavailable; install a working CPU build "
                "or use --embedding-backend semantic-hash-v1"
            ) from exc
        model = SentenceTransformer(
            self.model_name,
            revision=self.revision,
            device="cpu",
            local_files_only=True,
        )
        embeddings = model.encode(
            [signature.compact_text() for signature in signatures],
            batch_size=64,
            show_progress_bar=False,
            convert_to_numpy=True,
            normalize_embeddings=True,
        )
        return np.asarray(embeddings, dtype=np.float32)


def make_embedding_backend(name: str, model: str, revision: str | None) -> EmbeddingBackend:
    if name == "semantic-hash-v1":
        return FrozenSemanticHashEmbedding()
    if name == "sentence-transformers":
        return SentenceTransformerEmbedding(model, revision)
    raise ValueError(f"unsupported embedding backend: {name}")


def load_eligible_pscs(path: Path = PSC_PATH) -> list[dict[str, Any]]:
    cards = sorted(
        read_jsonl(path),
        key=lambda card: (str(card.get("card_id") or ""), str(card.get("paper_id") or "")),
    )
    required = ("card_id", "paper_id", "problem", "solution_summary", "research_field")
    errors: list[str] = []
    seen_cards: set[str] = set()
    for row_number, card in enumerate(cards, start=1):
        missing = [field for field in required if not card.get(field)]
        if missing:
            errors.append(f"row {row_number}: missing {missing}")
        card_id = str(card.get("card_id") or "")
        if card_id in seen_cards:
            errors.append(f"duplicate card_id: {card_id}")
        seen_cards.add(card_id)
        if not isinstance(card.get("research_field"), Mapping):
            errors.append(f"{card_id}: research_field is not an object")
    if errors:
        raise ValueError("ineligible canonical PSC records: " + "; ".join(errors[:20]))
    return cards


def top_k_candidate_pairs(
    embeddings: np.ndarray,
    card_ids: Sequence[str],
    top_k: int,
) -> dict[tuple[int, int], float]:
    if embeddings.ndim != 2 or embeddings.shape[0] != len(card_ids):
        raise ValueError("embedding matrix does not align with PSC IDs")
    similarities = embeddings @ embeddings.T
    np.fill_diagonal(similarities, -np.inf)
    pairs: dict[tuple[int, int], float] = {}
    for left in range(len(card_ids)):
        neighbors = sorted(
            (right for right in range(len(card_ids)) if right != left),
            key=lambda right: (-float(similarities[left, right]), card_ids[right]),
        )[:top_k]
        for right in neighbors:
            pair = (left, right) if left < right else (right, left)
            pairs[pair] = float(similarities[pair[0], pair[1]])
    return pairs


def _jaccard(left: Sequence[str], right: Sequence[str]) -> float:
    left_set, right_set = set(left), set(right)
    if not left_set and not right_set:
        return 0.0
    return len(left_set & right_set) / len(left_set | right_set)


def _has_overlap(left: Sequence[str], right: Sequence[str]) -> bool:
    return bool(set(left) & set(right))


def judge_candidate_pair(
    left: TaskSignature,
    right: TaskSignature,
    similarity: float,
    candidate_threshold: float,
) -> str:
    """Classify one semantic-neighbor pair; this is never called all-pairs."""
    if similarity < candidate_threshold:
        return "different_task"

    task_overlap = _has_overlap(left.task_types, right.task_types)
    target_overlap = _has_overlap(left.target_variables, right.target_variables)
    object_overlap = _has_overlap(left.research_objects, right.research_objects)
    process_overlap = _has_overlap(left.scientific_processes, right.scientific_processes)
    field_overlap = _has_overlap(left.research_fields, right.research_fields)
    subject_overlap = target_overlap or object_overlap or process_overlap
    token_jaccard = _jaccard(left.problem_tokens, right.problem_tokens)

    region_conflict = bool(left.regions and right.regions and not _has_overlap(left.regions, right.regions))
    temporal_conflict = bool(
        left.temporal_scales
        and right.temporal_scales
        and not _has_overlap(left.temporal_scales, right.temporal_scales)
    )

    same_task = (
        task_overlap
        and subject_overlap
        and not (region_conflict and temporal_conflict)
        and (
            similarity >= 0.72
            or (similarity >= 0.61 and target_overlap and (object_overlap or process_overlap))
            or (similarity >= 0.57 and token_jaccard >= 0.34 and field_overlap)
        )
    )
    if same_task:
        return "same_task"

    related = (
        similarity >= candidate_threshold
        and (
            subject_overlap
            or (task_overlap and field_overlap)
            or token_jaccard >= 0.24
        )
    )
    return "related_but_different_task" if related else "different_task"


class DisjointSet:
    def __init__(self, size: int) -> None:
        self.parent = list(range(size))
        self.rank = [0] * size

    def find(self, value: int) -> int:
        while self.parent[value] != value:
            self.parent[value] = self.parent[self.parent[value]]
            value = self.parent[value]
        return value

    def union(self, left: int, right: int) -> None:
        left_root, right_root = self.find(left), self.find(right)
        if left_root == right_root:
            return
        if self.rank[left_root] < self.rank[right_root]:
            left_root, right_root = right_root, left_root
        self.parent[right_root] = left_root
        if self.rank[left_root] == self.rank[right_root]:
            self.rank[left_root] += 1


def cluster_confidence(
    members: Sequence[int],
    pair_labels: Mapping[tuple[int, int], str],
    pair_scores: Mapping[tuple[int, int], float],
) -> str:
    member_set = set(members)
    internal = [
        (pair_labels[pair], pair_scores[pair])
        for pair in pair_labels
        if pair[0] in member_set and pair[1] in member_set
    ]
    if len(members) == 1:
        incident_related = any(
            label == "related_but_different_task" and members[0] in pair
            for pair, label in pair_labels.items()
        )
        return "medium" if incident_related else "high"

    same_scores = [score for label, score in internal if label == "same_task"]
    possible_edges = len(members) * (len(members) - 1) / 2
    density = len(same_scores) / possible_edges if possible_edges else 1.0
    has_internal_disagreement = any(label != "same_task" for label, _ in internal)
    if not same_scores or density < 0.50 or has_internal_disagreement:
        return "low"
    if min(same_scores) >= 0.68 and density >= 0.80:
        return "high"
    return "medium"


def make_cluster_rows(
    cards: Sequence[Mapping[str, Any]],
    embeddings: np.ndarray,
    pair_labels: Mapping[tuple[int, int], str],
    pair_scores: Mapping[tuple[int, int], float],
) -> list[dict[str, Any]]:
    disjoint = DisjointSet(len(cards))
    for pair in sorted(pair_labels):
        if pair_labels[pair] == "same_task":
            disjoint.union(*pair)

    components: dict[int, list[int]] = {}
    for index in range(len(cards)):
        components.setdefault(disjoint.find(index), []).append(index)

    rows: list[dict[str, Any]] = []
    for members in components.values():
        members = sorted(members, key=lambda index: str(cards[index]["card_id"]))
        member_ids = [str(cards[index]["card_id"]) for index in members]
        source_ids = sorted({str(cards[index]["paper_id"]) for index in members})
        centroid = np.mean(embeddings[members], axis=0)
        representative = min(
            members,
            key=lambda index: (-float(embeddings[index] @ centroid), str(cards[index]["card_id"])),
        )
        rows.append(
            {
                "research_task_cluster_id": stable_id("rtc", *member_ids, length=16),
                "canonical_problem": str(cards[representative]["problem"]),
                "member_psc_ids": member_ids,
                "member_source_ids": source_ids,
                "cluster_size": len(member_ids),
                "cluster_confidence": cluster_confidence(
                    members,
                    pair_labels,
                    pair_scores,
                ),
            }
        )
    return sorted(rows, key=lambda row: str(row["research_task_cluster_id"]))


def validate_cluster_rows(
    cards: Sequence[Mapping[str, Any]],
    rows: Sequence[Mapping[str, Any]],
) -> None:
    eligible_ids = {str(card["card_id"]) for card in cards}
    source_by_card = {str(card["card_id"]): str(card["paper_id"]) for card in cards}
    flattened = [str(card_id) for row in rows for card_id in row.get("member_psc_ids") or []]
    counts: dict[str, int] = {}
    for card_id in flattened:
        counts[card_id] = counts.get(card_id, 0) + 1
    duplicate_ids = sorted(card_id for card_id, count in counts.items() if count > 1)
    missing = sorted(eligible_ids - set(flattened))
    unexpected = sorted(set(flattened) - eligible_ids)
    if duplicate_ids or missing or unexpected:
        raise ValueError(
            f"invalid PSC coverage: duplicates={duplicate_ids}, missing={missing}, unexpected={unexpected}"
        )

    cluster_ids: set[str] = set()
    for row in rows:
        cluster_id = str(row.get("research_task_cluster_id") or "")
        if not cluster_id or cluster_id in cluster_ids:
            raise ValueError(f"missing or duplicate research_task_cluster_id: {cluster_id}")
        cluster_ids.add(cluster_id)
        member_ids = [str(value) for value in row.get("member_psc_ids") or []]
        expected_sources = sorted({source_by_card[card_id] for card_id in member_ids})
        actual_sources = [str(value) for value in row.get("member_source_ids") or []]
        if actual_sources != expected_sources:
            raise ValueError(
                f"{cluster_id}: member_source_ids do not resolve from member_psc_ids"
            )
        if row.get("cluster_size") != len(member_ids):
            raise ValueError(f"{cluster_id}: cluster_size mismatch")
        if row.get("cluster_confidence") not in {"high", "medium", "low"}:
            raise ValueError(f"{cluster_id}: invalid cluster_confidence")
        expected_id = stable_id("rtc", *sorted(member_ids), length=16)
        if cluster_id != expected_id:
            raise ValueError(f"{cluster_id}: non-deterministic cluster ID")

    sorted_ids = sorted(str(row["research_task_cluster_id"]) for row in rows)
    if [str(row["research_task_cluster_id"]) for row in rows] != sorted_ids:
        raise ValueError("cluster rows are not in deterministic ID order")


def make_summary(rows: Sequence[Mapping[str, Any]]) -> dict[str, int]:
    sizes = [int(row["cluster_size"]) for row in rows]
    return {
        "cluster_count": len(rows),
        "singleton_count": sum(size == 1 for size in sizes),
        "multi_paper_cluster_count": sum(size > 1 for size in sizes),
        "largest_cluster_size": max(sizes, default=0),
        "low_confidence_cluster_count": sum(
            row.get("cluster_confidence") == "low" for row in rows
        ),
    }


def build(
    *,
    embedding_backend: str = DEFAULT_EMBEDDING_BACKEND,
    embedding_model: str = DEFAULT_SENTENCE_TRANSFORMER_MODEL,
    embedding_revision: str | None = DEFAULT_SENTENCE_TRANSFORMER_REVISION,
    top_k: int = DEFAULT_TOP_K,
    candidate_threshold: float = DEFAULT_CANDIDATE_THRESHOLD,
) -> dict[str, int]:
    if top_k < 1:
        raise ValueError("top_k must be positive")
    cards = load_eligible_pscs()
    signatures = [build_task_signature(card) for card in cards]
    backend = make_embedding_backend(embedding_backend, embedding_model, embedding_revision)
    embeddings = backend.encode(signatures, cards)
    card_ids = [str(card["card_id"]) for card in cards]
    pair_scores = top_k_candidate_pairs(embeddings, card_ids, min(top_k, len(cards) - 1))
    pair_labels = {
        pair: judge_candidate_pair(
            signatures[pair[0]],
            signatures[pair[1]],
            score,
            candidate_threshold,
        )
        for pair, score in sorted(pair_scores.items())
    }
    if set(pair_labels.values()) - PAIR_LABELS:
        raise AssertionError("pair judge returned an unsupported label")

    rows = make_cluster_rows(cards, embeddings, pair_labels, pair_scores)
    validate_cluster_rows(cards, rows)
    summary = make_summary(rows)
    write_jsonl(CLUSTERS_PATH, rows)
    write_json(SUMMARY_PATH, summary)
    return summary


def validate_only() -> dict[str, int]:
    cards = load_eligible_pscs()
    rows = read_jsonl(CLUSTERS_PATH)
    validate_cluster_rows(cards, rows)
    expected_summary = make_summary(rows)
    actual_summary = json.loads(SUMMARY_PATH.read_text(encoding="utf-8"))
    if actual_summary != expected_summary:
        raise ValueError("task_cluster_summary.json does not match cluster rows")
    return expected_summary


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Build Phase 1 ResearchTaskCluster from ProblemSolutionCard only."
    )
    parser.add_argument(
        "--embedding-backend",
        choices=("semantic-hash-v1", "sentence-transformers"),
        default=DEFAULT_EMBEDDING_BACKEND,
    )
    parser.add_argument("--embedding-model", default=DEFAULT_SENTENCE_TRANSFORMER_MODEL)
    parser.add_argument("--embedding-revision", default=DEFAULT_SENTENCE_TRANSFORMER_REVISION)
    parser.add_argument("--top-k", type=int, default=DEFAULT_TOP_K)
    parser.add_argument("--candidate-threshold", type=float, default=DEFAULT_CANDIDATE_THRESHOLD)
    parser.add_argument("--validate-only", action="store_true")
    args = parser.parse_args()

    if args.validate_only:
        result = validate_only()
        print("RESEARCH_TASK_CLUSTER_VALIDATION_PASS")
    else:
        result = build(
            embedding_backend=args.embedding_backend,
            embedding_model=args.embedding_model,
            embedding_revision=args.embedding_revision or None,
            top_k=args.top_k,
            candidate_threshold=args.candidate_threshold,
        )
        print("RESEARCH_TASK_CLUSTER_BUILD_COMPLETE")
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))


if __name__ == "__main__":
    main()
