"""Controlled OceanAgentBench baseline runners."""

