"""Export only query IDs and text; keep evaluation labels out of model input."""
from pathlib import Path
import argparse
import json


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--split", choices=("train", "dev", "test"), required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    source = Path(__file__).resolve().parent / "knowledge_snapshot/benchmark/splits" / (args.split + ".jsonl")
    target = args.output.expanduser().resolve()
    if target == source.resolve():
        parser.error("Output must not overwrite the frozen split")
    target.parent.mkdir(parents=True, exist_ok=True)
    with source.open(encoding="utf-8") as read, target.open("x", encoding="utf-8") as write:
        for line in read:
            if not line.strip():
                continue
            row = json.loads(line)
            write.write(json.dumps({"query_id": row["query_id"], "query": row["query"]}, ensure_ascii=False) + "\n")


if __name__ == "__main__":
    main()
