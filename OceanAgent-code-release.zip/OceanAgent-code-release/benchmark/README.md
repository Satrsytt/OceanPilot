# OceanAgentBench retrieval data

This directory supplies the knowledge cards, dataset candidates, query splits,
retrieval labels, and requirement/route annotations used by the code release.
The scientific-method knowledge in the cards remains available to OceanAgent.
The package is a filtered export of the historical working snapshot. It does
not claim that every historical artifact is distributed or unchanged.

## Included data

| Item | Count |
|---|---:|
| ProblemSolutionCards / UsageBundleCards | 648 / 648 |
| DatasetCards / corpus entries | 2,260 / 2,260 |
| Eligible source tasks / query variants | 544 / 1,088 |
| Train source tasks / queries | 381 / 762 |
| Dev source tasks / queries | 54 / 108 |
| Test source tasks / queries | 109 / 218 |
| Dev tasks / queries with requirement and route annotations | 51 / 102 |

The source-group split assignments and random seed 42 are retained. Each
eligible task has two query variants. The 104 remaining ProblemSolutionCards
are auxiliary knowledge. Cards, corpus, dataset labels, and requirement/route
annotations retain their source bytes. Split rows retain query text, IDs,
source assignments, dataset labels, and retrieval metadata. The current export
removes unrelated assessment fields from those rows and from summary metadata.

`release_data_manifest.json` fingerprints the actual distributed files and
identifies unchanged files and release projections. Its prior-source hashes
document transformations; they are not expected to match projected release
bytes. `knowledge_snapshot/snapshot_manifest.json` and the source inventory
describe the current retained retrieval inputs.

The 544-task population is the one used by the released retrieval experiments.
The older Ocean-RAG working build with 543 tasks and 2,254 corpus entries is
not substituted. Original task membership is retained rather than regenerated
under a new eligibility rule.

## Integrity checks and model inputs

From the repository root:

```sh
python3.11 benchmark/verify_release.py
python3.11 benchmark/export_queries.py --split dev --output reproduced/dev_queries.jsonl
```

The verifier checks release fingerprints and sizes, unique IDs, corpus/card
agreement, label coverage, source separation, bibliography references, and
requirement/route dataset references. It uses the standard library and makes
no model calls. These are structural checks, not independent scientific
validation of the annotations.

The query exporter writes only `query_id` and `query` and refuses to overwrite
an existing output. Split and gold rows contain answer labels and source
evidence; use the label-free export as model input. The public input contract
is in `schemas/query_input.schema.json`.

For the retained E1 retrieval methods, `experiments/paper_e1/scripts/retrieval.py`
blocks both Dev and Test source PSC/UBC records while keeping all DatasetCards
available. The retained leakage report is a historical Train-plus-Dev test-view
audit; the current E1 source policy applies independently to both cohorts.
Use the experiment configuration and retrieval implementation for actual runs.

## Historical retrieval dependency

The retained E1 retrieval source reuses functions from an original baseline
module whose Python source was not recovered. Its CPython 3.11 artifact remains
under `legacy/benchmark/baselines/__pycache__/`, with the unchanged SHA-256:

```text
542dcf8cb901386be4ecf0c7ac2d7a6d62207e1f2b5d998ddf2a32924fe37fc5
```

`legacy/artifact_manifest.json` records this explicit binary dependency. It is
not an incidental cache, and it requires CPython 3.11. The original module is
not fully inspectable as source; the loader is not a reconstructed algorithm.
The source `legacy/benchmark/common.py` uses the shared release snapshot by
default; `OCEANAGENT_KNOWLEDGE_ROOT` can override that root.

The standard-library lexical smoke path is:

```sh
python3.11 benchmark/legacy/run_artifact.py baseline --method bm25 --split dev --output reproduced/bm25_dev.jsonl
```

Use the retained retrieval evaluation source under `experiments/` to score
rankings. Current methods and fresh inference use the experiment sources and
configuration rather than the historical runner's other interfaces. Dense
retrieval requires separately obtained embedding weights; model-based methods
require the configured provider credentials. No credential is distributed.

## Construction and annotation scope

`build/` retains the retrieval task population, query candidates, query
instances, and research-task clusters. `build_research_task_clusters.py` is
the original cluster-construction source and requires NumPy; its optional
embedding backend also needs sentence-transformers. Work on a copy when
running it because it writes cluster artifacts in place. The former combined
benchmark builder is outside this filtered export; this directory is intended
to consume the supplied retrieval labels rather than regenerate the full
historical working benchmark.

The Dev requirement/route files preserve their recorded annotation status and
notes. Those fields alone do not establish independent expert agreement or
complete scientific validity. No new annotations are inferred for missing
tasks or splits.

## Sources and external data

`manifest/paper_titles.jsonl` and `papers.jsonl` provide the original 3,599-paper
bibliography, including sources outside the eligible retrieval tasks. The
card evidence retains source paper IDs, published metadata, and recorded
excerpts or provider links. Publication PDFs, full-paper extraction caches,
large observation datasets, and model weights are not included.

Obtain external publications and datasets from the recorded sources under
their own access and license terms. Unresolved URLs, versions, and license
fields remain unresolved. No blanket permission for third-party materials is
implied. Scientific-method statements and measurements quoted from source
papers remain source knowledge rather than new OceanAgent evaluation data.
