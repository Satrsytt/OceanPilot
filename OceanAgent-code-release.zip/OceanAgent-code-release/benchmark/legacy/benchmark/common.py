from __future__ import annotations

import hashlib
import http.client
import json
import math
import os
import re
import socket
import statistics
import urllib.error
import urllib.request
from collections import Counter, deque
from pathlib import Path
from typing import Any, Iterable, Iterator, Mapping, Sequence


ROOT = Path(os.environ.get("OCEANAGENT_KNOWLEDGE_ROOT", str(Path(__file__).resolve().parents[2] / "knowledge_snapshot"))).expanduser().resolve()
BENCHMARK_ROOT = ROOT / "benchmark"
DEFAULT_CONFIG = BENCHMARK_ROOT / "benchmark_config.yaml"

UNKNOWN_TOKENS = {
    "",
    "unknown",
    "unresolved",
    "not_reported",
    "not reported",
    "not_applicable",
    "not applicable",
    "none",
    "null",
}


def read_config(path: Path = DEFAULT_CONFIG) -> dict[str, Any]:
    """Read the JSON-compatible YAML config without requiring PyYAML."""
    return json.loads(path.read_text(encoding="utf-8"))


def read_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def iter_jsonl(path: Path) -> Iterator[dict[str, Any]]:
    with path.open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, start=1):
            if not line.strip():
                continue
            try:
                value = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(f"invalid JSONL at {path}:{line_number}: {exc}") from exc
            if not isinstance(value, dict):
                raise ValueError(f"JSONL row is not an object at {path}:{line_number}")
            yield value


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    return list(iter_jsonl(path))


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)


def write_jsonl(path: Path, rows: Iterable[Mapping[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", encoding="utf-8", newline="\n") as handle:
        for row in rows:
            handle.write(json.dumps(dict(row), ensure_ascii=False, sort_keys=True) + "\n")
    temporary.replace(path)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def stable_hash(value: str, seed: int = 0) -> str:
    return hashlib.sha256(f"{seed}:{value}".encode("utf-8")).hexdigest()


def stable_id(prefix: str, *parts: str, length: int = 16) -> str:
    value = "\x1f".join(parts)
    return f"{prefix}_{hashlib.sha256(value.encode('utf-8')).hexdigest()[:length]}"


def is_known(value: Any) -> bool:
    if value is None:
        return False
    if isinstance(value, str):
        return value.strip().casefold() not in UNKNOWN_TOKENS
    if isinstance(value, (list, tuple, set)):
        return any(is_known(item) for item in value)
    if isinstance(value, dict):
        return any(is_known(item) for item in value.values())
    return True


def valid_evidence(items: Any, source_id: str | None = None) -> list[dict[str, Any]]:
    values = items if isinstance(items, list) else [items]
    return [
        item
        for item in values
        if isinstance(item, dict)
        and all(isinstance(item.get(key), str) and item[key].strip() for key in ("source_id", "page_or_section", "quote"))
        and (source_id is None or item.get("source_id") == source_id)
    ]


def evidence_ref(item: Mapping[str, Any]) -> dict[str, Any]:
    result = {
        "source_id": item.get("source_id"),
        "page_or_section": item.get("page_or_section"),
        "quote": item.get("quote"),
    }
    for key in ("url", "accessed_at"):
        if item.get(key) is not None:
            result[key] = item[key]
    return result


def dedupe_dicts(items: Iterable[Mapping[str, Any]]) -> list[dict[str, Any]]:
    found: dict[str, dict[str, Any]] = {}
    for item in items:
        value = dict(item)
        found.setdefault(json.dumps(value, ensure_ascii=False, sort_keys=True), value)
    return list(found.values())






def safe_distribution(values: Iterable[Any]) -> dict[str, int]:
    return dict(sorted(Counter(str(value) for value in values).items()))


def numeric_summary(values: Sequence[float | int]) -> dict[str, float | int | None]:
    if not values:
        return {"count": 0, "min": None, "max": None, "mean": None, "median": None}
    return {
        "count": len(values),
        "min": min(values),
        "max": max(values),
        "mean": sum(values) / len(values),
        "median": statistics.median(values),
    }






def mean(values: Sequence[float]) -> float:
    return sum(values) / len(values) if values else 0.0


def openai_compatible_json(
    *,
    base_url: str,
    api_key: str,
    model: str,
    messages: list[dict[str, str]],
    temperature: float,
    schema_name: str,
    schema: dict[str, Any],
    timeout: int = 180,
) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any]]:
    """Call an OpenAI-compatible chat endpoint and return one schema-shaped JSON object.

    Provider compatibility notes:
    - Some OpenAI-compatible providers accept ``json_schema`` but do not enforce
      ``strict`` semantics and may still wrap JSON in Markdown code fences.
    - To keep benchmark behavior provider-neutral, request JSON mode, put the
      exact schema contract in the system prompt, parse common fenced-JSON
      variants locally, and reject outputs that do not satisfy the top-level
      schema contract.
    - Do not silently rename provider-specific fields into benchmark fields:
      doing so would alter the evaluated model output and compromise baseline
      comparability.
    """

    schema_text = json.dumps(schema, ensure_ascii=False, sort_keys=True)
    output_contract = (
        "\n\nOUTPUT CONTRACT (mandatory):\n"
        f"Return exactly one JSON object conforming to the JSON Schema named {schema_name!r}.\n"
        "Return JSON only. Do not use Markdown code fences. Do not add prose before or after JSON.\n"
        "Use the schema field names exactly as written. Do not invent aliases or alternative top-level fields.\n"
        "If a value is unknown, use only a representation permitted by the schema.\n"
        f"JSON Schema:\n{schema_text}"
    )

    # Inject the contract into the first system message when one exists so the
    # provider receives the output constraint at system priority.
    request_messages = [dict(item) for item in messages]
    system_index = next(
        (index for index, item in enumerate(request_messages) if item.get("role") == "system"),
        None,
    )
    if system_index is None:
        request_messages.insert(0, {"role": "system", "content": output_contract.strip()})
    else:
        original = str(request_messages[system_index].get("content") or "")
        request_messages[system_index]["content"] = original.rstrip() + output_contract

    request_body = {
        "model": model,
        "temperature": temperature,
        "messages": request_messages,
        # ``json_object`` is more consistently implemented across
        # OpenAI-compatible providers than strict ``json_schema`` mode.
        # The exact benchmark schema is enforced locally below.
        "response_format": {"type": "json_object"},
    }

    request = urllib.request.Request(
        f"{base_url.rstrip('/')}/chat/completions",
        data=json.dumps(request_body, ensure_ascii=False).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        method="POST",
    )

    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            raw = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        if exc.code in {408, 409, 425, 429, 500, 502, 503, 504}:
            raise RuntimeError(
                f"transient API HTTP {exc.code}: {detail[:1000]}"
            ) from exc
        raise RuntimeError(
            f"judge/query API HTTP {exc.code}: {detail[:1000]}"
        ) from exc
    except (
        urllib.error.URLError,
        http.client.RemoteDisconnected,
        TimeoutError,
        socket.timeout,
        ConnectionResetError,
        ConnectionAbortedError,
        BrokenPipeError,
    ) as exc:
        raise RuntimeError(f"transient API connection error: {exc}") from exc

    try:
        content = raw["choices"][0]["message"]["content"]
    except (KeyError, IndexError, TypeError) as exc:
        raise RuntimeError(
            "judge/query API returned an unexpected response shape: "
            + json.dumps(raw, ensure_ascii=False)[:2000]
        ) from exc

    if os.environ.get("OCEAN_BENCH_DEBUG_LLM") == "1":
        print("DEBUG RAW RESPONSE:")
        print(json.dumps(raw, ensure_ascii=False, indent=2))
        print("DEBUG CONTENT:")
        print(repr(content))

    if isinstance(content, dict):
        parsed = content
    else:
        text = str(content or "").strip()
        if not text:
            raise RuntimeError(
                "judge/query API returned empty message.content: "
                + json.dumps(raw, ensure_ascii=False)[:2000]
            )

        # Common provider behavior:
        #   ```json
        #   {...}
        #   ```
        fenced = re.fullmatch(
            r"\s*```(?:json)?\s*(.*?)\s*```\s*",
            text,
            flags=re.IGNORECASE | re.DOTALL,
        )
        if fenced:
            text = fenced.group(1).strip()

        try:
            parsed = json.loads(text)
        except json.JSONDecodeError as first_exc:
            # Conservative fallback for providers that prepend/append a short
            # explanatory sentence despite JSON-mode instructions.
            first_object = text.find("{")
            last_object = text.rfind("}")
            if first_object >= 0 and last_object > first_object:
                candidate = text[first_object : last_object + 1].strip()
                try:
                    parsed = json.loads(candidate)
                except json.JSONDecodeError:
                    raise RuntimeError(
                        "judge/query API returned invalid JSON. "
                        f"content_prefix={text[:2000]!r}"
                    ) from first_exc
            else:
                raise RuntimeError(
                    "judge/query API returned invalid JSON. "
                    f"content_prefix={text[:2000]!r}"
                ) from first_exc

    if not isinstance(parsed, dict):
        raise RuntimeError(
            f"judge/query API must return a JSON object for {schema_name}; "
            f"got {type(parsed).__name__}"
        )

    # Enforce the most important JSON-Schema constraints locally without adding
    # a new runtime dependency. This prevents downstream KeyError failures and,
    # more importantly, prevents silently accepting a provider-specific schema.
    required = [str(key) for key in schema.get("required") or []]
    missing = [key for key in required if key not in parsed]
    if missing:
        raise RuntimeError(
            f"model output does not conform to {schema_name}: "
            f"missing required top-level fields {missing}; "
            f"returned fields={sorted(parsed)}"
        )

    properties = schema.get("properties") or {}
    if schema.get("additionalProperties") is False:
        extras = sorted(set(parsed) - set(properties))
        if extras:
            raise RuntimeError(
                f"model output does not conform to {schema_name}: "
                f"unexpected top-level fields {extras}"
            )

    def _matches_json_type(value: Any, expected: Any) -> bool:
        if isinstance(expected, list):
            return any(_matches_json_type(value, item) for item in expected)
        if expected == "object":
            return isinstance(value, dict)
        if expected == "array":
            return isinstance(value, list)
        if expected == "string":
            return isinstance(value, str)
        if expected == "integer":
            return isinstance(value, int) and not isinstance(value, bool)
        if expected == "number":
            return isinstance(value, (int, float)) and not isinstance(value, bool)
        if expected == "boolean":
            return isinstance(value, bool)
        if expected == "null":
            return value is None
        return True

    type_errors: list[str] = []
    for key, property_schema in properties.items():
        if key not in parsed or not isinstance(property_schema, dict):
            continue
        expected_type = property_schema.get("type")
        if expected_type is not None and not _matches_json_type(parsed[key], expected_type):
            type_errors.append(
                f"{key}: expected {expected_type!r}, got {type(parsed[key]).__name__}"
            )
    if type_errors:
        raise RuntimeError(
            f"model output does not conform to {schema_name}: "
            + "; ".join(type_errors)
        )

    return parsed, request_body, raw


def resolve_model_config(config: Mapping[str, Any], section: str) -> dict[str, Any]:
    block = dict(config[section])
    return {
        "model": os.environ.get(block["model_env"], block["default_model"]),
        "base_url": os.environ.get(block["base_url_env"], block["default_base_url"]),
        "api_key": os.environ.get(block["api_key_env"], ""),
        "temperature": float(block.get("temperature", 0.0)),
        "prompt_version": block["prompt_version"],
    }


def jsonable_text(value: Any) -> str:
    if isinstance(value, str):
        return value
    return json.dumps(value, ensure_ascii=False, sort_keys=True)


def ceil_ratio(total: int, ratio: float) -> int:
    return int(math.ceil(total * ratio))


def require_source_snapshot_current(
    benchmark_root: Path = BENCHMARK_ROOT,
    repository_root: Path = ROOT,
) -> dict[str, Any]:
    """Block evaluation when frozen Benchmark artifacts no longer match canonical Cards.

    Several runtime/baseline paths read ``ROOT/cards`` directly.  If cards have
    changed after ``benchmark/`` was built, mixing a stale split/corpus with new
    PSC/UBC content silently invalidates the experiment.  The build already
    records SHA-256 fingerprints in ``source_inventory.json``; enforce them here.
    """
    inventory_path = benchmark_root / "source_inventory.json"
    if not inventory_path.is_file():
        raise RuntimeError(
            f"formal evaluation blocked: missing source inventory {inventory_path}"
        )
    inventory = read_json(inventory_path)
    canonical_paths = {
        "cards/problem_solution_cards.jsonl",
        "cards/usage_bundle_cards.jsonl",
        "cards/dataset_cards.jsonl",
    }
    checked: list[dict[str, Any]] = []
    mismatches: list[dict[str, Any]] = []
    for item in inventory.get("sources") or []:
        relative_path = str(item.get("path") or "").replace("\\", "/")
        if relative_path not in canonical_paths:
            continue
        expected = str(item.get("sha256") or "")
        path = repository_root / Path(relative_path)
        actual = sha256_file(path) if path.is_file() else None
        record = {
            "path": relative_path,
            "expected_sha256": expected or None,
            "actual_sha256": actual,
            "exists": path.is_file(),
            "matches": bool(expected) and actual == expected,
        }
        checked.append(record)
        if not record["matches"]:
            mismatches.append(record)
    if len(checked) != len(canonical_paths):
        found = {item["path"] for item in checked}
        missing_inventory_entries = sorted(canonical_paths - found)
        raise RuntimeError(
            "formal evaluation blocked: source_inventory.json does not contain "
            f"all canonical Card fingerprints: {missing_inventory_entries}"
        )
    if mismatches:
        detail = "; ".join(
            f"{item['path']} expected={item['expected_sha256']} actual={item['actual_sha256']}"
            for item in mismatches
        )
        raise RuntimeError(
            "formal evaluation blocked: Benchmark snapshot is stale relative to "
            f"current canonical Cards. Rebuild benchmark before evaluation. {detail}"
        )
    return {"status": "pass", "checked": checked}


def require_leakage_pass(benchmark_root: Path = BENCHMARK_ROOT) -> dict[str, Any]:
    # Leakage PASS is meaningful only for the exact source snapshot on which it
    # was generated.  Enforce snapshot identity before accepting the audit.
    require_source_snapshot_current(benchmark_root=benchmark_root, repository_root=ROOT)
    path = benchmark_root / "reports" / "leakage_audit.json"
    if not path.is_file():
        raise RuntimeError(f"formal evaluation blocked: missing leakage audit {path}")
    report = read_json(path)
    if report.get("status") != "pass" or not all((report.get("checks") or {}).values()):
        raise RuntimeError("formal evaluation blocked: leakage audit is not PASS")
    return report
