"""Execute the retained CPython 3.11 retrieval baseline bytecode.

Its original Python source was not recovered. This is a release loader, not
reconstructed source. Use the current experiment sources for fresh inference;
the supported historical smoke path here is the lexical retrieval baseline.
"""
from pathlib import Path
import argparse
import importlib.machinery
import sys


ARTIFACTS = {
    "baseline": "baselines/run_baseline",
}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("artifact", choices=ARTIFACTS)
    args = parser.parse_args(sys.argv[1:2])
    remaining = sys.argv[2:]
    if sys.version_info[:2] != (3, 11):
        parser.error("The frozen artifacts require CPython 3.11")
    root = Path(__file__).resolve().parent
    relative = Path(ARTIFACTS[args.artifact])
    target = root / "benchmark" / relative.parent / "__pycache__" / (relative.name + ".cpython-311.pyc")
    sys.path.insert(0, str(root))
    sys.argv = [str(target), *remaining]
    code = importlib.machinery.SourcelessFileLoader("__main__", str(target)).get_code("__main__")
    namespace = {"__name__": "__main__", "__package__": None,
                 "__file__": str(root / "benchmark" / relative.with_suffix(".py"))}
    exec(code, namespace)


if __name__ == "__main__":
    main()
