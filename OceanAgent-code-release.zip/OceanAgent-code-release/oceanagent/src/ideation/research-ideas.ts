import { randomUUID } from "node:crypto";
import type { RuntimeTaskSpec } from "../rag/retrieval-decision.js";
import type { ExternalLiterature, IdeaCriterion, IdeationMode, IdeationResult, LiteratureEvidence,
  ResearchIdea, UserPaper } from "./types.js";

const VARIABLES: Array<{ variable: string; pattern: RegExp }> = [
  { variable: "sea surface temperature", pattern: /\b(?:SST|sea surface temperature)\b|海表温度|海温/i },
  { variable: "chlorophyll-a", pattern: /\b(?:chlorophyll[- ]?a|chl[- ]?a)\b|叶绿素/i },
  { variable: "salinity", pattern: /\b(?:salinity|sea surface salinity)\b|盐度/i },
  { variable: "sea ice concentration", pattern: /\b(?:sea ice concentration|SIC)\b|海冰密集度/i },
  { variable: "sea level", pattern: /\b(?:sea level|SSH)\b|海平面/i },
  { variable: "wind speed", pattern: /\b(?:wind speed|surface wind)\b|风速/i },
  { variable: "ocean current", pattern: /\b(?:ocean current|surface current)\b|海流/i },
];

function score(status: IdeaCriterion["status"], reason: string, uncertainty: string): IdeaCriterion {
  return { status, reason, uncertainty };
}

function theme(papers: UserPaper[]): string {
  return papers.map((paper) => paper.title).filter(Boolean).slice(0, 3).join("；") || "上传论文的研究主题待核实";
}

function chosenEvidence(papers: UserPaper[]): LiteratureEvidence[] {
  return papers.flatMap((paper) => {
    const preferred = paper.evidence.filter((item) => ["abstract", "method", "data", "limitation"].includes(item.section));
    return (preferred.length ? preferred : paper.evidence).slice(0, 4);
  });
}

function requirements(objective: string, papers: UserPaper[]): RuntimeTaskSpec["requirements"] {
  const text = `${objective} ${papers.map((paper) => `${paper.title ?? ""} ${paper.abstract ?? ""} ${paper.evidence
    .filter((item) => item.section === "data").map((item) => item.text).join(" ")}`).join(" ")}`;
  const years = objective.match(/\b((?:19|20)\d{2})\s*[-–—至到]\s*((?:19|20)\d{2})\b/);
  const temporal = years ? `${years[1]}-${years[2]}` : undefined;
  const spatial = /南海|South China Sea/i.test(objective) ? "South China Sea"
    : /北太平洋|North Pacific/i.test(objective) ? "North Pacific"
      : /全球|global/i.test(objective) ? "global" : undefined;
  return VARIABLES.filter((item) => item.pattern.test(text))
    .sort((left, right) => {
      const first = left.pattern.exec(objective)?.index ?? Number.POSITIVE_INFINITY;
      const second = right.pattern.exec(objective)?.index ?? Number.POSITIVE_INFINITY;
      return first === second ? 0 : first - second;
    })
    .slice(0, 4).map((item, index) => ({
    id: `idea_variable_${index + 1}`, variable: item.variable,
    role: index === 0 ? "target" as const : "predictor" as const, essential: true,
    ...(temporal ? { temporal } : {}), ...(spatial ? { spatial } : {}),
  }));
}

function methodDescription(papers: UserPaper[]): string {
  const found = papers.flatMap((paper) => paper.evidence.filter((item) => item.section === "method")
    .slice(0, 1).map((item) => `${paper.title ?? paper.filename}（第 ${item.page} 页）`));
  return found.length ? `以 ${found.join("、")} 所报告的方法为参考，设计对照与稳健性验证；具体算法参数仍须核对原文。`
    : "以论文摘要支持的研究问题为起点，先核对方法正文，再设计对照与稳健性验证。";
}

function comparePapers(papers: UserPaper[], externalCount: number): string {
  const observations = papers.map((paper) => {
    const method = paper.evidence.find((item) => item.section === "method");
    const data = paper.evidence.find((item) => item.section === "data");
    const limitation = paper.evidence.find((item) => item.section === "limitation");
    return `${paper.title ?? paper.filename}：${method ? `方法见第 ${method.page} 页` : "方法未可靠定位"}，`
      + `${data ? `数据见第 ${data.page} 页` : "数据未可靠定位"}，`
      + `${limitation ? `作者陈述的限制见第 ${limitation.page} 页` : "限制未可靠定位"}`;
  });
  return `${observations.join("；")}。${papers.length > 1
    ? "可比较这些已定位片段中的方法和数据差异；尚无足够证据断定结果冲突或方法优劣。"
    : "仅有一篇上传论文，无法作跨论文方法比较。"}`
    + (externalCount ? `另核验 ${externalCount} 条扩展文献的 DOI 元数据，尚未核对全文方法。` : "");
}

function buildIdea(mode: IdeationMode, conversationId: string, objective: string,
  papers: UserPaper[], external: ExternalLiterature[]): ResearchIdea | null {
  const evidence = chosenEvidence(papers);
  if (!evidence.length) return null;
  if (mode !== "L2") {
    const goalVariables = new Set(requirements(objective, []).map((item) => item.variable));
    const paperVariables = new Set(requirements("", papers).map((item) => item.variable));
    if (goalVariables.size && paperVariables.size
      && ![...goalVariables].some((variable) => paperVariables.has(variable))) return null;
  }
  const data = requirements(objective, papers);
  const support = papers.map((paper) => ({ paperId: paper.id,
    evidenceRefs: evidence.filter((item) => item.paperId === paper.id).map((item) => item.id) }));
  const limitations = papers.flatMap((paper) => paper.evidence.filter((item) => item.section === "limitation")
    .slice(0, 1).map((item) => `论文明确陈述的限制：${paper.title ?? paper.filename} 第 ${item.page} 页：${item.text}`));
  if (!limitations.length) limitations.push("论文限制未能可靠定位；不能据此声称发现新的研究空白。");
  if (mode === "L3" && !external.length) limitations.push("扩展文献未获得可核验记录，不能作广泛新颖性结论。");
  const topic = objective || theme(papers);
  const methodsWithEvidence = papers.filter((paper) => paper.evidence.some((item) => item.section === "method"));
  const comparative = methodsWithEvidence.length >= 2;
  const question = mode === "L1" ? objective
    : comparative
      ? `在“${topic}”主题下，两篇论文所报告方法在可比数据条件下的结论与适用范围有何差异？`
      : `在“${topic}”主题下，论文方法与数据条件变化时，哪些结论保持稳健？`;
  const taskSpec: RuntimeTaskSpec = { researchGoal: question, requirements: data };
  const hasData = data.length > 0;
  const evidenceRefs = [...evidence.map((item) => item.id), ...external.map((item) => item.url)];
  return {
    ideaId: randomUUID(), conversationId, mode,
    title: mode === "L1" ? `目标引导：${objective.slice(0, 70)}`
      : `${comparative ? "跨论文方法比较" : "论文方法稳健性"}：${topic.slice(0, 60)}`,
    researchQuestion: question,
    claimProvenance: { researchQuestion: mode === "L1" ? "user_goal" : "system_inference",
      scientificHypothesis: "system_inference", relatedWorkComparison: "system_inference",
      researchGapHypothesis: "system_inference" },
    scientificHypothesis: comparative
      ? `待验证推断：在可比数据和验证指标下，两篇论文报告的方法对“${topic}”的估计可能有可解释差异；方法是否实质不同及差异方向均未知。`
      : `待验证推断：若论文所述方法适用于该问题，则在独立数据检查与对照分析后，${topic} 的主要结论应具备可复核性。`,
    supportingLiterature: support,
    relatedWorkComparison: comparePapers(papers, external.length),
    researchGapHypothesis: "研究空白仅为待检验假设：需核对上传论文是否已充分验证不同数据条件下的稳健性；不代表全球文献未研究。",
    expectedContribution: "若通过后续文献和实验核验，可给出可复核的对照结果与适用范围。仅更换区域或数据集不视为重大创新。",
    essentialDataRequirements: data,
    proposedMethod: methodDescription(papers),
    feasibilityAssessment: {
      scientificPlausibility: score("partial", "研究问题与上传论文主题和可定位片段相关。", "假设需要专家及实验核验。"),
      dataFeasibility: score(hasData ? "uncertain" : "blocked", hasData
        ? `识别 ${data.length} 项候选必要变量；尚未通过 P1 Dataset Bundle 核验。`
        : "论文与目标未给出足够明确的数据变量。", "数据覆盖、分辨率和实际可用性待核验。"),
      methodFeasibility: score(papers.some((paper) => paper.evidence.some((item) => item.section === "method")) ? "partial" : "uncertain",
        "论文方法片段可定位，但尚未完成工具绑定和 DAG 验证。", "算法细节及参数需要查阅原文。"),
      literatureSupport: score(papers.length > 1 || external.length > 0 ? "partial" : "uncertain",
        `有 ${papers.length} 篇上传论文${external.length ? `及 ${external.length} 条核验外部元数据` : ""}。`,
        "文献覆盖有限；外部元数据不等于全文支持。"),
      potentialNovelty: score("uncertain", "尚未完成全面相关工作检索，不能给出客观创新概率或全球首创结论。",
        "论文作者已指出的限制及换区域/换数据本身不算原创发现。"),
      expectedResearchValue: score("uncertain", "可检验方法适用范围与结论稳健性。", "价值依赖实际数据、对照设计和结果。"),
      executionCost: score("uncertain", "需要数据获取、预处理、对照分析和验证。", "数据量与计算时间尚未估计。"),
    },
    expectedArtifacts: ["来源可追溯的研究设计", "对照分析结果", "科学验证报告"],
    evidenceRefs, limitations, taskSpec,
    planStatus: hasData ? "ready_for_planning" : "needs_data_or_clarification",
    createdAt: new Date().toISOString(),
  };
}

function clusters(papers: UserPaper[]): UserPaper[][] {
  if (papers.length <= 2) return [papers];
  const words = (paper: UserPaper) => new Set((paper.title ?? "").toLowerCase().match(/[a-z]{4,}/g) ?? []);
  const groups: UserPaper[][] = [];
  for (const paper of papers) {
    const tokens = words(paper);
    const matched = groups.find((group) => {
      const first = words(group[0]!);
      return [...tokens].some((token) => first.has(token));
    });
    if (matched) matched.push(paper);
    else groups.push([paper]);
  }
  return groups.slice(0, 3);
}

export function generateIdeas(conversationId: string, mode: IdeationMode, objective: string,
  papers: UserPaper[], external: ExternalLiterature[], externalSearchStatus: IdeationResult["externalSearchStatus"],
  externalSearchReason?: string): IdeationResult {
  if (mode === "L1" && !objective.trim()) throw new Error("L1 需要填写研究目标或初步 Idea");
  if (mode === "L3" && !objective.trim()) throw new Error("L3 需要研究 Prompt 以限定联网检索范围");
  const valid = papers.filter((paper) => paper.status === "parsed" && paper.evidence.length);
  if (!valid.length) throw new Error("没有可解析且具有页码证据的用户论文");
  const goalVariables = new Set(requirements(objective, []).map((item) => item.variable));
  const relevant = mode === "L2" ? valid : valid.filter((paper) => {
    const paperVariables = requirements("", [paper]).map((item) => item.variable);
    return !goalVariables.size || !paperVariables.length
      || paperVariables.some((variable) => goalVariables.has(variable));
  });
  const excluded = valid.filter((paper) => !relevant.includes(paper));
  const groups = mode === "L2" ? clusters(valid) : [relevant];
  const ideas = groups.map((group) => buildIdea(mode, conversationId, objective.trim(), group, external))
    .filter((idea): idea is ResearchIdea => idea !== null);
  const unique = new Map<string, ResearchIdea>();
  for (const idea of ideas) {
    const key = `${idea.researchQuestion.toLowerCase()}|${idea.essentialDataRequirements.map((item) => item.variable).sort().join("|")}`;
    if (!unique.has(key)) unique.set(key, idea);
  }
  const gaps = [
    ...papers.filter((paper) => paper.status === "failed").map((paper) => `${paper.filename}: ${paper.failureReason}`),
    ...excluded.map((paper) => `${paper.title ?? paper.filename}: 已识别变量与研究目标不一致，未作为该 Idea 的支持文献。`),
    ...(!ideas.length ? ["论文证据不足，或研究目标与论文中已识别的必要变量不一致；无法形成有依据的 Idea。"] : []),
    ...(mode === "L3" && externalSearchStatus !== "verified" ? [externalSearchReason ?? "扩展文献未核验成功。"] : []),
  ];
  return { mode, objective: objective.trim() || undefined, papers, externalLiterature: external,
    externalSearchStatus, externalSearchReason,
    themeSummary: `${theme(valid)}。${comparePapers(valid, external.length)}`,
    ideas: [...unique.values()],
    gaps, createdAt: new Date().toISOString() };
}
