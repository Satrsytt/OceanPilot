import { execFile } from "node:child_process";
import { createHash, randomUUID } from "node:crypto";
import { open, mkdir, readFile, rename, rm, writeFile } from "node:fs/promises";
import { basename, isAbsolute, relative, resolve } from "node:path";
import { promisify } from "node:util";
import type { IdeationResult, LiteratureEvidence, UserPaper } from "./types.js";

const execute = promisify(execFile);
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

interface PdfExtraction {
  title?: string;
  authors?: string[];
  year?: number;
  doi?: string;
  abstract?: string;
  pageCount?: number;
  evidence?: Array<{ page: number; section: LiteratureEvidence["section"]; text: string }>;
  uncertainties?: string[];
  error?: string;
}

function normalized(value: string | undefined): string {
  return (value ?? "").normalize("NFKC").toLowerCase().replace(/[^\p{L}\p{N}]+/gu, " ").trim();
}

function understanding(evidence: LiteratureEvidence[]): UserPaper["understanding"] {
  const cited = (section: LiteratureEvidence["section"]) => evidence.filter((item) => item.section === section)
    .slice(0, 3).map((item) => ({ text: item.text, evidenceRef: item.id, kind: "paper_explicit" as const }));
  const dataProducts = evidence.filter((item) => item.section === "data")
    .flatMap((item) => [...item.text.matchAll(/\b(?:OISST|ERA5|MODIS|AVHRR|GHRSST|CMEMS|GLORYS|Argo|GLODAP|SOCAT|PACE|SMAP|NSIDC)\b/gi)]
      .map((match) => ({ name: match[0], evidenceRef: item.id, kind: "paper_explicit" as const })));
  const distinctProducts = [...new Map(dataProducts.map((item) => [item.name.toLowerCase(), item])).values()];
  return { researchGoals: cited("abstract"), methods: cited("method"), dataProducts: distinctProducts,
    limitations: cited("limitation"),
    openQuestions: evidence.filter((item) => item.section === "limitation"
      && /future work|further research|remain(?:s)? (?:unknown|unclear)|open question/i.test(item.text))
      .slice(0, 3).map((item) => ({ text: item.text, evidenceRef: item.id, kind: "paper_explicit" as const })) };
}

export class UserLiteratureWorkspace {
  constructor(private readonly root: string, private readonly parserCode: string,
    private readonly parserScript: string,
    private readonly pythonPath = process.env.OCEAN_PYTHON_PATH ?? "python") {}

  directory(conversationId: string): string {
    if (!UUID.test(conversationId)) throw new Error("会话 ID 无效");
    return resolve(this.root, conversationId);
  }

  async list(conversationId: string): Promise<UserPaper[]> {
    try {
      return JSON.parse(await readFile(resolve(this.directory(conversationId), "papers.json"), "utf8")) as UserPaper[];
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === "ENOENT") return [];
      throw error;
    }
  }

  async latestIdeas(conversationId: string): Promise<IdeationResult | null> {
    try {
      return JSON.parse(await readFile(resolve(this.directory(conversationId), "ideas.json"), "utf8")) as IdeationResult;
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === "ENOENT") return null;
      throw error;
    }
  }

  async saveIdeas(conversationId: string, result: IdeationResult): Promise<void> {
    const directory = this.directory(conversationId);
    await mkdir(directory, { recursive: true });
    const temporary = resolve(directory, `ideas-${randomUUID()}.partial`);
    await writeFile(temporary, JSON.stringify(result), "utf8");
    await rename(temporary, resolve(directory, "ideas.json"));
  }

  async ingest(conversationId: string, temporaryPath: string, filename: string): Promise<{ paper: UserPaper; duplicate: boolean }> {
    const directory = this.directory(conversationId);
    if (filename !== basename(filename) || !/\.pdf$/i.test(filename)) throw new Error("只接受 PDF 文件");
    await mkdir(directory, { recursive: true });
    const uploadRelative = relative(directory, resolve(temporaryPath));
    if (!uploadRelative || uploadRelative.startsWith("..") || isAbsolute(uploadRelative)) {
      throw new Error("PDF 上传临时文件必须位于当前会话论文工作空间");
    }
    const handle = await open(temporaryPath, "r");
    const header = Buffer.alloc(5);
    try { await handle.read(header, 0, 5, 0); } finally { await handle.close(); }
    if (header.toString("ascii") !== "%PDF-") throw new Error("文件头不是有效 PDF");
    const sha256 = createHash("sha256").update(await readFile(temporaryPath)).digest("hex");
    const existing = await this.list(conversationId);
    const sameHash = existing.find((paper) => paper.sha256 === sha256);
    if (sameHash?.status === "parsed") {
      await rm(temporaryPath, { force: true }); return { paper: sameHash, duplicate: true };
    }
    if (existing.length >= 20 && !sameHash) throw new Error("单个论文工作空间最多保留 20 篇 PDF");
    let extracted: PdfExtraction;
    try {
      const { stdout } = await execute(this.pythonPath, [this.parserScript, temporaryPath, this.parserCode], {
        timeout: 90_000, maxBuffer: 3 * 1024 * 1024, windowsHide: true,
      });
      extracted = JSON.parse(stdout) as PdfExtraction;
    } catch (error) {
      extracted = { error: `本地 PDF 解析失败：${error instanceof Error ? error.message : String(error)}` };
    }
    const located = (extracted.evidence ?? []).filter((item) => Number.isInteger(item.page)
      && item.page > 0 && item.page <= (extracted.pageCount ?? 0)
      && typeof item.text === "string" && item.text.trim().length >= 20);
    if (!extracted.error && (!extracted.pageCount || !located.length)) {
      extracted = { error: "PDF 解析输出缺少页码或可定位正文片段" };
    }
    const samePublication = existing.find((paper) => paper.status === "parsed" && (
      extracted.doi && paper.doi === extracted.doi
      || extracted.title && normalized(paper.title) === normalized(extracted.title) && normalized(extracted.title).length >= 15));
    if (samePublication) { await rm(temporaryPath, { force: true }); return { paper: samePublication, duplicate: true }; }
    if (sameHash && extracted.error) {
      await rm(temporaryPath, { force: true });
      return { paper: sameHash, duplicate: true };
    }
    const id = sameHash?.id ?? randomUUID();
    if (sameHash) await rm(resolve(directory, `${id}.pdf`), { force: true });
    await rename(temporaryPath, resolve(directory, `${id}.pdf`));
    const evidence: LiteratureEvidence[] = located.map((item, index) => ({
      id: `${id}:p${item.page}:e${index + 1}`, paperId: id, page: item.page,
      section: item.section, text: item.text, kind: "paper_explicit",
    }));
    const paper: UserPaper = {
      id, conversationId, filename, sha256, status: extracted.error ? "failed" : "parsed",
      ...(extracted.error ? { failureReason: extracted.error } : {}),
      title: extracted.title, authors: extracted.authors ?? [], year: extracted.year,
      doi: extracted.doi, abstract: extracted.abstract, pageCount: extracted.pageCount,
      evidence, understanding: understanding(evidence),
      uncertainties: extracted.uncertainties ?? [], uploadedAt: new Date().toISOString(),
    };
    const temporaryIndex = resolve(directory, `papers-${randomUUID()}.partial`);
    await writeFile(temporaryIndex, JSON.stringify([...existing.filter((item) => item.id !== id), paper]), "utf8");
    await rename(temporaryIndex, resolve(directory, "papers.json"));
    await rm(resolve(directory, "ideas.json"), { force: true });
    return { paper, duplicate: false };
  }

  async remove(conversationId: string): Promise<void> {
    const root = resolve(this.root);
    const target = this.directory(conversationId);
    if (relative(root, target) !== conversationId) throw new Error("论文工作空间路径超出预期目录");
    await rm(target, { recursive: true, force: true });
  }
}
