import { describe, expect, it } from "vitest";
import { generateIdeas } from "./research-ideas.js";
import type { UserPaper } from "./types.js";

function paper(id: string, title: string, text = "Sea surface temperature observations support analysis of seasonal variability."): UserPaper {
  return { id, conversationId: "conversation", filename: `${id}.pdf`, sha256: id,
    status: "parsed", title, authors: ["Test Author"], year: 2020, doi: `10.1234/${id}`,
    abstract: text, pageCount: 4, uploadedAt: "2026-10-26T00:00:00Z", uncertainties: [],
    understanding: { researchGoals: [], methods: [], dataProducts: [], limitations: [], openQuestions: [] },
    evidence: [
      { id: `${id}:p1:e1`, paperId: id, page: 1, section: "abstract", text, kind: "paper_explicit" },
      { id: `${id}:p2:e2`, paperId: id, page: 2, section: "method",
        text: "We estimate a regression model using SST observations.", kind: "paper_explicit" },
    ] };
}

describe("offline, evidence-bounded ideation", () => {
  it("keeps L1 aligned to the user's goal and produces P1 TaskSpec requirements", () => {
    const result = generateIdeas("conversation", "L1", "研究海表温度长期变化", [paper("a", "SST trends")], [], "not_requested");
    expect(result.ideas).toHaveLength(1);
    expect(result.ideas[0]?.researchQuestion).toBe("研究海表温度长期变化");
    expect(result.ideas[0]?.taskSpec.requirements[0]?.variable).toBe("sea surface temperature");
    expect(result.ideas[0]?.evidenceRefs).toContain("a:p1:e1");
    expect(result.ideas[0]?.feasibilityAssessment.potentialNovelty.status).toBe("uncertain");
  });

  it("filters an L1 goal whose identified variable is absent from the uploaded paper", () => {
    const result = generateIdeas("conversation", "L1", "研究叶绿素反演", [paper("a", "SST trends")], [], "not_requested");
    expect(result.ideas).toHaveLength(0);
    expect(result.gaps.join(" ")).toContain("不一致");
  });

  it("explores L2 from multiple papers without claiming a verified conflict or novelty", () => {
    const result = generateIdeas("conversation", "L2", "", [
      paper("a", "SST trends"), paper("b", "SST anomaly methods"),
    ], [], "not_requested");
    expect(result.ideas.length).toBeGreaterThan(0);
    expect(result.themeSummary).toContain("第 2 页");
    expect(result.ideas[0]?.researchGapHypothesis).toContain("待检验假设");
  });

  it("keeps L3 external metadata separate from full-text scientific support", () => {
    const result = generateIdeas("conversation", "L3", "SST variability", [paper("a", "SST trends")], [
      { id: "doi:10.5678/b", doi: "10.5678/b", title: "SST methods", url: "https://doi.org/10.5678/b",
        authors: [], source: "crossref" },
    ], "verified");
    expect(result.ideas[0]?.evidenceRefs).toContain("https://doi.org/10.5678/b");
    expect(result.ideas[0]?.feasibilityAssessment.potentialNovelty.status).toBe("uncertain");
  });

  it("marks an Idea without identifiable data requirements as not ready for Plan", () => {
    const result = generateIdeas("conversation", "L2", "", [paper("a", "A conceptual framework",
      "A conceptual framework for scientific reasoning and uncertainty.")], [], "not_requested");
    expect(result.ideas[0]?.planStatus).toBe("needs_data_or_clarification");
  });

  it("reports failed papers instead of using them as evidence", () => {
    const broken: UserPaper = { ...paper("bad", "Unreadable"), status: "failed", evidence: [],
      failureReason: "scan quality too low" };
    const result = generateIdeas("conversation", "L1", "SST trend", [paper("a", "SST trends"), broken], [], "not_requested");
    expect(result.gaps.join(" ")).toContain("scan quality too low");
    expect(result.ideas[0]?.supportingLiterature.some((item) => item.paperId === "bad")).toBe(false);
  });
});
