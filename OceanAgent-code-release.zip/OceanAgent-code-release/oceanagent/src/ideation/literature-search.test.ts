import { afterEach, describe, expect, it, vi } from "vitest";
import type { OfficialWebSearch } from "../web-search.js";
import { searchVerifiedLiterature } from "./literature-search.js";

const originalFetch = globalThis.fetch;
afterEach(() => { globalThis.fetch = originalFetch; });

describe("L3 offline literature metadata validation", () => {
  it("deduplicates DOI results after Crossref verification", async () => {
    const search = { search: async () => [
      { title: "Paper", url: "https://doi.org/10.1234/example", snippet: "" },
      { title: "Same paper", url: "https://doi.org/10.1234/example", snippet: "" },
    ] } as unknown as OfficialWebSearch;
    globalThis.fetch = vi.fn(async () => ({ ok: true, json: async () => ({ message: {
      DOI: "10.1234/example", title: ["Verified paper"], author: [], published: { "date-parts": [[2022]] },
    } }) })) as unknown as typeof fetch;
    const result = await searchVerifiedLiterature(search, "ocean SST");
    expect(result.items).toHaveLength(1);
    expect(result.items[0]?.title).toBe("Verified paper");
  });

  it("blocks an unverified DOI and reports search failure without creating citations", async () => {
    const search = { search: async () => [
      { title: "Claim", url: "https://doi.org/10.1234/fake", snippet: "" },
    ] } as unknown as OfficialWebSearch;
    globalThis.fetch = vi.fn(async () => ({ ok: true, json: async () => ({ message: {
      DOI: "10.1234/different", title: ["Unrelated"],
    } }) })) as unknown as typeof fetch;
    expect((await searchVerifiedLiterature(search, "SST")).items).toHaveLength(0);
    const failed = await searchVerifiedLiterature({ search: async () => { throw new Error("offline"); } } as unknown as OfficialWebSearch, "SST");
    expect(failed.status).toBe("failed");
    expect(failed.items).toHaveLength(0);
  });
});
