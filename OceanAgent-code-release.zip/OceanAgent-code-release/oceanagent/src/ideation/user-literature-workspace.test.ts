import { afterEach, describe, expect, it } from "vitest";
import { mkdir, mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { basename, relative, resolve } from "node:path";
import { UserLiteratureWorkspace } from "./user-literature-workspace.js";

const folders: string[] = [];
afterEach(async () => {
  for (const folder of folders.splice(0)) {
    const target = resolve(folder);
    if (relative(resolve(tmpdir()), target).startsWith("..") || !basename(target).startsWith("ocean-idea-")) {
      throw new Error("测试清理路径超出专用临时目录");
    }
    await rm(target, { recursive: true, force: true });
  }
});

async function fixture(error?: string) {
  const root = await mkdtemp(resolve(tmpdir(), "ocean-idea-"));
  folders.push(root);
  const script = resolve(root, "mock-parser.cjs");
  const output = error ? { error } : { title: "Ocean SST Study", authors: ["A. Author"], year: 2020,
    doi: "10.1234/sst", abstract: "Sea surface temperature variation in the ocean.", pageCount: 3,
    evidence: [{ page: 1, section: "abstract", text: "Sea surface temperature variation in the ocean." }],
    uncertainties: [] };
  await writeFile(script, `process.stdout.write(${JSON.stringify(JSON.stringify(output))})`);
  return { root, script, workspace: new UserLiteratureWorkspace(resolve(root, "library"), root, script, process.execPath) };
}

const conversationA = "11111111-1111-4111-8111-111111111111";
const conversationB = "22222222-2222-4222-8222-222222222222";

describe("isolated user literature workspace with offline parser mock", () => {
  it("deduplicates PDFs and keeps other conversations isolated", async () => {
    const { workspace } = await fixture();
    const directory = workspace.directory(conversationA);
    await mkdir(directory, { recursive: true });
    const one = resolve(directory, "one.partial");
    const copy = resolve(directory, "copy.partial");
    await writeFile(one, "%PDF-1.4\nmock paper");
    await writeFile(copy, "%PDF-1.4\nmock paper");
    const first = await workspace.ingest(conversationA, one, "one.pdf");
    const duplicate = await workspace.ingest(conversationA, copy, "copy.pdf");
    expect(first.paper.status).toBe("parsed");
    expect(duplicate.duplicate).toBe(true);
    expect(duplicate.paper.id).toBe(first.paper.id);
    expect(await workspace.list(conversationB)).toHaveLength(0);
    expect((await readFile(resolve(workspace.directory(conversationA), "papers.json"), "utf8"))).toContain("Ocean SST Study");
    await workspace.remove(conversationA);
    expect(await workspace.list(conversationA)).toHaveLength(0);
  });

  it("records parser failure and blocks non-PDF content", async () => {
    const { workspace, script } = await fixture("scan quality too low");
    const directory = workspace.directory(conversationA);
    await mkdir(directory, { recursive: true });
    const broken = resolve(directory, "broken.partial");
    await writeFile(broken, "%PDF-1.4\nscan");
    const result = await workspace.ingest(conversationA, broken, "broken.pdf");
    expect(result.paper.status).toBe("failed");
    expect(result.paper.failureReason).toContain("scan quality");
    await writeFile(script, `process.stdout.write(${JSON.stringify(JSON.stringify({
      title: "Recovered paper", pageCount: 2,
      evidence: [{ page: 1, section: "abstract", text: "A recovered ocean paper." }],
    }))})`);
    const retry = resolve(directory, "retry.partial");
    await writeFile(retry, "%PDF-1.4\nscan");
    expect((await workspace.ingest(conversationA, retry, "broken.pdf")).paper.status).toBe("parsed");
    expect(await workspace.list(conversationA)).toHaveLength(1);
    const invalid = resolve(directory, "invalid.partial");
    await writeFile(invalid, "not a PDF");
    await expect(workspace.ingest(conversationA, invalid, "invalid.pdf")).rejects.toThrow("文件头");
  });
});
