import type { RuntimeTaskSpec } from "../rag/retrieval-decision.js";

export type IdeationMode = "L1" | "L2" | "L3";
export type EvidenceKind = "paper_explicit" | "system_inference" | "external_verified";

export interface LiteratureEvidence {
  id: string;
  paperId: string;
  page: number;
  section: "abstract" | "method" | "data" | "result" | "limitation" | "other";
  text: string;
  kind: "paper_explicit";
}

export interface UserPaper {
  id: string;
  conversationId: string;
  filename: string;
  sha256: string;
  status: "parsed" | "failed";
  failureReason?: string;
  title?: string;
  authors: string[];
  year?: number;
  doi?: string;
  abstract?: string;
  pageCount?: number;
  evidence: LiteratureEvidence[];
  understanding: {
    researchGoals: Array<{ text: string; evidenceRef: string; kind: "paper_explicit" }>;
    methods: Array<{ text: string; evidenceRef: string; kind: "paper_explicit" }>;
    dataProducts: Array<{ name: string; evidenceRef: string; kind: "paper_explicit" }>;
    limitations: Array<{ text: string; evidenceRef: string; kind: "paper_explicit" }>;
    openQuestions: Array<{ text: string; evidenceRef: string; kind: "paper_explicit" }>;
  };
  uncertainties: string[];
  uploadedAt: string;
}

export interface ExternalLiterature {
  id: string;
  title: string;
  doi: string;
  url: string;
  year?: number;
  authors: string[];
  source: "crossref";
}

export interface IdeaCriterion {
  status: "supported" | "partial" | "uncertain" | "blocked";
  reason: string;
  uncertainty: string;
}

export interface ResearchIdea {
  ideaId: string;
  conversationId: string;
  mode: IdeationMode;
  title: string;
  researchQuestion: string;
  scientificHypothesis: string;
  claimProvenance: {
    researchQuestion: "user_goal" | "system_inference";
    scientificHypothesis: "system_inference";
    relatedWorkComparison: "system_inference";
    researchGapHypothesis: "system_inference";
  };
  supportingLiterature: Array<{ paperId: string; evidenceRefs: string[] }>;
  relatedWorkComparison: string;
  researchGapHypothesis: string;
  expectedContribution: string;
  essentialDataRequirements: RuntimeTaskSpec["requirements"];
  proposedMethod: string;
  feasibilityAssessment: Record<"scientificPlausibility" | "dataFeasibility" | "methodFeasibility"
    | "literatureSupport" | "potentialNovelty" | "expectedResearchValue" | "executionCost", IdeaCriterion>;
  expectedArtifacts: string[];
  evidenceRefs: string[];
  limitations: string[];
  taskSpec: RuntimeTaskSpec;
  planStatus: "ready_for_planning" | "needs_data_or_clarification";
  createdAt: string;
}

export interface IdeationResult {
  mode: IdeationMode;
  objective?: string;
  papers: UserPaper[];
  externalLiterature: ExternalLiterature[];
  externalSearchStatus: "not_requested" | "verified" | "failed" | "no_verified_results";
  externalSearchReason?: string;
  themeSummary: string;
  ideas: ResearchIdea[];
  gaps: string[];
  createdAt: string;
}
