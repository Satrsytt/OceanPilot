import type { OfficialWebSearch } from "../web-search.js";
import type { ExternalLiterature } from "./types.js";

function doiFrom(value: string): string | null {
  let decoded: string;
  try { decoded = decodeURIComponent(value); } catch { decoded = value; }
  const match = decoded.match(/\b10\.\d{4,9}\/[-._;()/:A-Z0-9]+/i);
  return match ? match[0].replace(/[.,;)]+$/, "").toLowerCase() : null;
}

export async function searchVerifiedLiterature(search: OfficialWebSearch, query: string): Promise<{
  items: ExternalLiterature[]; status: "verified" | "failed" | "no_verified_results"; reason?: string;
}> {
  let hits;
  try {
    hits = await search.search(query, ["crossref.org", "doi.org"], 8);
  } catch (error) {
    return { items: [], status: "failed", reason: `联网文献发现失败：${error instanceof Error ? error.message : String(error)}` };
  }
  const dois = [...new Set(hits.map((hit) => doiFrom(`${hit.url} ${hit.title} ${hit.snippet}`))
    .filter((doi): doi is string => doi !== null))].slice(0, 6);
  const results = await Promise.allSettled(dois.map(async (doi): Promise<ExternalLiterature | null> => {
    const response = await fetch(`https://api.crossref.org/works/${encodeURIComponent(doi)}`, {
      signal: AbortSignal.timeout(12_000), headers: { "User-Agent": "OceanAgent/0.1 (literature metadata verification)" },
    });
    if (!response.ok) return null;
    const payload = await response.json() as { message?: {
      DOI?: string; title?: string[]; author?: Array<{ given?: string; family?: string }>;
      published?: { "date-parts"?: number[][] }; URL?: string; type?: string;
    } };
    const record = payload.message;
    const verifiedDoi = record?.DOI?.toLowerCase();
    const title = record?.title?.[0]?.trim();
    if (!record || verifiedDoi !== doi || !title
      || (record.type && !["journal-article", "proceedings-article", "posted-content", "book-chapter"].includes(record.type))) return null;
    return { id: `doi:${doi}`, title, doi, url: `https://doi.org/${doi}`,
      year: record?.published?.["date-parts"]?.[0]?.[0],
      authors: (record?.author ?? []).slice(0, 12).map((person) => [person.given, person.family].filter(Boolean).join(" ")),
      source: "crossref" };
  }));
  const records = results.flatMap((result) => result.status === "fulfilled" && result.value ? [result.value] : []);
  const seenTitles = new Set<string>();
  const items = records.filter((item) => {
    const key = item.title.normalize("NFKC").toLowerCase().replace(/[^\p{L}\p{N}]+/gu, " ").trim();
    if (seenTitles.has(key)) return false;
    seenTitles.add(key);
    return true;
  });
  return items.length ? { items, status: "verified" }
    : { items: [], status: "no_verified_results", reason: "搜索结果中没有可经 Crossref DOI 元数据核验的文献；未加入任何外部引用。" };
}
