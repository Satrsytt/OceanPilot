"""Self-contained offline adapter for section-aware PDF text extraction.

This script reads a user PDF only. It never invokes the knowledge-base extraction
runner, models, publication tools, embedded PDF actions, or a network endpoint.
"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

try:
    import pymupdf as fitz
except ImportError:
    import fitz


def extract_pdf_text(pdf_path: Path, max_chars: int) -> tuple[str, int]:
    """Extract a bounded, section-aware PDF view instead of only a prefix.

    Short papers retain every page.  For long papers the budget preserves the
    title/abstract, method/data/result pages, and the final pages where data and
    code availability commonly appear.  Selected pages remain in source order
    so evidence locators and continuous quote matching stay deterministic.
    """
    page_blocks: list[tuple[int, str, int]] = []
    section_terms = re.compile(
        r"\b(methods?|materials?|data(?:\s+availability)?|datasets?|"
        r"experiments?|results?|validation|evaluation|appendix|supplementary|"
        r"code\s+availability)\b",
        flags=re.IGNORECASE,
    )
    with fitz.open(pdf_path) as document:
        page_count = len(document)
        for page_index, page in enumerate(document, start=1):
            text = page.get_text("text") or ""
            if not text.strip():
                continue
            block = f"\n\n[PAGE {page_index}]\n{text.strip()}"
            score = len(section_terms.findall(text[:5000]))
            page_blocks.append((page_index, block, score))

    if sum(len(block) for _, block, _ in page_blocks) <= max_chars:
        return "".join(block for _, block, _ in page_blocks), page_count

    priority: list[int] = []
    available = {page_index for page_index, _, _ in page_blocks}
    for page_index in [1, 2, 3, page_count - 1, page_count]:
        if page_index in available and page_index not in priority:
            priority.append(page_index)
    for page_index, _, _ in sorted(
        page_blocks, key=lambda item: (-item[2], item[0])
    ):
        if page_index not in priority:
            priority.append(page_index)
    selected: dict[int, str] = {}
    used = 0
    for page_index in priority:
        block = next(value for number, value, _ in page_blocks if number == page_index)
        if used + len(block) <= max_chars:
            selected[page_index] = block
            used += len(block)
            continue
        remaining = max_chars - used
        if remaining >= 1200 and page_index <= 3:
            selected[page_index] = block[:remaining]
            used += remaining
        if used >= max_chars:
            break
    omitted = sorted(available - set(selected))
    marker = (
        "\n\n[PDF_SECTION_AWARE_TRUNCATION omitted_pages="
        + ",".join(map(str, omitted))
        + "]"
    )
    return "".join(selected[index] for index in sorted(selected)) + marker, page_count


def main() -> None:
    pdf_path = Path(sys.argv[1]).resolve()
    # Existing callers may pass a second KB-code argument. It is no longer
    # needed: this release retains the original extractor locally without loading
    # the unpublished API extraction pipeline or any provider configuration.

    text, page_count = extract_pdf_text(pdf_path, 40000)
    if len(re.sub(r"\s+", "", text)) < 500:
        raise RuntimeError("PDF 可提取文本不足；可能为扫描件、缺页或加密文件")
    printable = re.sub(r"\s+", "", text)
    if sum(char.isalpha() for char in printable) < 200:
        raise RuntimeError("PDF 文本质量不足，无法可靠识别论文内容")
    with fitz.open(pdf_path) as document:
        metadata = document.metadata or {}
        if document.is_encrypted:
            raise RuntimeError("PDF 已加密，无法可靠解析")
    pages = re.split(r"\[PAGE (\d+)\]", text)
    first_page = pages[2] if len(pages) > 2 else ""
    header = " ".join(first_page.splitlines()[:12])
    title = str(metadata.get("title") or "").strip()
    if not title or title.lower() in {"untitled", "microsoft word", "article"}:
        title = next((line.strip() for line in first_page.splitlines()[:10]
                      if len(line.strip()) > 20 and not re.search(r"abstract|doi|journal|copyright", line, re.I)), "")
    doi_match = re.search(r"\b10\.\d{4,9}/[-._;()/:A-Z0-9]+", first_page[:7000], re.I)
    doi = doi_match.group(0).rstrip(".,;)").lower() if doi_match else None
    year_match = re.search(r"\b(?:19|20)\d{2}\b", header)
    year = int(year_match.group(0)) if year_match else None
    author_text = str(metadata.get("author") or "").strip()
    authors = [part.strip() for part in re.split(r"[;,]", author_text) if part.strip()]
    abstract_match = re.search(r"\babstract\b\s*[:.\-]?\s*(.{100,2500}?)(?=\b(?:keywords?|introduction)\b|\[PAGE|$)",
                               text[:7000], re.I | re.S)
    abstract = " ".join(abstract_match.group(1).split())[:1800] if abstract_match else None
    abstract_pages = re.findall(r"\[PAGE (\d+)\]", text[:abstract_match.start()]) if abstract_match else []
    abstract_page = int(abstract_pages[-1]) if abstract_pages else 1
    patterns = {
        "method": re.compile(r"\b(method|algorithm|model|approach|procedure|regression|simulation)\b", re.I),
        "data": re.compile(r"\b(dataset|data source|observation|satellite|reanalysis|SST|chlorophyll|salinity)\b", re.I),
        "result": re.compile(r"\b(result|finding|performance|accuracy|uncertainty)\b", re.I),
        "limitation": re.compile(r"\b(limitation|limited by|future work|caveat|bias|uncertain)\b", re.I),
    }
    evidence: list[dict[str, object]] = []
    if abstract:
        evidence.append({"page": abstract_page, "section": "abstract", "text": abstract[:600]})
    for index in range(1, len(pages) - 1, 2):
        page = int(pages[index])
        page_text = pages[index + 1]
        clean = " ".join(page_text.split())
        if not clean:
            continue
        for section, pattern in patterns.items():
            match = pattern.search(clean)
            if not match:
                continue
            start = max(0, match.start() - 110)
            snippet = clean[start:min(len(clean), match.end() + 390)].strip()
            if len(snippet) >= 60 and not any(item["page"] == page and item["section"] == section for item in evidence):
                evidence.append({"page": page, "section": section, "text": snippet})
        if len(evidence) >= 24:
            break
    if not evidence:
        raise RuntimeError("PDF 未提取到可定位的摘要或研究片段")
    uncertainty = ["题名、作者、发表年份、DOI 与章节片段由本地规则或 PDF 元数据识别，需核对原文"]
    if not title:
        uncertainty.append("题名未能可靠识别")
    if not authors:
        uncertainty.append("作者未能从 PDF 元数据可靠识别")
    if not year:
        uncertainty.append("发表年份未能从首页可靠识别")
    if not doi:
        uncertainty.append("DOI 未能从首页可靠识别")
    if not abstract:
        uncertainty.append("摘要未能可靠定位")
    if "PDF_SECTION_AWARE_TRUNCATION" in text:
        uncertainty.append("长论文只读取了按章节挑选的页面，部分页面未纳入分析")
    if page_count < 2:
        uncertainty.append("PDF 只有一页；可能不是完整论文")
    print(json.dumps({"title": title or None, "authors": authors, "year": year, "doi": doi,
                      "abstract": abstract, "pageCount": page_count, "evidence": evidence,
                      "uncertainties": uncertainty}, ensure_ascii=False))


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(json.dumps({"error": str(exc)}, ensure_ascii=False))
