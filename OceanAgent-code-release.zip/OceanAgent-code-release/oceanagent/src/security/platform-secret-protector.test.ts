import { mkdtemp, readFile, rm, stat, unlink } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { afterEach, describe, expect, it, vi } from "vitest";
import { OceanDatabase } from "../db/database.js";
import { ModelSettingsRepository } from "../db/model-settings-repository.js";
import { CredentialUnavailableError, LocalSecretProtector } from "./platform-secret-protector.js";

const roots: string[] = [];
async function root() { const dir = await mkdtemp(join(tmpdir(), "ocean-mac-secret-")); roots.push(dir); return dir; }
afterEach(async () => { for (const dir of roots.splice(0)) await rm(dir, { recursive: true, force: true }); vi.restoreAllMocks(); });

describe.skipIf(process.platform === "win32")("local credential protection", () => {
  it("round-trips concurrent saves across restart with private key permissions", async () => {
    const dir = await root(), protector = new LocalSecretProtector(dir);
    const secrets = ["smoke-only-test-key", "another-smoke-only-key"];
    const sealed = await Promise.all(secrets.map(secret => protector.protect(secret)));
    const restarted = new LocalSecretProtector(dir);
    expect(await Promise.all(sealed.map(cipher => restarted.unprotect(cipher)))).toEqual(secrets);
    expect(sealed.join(" ")).not.toContain(secrets[0]);
    expect((await stat(protector.keyPath)).mode & 0o777).toBe(0o600);
    expect((await stat(protector.keyDirectory)).mode & 0o777).toBe(0o700);
    expect((await readFile(protector.keyPath)).length).toBe(32);
  });

  it("rejects migrated Windows credentials, tampering and missing local master keys", async () => {
    const protector = new LocalSecretProtector(await root());
    await expect(protector.unprotect("legacy-windows-dpapi-blob")).rejects.toThrow(/Windows.*Mac/);
    const sealed = await protector.protect("smoke-only-secret");
    const bytes = Buffer.from(sealed.slice("ocean-local-v1:".length), "base64"); bytes[bytes.length - 1]! ^= 1;
    await expect(protector.unprotect("ocean-local-v1:" + bytes.toString("base64"))).rejects.toBeInstanceOf(CredentialUnavailableError);
    await unlink(protector.keyPath);
    await expect(protector.unprotect(sealed)).rejects.toThrow(/密钥缺失/);
  });

  it("keeps migrated ciphertext for backup while requiring re-entry and permitting replacement", async () => {
    vi.spyOn(console, "warn").mockImplementation(() => {});
    const database = new OceanDatabase(":memory:");
    try {
      const repository = new ModelSettingsRepository(database, new LocalSecretProtector(await root()));
      await repository.saveProvider("deepseek", ["deepseek-chat"], "new-mac-test-key");
      database.raw.prepare("UPDATE model_provider_settings SET secret_ciphertext=? WHERE provider_id=?")
        .run("legacy-dpapi-blob", "deepseek");
      expect(await repository.getApiKey("deepseek")).toBeNull();
      expect(repository.getProvider("deepseek")?.hasSavedCredential).toBe(false);
      expect((database.raw.prepare("SELECT secret_ciphertext FROM model_provider_settings").get() as {secret_ciphertext: string}).secret_ciphertext).toBe("legacy-dpapi-blob");
      await repository.saveProvider("deepseek", ["deepseek-chat"], "replacement-mac-test-key");
      expect(repository.getProvider("deepseek")?.hasSavedCredential).toBe(true);
      expect(await repository.getApiKey("deepseek")).toBe("replacement-mac-test-key");
    } finally { database.close(); }
  });
});
