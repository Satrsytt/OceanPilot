import { createCipheriv, createDecipheriv, randomBytes } from "node:crypto";
import { constants } from "node:fs";
import { chmod, lstat, mkdir, open } from "node:fs/promises";
import { join } from "node:path";
import { DpapiSecretProtector, type SecretProtector } from "./dpapi-secret-protector.js";

const PREFIX = "ocean-local-v1:";
const AAD = Buffer.from("OceanAgent/local-credentials/v1");

/** Safe to display: never includes the ciphertext or supplied credential. */
export class CredentialUnavailableError extends Error {
  readonly code = "CREDENTIAL_REENTRY_REQUIRED";
  constructor(message = "此凭据无法在当前电脑解密，请在设置中重新填写 API Key 或重新连接 SSH。") {
    super(message); this.name = "CredentialUnavailableError";
  }
}

/**
 * Non-Windows local-at-rest protection. The random master key is kept outside
 * SQLite in a private directory. This is file-permission protection, not an OS
 * Keychain: a process running as this user can read the master key.
 */
export class LocalSecretProtector implements SecretProtector {
  readonly keyDirectory: string;
  readonly keyPath: string;
  private keyPreparation?: Promise<void>;
  constructor(rootDir: string) {
    this.keyDirectory = join(rootDir, "data", ".credentials");
    this.keyPath = join(this.keyDirectory, "master.key");
  }

  private async prepareKey(): Promise<void> {
      await mkdir(this.keyDirectory, { recursive: true, mode: 0o700 });
      const directory = await lstat(this.keyDirectory);
      if (!directory.isDirectory() || directory.isSymbolicLink()) throw new CredentialUnavailableError("本机凭据目录必须是实际目录，不能是符号链接。");
      await chmod(this.keyDirectory, 0o700);
      try {
        const file = await open(this.keyPath, constants.O_WRONLY | constants.O_CREAT | constants.O_EXCL, 0o600);
        try { await file.writeFile(randomBytes(32)); await file.sync(); } finally { await file.close(); }
      } catch (error) {
        if ((error as NodeJS.ErrnoException).code !== "EEXIST") throw error;
      }
  }

  private async masterKey(create: boolean): Promise<Buffer> {
    if (create) {
      this.keyPreparation ??= this.prepareKey().catch((error) => { this.keyPreparation = undefined; throw error; });
      await this.keyPreparation;
    }
    let file;
    try { file = await open(this.keyPath, constants.O_RDONLY | constants.O_NOFOLLOW); }
    catch { throw new CredentialUnavailableError("本机加密密钥缺失或无法读取；不能从 Windows DPAPI 恢复，请在设置中重新填写凭据。"); }
    try {
      const info = await file.stat();
      if (!info.isFile() || info.size !== 32 || typeof process.getuid === "function" && info.uid !== process.getuid()) {
        throw new CredentialUnavailableError("本机加密密钥文件无效，请恢复原密钥或重新填写凭据。");
      }
      if ((info.mode & 0o077) !== 0) await file.chmod(0o600);
      return await file.readFile();
    } finally { await file.close(); }
  }

  async protect(secret: string): Promise<string> {
    const key = await this.masterKey(true);
    try {
      const iv = randomBytes(12), cipher = createCipheriv("aes-256-gcm", key, iv);
      cipher.setAAD(AAD);
      const encrypted = Buffer.concat([cipher.update(secret, "utf8"), cipher.final()]);
      return PREFIX + Buffer.concat([iv, cipher.getAuthTag(), encrypted]).toString("base64");
    } finally { key.fill(0); }
  }

  async unprotect(ciphertext: string): Promise<string> {
    if (!ciphertext.startsWith(PREFIX)) {
      throw new CredentialUnavailableError("从 Windows 迁移的 DPAPI 凭据不能在 Mac 解密，请在设置中重新填写 API Key 或重新连接 SSH。");
    }
    const key = await this.masterKey(false);
    try {
      const bytes = Buffer.from(ciphertext.slice(PREFIX.length), "base64");
      if (bytes.length < 28) throw new CredentialUnavailableError();
      const decipher = createDecipheriv("aes-256-gcm", key, bytes.subarray(0, 12));
      decipher.setAAD(AAD); decipher.setAuthTag(bytes.subarray(12, 28));
      return Buffer.concat([decipher.update(bytes.subarray(28)), decipher.final()]).toString("utf8");
    } catch { throw new CredentialUnavailableError(); }
    finally { key.fill(0); }
  }
}

export function createSecretProtector(rootDir: string): SecretProtector {
  return process.platform === "win32" ? new DpapiSecretProtector() : new LocalSecretProtector(rootDir);
}
