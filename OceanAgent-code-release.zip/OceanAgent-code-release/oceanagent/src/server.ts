import { existsSync } from "node:fs";
import { resolve } from "node:path";
import { registerArtifactRoutes } from "./server/artifact-routes.js";
import { registerResearchCaseRoutes } from "./server/research-case-routes.js";
import fastifyStatic from "@fastify/static";
import cors from "@fastify/cors";
import Fastify from "fastify";
import { createAppContext } from "./app-context.js";
import { errorMessage } from "./http-errors.js";
import { registerConversationRoutes } from "./server/conversation-routes.js";
import { registerPlanRoutes } from "./server/plan-routes.js";
import { registerProjectRoutes } from "./server/project-routes.js";
import { registerRunRoutes } from "./server/run-routes.js";
import { ACTIVE_TOOL_NAMES } from "./agent/tools/index.js";
import { registerModelSettingsRoutes } from "./server/model-settings-routes.js";
import { registerKnowledgeGraphRoutes } from "./server/knowledge-graph-routes.js";
import { registerUploadRoutes } from "./server/upload-routes.js";
import { registerIdeationRoutes } from "./server/ideation-routes.js";
import { registerProvenanceRoutes } from "./server/provenance-routes.js";

const context = await createAppContext();
const server = Fastify({ logger: true, bodyLimit: 2 * 1024 * 1024 });
server.addContentTypeParser("application/octet-stream", (request, payload, done) => {
  done(null, payload);
});

await server.register(cors, {
  origin: /^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/,
  credentials: true,
});

server.get("/api/health", async () => ({
  ok: true,
  name: "OceanAgent",
  projectRole: process.env.OCEAN_PROJECT_ROLE ?? "paper-experiments",
  model: context.models.getState().defaultModel,
  tools: ACTIVE_TOOL_NAMES,
  remoteExecution: {
    configured: context.remoteConnections.list().length > 0,
  },
  rag: context.rag.getStatus(),
}));

registerConversationRoutes(server, context);
registerUploadRoutes(server, context);
registerIdeationRoutes(server, context);
registerProvenanceRoutes(server, context);
registerProjectRoutes(server, context);
registerRunRoutes(server, context);
registerPlanRoutes(server, context);
registerResearchCaseRoutes(server, context);
registerModelSettingsRoutes(server, context);
registerKnowledgeGraphRoutes(server, context.knowledgeGraph);
registerArtifactRoutes(server, resolve(context.config.rootDir, "data/artifacts"));

if (existsSync(context.config.frontendDist)) {
  await server.register(fastifyStatic, {
    root: context.config.frontendDist,
  });
}

server.setErrorHandler((error, _request, reply) => {
  const candidate = (error as { statusCode?: number }).statusCode;
  const statusCode = candidate && candidate >= 400 ? candidate : 500;
  reply.code(statusCode).send({ error: errorMessage(error) });
});

const shutdown = async () => {
  await server.close();
  context.close();
};
process.once("SIGINT", () => void shutdown());
process.once("SIGTERM", () => void shutdown());

await server.listen({ host: context.config.host, port: context.config.port });
