import type { RagSearchResult } from "../contracts.js";
import type { EmbeddingModelSettings } from "../agent/model-defaults.js";
import { DashScopeEmbeddingClient } from "./embedding-client.js";
import { RagStore, type RagRetrievalMode } from "./rag-store.js";
import type { ResearchFieldCode } from "./research-fields.js";
import type { RagDocument } from "./types.js";
import { decideDatasetRoutes, missingCapabilityQueries } from "./retrieval-decision.js";
import type { RetrievalDecision, RuntimeTaskSpec } from "./retrieval-decision.js";
import { projectKnowledgeDocument, projectKnowledgeSearchResult, requireKnowledgeAccess, requireDatasetAccess,
  resolveAblationPolicy, type AblationPolicy } from "../experiments/ablation-policy.js";

export type FieldConfidence = "high" | "medium" | "low";

export interface ExpandedResearchCase {
  problem: RagDocument;
  bundle: RagDocument;
  datasetIds: string[];
  graphTrace: {
    graphVersion: string | null;
    path: string[];
  };
}

export interface GlobalDatasetTrace {
  graphVersion: string | null;
  seedDatasetIds: string[];
  paths: Array<{
    fromDatasetId: string;
    toDatasetId: string;
    supportCount: number;
    paperIds: string[];
    bundleIds: string[];
    roles: string[];
  }>;
  truncated: boolean;
}

function datasetIdsFromBundle(bundle: RagDocument): string[] {
  const usages = Array.isArray(bundle.payload.data_usages) ? bundle.payload.data_usages : [];
  return [...new Set(usages.flatMap((usage) => {
    if (!usage || typeof usage !== "object") return [];
    const id = (usage as Record<string, unknown>).dataset_id;
    return typeof id === "string" && id ? [id] : [];
  }))];
}

export class RagService {
  private readonly embeddings: DashScopeEmbeddingClient;

  constructor(
    private readonly store: RagStore,
    private readonly settings: EmbeddingModelSettings,
    private readonly resolveApiKey: () => Promise<string | null>,
    private readonly hasCredential: () => boolean,
    private readonly refreshSnapshot?: () => Promise<unknown>,
    private readonly accessPolicy: AblationPolicy = resolveAblationPolicy("A1"),
    private readonly retrievalMode?: RagRetrievalMode,
  ) {
    this.embeddings = new DashScopeEmbeddingClient(settings, resolveApiKey);
  }

  /** Each run gets an immutable view; no shared environment or mutable access switch. */
  withAblationPolicy(policy: AblationPolicy): RagService {
    if (policy.condition === this.accessPolicy.condition && policy.publicDatasetAccessEnabled === this.accessPolicy.publicDatasetAccessEnabled) return this;
    return new RagService(this.store, this.settings, this.resolveApiKey, this.hasCredential, this.refreshSnapshot, policy, this.retrievalMode);
  }
  withRetrievalMode(mode: RagRetrievalMode): RagService {
    return new RagService(this.store, this.settings, this.resolveApiKey, this.hasCredential, this.refreshSnapshot, this.accessPolicy, mode);
  }

  getStatus(): Record<string, string | number | boolean | null> {
    if (!this.accessPolicy.knowledgeAccessEnabled && !this.accessPolicy.publicDatasetAccessEnabled) return { documents: 0, problemCards: 0, usageBundles: 0,
      datasetCards: 0, version: null, graphVersion: null, credentialConfigured: false,
      retrievalPolicy: "A0_no_knowledge_access", ablationCondition: "A0" };
    const problemCards = this.store.countByType("problem_solution"), datasetCards = this.store.countByType("dataset");
    return {
      documents: this.accessPolicy.bundleAccessEnabled ? this.store.count() : problemCards + datasetCards,
      problemCards,
      usageBundles: this.accessPolicy.bundleAccessEnabled ? this.store.countByType("usage_bundle") : 0,
      datasetCards,
      version: this.store.getMeta("index_version"),
      graphVersion: this.accessPolicy.bundleAccessEnabled ? this.store.getMeta("global_graph_version") : null,
      indexedAt: this.store.getMeta("indexed_at"),
      indexMode: this.store.getMeta("index_mode"),
      retrievalPolicy: "reviewed_cards_with_quality_status",
      embeddingModel: this.store.getMeta("embedding_model") ?? this.embeddings.model,
      embeddingDimensions: Number(this.store.getMeta("embedding_dimensions") ?? this.embeddings.dimensions),
      credentialConfigured: this.hasCredential(),
      qualityQuarantined: Number(this.store.getMeta("quality_quarantined") ?? 0),
      ablationCondition: this.accessPolicy.condition,
    };
  }

  async refreshLocalIndex(): Promise<Record<string, string | number | boolean | null>> {
    if (this.accessPolicy.knowledgeAccessEnabled) await this.refreshSnapshot?.();
    return this.getStatus();
  }

  async searchResearchCases(
    query: string,
    researchFields: ResearchFieldCode[],
    fieldConfidence: FieldConfidence,
    limit = 5,
    signal?: AbortSignal,
  ): Promise<RagSearchResult[]> {
    requireKnowledgeAccess(this.accessPolicy);
    this.ensureIndexed("problem_solution");
    const queryEmbedding = await this.tryEmbedding(
      `Retrieve a closely analogous ocean-science research problem and solution for this query:\n${query}`,
      signal,
    );
    return this.store.search(query, queryEmbedding, this.embeddings.model, this.embeddings.dimensions, {
      cardType: "problem_solution",
      retrievalMode: this.retrievalMode,
      researchFields: fieldConfidence === "low" ? [] : researchFields,
      includeUnresolved: fieldConfidence === "medium",
      limit: Math.min(Math.max(limit, 1), 6),
    }).map(result => projectKnowledgeSearchResult(result, this.accessPolicy));
  }

  async searchDatasets(query: string, limit = 5, signal?: AbortSignal, assessment = false): Promise<RagSearchResult[]> {
    requireDatasetAccess(this.accessPolicy);
    this.ensureIndexed("dataset");
    const queryEmbedding = await this.tryEmbedding(
      `Retrieve reusable authoritative data products matching this explicit ocean-data requirement:\n${query}`,
      signal,
    );
    return this.store.search(query, queryEmbedding, this.embeddings.model, this.embeddings.dimensions, {
      cardType: "dataset",
      retrievalMode: this.retrievalMode,
      limit: Math.min(Math.max(limit, 1), 6),
      bypassSimilarityGate: assessment,
    }).map(result => projectKnowledgeSearchResult(result, this.accessPolicy));
  }

  /** Bounded local-corpus assessment. Similarity scores are retained only as retrieval evidence. */
  async assessDatasetRoutes(queryId: string, task: RuntimeTaskSpec, signal?: AbortSignal): Promise<RetrievalDecision> {
    requireKnowledgeAccess(this.accessPolicy);
    const ids = task.requirements.map((item) => item.id);
    if (new Set(ids).size !== ids.length) throw new Error("数据能力 requirement id 必须唯一");
    const requirements = task.requirements.filter((item) => item.essential !== false
      && item.role !== "model_parameter" && item.role !== "prior");
    const queries = [task.researchGoal, ...requirements.slice(0, 4).map((item) =>
      [item.variable, item.spatial, item.temporal, item.vertical, item.modality]
        .filter(Boolean).join(" "))].filter(Boolean).slice(0, 5);
    const hits = new Map<string, RagSearchResult>();
    let remainingQueryChars = 3600;
    const bounded = (query: string): string => {
      const value = query.slice(0, Math.min(400, remainingQueryChars));
      remainingQueryChars -= value.length;
      return value;
    };
    for (const query of queries) {
      const searched = bounded(query);
      if (!searched) break;
      const results = await this.searchDatasets(searched, 6, signal, true);
      results.forEach((hit, index) => {
        if (!hits.has(hit.id)) hits.set(hit.id, { ...hit, retrievalQuery: searched, retrievalRank: index + 1 });
      });
    }
    const decide = (recovery: string[]) => decideDatasetRoutes(queryId, task, [...hits.values()],
      this.getDatasetCards([...hits.keys()]), recovery);
    let decision = decide([]);
    if (decision.bundles.length) return decision;

    // One recovery pass is reserved for missing capabilities, including aliases.
    const recovery = missingCapabilityQueries(task, decision).slice(0, 3).map((query) => query.slice(0, 400));
    for (const query of recovery) {
      const searched = bounded(query);
      if (!searched) break;
      const results = await this.searchDatasets(searched, 6, signal, true);
      results.forEach((hit, index) => {
        if (!hits.has(hit.id)) hits.set(hit.id, { ...hit, retrievalQuery: searched, retrievalRank: index + 1 });
      });
    }
    decision = decide(recovery);
    if (decision.bundles.length || task.replicationOnly || !this.accessPolicy.bundleAccessEnabled) return decision;

    // A PSC/UBC path contributes candidate IDs and historical method evidence only.
    // It never becomes a runtime plan or evidence of current data availability.
    let cases: RagSearchResult[] = [];
    if (remainingQueryChars > 0) {
      try {
        cases = await this.searchResearchCases(bounded(task.researchGoal), [], "low", 3, signal);
      } catch (error) {
        if (signal?.aborted) throw error;
        return decision;
      }
    }
    const caseIds: string[] = [];
    const bundleIds: string[] = [];
    for (const [index, candidate] of cases.entries()) {
      try {
        const expanded = this.expandResearchCase(candidate.id);
        caseIds.push(candidate.id);
        bundleIds.push(expanded.bundle.id);
        hits.set(candidate.id, { ...candidate, retrievalQuery: task.researchGoal, retrievalRank: index + 1 });
        hits.set(expanded.bundle.id, {
          id: expanded.bundle.id, cardType: "usage_bundle", title: expanded.bundle.title,
          excerpt: expanded.bundle.content.slice(0, 900), sourceIds: expanded.bundle.sourceIds,
          score: 0, retrievalMethod: "exact_link", scoreSemantics: "exact_link_no_score",
          retrievalQuery: `PSC:${candidate.id}`, retrievalRank: 1,
          payload: expanded.bundle.payload,
        });
        for (const card of this.getDatasetCards(expanded.datasetIds)) {
          const prior = hits.get(card.id);
          if (prior) {
            hits.set(card.id, { ...prior,
              sourceIds: [...new Set([...prior.sourceIds, candidate.id, expanded.bundle.id])] });
          } else hits.set(card.id, {
            id: card.id, cardType: "dataset", title: card.title, excerpt: card.content.slice(0, 900),
            sourceIds: [...card.sourceIds, candidate.id, expanded.bundle.id], score: 0,
            retrievalMethod: "exact_link", scoreSemantics: "exact_link_no_score",
            retrievalQuery: `UBC:${expanded.bundle.id}`, retrievalRank: 1,
            payload: card.payload,
          });
        }
      } catch { /* A broken historical link cannot validate a route. */ }
    }
    decision = decide([...recovery, ...caseIds.map((id) => `PSC:${id}`), ...bundleIds.map((id) => `UBC:${id}`)]);
    return decision;
  }

  getProblemSolutionCard(cardId: string): RagDocument {
    requireKnowledgeAccess(this.accessPolicy);
    const problem = this.store.getDocument(cardId, "problem_solution");
    if (!problem) throw new Error(`未找到问题方案卡：${cardId}`);
    return projectKnowledgeDocument(problem, this.accessPolicy);
  }

  expandResearchCase(cardId: string): ExpandedResearchCase {
    requireKnowledgeAccess(this.accessPolicy, true);
    const problem = this.store.getDocument(cardId, "problem_solution");
    if (!problem) throw new Error(`未找到问题方案卡：${cardId}`);
    const bundleId = problem.payload.bundle_id;
    if (typeof bundleId !== "string" || !bundleId) throw new Error(`问题方案卡 ${cardId} 缺少 bundle_id`);
    const bundle = this.store.getDocument(bundleId, "usage_bundle");
    if (!bundle) throw new Error(`未找到问题方案卡关联的数据包：${bundleId}`);
    return {
      problem,
      bundle,
      datasetIds: datasetIdsFromBundle(bundle),
      graphTrace: {
        graphVersion: this.store.getMeta("global_graph_version") ?? this.store.getMeta("index_version"),
        path: [`ProblemSolutionCard:${problem.id}`, `UsageBundleCard:${bundle.id}`],
      },
    };
  }

  getDatasetCards(datasetIds: string[]): RagDocument[] {
    requireDatasetAccess(this.accessPolicy);
    return [...new Set(datasetIds)].flatMap((id) => {
      const document = this.store.getDocument(id, "dataset");
      return document ? [projectKnowledgeDocument(document, this.accessPolicy)] : [];
    });
  }

  getUsageBundleCards(bundleIds: string[]): RagDocument[] {
    requireKnowledgeAccess(this.accessPolicy, true);
    return [...new Set(bundleIds)].flatMap((id) => {
      const document = this.store.getDocument(id, "usage_bundle");
      return document ? [document] : [];
    });
  }

  traceGlobalDatasetRelations(datasetIds: string[], limit = 20): GlobalDatasetTrace {
    requireKnowledgeAccess(this.accessPolicy, true);
    this.ensureIndexed("usage_bundle");
    const seeds = new Set(datasetIds.filter(Boolean));
    const problemByBundle = new Map<string, RagDocument>();
    for (const problem of this.store.listDocuments("problem_solution")) {
      const bundleId = problem.payload.bundle_id;
      if (typeof bundleId === "string" && bundleId) problemByBundle.set(bundleId, problem);
    }
    const relations = new Map<string, {
      fromDatasetId: string;
      toDatasetId: string;
      paperIds: Set<string>;
      bundleIds: Set<string>;
      roles: Set<string>;
    }>();
    for (const bundle of this.store.listDocuments("usage_bundle")) {
      const usages = Array.isArray(bundle.payload.data_usages) ? bundle.payload.data_usages : [];
      const normalized = usages.flatMap((value) => {
        if (!value || typeof value !== "object") return [];
        const usage = value as Record<string, unknown>;
        const datasetId = typeof usage.dataset_id === "string" ? usage.dataset_id : "";
        return datasetId ? [{ datasetId, role: typeof usage.role === "string" ? usage.role : "使用数据" }] : [];
      });
      const seedUsages = normalized.filter((usage) => seeds.has(usage.datasetId));
      if (seedUsages.length === 0) continue;
      const problem = problemByBundle.get(bundle.id);
      const paperId = typeof problem?.payload.paper_id === "string" ? problem.payload.paper_id : "";
      for (const seed of seedUsages) {
        for (const related of normalized) {
          if (related.datasetId === seed.datasetId) continue;
          const key = `${seed.datasetId}\u0000${related.datasetId}`;
          const current = relations.get(key) ?? {
            fromDatasetId: seed.datasetId,
            toDatasetId: related.datasetId,
            paperIds: new Set<string>(),
            bundleIds: new Set<string>(),
            roles: new Set<string>(),
          };
          if (paperId) current.paperIds.add(paperId);
          current.bundleIds.add(bundle.id);
          current.roles.add(`${seed.role} → ${related.role}`);
          relations.set(key, current);
        }
      }
    }
    const allPaths = [...relations.values()]
      .map((item) => ({
        fromDatasetId: item.fromDatasetId,
        toDatasetId: item.toDatasetId,
        supportCount: item.bundleIds.size,
        paperIds: [...item.paperIds].sort(),
        bundleIds: [...item.bundleIds].sort(),
        roles: [...item.roles].sort(),
      }))
      .sort((left, right) => right.supportCount - left.supportCount
        || `${left.fromDatasetId}:${left.toDatasetId}`.localeCompare(`${right.fromDatasetId}:${right.toDatasetId}`));
    return {
      graphVersion: this.store.getMeta("global_graph_version") ?? this.store.getMeta("index_version"),
      seedDatasetIds: [...seeds],
      paths: allPaths.slice(0, Math.min(Math.max(limit, 1), 40)),
      truncated: allPaths.length > limit,
    };
  }

  private ensureIndexed(cardType: RagDocument["cardType"]): void {
    if (this.store.countByType(cardType) === 0) {
      throw new Error("Ocean-RAG 本地索引为空或缺少对应卡片，请确认 OCEAN_RAG_ROOT 后重启应用；需要重算语义向量时再运行 npm run index:rag");
    }
  }

  private async tryEmbedding(text: string, signal?: AbortSignal): Promise<number[] | null> {
    if (this.retrievalMode === "lexical") return null;
    if (!this.hasCredential()) return null;
    try {
      return await this.embeddings.embedOne(text, signal);
    } catch (error) {
      if (signal?.aborted) throw error;
      // Keyword retrieval remains available when the embedding provider is
      // temporarily unavailable; this keeps the local Ocean-RAG usable.
      return null;
    }
  }
}
