import { describe, expect, it } from "vitest";
import type { RagSearchResult } from "../contracts.js";
import { decideDatasetRoutes, matchRequirement, missingCapabilityQueries } from "./retrieval-decision.js";
import type { DataRequirement, RuntimeTaskSpec } from "./retrieval-decision.js";
import type { RagDocument } from "./types.js";

const sst: DataRequirement = { id: "sst", variable: "sea surface temperature", role: "target",
  temporal: "2001-2010" };
const wind: DataRequirement = { id: "wind", variable: "wind speed", role: "predictor",
  temporal: "2001-2010" };

function card(id: string, fields: string[], temporal = "1990-2020", available = true): RagDocument {
  return { id, cardType: "dataset", title: id, content: id, sourceIds: [`source:${id}`],
    sourcePath: `${id}.jsonl`, sourceHash: id,
    payload: { fields: fields.map((name) => ({ raw_name: name, unit: "m/s" })),
      coverage: { spatial: "Global", temporal, vertical: "Surface" },
      resolution: { spatial: "1 km", temporal: "daily", vertical: "surface" },
      public_availability: available ? "public" : "unresolved",
      access: available ? [{ url: `https://example.org/${id}`, status: "active" }] : [] },
  };
}

function hit(document: RagDocument, score = 0.1): RagSearchResult {
  return { id: document.id, cardType: "dataset", title: document.title, excerpt: document.content,
    sourceIds: document.sourceIds, score, rawScore: score, retrievalMethod: "dense_lexical_fusion",
    scoreSemantics: "cosine_similarity", payload: document.payload };
}

function decide(requirements: DataRequirement[], cards: RagDocument[], scores?: number[], replicationOnly = false) {
  const task: RuntimeTaskSpec = { researchGoal: "ocean analysis", requirements, replicationOnly };
  return decideDatasetRoutes("synthetic", task, cards.map((item, index) => hit(item, scores?.[index])), cards);
}

describe("adaptive scientific dataset decisions (local synthetic cards)", () => {
  it("keeps one dataset when Top-1 covers every essential capability", () => {
    const result = decide([sst, wind], [card("both", [sst.variable, wind.variable])]);
    expect(result.state).toBe("single_dataset_sufficient");
    expect(result.bundles[0]?.datasetIds).toEqual(["both"]);
  });

  it("does not mistake high Top-1 similarity for a missing key variable", () => {
    const cards = [card("top", [sst.variable]), card("complement", [wind.variable])];
    const result = decide([sst, wind], cards, [0.99, 0.2]);
    expect(result.state).toBe("bundle_required");
    expect(result.bundles[0]?.datasetIds).toEqual(["top", "complement"]);
    expect(result.assessments[0]?.unsupported_requirements).toContain("wind");
  });

  it("combines two complementary cards without requiring a third", () => {
    const result = decide([sst, wind], [card("temperature", [sst.variable]), card("wind", [wind.variable])]);
    expect(result.bundles).toHaveLength(1);
    expect(result.bundles[0]?.datasetIds).toHaveLength(2);
  });

  it("retains materially distinct feasible routes", () => {
    const result = decide([sst, wind], [card("sst_a", [sst.variable]),
      card("sst_b", [sst.variable]), card("wind", [wind.variable])]);
    expect(result.state).toBe("multiple_feasible_bundles");
    expect(result.bundles).toHaveLength(2);
  });

  it("rejects a high-scoring dataset outside the required years", () => {
    const result = decide([sst], [card("old", [sst.variable], "1980-1990"),
      card("new", [sst.variable], "2000-2020")], [0.99, 0.12]);
    expect(result.bundles[0]?.datasetIds).toEqual(["new"]);
    expect(result.matches.find((item) => item.datasetId === "old")?.dimensions.temporal).toBe("not_satisfied");
  });

  it("marks partial time coverage without promoting it to a complete route", () => {
    const dataset = card("partial", [sst.variable], "2005-2020");
    const result = decide([sst], [dataset]);
    expect(matchRequirement(sst, dataset).dimensions.temporal).toBe("partially_satisfied");
    expect(result.bundles).toHaveLength(0);
  });

  it("reports low confidence when all candidates lack the variables", () => {
    const result = decide([sst], [card("irrelevant", ["wave height"])], [0.01]);
    expect(result.state).toBe("low_retrieval_confidence");
    expect(result.corpusStatus).toBe("not_found_in_current_corpus");
  });

  it("keeps missing availability metadata unknown", () => {
    const dataset = card("uncertain", [sst.variable], "1990-2020", false);
    const result = decide([sst], [dataset]);
    expect(result.bundles).toHaveLength(0);
    expect(matchRequirement(sst, dataset).dimensions.availability).toBe("unknown");
    expect(result.uncertainRequirements).toContain("sst");
  });

  it("does not turn a similar historical paper into a dataset route for replication", () => {
    const result = decide([sst], [], [], true);
    expect(result.bundles).toHaveLength(0);
    expect(result.corpusStatus).toBe("not_found_in_current_corpus");
  });

  it("can find a data route when no literature card is present", () => {
    const result = decide([sst], [card("dataset_only", [sst.variable])]);
    expect(result.state).toBe("single_dataset_sufficient");
  });

  it("does not require model parameters to map to DatasetCards", () => {
    const parameter: DataRequirement = { id: "alpha", variable: "regularization alpha", role: "model_parameter" };
    const result = decide([sst, parameter], [card("data", [sst.variable])]);
    expect(result.state).toBe("single_dataset_sufficient");
    expect(result.bundles[0]?.requirementIds).toEqual(["sst"]);
  });

  it("rewrites missing capability queries with aliases", () => {
    const task: RuntimeTaskSpec = { researchGoal: "SST trend", requirements: [sst] };
    const decision = decideDatasetRoutes("synthetic", task, [], []);
    expect(missingCapabilityQueries(task, decision)[0]).toContain("sst");
  });
});
