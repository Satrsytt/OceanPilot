import type { RagSearchResult } from "../contracts.js";
import type { RagDocument } from "./types.js";

export type CapabilityStatus = "satisfied" | "partially_satisfied" | "not_satisfied" | "unknown";
export type DecisionState = "single_dataset_sufficient" | "bundle_required" | "multiple_feasible_bundles"
  | "insufficient_resources" | "low_retrieval_confidence" | "needs_clarification";

export interface DataRequirement {
  id: string;
  variable: string;
  role: "target" | "predictor" | "control" | "context" | "validation" | "model_parameter" | "prior";
  aliases?: string[];
  spatial?: string;
  temporal?: string;
  vertical?: string;
  spatialResolution?: string;
  temporalResolution?: string;
  modality?: string;
  unit?: string;
  essential?: boolean;
}

export interface RuntimeTaskSpec {
  researchGoal: string;
  requirements: DataRequirement[];
  replicationOnly?: boolean;
}

export interface CapabilityMatch {
  requirementId: string;
  datasetId: string;
  status: CapabilityStatus;
  dimensions: Record<string, CapabilityStatus>;
  evidenceRefs: string[];
  reason: string;
}

export interface RetrievalAssessment {
  query_id: string;
  candidate_id: string;
  card_type: RagDocument["cardType"];
  retrieval_method: string;
  raw_score: number | null;
  score_semantics: string;
  rank: number;
  retrieval_query?: string;
  matched_requirements: string[];
  unsupported_requirements: string[];
  evidence_refs: string[];
  assessment_status: "supported" | "partial" | "unsupported" | "uncertain";
  assessment_reason: string;
  requirement_coverage: { satisfied: number; essential: number };
  scientific_feasibility: "supported_by_card_metadata" | "infeasible_alone" | "uncertain";
  bm25_score?: number;
  dense_similarity?: number;
  fusion_score?: number;
}

export interface DatasetBundle {
  datasetIds: string[];
  requirementIds: string[];
  evidenceRefs: string[];
  score: { coveredEssential: number; datasetCount: number; uncertainCapabilities: number };
  scientificFeasibility: "supported_by_card_metadata";
}

export interface RetrievalDecision {
  queryId: string;
  state: DecisionState;
  reason: string;
  bundles: DatasetBundle[];
  missingRequirements: string[];
  uncertainRequirements: string[];
  assessments: RetrievalAssessment[];
  matches: CapabilityMatch[];
  recoveryQueries: string[];
  corpusStatus: "supported_by_current_corpus" | "not_found_in_current_corpus";
}

const UNKNOWN = /^(?:unresolved|unknown|not[_ -]?(?:reported|specified|verified|available)|none|null|pending)$/i;
const ALIASES: Record<string, string[]> = {
  sst: ["sea surface temperature", "sea_surface_temperature", "ocean surface temperature", "海表温度", "海温"],
  "sea surface temperature": ["sst", "sea_surface_temperature", "海表温度", "海温"],
  chlorophyll: ["chlorophyll a", "chlorophyll-a", "chl a", "叶绿素"],
  "sea ice concentration": ["sic", "sea_ice_concentration", "海冰密集度"],
  salinity: ["sea water salinity", "sss", "海水盐度"],
};

function clean(value: unknown): string {
  return typeof value === "string" ? value.trim() : "";
}

function known(value: unknown): string {
  const text = clean(value);
  return text && !UNKNOWN.test(text) ? text : "";
}

function normalize(value: string): string {
  return value.normalize("NFKC").toLowerCase().replace(/[_\-/]+/g, " ")
    .replace(/[^\p{L}\p{N}]+/gu, " ").trim().replace(/\s+/g, " ");
}

function comparable(requested: string | undefined, actual: unknown): CapabilityStatus {
  if (!requested?.trim()) return "satisfied";
  const present = known(actual);
  if (!present) return "unknown";
  const wanted = normalize(requested);
  const have = normalize(present);
  if (wanted === have || have.includes(wanted)) return "satisfied";
  return "unknown";
}

function years(value: string): [number, number] | null {
  const numbers = [...value.matchAll(/(?:18|19|20|21)\d{2}/g)].map((match) => Number(match[0]));
  return numbers.length ? [Math.min(...numbers), Math.max(...numbers)] : null;
}

function temporal(requested: string | undefined, actual: unknown): CapabilityStatus {
  if (!requested?.trim()) return "satisfied";
  const present = known(actual);
  if (!present) return "unknown";
  const target = years(requested);
  const available = years(present);
  if (target && available) {
    if (available[1] < target[0] || available[0] > target[1]) return "not_satisfied";
    return available[0] <= target[0] && available[1] >= target[1]
      ? "satisfied" : "partially_satisfied";
  }
  return comparable(requested, present);
}

function spatial(requested: string | undefined, actual: unknown): CapabilityStatus {
  if (!requested?.trim()) return "satisfied";
  const present = known(actual);
  if (!present) return "unknown";
  if (/^(global|worldwide|全球)$/i.test(present)) return "satisfied";
  const target = normalize(requested);
  const available = normalize(present);
  if (target === available) return "satisfied";
  const basins = ["pacific", "atlantic", "indian", "arctic", "southern"];
  const requestedBasin = basins.find((basin) => target.includes(basin));
  const actualBasin = basins.find((basin) => available.includes(basin));
  if (requestedBasin && actualBasin && requestedBasin !== actualBasin) return "not_satisfied";
  if (available.includes(target) || target.includes(available)) return "partially_satisfied";
  return "unknown";
}

function depth(requested: string | undefined, actual: unknown): CapabilityStatus {
  if (!requested?.trim()) return "satisfied";
  const present = known(actual);
  if (!present) return "unknown";
  if (normalize(requested) === normalize(present)) return "satisfied";
  const parse = (value: string): [number, number] | null => {
    const numbers = [...value.matchAll(/\d+(?:\.\d+)?/g)].map((match) => Number(match[0]));
    if (!numbers.length || !/(?:^|\W)(?:m|meter|metre|km)(?:\W|$)/i.test(value)) return null;
    const multiplier = /(?:^|\W)km(?:\W|$)/i.test(value) ? 1000 : 1;
    return [Math.min(...numbers) * multiplier, Math.max(...numbers) * multiplier];
  };
  const target = parse(requested);
  const available = parse(present);
  if (!target || !available) return "unknown";
  if (available[1] < target[0] || available[0] > target[1]) return "not_satisfied";
  return available[0] <= target[0] && available[1] >= target[1]
    ? "satisfied" : "partially_satisfied";
}

function resolutionCheck(requested: string | undefined, actual: unknown): CapabilityStatus {
  if (!requested?.trim()) return "satisfied";
  const present = known(actual);
  if (!present) return "unknown";
  const parse = (value: string) => value.match(/(\d+(?:\.\d+)?)\s*(km|m|days?|hours?|months?)/i);
  const target = parse(requested);
  const available = parse(present);
  if (target && available) {
    const units = (unit: string) => unit.toLowerCase().replace(/s$/, "");
    if (units(target[2]!) !== units(available[2]!)) return "unknown";
    return Number(available[1]) <= Number(target[1]) ? "satisfied" : "not_satisfied";
  }
  return comparable(requested, present);
}

function variableField(requirement: DataRequirement, payload: Record<string, unknown>): Record<string, unknown> | null {
  const fields = Array.isArray(payload.fields) ? payload.fields
    : Array.isArray(payload.variables) ? payload.variables : [];
  const aliases = [requirement.variable, ...(requirement.aliases ?? []), ...(ALIASES[normalize(requirement.variable)] ?? [])]
    .map(normalize).filter((value) => value.length >= 2);
  for (const value of fields) {
    if (!value || typeof value !== "object") continue;
    const field = value as Record<string, unknown>;
    const names = [field.raw_name, field.name, field.description].map((item) => normalize(clean(item))).filter(Boolean);
    if (names.some((name) => aliases.some((alias) => name === alias || name.includes(` ${alias} `)
      || name.startsWith(`${alias} `) || name.endsWith(` ${alias}`)))) return field;
  }
  return null;
}

function availability(payload: Record<string, unknown>): CapabilityStatus {
  const declared = normalize(clean(payload.public_availability));
  if (["not available", "not found", "unavailable"].includes(declared)) return "not_satisfied";
  const quality = payload.publication_quality as Record<string, unknown> | undefined;
  if (quality?.status === "needs_completion") return "unknown";
  const access = Array.isArray(payload.access) ? payload.access : [];
  const hasAccess = access.some((item) => item && typeof item === "object"
    && /^https?:\/\//.test(clean((item as Record<string, unknown>).url))
    && !/unresolved|unavailable|not available/i.test(clean((item as Record<string, unknown>).status)));
  return ["public", "open", "available"].includes(declared) && hasAccess ? "satisfied" : "unknown";
}

function evidenceRefs(card: RagDocument): string[] {
  const refs = new Set<string>([card.id, ...card.sourceIds]);
  const sources = Array.isArray(card.payload.sources) ? card.payload.sources : [];
  for (const source of sources) {
    if (source && typeof source === "object") {
      const item = source as Record<string, unknown>;
      if (known(item.source_id)) refs.add(clean(item.source_id));
      if (known(item.url)) refs.add(clean(item.url));
    }
  }
  return [...refs];
}

export function matchRequirement(requirement: DataRequirement, card: RagDocument): CapabilityMatch {
  const refs = evidenceRefs(card);
  if (["model_parameter", "prior"].includes(requirement.role)) {
    return { requirementId: requirement.id, datasetId: card.id, status: "unknown",
      dimensions: {}, evidenceRefs: refs, reason: "模型参数或先验不强制绑定 DatasetCard" };
  }
  const payload = card.payload;
  const field = variableField(requirement, payload);
  const coverage = payload.coverage && typeof payload.coverage === "object"
    ? payload.coverage as Record<string, unknown> : {};
  const resolution = payload.resolution && typeof payload.resolution === "object"
    ? payload.resolution as Record<string, unknown> : {};
  const dimensions: Record<string, CapabilityStatus> = {
    variable: field ? "satisfied" : "not_satisfied",
    scientificRole: field ? "satisfied" : "not_satisfied",
    spatial: spatial(requirement.spatial, coverage.spatial),
    temporal: temporal(requirement.temporal, coverage.temporal),
    vertical: depth(requirement.vertical, coverage.vertical),
    spatialResolution: resolutionCheck(requirement.spatialResolution, resolution.spatial),
    temporalResolution: resolutionCheck(requirement.temporalResolution, resolution.temporal),
    modality: comparable(requirement.modality, field?.modality ?? payload.measurement_modality),
    unit: comparable(requirement.unit, field?.unit),
    availability: availability(payload),
  };
  const values = Object.values(dimensions);
  const status: CapabilityStatus = values.includes("not_satisfied") ? "not_satisfied"
    : values.includes("partially_satisfied") ? "partially_satisfied"
      : values.includes("unknown") ? "unknown" : "satisfied";
  const unresolved = Object.entries(dimensions).filter(([, value]) => value !== "satisfied")
    .map(([key, value]) => `${key}:${value}`);
  return { requirementId: requirement.id, datasetId: card.id, status, dimensions,
    evidenceRefs: refs, reason: unresolved.length ? unresolved.join(", ") : "必要能力及可获取性均有卡片元数据支持" };
}

function compatible(cards: RagDocument[]): boolean {
  for (let i = 0; i < cards.length; i += 1) for (let j = i + 1; j < cards.length; j += 1) {
    const a = (cards[i]?.payload.coverage as Record<string, unknown> | undefined)?.temporal;
    const b = (cards[j]?.payload.coverage as Record<string, unknown> | undefined)?.temporal;
    const left = years(clean(a));
    const right = years(clean(b));
    if (left && right && (left[1] < right[0] || right[1] < left[0])) return false;
    const firstSpace = normalize(clean((cards[i]?.payload.coverage as Record<string, unknown> | undefined)?.spatial));
    const secondSpace = normalize(clean((cards[j]?.payload.coverage as Record<string, unknown> | undefined)?.spatial));
    const basins = ["pacific", "atlantic", "indian", "arctic", "southern"];
    const firstBasin = basins.find((basin) => firstSpace.includes(basin));
    const secondBasin = basins.find((basin) => secondSpace.includes(basin));
    if (!firstSpace.includes("global") && !secondSpace.includes("global")
      && firstBasin && secondBasin && firstBasin !== secondBasin) return false;
  }
  return true;
}

export function decideDatasetRoutes(
  queryId: string,
  task: RuntimeTaskSpec,
  hits: RagSearchResult[],
  cards: RagDocument[],
  recoveryQueries: string[] = [],
): RetrievalDecision {
  const essential = task.requirements.filter((item) => item.essential !== false
    && item.role !== "model_parameter" && item.role !== "prior");
  const uniqueCards = [...new Map(cards.filter((card) => card.cardType === "dataset")
    .map((card) => [card.id, card])).values()];
  const matches = uniqueCards.flatMap((card) => essential.map((requirement) => matchRequirement(requirement, card)));
  const byId = new Map(uniqueCards.map((card) => [card.id, card]));
  const hitById = new Map(hits.map((hit) => [hit.id, hit]));
  const matched = (datasetId: string) => matches.filter((item) => item.datasetId === datasetId
    && item.status === "satisfied").map((item) => item.requirementId);
  const assessments: RetrievalAssessment[] = hits.map((hit, index) => {
    if (hit.cardType !== "dataset") return {
      query_id: queryId, candidate_id: hit.id, card_type: hit.cardType,
      retrieval_method: hit.retrievalMethod ?? "unknown",
      raw_score: hit.retrievalMethod === "exact_link" ? null : hit.rawScore ?? hit.score,
      score_semantics: hit.scoreSemantics ?? "uncalibrated_legacy_score",
      rank: hit.retrievalRank ?? index + 1, retrieval_query: hit.retrievalQuery,
      matched_requirements: [], unsupported_requirements: essential.map((item) => item.id),
      evidence_refs: hit.sourceIds, assessment_status: "uncertain",
      assessment_reason: "历史科学方法或精确关联证据，不证明当前 DatasetCard 能力",
      requirement_coverage: { satisfied: 0, essential: essential.length }, scientific_feasibility: "uncertain",
      bm25_score: hit.bm25Score, dense_similarity: hit.denseSimilarity, fusion_score: hit.fusionScore,
    };
    const cardMatches = matches.filter((item) => item.datasetId === hit.id);
    const supported = cardMatches.filter((item) => item.status === "satisfied").map((item) => item.requirementId);
    const unsupported = essential.map((item) => item.id).filter((id) => !supported.includes(id));
    const status = supported.length === essential.length && essential.length ? "supported"
      : supported.length ? "partial"
        : cardMatches.some((item) => item.status === "unknown") ? "uncertain" : "unsupported";
    return {
      query_id: queryId, candidate_id: hit.id, card_type: hit.cardType,
      retrieval_method: hit.retrievalMethod ?? "unknown",
      raw_score: hit.retrievalMethod === "exact_link" ? null : hit.rawScore ?? hit.score,
      score_semantics: hit.scoreSemantics ?? "uncalibrated_legacy_score",
      rank: hit.retrievalRank ?? index + 1, retrieval_query: hit.retrievalQuery,
      matched_requirements: supported, unsupported_requirements: unsupported,
      evidence_refs: [...new Set([...(byId.has(hit.id) ? evidenceRefs(byId.get(hit.id)!) : []), ...hit.sourceIds])],
      assessment_status: status, assessment_reason: cardMatches.map((item) => `${item.requirementId}: ${item.reason}`).join("; ")
        || "检索候选未进入能力匹配池",
      requirement_coverage: { satisfied: supported.length, essential: essential.length },
      scientific_feasibility: status === "supported" ? "supported_by_card_metadata"
        : status === "uncertain" ? "uncertain" : "infeasible_alone",
      bm25_score: hit.bm25Score, dense_similarity: hit.denseSimilarity, fusion_score: hit.fusionScore,
    };
  });
  // Preserve complements found by a requirement-specific query even when the
  // first broad query fills its Top-K. Search size remains bounded separately.
  const pool = new Set<string>(uniqueCards.slice(0, 6).map((card) => card.id));
  for (const requirement of essential) {
    for (const card of uniqueCards.filter((item) => matched(item.id).includes(requirement.id)).slice(0, 3)) {
      pool.add(card.id);
    }
  }
  const candidates = uniqueCards.filter((card) => pool.has(card.id) && matched(card.id).length).slice(0, 24);
  const bundles: DatasetBundle[] = [];
  const visit = (start: number, chosen: RagDocument[]) => {
    if (chosen.length && compatible(chosen)) {
      const covered = new Set(chosen.flatMap((card) => matched(card.id)));
      if (essential.every((item) => covered.has(item.id))) {
        bundles.push({ datasetIds: chosen.map((card) => card.id), requirementIds: [...covered].sort(),
          evidenceRefs: [...new Set(chosen.flatMap((card) =>
            [...evidenceRefs(card), ...(hitById.get(card.id)?.sourceIds ?? [])]))],
          score: { coveredEssential: covered.size, datasetCount: chosen.length, uncertainCapabilities: 0 },
          scientificFeasibility: "supported_by_card_metadata" });
        return;
      }
    }
    if (chosen.length >= 3) return;
    for (let index = start; index < candidates.length; index += 1) visit(index + 1, [...chosen, candidates[index]!]);
  };
  visit(0, []);
  bundles.sort((a, b) => a.datasetIds.length - b.datasetIds.length
    || a.datasetIds.join(",").localeCompare(b.datasetIds.join(",")));
  const minimalCandidates = bundles.filter((bundle) => !bundles.some((other) => other !== bundle
    && other.datasetIds.length < bundle.datasetIds.length
    && other.datasetIds.every((id) => bundle.datasetIds.includes(id))));
  const routeProducts = new Set<string>();
  const minimal = minimalCandidates.filter((bundle) => {
    const products = bundle.datasetIds.map((id) => {
      const card = byId.get(id);
      return normalize(`${clean(card?.payload.product_id) || clean(card?.payload.name) || id} ${known(card?.payload.version)}`);
    }).sort().join("|");
    if (routeProducts.has(products)) return false;
    routeProducts.add(products);
    return true;
  }).slice(0, 3);
  const missingRequirements = essential.filter((item) => !matches.some((match) => match.requirementId === item.id
    && match.status === "satisfied")).map((item) => item.id);
  const uncertainRequirements = essential.filter((item) => matches.some((match) => match.requirementId === item.id
    && match.status === "unknown") && missingRequirements.includes(item.id)).map((item) => item.id);
  let state: DecisionState;
  if (!essential.length || essential.some((item) => !item.variable.trim())) state = "needs_clarification";
  else if (minimal.length > 1) state = "multiple_feasible_bundles";
  else if (minimal[0]?.datasetIds.length === 1) state = "single_dataset_sufficient";
  else if (minimal.length) state = "bundle_required";
  else if (!matches.some((item) => item.dimensions.variable === "satisfied")) state = "low_retrieval_confidence";
  else state = "insufficient_resources";
  return {
    queryId, state, bundles: minimal, missingRequirements, uncertainRequirements,
    assessments, matches, recoveryQueries,
    corpusStatus: minimal.length ? "supported_by_current_corpus" : "not_found_in_current_corpus",
    reason: minimal.length ? `当前卡片支持 ${minimal.length} 条最小数据路线`
      : `当前卡片无法确认覆盖必要能力：${missingRequirements.join(", ") || "时空兼容性"}`,
  };
}

export function missingCapabilityQueries(task: RuntimeTaskSpec, decision: RetrievalDecision): string[] {
  if (!decision.missingRequirements.length && !decision.bundles.length) {
    const joint = task.requirements.filter((item) => item.essential !== false
      && item.role !== "model_parameter" && item.role !== "prior").slice(0, 3);
    return joint.length ? [joint.flatMap((item) => [item.variable, item.spatial, item.temporal])
      .filter(Boolean).join(" ")] : [];
  }
  return task.requirements.filter((item) => decision.missingRequirements.includes(item.id))
    .map((item) => [item.variable, ...(ALIASES[normalize(item.variable)] ?? []).slice(0, 2),
      item.spatial, item.temporal, item.vertical, item.modality].filter(Boolean).join(" "));
}
