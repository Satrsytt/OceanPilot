import { createHash } from "node:crypto";
import { join } from "node:path";
import type { AppConfig } from "../config.js";
import { DashScopeEmbeddingClient } from "./embedding-client.js";
import { loadRagDocuments } from "./normalizer.js";
import { RagStore } from "./rag-store.js";
import { researchFieldLabel } from "./research-fields.js";
import type { RagDocument } from "./types.js";

export interface IndexProgress {
  completed: number;
  total: number;
  message: string;
}

export interface IndexResult {
  discovered: number;
  eligible: number;
  quarantined: number;
  embedded: number;
  removed: number;
  version: string;
}

export interface IndexOptions {
  force?: boolean;
  signal?: AbortSignal;
}

const CARD_FILES = [
  "dataset_cards.jsonl",
  "problem_solution_cards.jsonl",
  "usage_bundle_cards.jsonl",
];

const EMBEDDING_SCHEMA_VERSION = "typed-cards-v3-reviewed-with-quality";
const TEMPORARY_MARKER = /(unresolved|pending_web_search)/i;
const TERMINAL_STATUSES = new Set([
  "not_applicable", "not_available", "not_found", "not_reported",
  "not_versioned", "restricted_or_by_request", "conflicted",
]);
const DATASET_FIELD_REQUIRED_KEYS = [
  "raw_name", "description", "unit", "dimensions", "valid_range", "quality_field", "quality_rule",
];

function containsTemporaryMarker(value: unknown): boolean {
  if (typeof value === "string") return TEMPORARY_MARKER.test(value);
  if (Array.isArray(value)) return value.some(containsTemporaryMarker);
  if (value && typeof value === "object") return Object.values(value as Record<string, unknown>).some(containsTemporaryMarker);
  return false;
}

function ambiguous(value: unknown): boolean {
  if (value == null) return true;
  if (typeof value !== "string") return false;
  const normalized = value.trim().toLocaleLowerCase();
  return !normalized || TEMPORARY_MARKER.test(normalized)
    || ["not reported", "not specified", "not provided", "not verified", "no web access"].some((marker) => normalized.includes(marker))
    || ["unknown", "none", "null"].includes(normalized);
}

function httpUrl(value: unknown): boolean {
  if (typeof value !== "string") return false;
  try { return ["http:", "https:"].includes(new URL(value).protocol); } catch { return false; }
}

function explicitTerminal(value: unknown): boolean {
  if (typeof value !== "string") return false;
  return TERMINAL_STATUSES.has(value.trim().toLocaleLowerCase().replace(/[\s-]+/g, "_"));
}

function missingStructuredValue(value: unknown): boolean {
  return value == null || value === "" || (Array.isArray(value) && value.length === 0) || ambiguous(value);
}

function completeDatasetCard(payload: Record<string, unknown>): boolean {
  if (containsTemporaryMarker(payload)) return false;
  for (const key of ["dataset_id", "product_id", "name", "provider", "version", "description", "ownership", "public_availability", "license"]) {
    if (ambiguous(payload[key])) return false;
  }
  for (const key of ["coverage", "resolution"]) {
    const value = payload[key];
    if (!value || typeof value !== "object" || Array.isArray(value)) return false;
    const item = value as Record<string, unknown>;
    if (["spatial", "temporal", "vertical"].some((component) => ambiguous(item[component]))) return false;
  }
  const fields = (Array.isArray(payload.fields) ? payload.fields : []) as unknown[];
  if (fields.length === 0 || fields.some((value) => {
    if (!value || typeof value !== "object" || Array.isArray(value)) return true;
    const field = value as Record<string, unknown>;
    return DATASET_FIELD_REQUIRED_KEYS.some((key) => ambiguous(field[key]))
      || (!httpUrl(field.source_url) && !explicitTerminal(field.source_url));
  })) return false;
  const sources = (Array.isArray(payload.sources) ? payload.sources : []) as unknown[];
  if (!sources.some((value) => value && typeof value === "object" && httpUrl((value as Record<string, unknown>).url))) return false;
  if (sources.some((value) => {
    if (!value || typeof value !== "object" || Array.isArray(value)) return false;
    const source = value as Record<string, unknown>;
    return httpUrl(source.url) && ["authority", "supports", "accessed_at"].some((key) => missingStructuredValue(source[key]));
  })) return false;
  const availability = String(payload.public_availability ?? "").toLocaleLowerCase();
  const access = (Array.isArray(payload.access) ? payload.access : []) as unknown[];
  if (!["not_found", "not_available"].includes(availability)
    && !access.some((value) => value && typeof value === "object" && httpUrl((value as Record<string, unknown>).url))) return false;
  return !access.some((value) => {
    if (!value || typeof value !== "object" || Array.isArray(value)) return true;
    const entry = value as Record<string, unknown>;
    return !httpUrl(entry.url) || ["type", "authentication", "status", "accessed_at"].some((key) => ambiguous(entry[key]));
  });
}

function publicationEligibleDocuments(documents: RagDocument[]): RagDocument[] {
  const validDatasetIds = new Set(documents
    .filter((document) => document.cardType === "dataset" && completeDatasetCard(document.payload))
    .map((document) => document.id));
  const validBundles = documents.filter((document) => {
    if (document.cardType !== "usage_bundle" || containsTemporaryMarker(document.payload)) return false;
    const steps = Array.isArray(document.payload.steps) ? document.payload.steps : [];
    const usages = Array.isArray(document.payload.data_usages) ? document.payload.data_usages : [];
    return steps.length > 0 && usages.every((value) => {
      if (!value || typeof value !== "object") return false;
      const datasetId = (value as Record<string, unknown>).dataset_id;
      return typeof datasetId === "string" && validDatasetIds.has(datasetId);
    });
  });
  const validBundleIds = new Set(validBundles.map((document) => document.id));
  return documents.filter((document) => {
    if (document.cardType === "dataset") return validDatasetIds.has(document.id);
    if (document.cardType === "usage_bundle") return validBundleIds.has(document.id);
    if (containsTemporaryMarker(document.payload)) return false;
    const bundleId = document.payload.bundle_id;
    return typeof bundleId === "string" && validBundleIds.has(bundleId);
  });
}

function reviewedDocumentsWithQuality(documents: RagDocument[]): {
  documents: RagDocument[];
  publishReadyIds: Set<string>;
} {
  const publishReadyIds = new Set(publicationEligibleDocuments(documents).map((document) => document.id));
  return {
    publishReadyIds,
    documents: documents.map((document) => {
      const status = publishReadyIds.has(document.id) ? "publish_ready" : "needs_completion";
      return {
        ...document,
        content: `${document.content}\n发布质量 ${status}`,
        payload: {
          ...document.payload,
          publication_quality: {
            status,
            note: status === "publish_ready"
              ? "该卡已通过严格发布门禁。"
              : "该卡已完成抽取与复核，但仍有字段待补全；回答时须明确证据边界。",
          },
        },
        sourceHash: createHash("sha256").update(`${document.sourceHash}\n${status}`).digest("hex"),
      };
    }),
  };
}

function snapshotVersion(documents: RagDocument[]): string {
  return createHash("sha256")
    .update(`${EMBEDDING_SCHEMA_VERSION}\n${documents.map((document) => `${document.id}:${document.sourceHash}`).sort().join("\n")}`)
    .digest("hex")
    .slice(0, 16);
}

async function loadReviewedSnapshot(config: AppConfig): Promise<{
  sourcePaths: string[];
  discovered: RagDocument[];
  documents: RagDocument[];
  publishReadyIds: Set<string>;
}> {
  const sourcePaths = CARD_FILES.map((name) => join(config.ragRoot, "cards", name));
  const groups = await Promise.all(sourcePaths.map(loadRagDocuments));
  const discovered = groups.flat();
  const reviewed = reviewedDocumentsWithQuality(discovered);
  return { sourcePaths, discovered, ...reviewed };
}

export async function syncOceanRagLexical(config: AppConfig, store: RagStore): Promise<IndexResult> {
  const { sourcePaths, discovered, documents, publishReadyIds } = await loadReviewedSnapshot(config);
  const version = snapshotVersion(documents);
  const quarantinedPapers = documents.filter((document) => document.cardType === "problem_solution" && !publishReadyIds.has(document.id)).length;
  if (store.getMeta("index_version") === version && store.count() === documents.length) {
    return {
      discovered: discovered.length,
      eligible: documents.length,
      quarantined: quarantinedPapers,
      embedded: 0,
      removed: 0,
      version,
    };
  }
  for (const document of documents) store.upsertLexical(document);
  const removed = store.removeMissing(new Set(documents.map((document) => document.id)), sourcePaths);
  store.setMeta("index_version", version);
  store.setMeta("global_graph_version", version);
  store.setMeta("indexed_at", new Date().toISOString());
  store.setMeta("index_mode", "local_lexical_with_optional_embeddings");
  store.setMeta("quality_quarantined", String(quarantinedPapers));
  return {
    discovered: discovered.length,
    eligible: documents.length,
    quarantined: quarantinedPapers,
    embedded: 0,
    removed,
    version,
  };
}

function embeddingText(document: RagDocument): string {
  if (document.cardType === "problem_solution") {
    const field = document.payload.research_field as Record<string, unknown> | undefined;
    const primary = researchFieldLabel(String(field?.primary ?? "unresolved"));
    const secondary = Array.isArray(field?.secondary)
      ? field.secondary.map((code) => researchFieldLabel(String(code))).join("、")
      : "";
    return [
      "Represent this ocean-science research problem and its reported high-level solution.",
      `Primary research field: ${primary}`,
      `Secondary research fields: ${secondary}`,
      document.content,
    ].join("\n");
  }
  if (document.cardType === "dataset") {
    return [
      "Represent this reusable authoritative data product for direct dataset discovery.",
      document.content,
    ].join("\n");
  }
  return [
    "Usage bundles are stored for exact lookup and are not semantic-search documents.",
    `Bundle ID: ${document.id}`,
  ].join("\n");
}

export async function indexOceanRag(
  config: AppConfig,
  store: RagStore,
  client: DashScopeEmbeddingClient,
  onProgress?: (progress: IndexProgress) => void,
  options: IndexOptions = {},
): Promise<IndexResult> {
  const { sourcePaths, discovered: discoveredDocuments, documents, publishReadyIds } = await loadReviewedSnapshot(config);
  const quarantinedPapers = documents.filter((document) => document.cardType === "problem_solution" && !publishReadyIds.has(document.id)).length;
  const validIds = new Set(documents.map((document) => document.id));
  const embeddable = documents.filter((document) => document.cardType !== "usage_bundle");
  const embeddingSchemaChanged = store.getMeta("embedding_schema_version") !== EMBEDDING_SCHEMA_VERSION;
  const pending = options.force || embeddingSchemaChanged
    ? embeddable
    : embeddable.filter((document) => store.needsEmbedding(document, client.model, client.dimensions));

  for (const document of documents.filter((item) => item.cardType === "usage_bundle")) {
    store.upsert(document, null);
  }

  let completed = 0;
  for (let offset = 0; offset < pending.length; offset += 20) {
    if (options.signal?.aborted) throw new Error("RAG索引已取消");
    const batch = pending.slice(offset, offset + 20);
    onProgress?.({ completed, total: pending.length, message: `正在嵌入 ${offset + 1}-${offset + batch.length}` });
    const embeddings = await client.embed(batch.map(embeddingText), options.signal);
    batch.forEach((document, index) => {
      const embedding = embeddings[index];
      if (!embedding) throw new Error(`缺少文档 ${document.id} 的向量`);
      store.upsert(document, embedding, client.model, client.dimensions);
    });
    completed += batch.length;
    onProgress?.({ completed, total: pending.length, message: `已嵌入 ${completed}/${pending.length}` });
  }

  const removed = store.removeMissing(validIds, sourcePaths);
  const version = snapshotVersion(documents);
  store.setMeta("index_version", version);
  // The runtime graph is a deterministic projection of this reviewed
  // snapshot, so its trace version intentionally matches the indexed cards.
  store.setMeta("global_graph_version", version);
  store.setMeta("embedding_model", client.model);
  store.setMeta("embedding_dimensions", String(client.dimensions));
  store.setMeta("embedding_schema_version", EMBEDDING_SCHEMA_VERSION);
  store.setMeta("indexed_at", new Date().toISOString());
  store.setMeta("index_mode", "hybrid_embeddings_and_lexical");
  store.setMeta("quality_quarantined", String(quarantinedPapers));

  return {
    discovered: discoveredDocuments.length,
    eligible: documents.length,
    quarantined: quarantinedPapers,
    embedded: pending.length,
    removed,
    version,
  };
}
