/** Task-scoped evaluation trace. Only metadata from observed calls is persisted. */
import { AsyncLocalStorage } from "node:async_hooks";
import { createHash, randomUUID } from "node:crypto";
import { appendFileSync, existsSync, mkdirSync, readFileSync, renameSync, writeFileSync } from "node:fs";
import { basename, join, resolve } from "node:path";
import { arch, hostname, platform, release } from "node:os";
import type { ModelRuntime } from "@earendil-works/pi-coding-agent";
import type { ResearchPlan } from "../contracts.js";
import type { DatasetRecommendation } from "../experiments/scientific-protocol.js";

type Terminal = "completed" | "failed" | "failed_safe" | "cancelled" | "unknown" | "awaiting_approval" | "partial";
type Scope = { trace: RunTelemetry; agentId: string; parentSpanId: string | null };
const scope = new AsyncLocalStorage<Scope>();
const installed = new WeakSet<ModelRuntime>();
const iso = () => new Date().toISOString();
export const hashText = (value: string) => createHash("sha256").update(value).digest("hex");
const hashJson = (value: unknown): string | null => {
  try { const serialized = JSON.stringify(value); return serialized === undefined ? null : hashText(serialized); }
  catch { return null; }
};
const safeId = (value: string) => value.replace(/[^\w.-]/g, "_").slice(0, 96);
const object = (value: unknown): Record<string, unknown> => value && typeof value === "object"
  ? value as Record<string, unknown> : {};
const strings = (value: unknown): string[] => Array.isArray(value)
  ? value.filter((item): item is string => typeof item === "string" && Boolean(item)) : [];
const number = (value: unknown): number | null => typeof value === "number" && Number.isFinite(value) && value >= 0
  ? value : null;

const secretKey = /^(?:authorization|auth|session|proxy[-_]authorization|cookie|set[-_]cookie|passwd|(?:.*[-_])?(?:api[-_]?key|password|secret|credentials)|access[-_]?token|refresh[-_]?token|token|signature|x-amz-(?:credential|signature|security-token))$/i;
/** Event contexts may contain URLs/errors; never persist credentials from either. */
export function redactTelemetry(value: unknown, key = ""): unknown {
  if (secretKey.test(key)) return "[REDACTED]";
  if (typeof value === "string") return value
    // Redact natural-language credentials before URL encoding can remove word boundaries.
    .replace(/\bBearer\s+[^\s,;"']+/gi, "Bearer [REDACTED]")
    .replace(/\b((?:api[-_]?key|access[-_]?token|refresh[-_]?token|password|secret|token)\s*[=:]\s*)[^\s&,;"']+/gi, "$1[REDACTED]")
    .replace(/https?:\/\/[^\s<>"']+/gi, (raw) => {
      try {
        const url = new URL(raw);
        if (url.username) url.username = "REDACTED";
        if (url.password) url.password = "REDACTED";
        for (const name of [...url.searchParams.keys()]) if (secretKey.test(name)) url.searchParams.set(name, "REDACTED");
        return url.toString();
      } catch { return "[INVALID_URL]"; }
    });
  if (Array.isArray(value)) return value.map((item) => redactTelemetry(item));
  if (value && typeof value === "object") return Object.fromEntries(Object.entries(value)
    .map(([name, item]) => [name, redactTelemetry(item, name)]));
  return value;
}

const lifecycleAliases: Record<string, string> = {
  "run.started": "task_start", "knowledge.retrieved": "knowledge_retrieval",
  "knowledge.route_candidate": "dataset_recommendation", "plan.generated": "plan_generated",
  "plan.step.started": "step_execution", "plan.step.completed": "step_execution",
  "plan.step.failed": "step_execution", "run.finished": "task_finish",
};
const eventStatus = (event: string, payload: Record<string, unknown>): string => {
  if (typeof payload.status === "string") return payload.status;
  if (typeof payload.terminal_status === "string") return payload.terminal_status;
  if (typeof payload.request_status === "string") return payload.request_status;
  if (/failed|failure/.test(event)) return "failed";
  if (/started|_start$|_attempt$/.test(event)) return "started";
  return "completed";
};

export function currentTelemetry(): Scope | undefined { return scope.getStore(); }
export function withRunTelemetry<T>(trace: RunTelemetry, work: () => Promise<T>): Promise<T> {
  return scope.run({ trace, agentId: "OceanAgent", parentSpanId: null }, work);
}
export function withSubagentTelemetry<T>(subagentId: string, parentSpanId: string, work: () => Promise<T>): Promise<T> {
  const current = scope.getStore();
  return current ? scope.run({ trace: current.trace, agentId: subagentId, parentSpanId }, work) : work();
}

interface ToolStart { callId: string; retrievalId: string; name: string; agentId: string; parentSpanId: string | null; start: number; at: string; stepId?: string }
interface RunStart {
  taskId: string; runId: string; inputHash: string; model: string; provider: string | null;
  configHash: string; gitCommit: string | null; datasetSnapshot: string | null;
  knowledgeSnapshot: string | null; knowledgeMode: "on" | "off";
  /** Caller supplies verified runtime details; absent Python/version data stays unknown. */
  pythonExecutable?: string | null; pythonVersion?: string | null; configVersion?: string | null;
  runKind?: "agent" | "smoke_test" | "test" | "deterministic_integration";
  experiment?: Record<string, unknown>;
}

export class RunTelemetry {
  hasRetrievedCard(id: string): boolean { return this.retrieved.has(id); }

  recommendationSubmitted(value: DatasetRecommendation): void {
    this.writeJson(join(this.runDir, "recommendation.json"), value);
    this.emit("dataset_recommendation", { status: "submitted", contract_version: value.schema_version,
      ranking_semantics: value.ranking_semantics, candidate_sha256: value.candidate_sha256,
      candidates: value.candidates, scientific_acceptance: null });
  }
  readonly runDir: string;
  readonly eventsPath: string;
  readonly summaryPath: string;
  readonly environmentId: string;
  readonly environment: Record<string, unknown>;
  private readonly applicationRoot: string;
  private readonly startedAt = iso();
  private readonly startClock = performance.now();
  private seq = 0;
  private finished = false;
  private writeFailures = 0;
  private readonly tools = new Map<string, ToolStart>();
  private readonly retrieved = new Map<string, string>();
  private readonly selected = new Set<string>();
  private readonly artifacts = new Map<string, string | null>();
  private readonly artifactDetails = new Map<string, Record<string, unknown>>();
  private readonly datasetAssets = new Map<string, Record<string, unknown>>();
  private latestPlanId: string | null = null;
  private executionPlan: ResearchPlan | null = null;
  private reportPath: string | null = null;
  private hasTransportByteTotals = false;
  private readonly stats = {
    llmCalls: 0, llmFailed: 0, llmUsageComplete: 0, cacheComplete: 0,
    input: 0, inclusiveInput: 0, inclusiveComplete: 0, output: 0, cache: 0,
    cacheWrite: 0, cacheWriteComplete: 0, toolCalls: 0, toolFailed: 0,
    downloadAttempts: 0, downloadBytes: 0, downloadRetries: 0,
    retries: 0, subagents: 0, knowledgeRequests: 0,
    retrievedCards: 0, selectedCards: 0, usedInPlan: 0,
    datasetReadRefs: 0,
  };

  constructor(root: string, private readonly meta: RunStart) {
    this.applicationRoot = resolve(root, "..");
    this.environment = {
      platform: platform(), architecture: arch(), os_release: release(), node_version: process.version,
      // A host name can contain a person's name. Keep a stable comparison key without exposing it.
      hostname_sha256: hashText(hostname()),
      python_executable: meta.pythonExecutable ?? null, python_version: meta.pythonVersion ?? null,
      config_version: meta.configVersion ?? null, telemetry_schema_version: "2.0",
    };
    this.environmentId = hashText(JSON.stringify(this.environment));
    this.runDir = join(root, "OceanAgent", safeId(meta.taskId), safeId(meta.runId));
    mkdirSync(this.runDir, { recursive: true });
    this.eventsPath = join(this.runDir, "events.jsonl");
    this.summaryPath = join(this.runDir, "summary.json");
    writeFileSync(this.eventsPath, "", { flag: "wx" });
    this.emit("run.started", {
      started_at: this.startedAt, model: meta.model, provider: meta.provider,
      knowledge_mode: meta.knowledgeMode, input_sha256: meta.inputHash,
      config_sha256: meta.configHash, git_commit: meta.gitCommit,
      data_snapshot_id: meta.datasetSnapshot, knowledge_snapshot_id: meta.knowledgeSnapshot,
      environment: this.environment, environment_id: this.environmentId,
      run_kind: meta.runKind ?? "agent", log_origin: "native_runtime",
      experiment: meta.experiment ?? null,
    });
    this.writeManifest("running");
  }

  emit(eventType: string, payload: Record<string, unknown>, agentId = currentTelemetry()?.agentId ?? "OceanAgent"): void {
    if (this.finished) return;
    if (eventType === "download_attempt" && (payload.status === "started" || payload.status === undefined)) {
      this.stats.downloadAttempts += 1;
      if ((number(payload.retry_count) ?? 0) > 0) this.stats.downloadRetries += 1;
    }
    const transportTotal = number(payload.downloaded_bytes_total);
    if (transportTotal !== null) {
      this.hasTransportByteTotals = true;
      // The acquisition context shares one run budget; includes metadata,
      // pilots, failed transfers and retries. Completion events are not additive.
      this.stats.downloadBytes = Math.max(this.stats.downloadBytes, transportTotal);
    }
    if (eventType === "download_complete") {
      if (!this.hasTransportByteTotals) this.stats.downloadBytes +=
        number(payload.download_bytes ?? payload.downloaded_bytes ?? payload.bytes) ?? 0;
      if (typeof payload.dataset_id === "string") this.datasetAssets.set(payload.dataset_id, payload);
    }
    try {
      const status = eventStatus(eventType, payload);
      const write = (type: string) => appendFileSync(this.eventsPath, JSON.stringify({
        schema_version: "2.0", event_id: randomUUID(), seq: ++this.seq,
        event_type: type, timestamp_utc: iso(), agent_id: agentId,
        task_id: this.meta.taskId, run_id: this.meta.runId,
        experiment: this.meta.experiment ?? null,
        environment_id: this.environmentId, runtime_platform: this.environment.platform,
        log_origin: "native_runtime", run_kind: this.meta.runKind ?? "agent",
        stage: lifecycleAliases[eventType] ?? eventType.split(".")[0], status,
        payload: redactTelemetry(payload),
      }) + "\n", "utf8");
      write(eventType);
      const alias = lifecycleAliases[eventType];
      if (alias) write(alias);
      if (eventType === "run.finished" && ["failed", "failed_safe", "cancelled", "partial"].includes(status)) write("task_failure");
    } catch (error) {
      this.writeFailures += 1;
      console.error("评价事件写入失败，科研执行继续：", error);
    }
  }

  private writeJson(path: string, value: unknown): void {
    try {
      writeFileSync(path + ".tmp", JSON.stringify(redactTelemetry(value), null, 2) + "\n", "utf8");
      renameSync(path + ".tmp", path);
    } catch { this.writeFailures += 1; }
  }

  private writeManifest(status: string): void {
    this.writeJson(join(this.runDir, "manifest.json"), {
      schema_version: "2.0", run_id: this.meta.runId, task_id: this.meta.taskId,
      started_at_utc: this.startedAt, updated_at_utc: iso(), status,
      environment_id: this.environmentId, environment: this.environment,
      log_origin: "native_runtime", run_kind: this.meta.runKind ?? "agent",
      experiment: this.meta.experiment ?? null,
      plan_id: this.latestPlanId, plan_path: this.latestPlanId ? join(this.runDir, "plan.json") : null,
      report_path: this.reportPath, events_path: this.eventsPath,
      metrics_path: join(this.runDir, "metrics.json"),
      datasets: [...this.datasetAssets.values()],
      output_artifacts: [...this.artifacts.entries()].map(([id, sha256]) => ({ id, sha256,
        ...this.artifactDetails.get(id) })),
    });
  }

  reportGenerated(markdown: string, context: Record<string, unknown> = {}): void {
    if (this.finished) return;
    this.reportPath = join(this.runDir, "report.md");
    try { writeFileSync(this.reportPath, String(redactTelemetry(markdown)), "utf8"); }
    catch { this.writeFailures += 1; }
    this.emit("report_generated", { ...context, output_path: this.reportPath,
      sha256: hashText(String(redactTelemetry(markdown))) });
    this.writeManifest("running");
  }

  transition(from: string, to: string, reasonCode: string | null = null): void {
    this.emit("agent.transition", { from, to, reason_code: reasonCode });
  }

  /** Preserve the approved Plan in its execution run without logging a second generation. */
  setExecutionPlan(plan: ResearchPlan): void {
    if (this.finished) return;
    this.executionPlan = plan;
    this.latestPlanId = plan.id;
    this.writeJson(join(this.runDir, "plan.json"), plan);
    this.writeManifest("running");
    this.emit("plan.execution_context", { plan_id: plan.id, step_ids: plan.steps.map(step => step.id),
      dataset_ids: plan.datasets, evidence_refs: plan.evidenceRefs ?? [], selected_in_prior_plan: true });
  }

  toolStarted(callId: string, name: string, args?: unknown): void {
    const context = currentTelemetry();
    const agentId = context?.agentId ?? "OceanAgent";
    const key = `${agentId}:${callId}`;
    if (this.tools.has(key)) return;
    const at = iso();
    const retrievalId = randomUUID();
    const requestedStep = object(args).planStepId;
    const stepId = ["bash", "powershell", "run_remote_command"].includes(name)
      && typeof requestedStep === "string" && this.executionPlan?.steps.some(step => step.id === requestedStep)
      ? requestedStep : undefined;
    this.tools.set(key, { callId, retrievalId, name, agentId,
      parentSpanId: context?.parentSpanId ?? null, start: performance.now(), at, stepId });
    this.stats.toolCalls += 1;
    this.emit("tool.started", { call_id: callId, tool_name: name, started_at: at,
      parent_span_id: context?.parentSpanId ?? null,
      input_sha256: args === undefined ? null : hashJson(args) });
    if (stepId) this.emit("plan.step.started", { step_id: stepId, plan_id: this.executionPlan!.id,
      tool_name: name, tool_call_id: callId, execution_scope: "shell_tool_call", method: "observed_tool_execution",
      completion_semantics: "one associated shell call; not independent scientific step acceptance" }, agentId);
    if (["search_research_cases", "expand_research_case", "search_ocean_datasets",
      "assess_dataset_routes", "get_dataset_facts", "trace_global_knowledge_graph"].includes(name)) {
      this.stats.knowledgeRequests += 1;
      this.emit("knowledge.requested", { retrieval_id: retrievalId, tool_call_id: callId, tool_name: name,
        query_sha256: args === undefined ? null : hashJson(args),
        knowledge_snapshot_id: this.meta.knowledgeSnapshot });
    }
  }

  toolEnded(callId: string, failed: boolean, result?: unknown, errorCode?: string | null, agentId = currentTelemetry()?.agentId ?? "OceanAgent"): void {
    const key = `${agentId}:${callId}`;
    const started = this.tools.get(key);
    if (!started) return;
    this.tools.delete(key);
    const details = object(object(result).details);
    const sdkIsError = failed;
    // The acquisition tool returns a recoverable structured failure to the model.
    // A normal SDK return is not proof that the requested acquisition succeeded.
    failed ||= started.name === "acquire_scientific_data" && typeof details.errorType === "string";
    if (failed) this.stats.toolFailed += 1;
    const durationMs = Math.max(0, performance.now() - started.start);
    const outputHash = result === undefined ? null : hashJson(result);
    this.emit(failed ? "tool.failed" : "tool.completed", {
      call_id: callId, tool_name: started.name, parent_span_id: started.parentSpanId,
      started_at: started.at, ended_at: iso(), duration_ms: durationMs,
      result_status: failed ? "failed" : "completed",
      sdk_is_error: sdkIsError,
      error_code: errorCode ?? (typeof details.errorCode === "string" ? details.errorCode
        : typeof details.errorType === "string" ? details.errorType : failed ? "TOOL_ERROR" : null),
      retry_count: null, output_sha256: outputHash,
    }, started.agentId);
    if (started.stepId) {
      const step = this.executionPlan!.steps.find(item => item.id === started.stepId)!;
      const verifiedFiles = Array.isArray(object(step.inputs).verifiedDataFiles)
        ? object(step.inputs).verifiedDataFiles as unknown[] : [];
      this.emit(failed ? "plan.step.failed" : "plan.step.completed", {
        step_id: started.stepId, plan_id: this.executionPlan!.id,
        tool_name: started.name, tool_call_id: callId, started_at: started.at, ended_at: iso(),
        duration_ms: durationMs, execution_scope: "shell_tool_call", method: "observed_tool_execution",
        completion_semantics: "one associated shell call; not independent scientific step acceptance",
        error_code: errorCode ?? (failed ? "TOOL_ERROR" : null),
        exit_code: typeof details.exitCode === "number" ? details.exitCode : null,
        declared_input_paths: verifiedFiles.map(item => object(item).path).filter(item => typeof item === "string"),
        stdout_path: details.stdoutPath ?? null, stderr_path: details.stderrPath ?? null,
        output_path: details.outputPath ?? null,
      }, started.agentId);
    }
    if (!failed && details.recommendation_cache_hit === true) {
      this.emit("tool.cache_hit", { tool_name: started.name, tool_call_id: callId,
        cache_scope: "agent_session", original_tool_call_id: details.original_tool_call_id ?? null }, started.agentId);
    } else if (!failed) this.knowledgeFromTool(started.name, started.retrievalId, details);
    if (!failed && started.name === "record_dataset_read") {
      this.emit("data.asset", { dataset_id: details.datasetId ?? null,
        asset_id: typeof details.sha256 === "string" ? details.sha256 : null,
        source_sha256: details.sha256 ?? null, plan_step_id: details.planStepId ?? null,
        operation: "read", output_path: details.path ?? null, size_bytes: number(details.sizeBytes) }, started.agentId);
      if (typeof details.datasetId === "string" && details.identity_source === "dataset_card") {
        this.stats.datasetReadRefs += 1;
        this.emit("knowledge.used", { card_id: details.datasetId,
          plan_step_id: details.planStepId ?? null, tool_call_id: callId,
          relation: "dataset_card_associated_with_file_read", verified_by: "record_dataset_read_sha256",
          scientific_compute_usage: null,
          evidence_semantics: "A selected DatasetCard was associated with a file read; this is not proof of its use in a scientific calculation." }, started.agentId);
      }
    }
    if (!failed && started.name === "complete_research_plan") {
      for (const item of Array.isArray(details.artifacts) ? details.artifacts : []) {
        const artifact = object(item);
        if (typeof artifact.name !== "string") continue;
        const sha = typeof artifact.sha256 === "string" ? artifact.sha256 : null;
        this.artifacts.set(artifact.name, sha);
        const published = join(this.applicationRoot, "data", "artifacts", this.meta.runId, artifact.name);
        const artifactInfo = { url: typeof artifact.url === "string" ? artifact.url : null,
          size_bytes: number(artifact.sizeBytes),
          output_path: artifact.name === basename(artifact.name) && existsSync(published) ? published : null };
        this.artifactDetails.set(artifact.name, artifactInfo);
        this.emit("artifact.produced", { artifact_id: artifact.name, sha256: sha,
          artifact_type: "research_output", ...artifactInfo }, started.agentId);
      }
      this.emit("science.validation", { check_id: "agent_supplied_manifest", verdict: "unverified",
        validator_id: "complete_research_plan_self_check", reference_sha256: null }, started.agentId);
    }
  }

  private markRetrieved(retrievalId: string, cards: Array<{ id: string; type: string; rank: number }>, queryId: string | null = null): void {
    const unique = cards.filter((item) => item.id && item.type);
    for (const card of unique) if (!this.retrieved.has(card.id)) {
      this.retrieved.set(card.id, retrievalId);
      this.stats.retrievedCards += 1;
    }
    this.emit("knowledge.retrieved", { retrieval_id: retrievalId, query_id: queryId,
      card_ids: unique.map((item) => item.id), card_types: unique.map((item) => item.type),
      ranks: unique.map((item) => item.rank), knowledge_snapshot_id: this.meta.knowledgeSnapshot });
  }

  private selectCard(id: string, reason: string, planId: string | null = null): void {
    const retrievalId = this.retrieved.get(id);
    if (!retrievalId) return; // A card hit is not proof that it was selected.
    if (!this.selected.has(id)) this.stats.selectedCards += 1;
    this.selected.add(id);
    this.emit("knowledge.selected", { card_id: id, retrieval_id: retrievalId,
      reason, plan_id: planId });
  }

  private knowledgeFromTool(name: string, callId: string, details: Record<string, unknown>): void {
    if (name === "search_research_cases" || name === "search_ocean_datasets") {
      const cards = (Array.isArray(details.results) ? details.results : []).map((value, index) => {
        const item = object(value);
        return { id: String(item.id ?? ""), type: String(item.cardType ?? ""),
          rank: number(item.retrievalRank) ?? index + 1 };
      });
      this.markRetrieved(callId, cards);
      if (name === "search_ocean_datasets") this.emit("dataset_recommendation", {
        retrieval_id: callId, dataset_ids: cards.map((card) => card.id),
        evidence_ids: cards.map((card) => card.id),
      });
    } else if (name === "assess_dataset_routes") {
      const cards = (Array.isArray(details.assessments) ? details.assessments : []).map((value, index) => {
        const item = object(value);
        return { id: String(item.candidate_id ?? ""), type: String(item.card_type ?? ""),
          rank: number(item.rank) ?? index + 1 };
      });
      this.markRetrieved(callId, cards, typeof details.queryId === "string" ? details.queryId : null);
      for (const bundle of Array.isArray(details.bundles) ? details.bundles : []) {
        this.emit("knowledge.route_candidate", { retrieval_id: callId,
          dataset_ids: strings(object(bundle).datasetIds), evidence_refs: strings(object(bundle).evidenceRefs) });
      }
    } else if (name === "expand_research_case") {
      const problem = object(details.problem), bundle = object(details.bundle);
      if (typeof problem.id === "string" && this.retrieved.has(problem.id)) {
        this.selectCard(problem.id, "explicit_case_expansion");
        const linked = [bundle.id, ...strings(details.datasetIds)].filter((id): id is string => typeof id === "string");
        this.emit("knowledge.linked", { retrieval_id: this.retrieved.get(problem.id),
          problem_solution_card_id: problem.id, usage_bundle_card_id: bundle.id ?? null,
          dataset_card_ids: strings(details.datasetIds), graph_version: object(details.graphTrace).graphVersion ?? null });
        this.markRetrieved(callId, linked.map((id, rank) => ({ id, type: rank === 0 ? "usage_bundle" : "dataset", rank: rank + 1 })));
      }
    } else if (name === "get_dataset_facts") {
      const cards = (Array.isArray(details.documents) ? details.documents : []).map((value, index) => ({
        id: String(object(value).id ?? ""), type: "dataset", rank: index + 1,
      }));
      this.markRetrieved(callId, cards);
      for (const card of cards) this.selectCard(card.id, "explicit_dataset_facts_request");
    } else if (name === "trace_global_knowledge_graph") {
      const paths = Array.isArray(details.paths) ? details.paths : [];
      const bundles = [...new Set(paths.flatMap((value) => strings(object(value).bundleIds)))];
      const datasets = [...new Set(paths.flatMap((value) => [object(value).fromDatasetId,
        object(value).toDatasetId].filter((id): id is string => typeof id === "string")))];
      this.markRetrieved(callId, [
        ...bundles.map((id, index) => ({ id, type: "usage_bundle", rank: index + 1 })),
        ...datasets.map((id, index) => ({ id, type: "dataset", rank: bundles.length + index + 1 })),
      ]);
    }
  }

  planGenerated(plan: ResearchPlan): void {
    this.latestPlanId = plan.id;
    this.writeJson(join(this.runDir, "plan.json"), plan);
    this.writeManifest("running");
    this.emit("plan.generated", { plan_id: plan.id, task_id: plan.taskId ?? this.meta.taskId,
      method_family: plan.methodFamily ?? null, dataset_ids: plan.datasets,
      evidence_refs: plan.evidenceRefs ?? [], retrieval_query_id: plan.retrievalTrace?.queryId ?? null });
    for (const id of plan.datasets) this.selectCard(id, "selected_in_plan", plan.id);
    for (const ref of plan.evidenceRefs ?? []) if (this.retrieved.has(ref)) {
      this.selectCard(ref, "cited_in_plan", plan.id);
    }
    for (const step of plan.steps) {
      const inputs = object(step.inputs);
      const refs = strings(inputs.evidenceRefs ?? inputs.evidence_refs ?? inputs.supports);
      this.emit("plan.step", { step_id: step.id, plan_id: plan.id,
        status: "generated", operator: step.tool ?? null, evidence_ids: refs,
        input_artifact_ids: [], output_artifact_ids: [] });
      for (const id of refs) if (this.retrieved.has(id)) {
        this.stats.usedInPlan += 1;
        this.emit("knowledge.used", { plan_step_id: step.id, plan_id: plan.id,
          card_id: id, relation: "explicit_step_evidence_ref",
          retrieval_id: this.retrieved.get(id), verified_by: null });
      }
    }
  }

  retry(operation: string, attempt: number | null = null): void {
    this.stats.retries += 1;
    this.emit("operation.retry", { operation, attempt_number: attempt,
      reason_code: "SDK_REPORTED_RETRY", parent_span_id: currentTelemetry()?.parentSpanId ?? null });
  }

  subagentStarted(id: string, parentCallId: string): void {
    this.stats.subagents += 1;
    this.emit("subagent.started", { subagent_id: id, role: "research_subtask",
      parent_agent_id: "OceanAgent", parent_span_id: `OceanAgent:${parentCallId}` });
  }
  subagentFinished(id: string, status: string): void {
    this.emit("subagent.finished", { subagent_id: id, terminal_status: status });
  }

  llmStarted(model: string, provider: string, agentId: string, parentSpanId: string | null) {
    const id = randomUUID();
    const at = iso(), start = performance.now();
    this.stats.llmCalls += 1;
    this.emit("llm.started", { call_id: id, model, provider, started_at: at,
      parent_span_id: parentSpanId, retry_attempt: null }, agentId);
    let ended = false;
    return (response: unknown, errorType: string | null = null) => {
      if (ended) return;
      ended = true;
      const message = object(response), usage = object(message.usage);
      const input = number(usage.input), output = number(usage.output);
      const total = number(usage.totalTokens);
      // Pi's normalized usage can contain zero placeholders if a provider sent no usage.
      const hasUsage = input !== null && output !== null && (input + output > 0 || (total ?? 0) > 0);
      const cache = hasUsage && number(usage.cacheRead) !== null && Number(usage.cacheRead) > 0
        ? Number(usage.cacheRead) : null;
      const cacheWrite = hasUsage && (number(usage.cacheWrite) ?? 0) > 0 ? Number(usage.cacheWrite) : null;
      // Pi input excludes cache reads/writes; totalTokens includes both. Keep the
      // raw non-cached value separately and use inclusive input for comparisons.
      const inclusiveInput = hasUsage && total !== null && total >= input! + output!
        ? total - output! : null;
      if (hasUsage) { this.stats.llmUsageComplete += 1; this.stats.input += input!; this.stats.output += output!; }
      if (inclusiveInput !== null) { this.stats.inclusiveComplete += 1; this.stats.inclusiveInput += inclusiveInput; }
      if (cache !== null) { this.stats.cacheComplete += 1; this.stats.cache += cache; }
      if (cacheWrite !== null) { this.stats.cacheWriteComplete += 1; this.stats.cacheWrite += cacheWrite; }
      if (errorType) this.stats.llmFailed += 1;
      this.emit(errorType ? "llm.failed" : "llm.completed", { call_id: id, model, provider,
        started_at: at, ended_at: iso(), duration_ms: Math.max(0, performance.now() - start),
        input_tokens: inclusiveInput, non_cached_input_tokens: hasUsage ? input : null,
        input_token_semantics: "includes_cache_read_and_cache_write", output_tokens: hasUsage ? output : null,
        total_tokens: inclusiveInput !== null ? inclusiveInput + output! : null,
        sdk_total_tokens: hasUsage ? total : null,
        cached_input_tokens: cache, cache_write_input_tokens: cacheWrite,
        request_status: errorType ? "failed" : "completed",
        stop_reason: typeof message.stopReason === "string" ? message.stopReason : null,
        error_type: errorType, retry_attempt: null, actual_cost_usd: null,
        estimated_cost_usd: null }, agentId);
    };
  }

  finish(status: Terminal, errorCode: string | null = null): void {
    if (this.finished) return;
    for (const pending of [...this.tools.values()]) {
      this.toolEnded(pending.callId, true, undefined, "RUN_TERMINATED", pending.agentId);
    }
    const endedAt = iso();
    const elapsed = Math.max(0, (performance.now() - this.startClock) / 1000);
    this.emit("run.finished", { terminal_status: status, error_code: errorCode,
      ended_at: endedAt, duration_seconds: elapsed,
      output_artifacts: [...this.artifacts.entries()].map(([id, sha256]) => ({ id, sha256 })) });
    this.finished = true;
    const n = this.stats.llmCalls;
    const summary = {
      schema_version: "2.0", task_id: this.meta.taskId, run_id: this.meta.runId,
      agent_id: "OceanAgent", started_at_utc: this.startedAt, ended_at_utc: endedAt,
      environment_id: this.environmentId, environment: this.environment,
      log_origin: "native_runtime", run_kind: this.meta.runKind ?? "agent",
      experiment: this.meta.experiment ?? null,
      wall_time_seconds: elapsed, terminal_status: status, error_code: errorCode,
      model: this.meta.model, provider: this.meta.provider, knowledge_mode: this.meta.knowledgeMode,
      input_sha256: this.meta.inputHash, config_sha256: this.meta.configHash,
      git_commit: this.meta.gitCommit, data_snapshot_id: this.meta.datasetSnapshot,
      knowledge_snapshot_id: this.meta.knowledgeSnapshot,
      trace_write_failures: this.writeFailures,
      llm_calls: this.writeFailures ? null : n,
      llm_failed_calls: this.writeFailures ? null : this.stats.llmFailed,
      tool_calls: this.writeFailures ? null : this.stats.toolCalls,
      tool_failed_calls: this.writeFailures ? null : this.stats.toolFailed,
      retries_observed: this.writeFailures ? null : this.stats.retries + this.stats.downloadRetries,
      sdk_retries_observed: this.writeFailures ? null : this.stats.retries,
      input_tokens: !this.writeFailures && this.stats.inclusiveComplete === n ? this.stats.inclusiveInput : null,
      input_token_semantics: "includes_cache_read_and_cache_write",
      non_cached_input_tokens: !this.writeFailures && this.stats.llmUsageComplete === n ? this.stats.input : null,
      output_tokens: !this.writeFailures && this.stats.llmUsageComplete === n ? this.stats.output : null,
      total_tokens: !this.writeFailures && this.stats.inclusiveComplete === n && this.stats.llmUsageComplete === n
        ? this.stats.inclusiveInput + this.stats.output : null,
      cached_input_tokens: !this.writeFailures && this.stats.cacheComplete === n ? this.stats.cache : null,
      cache_write_input_tokens: !this.writeFailures && this.stats.cacheWriteComplete === n ? this.stats.cacheWrite : null,
      observed_input_tokens: this.writeFailures ? null : this.stats.inclusiveInput,
      observed_non_cached_input_tokens: this.writeFailures ? null : this.stats.input,
      observed_output_tokens: this.writeFailures ? null : this.stats.output,
      llm_usage_complete: !this.writeFailures && this.stats.llmUsageComplete === n && this.stats.inclusiveComplete === n,
      download_attempts: this.stats.downloadAttempts, download_bytes: this.stats.downloadBytes,
      download_retries: this.stats.downloadRetries,
      actual_cost_usd: null, actual_cost_complete: false,
      knowledge_retrieval_requests: this.writeFailures ? null : this.stats.knowledgeRequests,
      knowledge_retrieved_cards: this.writeFailures ? null : this.stats.retrievedCards,
      knowledge_selected_cards: this.writeFailures ? null : this.stats.selectedCards,
      knowledge_used_in_plan_refs: this.writeFailures ? null : this.stats.usedInPlan,
      knowledge_dataset_read_refs: this.writeFailures ? null : this.stats.datasetReadRefs,
      subagent_starts: this.writeFailures ? null : this.stats.subagents,
      output_artifacts: [...this.artifacts.entries()].map(([id, sha256]) => ({ id, sha256,
        ...this.artifactDetails.get(id) })),
      process_success: status === "completed" ? true : ["unknown", "awaiting_approval"].includes(status) ? null : false,
      execution_success: null,
      missing_reason: {
        input_tokens: this.writeFailures ? "trace write failure" : this.stats.inclusiveComplete < n ? "provider total usage unavailable on at least one observed call" : null,
        output_tokens: this.writeFailures ? "trace write failure" : this.stats.llmUsageComplete < n ? "provider usage unavailable on at least one observed call" : null,
        cached_input_tokens: this.writeFailures ? "trace write failure" : this.stats.cacheComplete < n ? "provider cache usage absent or zero is SDK-normalized and cannot be distinguished from missing" : null,
        actual_cost_usd: "no provider billing record attached to individual calls",
      },
      coverage_note: "Input includes cache reads/writes; non_cached_input_tokens preserves Pi usage.input. Calls cover ModelRuntime.streamSimple and Pi session tool events; SDK internal retries and direct embedding HTTP are unobserved. Dataset file reads do not prove scientific compute use. Cost and cache-zero semantics are unverified. Trace write failures invalidate complete counts.",
    };
    this.writeJson(this.summaryPath, summary);
    this.writeJson(join(this.runDir, "metrics.json"), summary);
    this.writeManifest(status);
  }
}

/** Mark a process crash on next startup; elapsed time and unobserved calls stay null. */
export function recoverInterruptedTelemetry(root: string, taskId: string, runId: string): void {
  const runDir = join(root, "OceanAgent", safeId(taskId), safeId(runId));
  const eventsPath = join(runDir, "events.jsonl"), summaryPath = join(runDir, "summary.json");
  if (!existsSync(eventsPath) || existsSync(summaryPath)) return;
  const events = readFileSync(eventsPath, "utf8").split(/\r?\n/).filter(Boolean).flatMap((line) => {
    try { return [JSON.parse(line) as Record<string, unknown>]; } catch { return []; }
  });
  if (!events.length || events.some((event) => event.event_type === "run.finished")) return;
  const started = events.find((event) => event.event_type === "run.started");
  const payload = object(started?.payload);
  // Recovery may run on a Mac against a copied Windows trace. Preserve the
  // original environment, or mark it unknown; never label it with this host.
  const origin = {
    environment_id: started?.environment_id ?? payload.environment_id ?? null,
    environment: payload.environment ?? null,
    log_origin: started?.log_origin ?? payload.log_origin ?? "legacy_unknown",
    run_kind: started?.run_kind ?? payload.run_kind ?? "legacy_unknown",
  };
  for (const [index, eventType] of ["run.finished", "task_finish", "task_failure"].entries()) {
    appendFileSync(eventsPath, JSON.stringify({ schema_version: "2.0", event_id: randomUUID(),
      seq: events.length + index + 1, event_type: eventType, timestamp_utc: iso(),
      stage: "task_finish", status: "failed", agent_id: "OceanAgent", task_id: taskId, run_id: runId,
      ...origin,
      payload: { terminal_status: "failed", error_code: "SERVER_RESTART",
        ended_at: null, recovered_at: iso(), duration_seconds: null } }) + "\n", "utf8");
  }
  const summary = { schema_version: "1.0", task_id: taskId, run_id: runId,
    ...origin,
    agent_id: "OceanAgent", started_at_utc: started?.timestamp_utc ?? null,
    ended_at_utc: null, recovered_at_utc: iso(), wall_time_seconds: null,
    terminal_status: "failed", error_code: "SERVER_RESTART",
    model: payload.model ?? null, provider: payload.provider ?? null,
    knowledge_mode: payload.knowledge_mode ?? null, input_sha256: payload.input_sha256 ?? null,
    config_sha256: payload.config_sha256 ?? null, git_commit: payload.git_commit ?? null,
    data_snapshot_id: payload.data_snapshot_id ?? null,
    knowledge_snapshot_id: payload.knowledge_snapshot_id ?? null,
    llm_calls: null, tool_calls: null, retries_observed: null,
    input_tokens: null, output_tokens: null, cached_input_tokens: null,
    actual_cost_usd: null, actual_cost_complete: false, llm_usage_complete: false,
    process_success: false, execution_success: null,
    coverage_note: "Process exited before telemetry finalized; end time, duration and complete counts are unavailable.",
  };
  writeFileSync(summaryPath, JSON.stringify(summary, null, 2) + "\n", { flag: "wx" });
  writeFileSync(join(runDir, "metrics.json"), JSON.stringify(summary, null, 2) + "\n", "utf8");
  const manifestPath = join(runDir, "manifest.json");
  let manifest: Record<string, unknown> = {};
  try { manifest = object(JSON.parse(readFileSync(manifestPath, "utf8"))); } catch { /* legacy trace */ }
  writeFileSync(manifestPath, JSON.stringify(redactTelemetry({ ...manifest,
    ...origin,
    run_id: runId, task_id: taskId, status: "failed", error_code: "SERVER_RESTART",
    updated_at_utc: iso(), events_path: eventsPath, metrics_path: join(runDir, "metrics.json"),
  }), null, 2) + "\n", "utf8");
}

/** One hook covers main/subagent streaming and SDK compaction through the shared runtime. */
export function installModelTelemetry(runtime: ModelRuntime): void {
  if (installed.has(runtime)) return;
  installed.add(runtime);
  const original = runtime.streamSimple.bind(runtime);
  runtime.streamSimple = ((model, context, options) => {
    const active = currentTelemetry();
    if (!active) return original(model, context, options);
    const stream = original(model, context, options);
    const end = active.trace.llmStarted(model.id, model.provider, active.agentId, active.parentSpanId);
    return new Proxy(stream, {
      get(target, property) {
        if (property === Symbol.asyncIterator) return async function* () {
          try {
            for await (const event of target) {
              if (event.type === "done") end(event.message,
                event.message.stopReason === "error" ? "MODEL_ERROR"
                  : event.message.stopReason === "aborted" ? "ABORTED" : null);
              if (event.type === "error") end(event.error, "MODEL_ERROR");
              yield event;
            }
          } catch (error) { end(null, error instanceof Error ? error.name : "STREAM_ERROR"); throw error; }
        };
        if (property === "result") return async () => {
          try {
            const result = await target.result();
            end(result, result.stopReason === "error" ? "MODEL_ERROR"
              : result.stopReason === "aborted" ? "ABORTED" : null);
            return result;
          } catch (error) {
            end(null, error instanceof Error ? error.name : "MODEL_ERROR");
            throw error;
          }
        };
        const value = Reflect.get(target, property, target) as unknown;
        return typeof value === "function" ? value.bind(target) : value;
      },
    });
  }) as ModelRuntime["streamSimple"];
}
