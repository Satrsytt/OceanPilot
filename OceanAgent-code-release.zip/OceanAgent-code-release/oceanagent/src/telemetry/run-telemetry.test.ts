import { mkdtempSync, readFileSync, rmSync } from "node:fs";
import { hostname, platform, tmpdir } from "node:os";
import { join } from "node:path";
import { afterEach, describe, expect, it } from "vitest";
import type { ResearchPlan } from "../contracts.js";
import { hashText, recoverInterruptedTelemetry, RunTelemetry } from "./run-telemetry.js";

const scratch: string[] = [];
afterEach(() => { for (const dir of scratch.splice(0)) rmSync(dir, { recursive: true, force: true }); });
function trace() {
  const root = mkdtempSync(join(tmpdir(), "ocean-telemetry-test-"));
  scratch.push(root);
  return { root, log: new RunTelemetry(root, {
    taskId: "task", runId: "run", inputHash: "input-hash", model: "offline", provider: null,
    configHash: "config-hash", gitCommit: null, datasetSnapshot: null,
    knowledgeSnapshot: null, knowledgeMode: "on",
  }) };
}
const json = (path: string) => JSON.parse(readFileSync(path, "utf8"));
const events = (log: RunTelemetry): Array<Record<string, any>> => readFileSync(log.eventsPath, "utf8")
  .trim().split("\n").map((line) => JSON.parse(line));

describe("native run telemetry", () => {
  it("logs cached read attempts without presenting a second backend retrieval as new evidence", () => {
    const { log } = trace();
    const details = { documents: [{ id: "dataset", cardType: "dataset" }] };
    log.toolStarted("first", "get_dataset_facts"); log.toolEnded("first", false, { details });
    log.toolStarted("cached", "get_dataset_facts"); log.toolEnded("cached", false, { details: {
      ...details, recommendation_cache_hit: true, original_tool_call_id: "first", cache_scope: "agent_session" } });
    log.finish("completed");
    const rows = events(log);
    expect(rows.filter(row => row.event_type === "knowledge.retrieved")).toHaveLength(1);
    expect(rows.find(row => row.event_type === "tool.cache_hit")?.payload).toMatchObject({
      tool_call_id: "cached", original_tool_call_id: "first", cache_scope: "agent_session" });
    expect(json(log.summaryPath)).toMatchObject({ tool_calls: 2, knowledge_retrieval_requests: 2 });
    expect(log.hasRetrievedCard("dataset")).toBe(true);
  });
  it("binds native events, manifest and metrics to the immutable experiment identity", () => {
    const root = mkdtempSync(join(tmpdir(), "ocean-experiment-telemetry-")); scratch.push(root);
    const experiment = { schema_version: "stage3-ablation-v1", experiment_id: "exp", unit_id: "u", condition: "A0" };
    const log = new RunTelemetry(root, { taskId: "task", runId: "run", inputHash: "i", configHash: "c",
      model: "offline", provider: null, gitCommit: null, datasetSnapshot: null, knowledgeSnapshot: null,
      knowledgeMode: "off", experiment });
    log.toolStarted("public", "record_dataset_read");
    log.toolEnded("public", false, { details: { datasetId: "official-data", path: "/tmp/local.json",
      identity_source: "validated_public_data", sha256: "sha", sizeBytes: 12 } });
    log.finish("awaiting_approval");
    expect(events(log).every(row => row.experiment?.unit_id === "u")).toBe(true);
    for (const file of ["manifest.json", "metrics.json"]) expect(json(join(log.runDir, file)).experiment).toEqual(experiment);
    expect(events(log).some(row => row.event_type === "data.asset")).toBe(true);
    expect(events(log).some(row => row.event_type === "knowledge.used")).toBe(false);
    expect(json(join(log.runDir, "metrics.json")).knowledge_dataset_read_refs).toBe(0);
  });
  it("persists acquisition, plan and report in one run directory with no credentials", () => {
    const { log } = trace();
    log.emit("access_resolution", { dataset_id: "oisst", status: "completed",
      url: "https://user:private@coastwatch.pfeg.noaa.gov/erddap?api_key=private-key&auth=private-auth",
      authorization: "Bearer private-bearer", password: "private-password" });
    log.emit("download_attempt", { dataset_id: "oisst", retry_count: 0, request_status: "started" });
    log.emit("download_attempt", { dataset_id: "oisst", retry_count: 0, status: "failed", downloaded_bytes_total: 32 });
    log.emit("download_attempt", { dataset_id: "oisst", retry_count: 1, request_status: "started" });
    log.emit("download_attempt", { dataset_id: "oisst", retry_count: 1, status: "response", downloaded_bytes_total: 1024 });
    log.emit("download_complete", { dataset_id: "oisst", download_bytes: 1024, output_path: "/tmp/subset.nc" });
    log.emit("data_validation", { dataset_id: "oisst", status: "completed", valid_samples: 12 });
    log.planGenerated({ id: "plan", datasets: ["oisst"], steps: [] } as unknown as ResearchPlan);
    log.emit("plan.step.started", { step_id: "step" });
    log.reportGenerated("# Result\n12 valid samples. Bearer private-output-token");
    log.finish("completed");
    const rows = events(log);
    for (const name of ["task_start", "access_resolution", "download_attempt", "download_complete",
      "data_validation", "plan_generated", "step_execution", "report_generated", "task_finish"]) {
      expect(rows.some((row) => row.event_type === name)).toBe(true);
    }
    for (const row of rows) expect(row).toMatchObject({ task_id: "task", run_id: "run" });
    expect(rows.every((row) => typeof row.stage === "string" && typeof row.status === "string")).toBe(true);
    const text = readFileSync(log.eventsPath, "utf8") + readFileSync(join(log.runDir, "report.md"), "utf8");
    for (const secret of ["private-key", "private-auth", "private-bearer", "private-password", "private-output-token", "user:private"]) {
      expect(text).not.toContain(secret);
    }
    expect(json(join(log.runDir, "metrics.json"))).toMatchObject({ download_bytes: 1024,
      download_attempts: 2, download_retries: 1, llm_calls: 0 });
    expect(json(join(log.runDir, "plan.json")).id).toBe("plan");
    expect(json(join(log.runDir, "manifest.json"))).toMatchObject({ status: "completed", plan_id: "plan" });
    expect(json(join(log.runDir, "manifest.json")).datasets[0].dataset_id).toBe("oisst");
    expect(json(join(log.runDir, "manifest.json"))).toMatchObject({
      log_origin: "native_runtime", run_kind: "agent", environment_id: log.environmentId,
      environment: { platform: platform(), node_version: process.version, hostname_sha256: hashText(hostname()),
        python_version: null },
    });
    expect(rows.every(row => row.environment_id === log.environmentId && row.runtime_platform === platform())).toBe(true);
  });

  it("counts inclusive input once and preserves unknown cache usage", () => {
    const { log } = trace();
    log.llmStarted("model", "provider", "OceanAgent", null)({
      stopReason: "length", usage: { input: 100, output: 20, cacheRead: 900, cacheWrite: 50, totalTokens: 1070 },
    });
    log.llmStarted("model", "provider", "OceanAgent", null)({
      usage: { input: 100, output: 20, cacheRead: 0, cacheWrite: 0, totalTokens: 120 },
    });
    log.finish("completed");
    expect(json(log.summaryPath)).toMatchObject({ input_tokens: 1150, non_cached_input_tokens: 200,
      output_tokens: 40, total_tokens: 1190, cached_input_tokens: null,
      cache_write_input_tokens: null, llm_usage_complete: true });
    expect(events(log).filter((row) => row.event_type === "llm.completed")[0]?.payload)
      .toMatchObject({ input_tokens: 1050, non_cached_input_tokens: 100, cached_input_tokens: 900,
        cache_write_input_tokens: 50, total_tokens: 1070, stop_reason: "length" });
  });

  it("records failure and recovered crashes without fabricated usage", () => {
    const { root, log } = trace();
    log.llmStarted("model", "provider", "OceanAgent", null)({
      usage: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0, totalTokens: 0 },
    });
    recoverInterruptedTelemetry(root, "task", "run");
    expect(json(join(log.runDir, "metrics.json"))).toMatchObject({
      terminal_status: "failed", error_code: "SERVER_RESTART", input_tokens: null,
      wall_time_seconds: null,
    });
    expect(events(log).filter((row) => row.event_type === "task_failure")).toHaveLength(1);
    expect(json(join(log.runDir, "manifest.json")).status).toBe("failed");
    expect(json(join(log.runDir, "manifest.json")).environment_id).toBe(log.environmentId);
  });

  it("does not mark a Plan awaiting approval as a successful research task", () => {
    const { log } = trace();
    log.finish("awaiting_approval");
    expect(json(join(log.runDir, "metrics.json"))).toMatchObject({
      terminal_status: "awaiting_approval", process_success: null,
    });
    expect(events(log).some(row => row.event_type === "task_failure")).toBe(false);
  });

  it("records dataset-read evidence without claiming scientific calculation use", () => {
    const { log } = trace();
    log.toolStarted("read", "record_dataset_read");
    log.toolEnded("read", false, { details: { datasetId: "oisst", path: "/tmp/subset.json",
      sha256: "sha", sizeBytes: 12, planStepId: "S1", identity_source: "dataset_card" } });
    log.finish("completed");
    expect(events(log).find(row => row.event_type === "data.asset")?.payload).toMatchObject({
      output_path: "/tmp/subset.json", size_bytes: 12,
    });
    expect(events(log).find(row => row.event_type === "knowledge.used")?.payload).toMatchObject({
      relation: "dataset_card_associated_with_file_read", scientific_compute_usage: null,
    });
    expect(json(join(log.runDir, "metrics.json")).knowledge_dataset_read_refs).toBe(1);
  });

  it("associates actual shell calls with approved steps and fails unfinished calls", () => {
    const { log } = trace();
    log.setExecutionPlan({ id: "approved", datasets: ["oisst"], steps: [{ id: "S1",
      inputs: { verifiedDataFiles: [{ path: "/tmp/subset.json" }] } }] } as unknown as ResearchPlan);
    log.toolStarted("read", "record_dataset_read", { planStepId: "S1" });
    log.toolEnded("read", false, { details: {} });
    log.toolStarted("invalid", "bash", { planStepId: "unknown" });
    log.toolEnded("invalid", true);
    log.toolStarted("valid", "bash", { planStepId: "S1" });
    log.toolEnded("valid", false, { details: { exitCode: 0, stdoutPath: "/tmp/stdout.log" } });
    log.toolStarted("pending", "bash", { planStepId: "S1" });
    log.finish("failed");
    const rows = events(log);
    const completed = rows.filter(row => row.event_type === "plan.step.completed");
    expect(completed).toHaveLength(1);
    expect(completed[0]?.payload).toMatchObject({ step_id: "S1", plan_id: "approved", tool_call_id: "valid",
      execution_scope: "shell_tool_call", exit_code: 0, stdout_path: "/tmp/stdout.log",
      declared_input_paths: ["/tmp/subset.json"] });
    expect(completed[0]?.payload.duration_ms).toBeGreaterThanOrEqual(0);
    expect(rows.find(row => row.event_type === "plan.step.failed")?.payload)
      .toMatchObject({ tool_call_id: "pending", error_code: "RUN_TERMINATED" });
    expect(rows.filter(row => row.event_type === "plan.step.started")).toHaveLength(2);
    expect(rows.some(row => row.event_type === "plan_generated")).toBe(false);
    expect(json(join(log.runDir, "plan.json")).id).toBe("approved");
  });

  it("counts recoverable acquisition failures even when the SDK returned normally", () => {
    const { log } = trace();
    log.toolStarted("acquire", "acquire_scientific_data");
    log.toolEnded("acquire", false, { details: { errorType: "TIMEOUT", requiresAuthentication: false } });
    log.finish("partial");
    expect(events(log).find(row => row.event_type === "tool.failed")?.payload)
      .toMatchObject({ error_code: "TIMEOUT", sdk_is_error: false, result_status: "failed" });
    expect(json(join(log.runDir, "metrics.json"))).toMatchObject({ tool_calls: 1, tool_failed_calls: 1 });
  });
});
