/** Human-invoked, no-provider OceanAgent failure-path smoke. Never called by the app. */
import { mkdtempSync, readFileSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { basename, dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { createAppContext } from "../app-context.js";
import { loadConfig } from "../config.js";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "../..");
const scratch = mkdtempSync(join(tmpdir(), "oceanagent-telemetry-smoke-"));
const config = loadConfig(root);
config.databasePath = join(scratch, "isolated.sqlite");
config.ragAutoSync = false;
process.env.OCEANAGENT_KNOWLEDGE_MODE = "off";
process.env.OCEANAGENT_RUN_KIND = "smoke_test";
let app: Awaited<ReturnType<typeof createAppContext>> | undefined;
try {
  app = await createAppContext(config);
  const conversation = app.conversations.create("telemetry offline smoke");
  const node = app.conversations.addNode({ conversationId: conversation.id,
    role: "user", content: "offline telemetry smoke; no model credentials" });
  // This model is deliberately unconfigured: the actual OceanAgentRunner must
  // fail before an SDK request. Do not replace it with a paid model.
  const run = app.runs.create(conversation.id, node.id, "offline-smoke::no-provider");
  await app.runner.execute(run.id);
  const runDir = join(root, "eval_logs", "OceanAgent", node.id, run.id);
  const summary = JSON.parse(readFileSync(join(runDir, "summary.json"), "utf8")) as Record<string, unknown>;
  const events = readFileSync(join(runDir, "events.jsonl"), "utf8").trim().split(/\r?\n/)
    .map((line) => JSON.parse(line) as { event_type: string });
  if (summary.terminal_status !== "failed" || summary.llm_calls !== 0
    || events.filter((event) => event.event_type === "run.started").length !== 1
    || events.filter((event) => event.event_type === "run.finished").length !== 1) {
    throw new Error("Offline OceanAgent smoke trace did not satisfy lifecycle or missing-value checks");
  }
  console.log(JSON.stringify({ run_dir: runDir, terminal_status: summary.terminal_status,
    llm_calls: summary.llm_calls, paid_model_requests: 0 }));
} finally {
  app?.close();
  const absolute = resolve(scratch), temporaryRoot = resolve(tmpdir());
  if (dirname(absolute) === temporaryRoot && basename(absolute).startsWith("oceanagent-telemetry-smoke-")) {
    rmSync(absolute, { recursive: true, force: true });
  }
}
