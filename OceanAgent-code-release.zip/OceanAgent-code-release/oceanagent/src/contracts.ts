export type NodeRole = "user" | "assistant" | "system" | "tool";
export type NodeKind = "message" | "clarification" | "plan" | "status";
export type RunStatus = "queued" | "running" | "settled" | "failed" | "cancelled";
export type RunOutcome = "queued" | "running" | "awaiting_approval" | "completed" | "partial" | "failed" | "cancelled" | "interrupted";
export type PlanStatus = "awaiting_approval" | "approved" | "rejected" | "executing" | "completed" | "partial" | "failed" | "cancelled" | "interrupted";
export type ProjectExecutionTarget = "local" | "ssh";
export type ProjectConnectionStatus = "local" | "saved" | "connected" | "credentials_required";

export interface RemoteConnectionProfile {
  id: string;
  name: string;
  host: string;
  port: number;
  username: string;
  createdAt: string;
  updatedAt: string;
  lastConnectedAt?: string;
}

export interface ModelReference {
  providerId: string;
  modelId: string;
}

export interface ConfiguredModel extends ModelReference {
  key: string;
  providerName: string;
  name: string;
  reasoning: boolean;
  contextWindow: number;
  input: ("text" | "image")[];
}

export interface ModelProviderSummary {
  id: string;
  name: string;
  modelCount: number;
  configured: boolean;
  enabledModelIds: string[];
  configurationMode: "api_key" | "advanced";
  keyLabel: string;
  credentialSource?: "saved";
}

export interface ModelSettingsState {
  providers: ModelProviderSummary[];
  enabledModels: ConfiguredModel[];
  defaultModel: ModelReference | null;
}

export type ModelCatalogSource = "remote" | "pi_catalog";

export interface ModelDiscoveryResult {
  providerId: string;
  models: ConfiguredModel[];
  source: ModelCatalogSource;
  message: string;
  discoveredAt: string;
}

export interface ResearchProject {
  id: string;
  title: string;
  executionTarget: ProjectExecutionTarget;
  workspacePath: string;
  remoteConnectionId?: string;
  sshHost?: string;
  sshPort?: number;
  sshUsername?: string;
  connectionStatus?: ProjectConnectionStatus;
  createdAt: string;
  updatedAt: string;
}

export interface CreateResearchProjectInput {
  title: string;
  executionTarget: ProjectExecutionTarget;
  workspacePath: string;
  ssh?: {
    connectionId?: string;
    name?: string;
    host?: string;
    port?: number;
    username?: string;
    password?: string;
  };
}

export interface Conversation {
  id: string;
  projectId: string;
  title: string;
  activeNodeId: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface ConversationNode {
  id: string;
  conversationId: string;
  parentId: string | null;
  role: NodeRole;
  kind: NodeKind;
  content: string;
  metadata: Record<string, unknown>;
  createdAt: string;
}

export interface AgentRun {
  id: string;
  conversationId: string;
  userNodeId: string;
  assistantNodeId: string | null;
  status: RunStatus;
  outcome: RunOutcome;
  checkpoint: Record<string, unknown> | null;
  model: string;
  error: string | null;
  startedAt: string | null;
  settledAt: string | null;
  createdAt: string;
}

export interface ToolTrace {
  id: string;
  runId: string;
  name: string;
  status: "running" | "completed" | "failed";
  detail?: string;
  startedAt: string;
  finishedAt?: string;
  args?: unknown;
  result?: unknown;
}

export interface PlanStep {
  id: string;
  title: string;
  description: string;
  tool?: string;
  inputs?: Record<string, unknown>;
  dependsOn: string[];
  expectedOutputs: string[];
  risks: string[];
  phase?: "data" | "analysis" | "validation" | "artifact";
}

export interface ResearchPlan {
  id: string;
  conversationId: string;
  nodeId?: string;
  version: number;
  status: PlanStatus;
  objective: string;
  title?: string;
  taskId?: string;
  knowledgeMode?: "on" | "off";
  ablationCondition?: "A0" | "A1" | "A2";
  candidateGroupId?: string;
  repairedFromPlanId?: string;
  candidateRank?: number;
  methodFamily?: string;
  scientificFocus?: string;
  feasibilityStatus?: "executable" | "data_discovery_only";
  coverageReport?: { satisfiedRequirementIds: string[]; essentialRequirementIds: string[] };
  datasetRoles?: Record<string, string>;
  estimatedResources?: { dataGb?: number; computeHours?: number; toolCalls: number; note?: string };
  tradeoffs?: { advantages: string[]; risks: string[] };
  evidenceRefs?: string[];
  assumptions: string[];
  requiredInputs: string[];
  datasets: string[];
  retrievalTrace?: {
    queryId: string;
    decisionState: string;
    datasetIds: string[];
    requirementIds: string[];
    evidenceRefs: string[];
  };
  verifiedDataSources?: Array<{
    dataset: string;
    pageUrl: string;
    dataUrl?: string;
    status: "available" | "metadata_only" | "requires_access" | "unavailable";
    reason: string;
    checkedAt: string;
    localPath?: string;
    sha256?: string;
    bytes?: number;
    validated?: boolean;
    protocol?: string;
    validation?: unknown;
    transformations?: string[];
    errorType?: string;
    compatibilityGroup?: string;
  }>;
  evidenceNeeds: string[];
  steps: PlanStep[];
  deliverables: string[];
  risks: string[];
  estimatedCost?: string;
  createdAt: string;
  approvedAt?: string;
}

export interface Citation {
  id: string;
  nodeId?: string;
  runId: string;
  sourceType: "ocean_rag" | "web";
  sourceId: string;
  title: string;
  locator?: string;
  url?: string;
  evidenceText?: string;
  metadata: Record<string, unknown>;
}

export interface StreamEvent<T = unknown> {
  id?: number;
  runId: string;
  type:
    | "run.started"
    | "run.progress"
    | "message.delta"
    | "message.completed"
    | "tool.started"
    | "tool.progress"
    | "tool.completed"
    | "citation.added"
    | "clarification.requested"
    | "plan.proposed"
    | "plan.candidates"
    | "plan.awaiting_approval"
    | "run.settled"
    | "run.error";
  data: T;
  createdAt: string;
}

export interface RagSearchResult {
  id: string;
  cardType: "dataset" | "problem_solution" | "usage_bundle";
  title: string;
  excerpt: string;
  sourceIds: string[];
  url?: string;
  locator?: string;
  score: number;
  retrievalQuery?: string;
  retrievalRank?: number;
  /** Historical display score. See scoreSemantics before interpreting it. */
  retrievalMethod?: "lexical" | "dense" | "dense_lexical_fusion" | "like_fallback" | "exact_link";
  rawScore?: number;
  scoreSemantics?: "cosine_similarity" | "sqlite_fts5_bm25_lower_is_better"
    | "reciprocal_like_rank" | "uncalibrated_legacy_score" | "exact_link_no_score";
  bm25Score?: number;
  denseSimilarity?: number;
  fusionScore?: number;
  payload: Record<string, unknown>;
}

export type KnowledgePerspective = "global" | "paper" | "dataset";
export type KnowledgeNodeType =
  | "paper"
  | "problem_solution"
  | "usage_bundle"
  | "dataset"
  | "step"
  | "scientific_variable"
  | "experiment_setting"
  | "evaluation_metric"
  | "concept";

export interface KnowledgeCatalogItem {
  id: string;
  title: string;
  subtitle: string;
}

export interface KnowledgeGraphStats {
  knowledgeBases: number;
  papers: number;
  publishedPapers: number;
  papersWithKnowledge: number;
  publishReadyPapers: number;
  quarantinedPapers: number;
  knowledgeCards: number;
  problemCards: number;
  usageBundles: number;
  datasetCards: number;
  planSteps: number;
  dataUsages: number;
  dataRelations: number;
  validationRules: number;
  unresolvedDatasetCards: number;
  lastUpdated: string | null;
  sourceName: string;
  sourcePath: string;
}

export interface KnowledgeGraphNode {
  id: string;
  entityId: string;
  type: KnowledgeNodeType;
  title: string;
  subtitle: string;
  payload: Record<string, unknown>;
}

export type KnowledgeEdgeKind =
  | "paper_problem"
  | "problem_bundle"
  | "bundle_dataset"
  | "bundle_step"
  | "step_dependency"
  | "dataset_input"
  | "data_relation"
  | "paper_entity"
  | "dataset_variable"
  | "global_contains"
  | "dataset_co_usage";

export interface KnowledgeGraphEdge {
  id: string;
  source: string;
  target: string;
  label: string;
  kind: KnowledgeEdgeKind;
  weight?: number;
  evidenceIds?: string[];
}

export interface KnowledgeGraphResponse {
  perspective: KnowledgePerspective;
  focusId: string;
  focusNodeId: string;
  nodes: KnowledgeGraphNode[];
  edges: KnowledgeGraphEdge[];
  counts: {
    nodes: number;
    edges: number;
    datasets: number;
    steps: number;
    papers: number;
  };
  truncated: boolean;
}
