/** Isolated TRAIN retrievability diagnostics. Never opens the application DB or mutates the KB. */
import { createHash } from "node:crypto";
import { mkdir, readFile, realpath, writeFile } from "node:fs/promises";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { OceanDatabase } from "../db/database.js";
import { loadRagDocuments } from "../rag/normalizer.js";
import { RagStore, RetrievalModeUnavailableError, type RagRetrievalMode } from "../rag/rag-store.js";
import type { RagDocument } from "../rag/types.js";
import { projectStage3PublicDatasetCatalog, bundledPublicProductDocuments } from "./public-product-catalog.js";

type Row = Record<string, unknown>;
const sha = (value: string | Buffer): string => createHash("sha256").update(value).digest("hex");
function canonical(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(canonical);
  return value && typeof value === "object" ? Object.fromEntries(Object.entries(value).sort(([a], [b]) => a.localeCompare(b))
    .map(([key, item]) => [key, canonical(item)])) : value;
}
const json = (value: unknown): string => JSON.stringify(canonical(value));
function assert(value: unknown, message: string): asserts value { if (!value) throw new Error(`Retrieval diagnostic: ${message}`); }
function object(value: unknown): value is Row { return !!value && typeof value === "object" && !Array.isArray(value); }
function forbidden(path: string): void {
  assert(!/(?:^|[\\/])(?:OceanAgent-main|test|blind[ _-]?test)(?:[\\/.]|$)/i.test(path), "main and TEST paths are forbidden");
}
async function checked(path: string): Promise<string> { forbidden(path); const physical = await realpath(path); forbidden(physical); return physical; }
export interface TrainRetrievalCase {
  case_id: string; source_id: string; source_group_id: string; query: string;
  target_psc_ids: string[]; target_ubc_ids: string[];
}
export interface TrainDiagnosticSnapshot {
  documents: RagDocument[]; cases: TrainRetrievalCase[]; snapshot_sha256: string;
  train_sha256: string; cases_sha256: string; source_files_sha256: Record<string, string>;
}
export interface RetrievalVectorArtifact {
  schema_version: "stage3-retrieval-vectors-v1";
  snapshot_sha256: string;
  provenance_kind: "provider_api";
  synthetic?: false;
  provider: string; model: string; dimensions: number; endpoint: string;
  generated_at: string;
  documents: Array<{ id: string; content_sha256: string; embedding: number[] }>;
  queries: Array<{ query_sha256: string; embedding: number[] }>;
}

/** Bind rendered content and payload, not upstream sourceHash that predates a projection. */
export function retrievalVectorDocumentHash(document: RagDocument): string {
  return sha(json({ id: document.id, cardType: document.cardType, title: document.title,
    content: document.content, payload: document.payload }));
}
export function retrievalSnapshotHash(documents: RagDocument[]): string {
  return sha(json(documents.map(document => ({ id: document.id, sha256: retrievalVectorDocumentHash(document) }))
    .sort((a, b) => a.id.localeCompare(b.id))));
}

/** Metadata is an external provenance claim, never a locally fabricated real-vector fallback. */
export function validateRetrievalVectorArtifact(value: unknown, documents: RagDocument[], queries: string[]): RetrievalVectorArtifact {
  assert(object(value) && value.schema_version === "stage3-retrieval-vectors-v1", "unsupported vector artifact schema");
  assert(value.provenance_kind === "provider_api" && value.synthetic !== true, "only explicitly provider-produced artifacts are eligible");
  assert(value.snapshot_sha256 === retrievalSnapshotHash(documents), "vector snapshot differs from current projected knowledge");
  assert(typeof value.provider === "string" && value.provider.trim() && typeof value.model === "string" && value.model.trim(), "vector provider/model missing");
  const dimensions = Number(value.dimensions);
  assert(Number.isInteger(dimensions) && dimensions > 0 && dimensions <= 16384, "invalid dimensions");
  assert(typeof value.endpoint === "string" && typeof value.generated_at === "string" && Number.isFinite(Date.parse(value.generated_at)), "vector provenance missing");
  let endpoint: URL;
  try { endpoint = new URL(value.endpoint); } catch { throw new Error("Retrieval diagnostic: invalid provenance endpoint"); }
  assert(endpoint.protocol === "https:" && !endpoint.username && !endpoint.password && !endpoint.search, "unsafe or credential-bearing provenance endpoint");
  assert(Array.isArray(value.documents) && Array.isArray(value.queries), "vector rows missing");
  const validVector = (embedding: unknown): boolean => Array.isArray(embedding) && embedding.length === dimensions
    && embedding.every(item => typeof item === "number" && Number.isFinite(item)) && embedding.some(item => item !== 0);
  const documentMap = new Map(documents.filter(document => document.cardType !== "usage_bundle").map(document => [document.id, document]));
  const seen = new Set<string>();
  for (const row of value.documents) {
    assert(object(row) && typeof row.id === "string" && !seen.has(row.id), "duplicate or malformed document vector");
    const source = documentMap.get(row.id); assert(source, "unexpected or hidden document vector");
    assert(row.content_sha256 === retrievalVectorDocumentHash(source) && validVector(row.embedding), "stale or invalid document embedding");
    seen.add(row.id);
  }
  assert(seen.size === documentMap.size, "document embedding coverage incomplete");
  const wanted = new Set(queries.map(query => sha(query))), querySeen = new Set<string>();
  for (const row of value.queries) {
    assert(object(row) && typeof row.query_sha256 === "string" && wanted.has(row.query_sha256) && !querySeen.has(row.query_sha256), "unexpected/duplicate query vector");
    assert(validVector(row.embedding), "invalid query embedding"); querySeen.add(row.query_sha256);
  }
  assert(querySeen.size === wanted.size, "query embedding coverage incomplete");
  return value as unknown as RetrievalVectorArtifact;
}

export async function loadTrainDiagnosticSnapshot(knowledgeRoot: string, casesPath: string): Promise<TrainDiagnosticSnapshot> {
  const root = await checked(resolve(knowledgeRoot)), trainPath = await checked(join(root, "benchmark", "splits", "train.jsonl"));
  const trainText = await readFile(trainPath, "utf8"), train = trainText.split(/\r?\n/).filter(line => line.trim()).map(line => JSON.parse(line) as Row);
  const sourceIds = new Set(train.map(row => String(row.source_id))), groups = new Set(train.map(row => String(row.source_group_id)));
  assert(sourceIds.size > 0 && groups.size > 0, "TRAIN whitelist empty");
  const sourceFiles: Record<string, string> = {};
  const read = async (name: string) => {
    const path = await checked(join(root, "cards", name)); sourceFiles[name] = sha(await readFile(path)); return loadRagDocuments(path);
  };
  const datasetMap = new Map((await read("dataset_cards.jsonl")).map(document => {
    const projected = projectStage3PublicDatasetCatalog(document); return [projected.id, projected];
  }));
  for (const document of bundledPublicProductDocuments()) datasetMap.set(document.id, document);
  const datasets = [...datasetMap.values()].sort((a, b) => a.id.localeCompare(b.id));
  const psc = (await read("problem_solution_cards.jsonl")).filter(document => {
    const ids = [document.payload.paper_id, document.payload.source_id].filter((id): id is string => typeof id === "string");
    return ids.length > 0 && ids.every(id => sourceIds.has(id))
      && (typeof document.payload.source_group_id !== "string" || groups.has(document.payload.source_group_id));
  });
  const bundleIds = new Set(psc.map(document => document.payload.bundle_id).filter((id): id is string => typeof id === "string"));
  const ubc = (await read("usage_bundle_cards.jsonl")).filter(document => bundleIds.has(document.id));
  const documents = [...datasets, ...psc, ...ubc];
  assert(new Set(documents.map(document => document.id)).size === documents.length, "duplicate knowledge IDs");
  const casesText = await readFile(await checked(casesPath), "utf8"), fixture = JSON.parse(casesText) as Row;
  assert(fixture.schema_version === "stage3-train-in-kb-cases-v1" && Array.isArray(fixture.cases), "invalid TRAIN diagnostic cases");
  const cases = fixture.cases as TrainRetrievalCase[], byId = new Map(documents.map(document => [document.id, document]));
  assert(cases.length > 0 && cases.length <= 128, "diagnostic case count outside bounded range");
  const caseIds = new Set<string>();
  for (const item of cases) {
    assert(typeof item.case_id === "string" && !caseIds.has(item.case_id), "duplicate case ID"); caseIds.add(item.case_id);
    assert(sourceIds.has(item.source_id) && groups.has(item.source_group_id), "case must originate in TRAIN");
    assert(typeof item.query === "string" && item.query.trim().length >= 20 && !/\b(?:psc_|bundle_|paper_\d)/i.test(item.query), "query must be natural language without card identities");
    assert(Array.isArray(item.target_psc_ids) && item.target_psc_ids.length > 0 && Array.isArray(item.target_ubc_ids) && item.target_ubc_ids.length > 0, "target card IDs required");
    for (const id of item.target_psc_ids) {
      const target = byId.get(id); assert(target?.cardType === "problem_solution" && target.payload.paper_id === item.source_id
        && target.payload.source_group_id === item.source_group_id, "target PSC is not this TRAIN case");
      assert(item.query !== target.payload.problem && !String(target.payload.problem).includes(item.query), "query cannot copy original problem");
    }
    const expectedBundles = new Set(item.target_psc_ids.map(id => String(byId.get(id)!.payload.bundle_id)));
    assert(item.target_ubc_ids.every(id => expectedBundles.has(id) && byId.get(id)?.cardType === "usage_bundle"), "target UBC not linked to case PSC");
  }
  return { documents, cases, snapshot_sha256: retrievalSnapshotHash(documents), train_sha256: sha(trainText),
    cases_sha256: sha(casesText), source_files_sha256: sourceFiles };
}

export function runTrainRetrievalDiagnostic(snapshot: TrainDiagnosticSnapshot, vectors?: RetrievalVectorArtifact, limit = 10): Row {
  assert(Number.isInteger(limit) && limit >= 10 && limit <= 50, "limit must cover Top10 and be <=50");
  if (vectors) validateRetrievalVectorArtifact(vectors, snapshot.documents, snapshot.cases.map(item => item.query));
  const database = new OceanDatabase(":memory:");
  try {
    const store = new RagStore(database), embeddings = new Map(vectors?.documents.map(item => [item.id, item.embedding]) ?? []);
    for (const document of snapshot.documents) store.upsert(document, embeddings.get(document.id) ?? null, vectors?.model, vectors?.dimensions);
    const queries = new Map(vectors?.queries.map(item => [item.query_sha256, item.embedding]) ?? []);
    const cases = snapshot.cases.flatMap(item => (["lexical", "dense", "hybrid"] as RagRetrievalMode[]).map(mode => {
      const started = performance.now();
      try {
        const results = store.search(item.query, queries.get(sha(item.query)) ?? null, vectors?.model ?? "unavailable", vectors?.dimensions ?? 0,
          { cardType: "problem_solution", limit, retrievalMode: mode, bypassSimilarityGate: true });
        const ids = results.map(result => result.id), recalls = Object.fromEntries([5, 10].map(k => [`PSC_Recall@${k}`,
          item.target_psc_ids.filter(id => ids.slice(0, k).includes(id)).length / item.target_psc_ids.length]));
        const expanded = results.map((result, index) => {
          const id = String(result.payload.bundle_id ?? ""), bundle = store.getDocument(id, "usage_bundle");
          const dataIds = (Array.isArray(bundle?.payload.data_usages) ? bundle.payload.data_usages : []).map(value => String((value as Row).dataset_id));
          return { psc_id: result.id, rank: index + 1, ubc_id: bundle?.id ?? null, target_ubc: item.target_ubc_ids.includes(id),
            dataset_ids: dataIds, reachable_dataset_ids: dataIds.filter(datasetId => !!store.getDocument(datasetId, "dataset")),
            missing_dataset_ids: dataIds.filter(datasetId => !store.getDocument(datasetId, "dataset")) };
        });
        const allData = [...new Set(expanded.flatMap(row => row.dataset_ids))], reachableData = [...new Set(expanded.flatMap(row => row.reachable_dataset_ids))];
        const retrievedTargets = item.target_psc_ids.filter(id => ids.slice(0, 10).includes(id));
        return { case_id: item.case_id, source_group_id: item.source_group_id, query: item.query, mode, status: "completed",
          ...recalls, target_ubc_reachable_at_10: item.target_ubc_ids.every(id => expanded.slice(0, 10).some(row => row.ubc_id === id)),
          target_ubc_expandable_given_psc_hit: retrievedTargets.length ? retrievedTargets.every(id => !!store.getDocument(String(store.getDocument(id)!.payload.bundle_id), "usage_bundle")) : null,
          dataset_card_reachability: allData.length ? reachableData.length / allData.length : null,
          elapsed_ms: performance.now() - started, results: results.map((result, index) => ({ id: result.id, rank: index + 1,
            source_group_id: result.payload.source_group_id ?? null, score: result.score, retrieval_method: result.retrievalMethod,
            raw_score: result.rawScore, bm25_score: result.bm25Score ?? null, dense_similarity: result.denseSimilarity ?? null,
            fusion_score: result.fusionScore ?? null })), expanded };
      } catch (error) {
        if (!(error instanceof RetrievalModeUnavailableError)) throw error;
        return { case_id: item.case_id, source_group_id: item.source_group_id, query: item.query, mode, status: "unavailable",
          reason: vectors ? error.message : "No hash-bound provider-produced vector artifact supplied; no embedding API was called.",
          "PSC_Recall@5": null, "PSC_Recall@10": null, target_ubc_reachable_at_10: null, dataset_card_reachability: null,
          elapsed_ms: performance.now() - started, results: null, expanded: null };
      }
    }));
    const summaryByMode = Object.fromEntries((["lexical", "dense", "hybrid"] as RagRetrievalMode[]).map(mode => {
      const eligible = cases.filter(row => row.mode === mode), observed = eligible.filter(row => row.status === "completed");
      const mean = (key: string) => {
        const values = observed.map(row => (row as Row)[key]).filter((value): value is number => typeof value === "number" && Number.isFinite(value));
        return values.length ? values.reduce((a, b) => a + b, 0) / values.length : null;
      };
      return [mode, { observed_n: observed.length, unavailable_n: eligible.length - observed.length, expected_n: snapshot.cases.length,
        "PSC_Recall@5": mean("PSC_Recall@5"), "PSC_Recall@10": mean("PSC_Recall@10"), dataset_card_reachability: mean("dataset_card_reachability") }];
    }));
    return { schema_version: "stage3-train-in-kb-diagnostic-v1", split: "TRAIN_IN_KB_DIAGNOSTIC", formal_generalization_result: false,
      snapshot_sha256: snapshot.snapshot_sha256, train_sha256: snapshot.train_sha256, cases_sha256: snapshot.cases_sha256,
      source_files_sha256: snapshot.source_files_sha256, document_counts: Object.fromEntries(["dataset", "problem_solution", "usage_bundle"]
        .map(type => [type, snapshot.documents.filter(document => document.cardType === type).length])),
      retrieval_parameters: { limit, tokenizer: "explicit-v2-function-words-dedup-max64; legacy default unchanged", similarity_gate: "disabled identically for explicit ranking comparison", field_filter: "none identically across modes" },
      vector_provenance: vectors ? { provider: vectors.provider, model: vectors.model, dimensions: vectors.dimensions,
        endpoint: vectors.endpoint, generated_at: vectors.generated_at, evidence: "Externally supplied provider_api provenance claim; not independently reverified by this offline command." } : null,
      unavailable_dependencies: vectors ? [] : ["Hash-bound real document/query embeddings (and configured embedding-provider credentials to generate them separately)"],
      interpretation: "Known TRAIN target-card recovery and deterministic exact linked-card expansion of Top10. This is not an Agent tool call, expert scientific relevance, alternative-product validity or DEV/TEST performance.", summary_by_mode: summaryByMode, cases };
  } finally { database.close(); }
}

async function main(args: string[]): Promise<void> {
  const allowed = new Set(["--knowledge-root", "--out", "--vectors", "--cases", "--limit"]), options = new Map<string, string>();
  for (let i = 0; i < args.length; i += 2) {
    const flag = args[i]!, value = args[i + 1]; assert(allowed.has(flag) && value && !value.startsWith("--") && !options.has(flag), "invalid/duplicate option"); options.set(flag, value);
  }
  assert(options.has("--knowledge-root") && options.has("--out"), "usage: --knowledge-root PATH --out NEW.json [--vectors REAL.json] [--limit 10]");
  const root = resolve(dirname(fileURLToPath(import.meta.url)), "../.."), out = resolve(options.get("--out")!); forbidden(out);
  assert(out.startsWith(join(root, "outputs", "stage3", "retrieval-diagnostics") + "/"), "output must use outputs/stage3/retrieval-diagnostics/<new-name>.json");
  const casesPath = options.get("--cases") ?? join(root, "src", "experiments", "fixtures", "train-retrieval-diagnostic-v1.json");
  const snapshot = await loadTrainDiagnosticSnapshot(options.get("--knowledge-root")!, casesPath);
  const vectorPath = options.get("--vectors"), vectorText = vectorPath ? await readFile(await checked(vectorPath), "utf8") : null;
  const vectors = vectorText ? validateRetrievalVectorArtifact(JSON.parse(vectorText), snapshot.documents, snapshot.cases.map(item => item.query)) : undefined;
  const report = runTrainRetrievalDiagnostic(snapshot, vectors, Number(options.get("--limit") ?? 10));
  if (vectorText) report.vector_artifact_sha256 = sha(vectorText);
  await mkdir(dirname(out), { recursive: true }); await writeFile(out, JSON.stringify(report, null, 2) + "\n", { flag: "wx", mode: 0o600 });
  console.log(JSON.stringify({ output: out, snapshot_sha256: snapshot.snapshot_sha256,
    statuses: (report.cases as Row[]).map(row => ({ case: row.case_id, mode: row.mode, status: row.status, recall_at_5: row["PSC_Recall@5"] })) }));
}
if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) main(process.argv.slice(2))
  .catch(error => { console.error(error instanceof Error ? error.message : "Retrieval diagnostic failed"); process.exitCode = 1; });
