import { afterEach, describe, expect, it, vi } from "vitest";
import type { ToolDefinition } from "@earendil-works/pi-coding-agent";
import type { Stage3UnitSpec } from "./paired-dev.js";
import { beginKbPlanFinalization, createKbPlanningToolCoordinator, kbPlanIsFinalizing, shouldFinalizeKbPlanning } from "./kb-planning-control.js";
import { KB_ABLATION_REPAIR_PROTOCOL, kbPlanningSystemPrompt } from "./kb-ablation-protocol.js";
import { consumeExperimentTool, experimentBudgetProgress, startExperimentBudget } from "./runtime-context.js";

function fixture(condition = "A0") {
  const unit = { condition, runtime_config: { protocol_version: KB_ABLATION_REPAIR_PROTOCOL },
    budget: { max_agent_ms: 180000, max_tool_calls: 16, max_output_tokens: 8192, max_download_bytes: 1 } } as Stage3UnitSpec;
  startExperimentBudget(unit);
  return { unit, wrap: createKbPlanningToolCoordinator(unit) };
}
const tool = (name: string, execute: any) => ({ name, execute } as ToolDefinition<any,any,any>);
async function call(unit: Stage3UnitSpec, wrapped: ToolDefinition<any,any,any>, params = {}, signal?: AbortSignal) {
  consumeExperimentTool(unit); return wrapped.execute("test",params,signal,undefined,{} as never);
}
afterEach(() => { vi.restoreAllMocks(); vi.useRealTimers(); });
describe("shared bounded scientific planning", () => {
  it.each(["A0","A1"])("reserves the same hard budget for submission in %s", async condition => {
    const {unit,wrap}=fixture(condition), read=vi.fn(async()=>({content:[{type:"text",text:"unverified"}],details:{}}));
    const wrapped=wrap(tool("search_official_web",read));
    for(let n=0;n<8;n++) await call(unit,wrapped,{query:`different ${n}`});
    expect(shouldFinalizeKbPlanning(unit)).toBe(true);
    expect(read).toHaveBeenCalledTimes(4); // public request cap; refusals still charged
    beginKbPlanFinalization(unit);
    const denied=await call(unit,wrapped);
    expect(denied.details).toMatchObject({executed:false,reason:"submission_reserve"});
    const submit=vi.fn(async()=>({content:[],details:{submitted:true},terminate:true}));
    expect((await call(unit,wrap(tool("propose_research_plan",submit)))).terminate).toBe(true);
    expect(submit).toHaveBeenCalledTimes(1);
    expect(experimentBudgetProgress(unit).tools).toBe(10); // no budget increase, no cached free calls
  });
  it("reuses negative source checks without inventing a successful verification", async()=>{
    const {unit,wrap}=fixture(), probe=vi.fn(async()=>({content:[{type:"text",text:"HTTP 0 UNSAFE_URL"}],details:{status:"unavailable",reason:"UNSAFE_URL"}}));
    const wrapped=wrap(tool("check_official_data_source",probe)), args={dataset:"x",pageUrl:"https://example.org/product"};
    await call(unit,wrapped,args); const repeat=await call(unit,wrapped,{...args,dataUrl:"https://example.org/guessed.nc"});
    expect(probe).toHaveBeenCalledTimes(1);
    expect(repeat.details).toMatchObject({status:"unavailable",planning_cache_hit:true,requested_alternate_data_url_not_checked:true});
    expect(experimentBudgetProgress(unit).tools).toBe(2);
  });
  it("bounds an external call, caches its real failure and keeps submission available", async()=>{
    const deadline=vi.spyOn(AbortSignal,"timeout"); const {unit,wrap}=fixture();
    const probe=vi.fn(async(_id:any,_p:any,signal:AbortSignal)=>{throw new Error(signal instanceof AbortSignal ? "source unavailable" : "missing deadline");});
    const wrapped=wrap(tool("search_official_web",probe));
    const first=await call(unit,wrapped,{query:"q"});
    expect(first.isError).toBe(true);
    await call(unit,wrapped,{query:"q"}); expect(probe).toHaveBeenCalledTimes(1);
    expect(probe.mock.calls[0]![2]).toBeInstanceOf(AbortSignal);
    expect(deadline).toHaveBeenCalledWith(12000);
    expect(first.content[0]).toMatchObject({text:expect.stringContaining("未验证任何科学事实")});
  });
  it("uses elapsed time and a failed Plan attempt to leave evidence collection", async()=>{
    let now=0; vi.spyOn(performance,"now").mockImplementation(()=>now);
    const {unit,wrap}=fixture(); now=90001; expect(shouldFinalizeKbPlanning(unit)).toBe(true);
    const broken=wrap(tool("propose_research_plan",async()=>{throw new Error("invalid dependency");}));
    await expect(call(unit,broken)).rejects.toThrow("invalid dependency");
    expect(kbPlanIsFinalizing(unit)).toBe(true);
  });
  it("removes the download/file workflow while keeping identical scientific and submission rules",()=>{
    for(const c of ["A0","A1"]){
      const system=kbPlanningSystemPrompt(c);
      expect(system).not.toMatch(/acquire_scientific_data|run_remote_command|read`|write`|必须.*下载.*后/);
      expect(system).toContain("最多8次工具调用或90秒");
      expect(system).toContain("propose_research_plan");
    }
    expect(kbPlanningSystemPrompt("A0")).not.toContain("search_research_cases");
  });
});
