import { constants, accessSync, existsSync, lstatSync, realpathSync } from "node:fs";
import { dirname, isAbsolute, relative, resolve, sep, delimiter } from "node:path";
import type { BashSpawnHook, ToolDefinition } from "@earendil-works/pi-coding-agent";

export interface ExperimentToolIsolationOptions {
  workspace: string;
  unitDir: string;
  runtimeHome: string;
  privateTmp?: string;
  applicationRoot?: string;
  /** Trusted runtime libraries only. Never pass a repository, dataset or another arm's directory. */
  runtimeReadPaths?: readonly string[];
  pythonExecutable?: string;
  nodeExecutable?: string;
  /** The worker owns the shared budget across sessions, agents and tools. */
  beforeExecute?: () => void;
  platform?: NodeJS.Platform;
  sandboxExecutable?: string;
}

function within(root: string, target: string): boolean {
  const suffix = relative(root, target);
  return !suffix || !suffix.startsWith(`..${sep}`) && suffix !== ".." && !isAbsolute(suffix);
}

function rejectRunningProject(path: string): void {
  if (path.split(sep).some(part => /^OceanAgent-main$/i.test(part))) {
    throw new Error("实验禁止访问正在运行的 OceanAgent-main");
  }
}

/** Resolve existing symlinks, including the nearest parent of a file not created yet. */
function physicalPath(path: string): string {
  let current = resolve(path);
  rejectRunningProject(current);
  const tail: string[] = [];
  const entryExists = (entry: string) => {
    try { lstatSync(entry); return true; } catch (error) {
      if ((error as NodeJS.ErrnoException).code === "ENOENT") return false;
      throw error;
    }
  };
  while (!entryExists(current)) {
    const parent = dirname(current);
    if (parent === current) throw new Error("无法解析实验隔离路径");
    tail.unshift(current.slice(parent.length + (parent.endsWith(sep) ? 0 : 1)));
    current = parent;
  }
  const physical = resolve(realpathSync(current), ...tail);
  rejectRunningProject(physical);
  return physical;
}

function boundaries(options: ExperimentToolIsolationOptions) {
  const unitDir = physicalPath(options.unitDir);
  const workspace = physicalPath(options.workspace);
  const runtimeHome = physicalPath(options.runtimeHome);
  const privateTmp = physicalPath(options.privateTmp ?? resolve(unitDir, "tmp"));
  for (const path of [workspace, runtimeHome, privateTmp]) {
    if (path === unitDir || !within(unitDir, path)) throw new Error("实验 workspace、HOME 和临时目录必须独立位于当前 unitDir 内");
  }
  return { unitDir, workspace, runtimeHome, privateTmp };
}

export function containedExperimentPath(workspace: string, input: string): string {
  const logicalRoot = resolve(workspace);
  const root = physicalPath(workspace);
  const candidate = resolve(root, input);
  if (!within(root, candidate) && !within(logicalRoot, candidate)) throw new Error("实验工具路径越出当前 workspace");
  const physical = physicalPath(candidate);
  if (!within(root, physical)) throw new Error("实验工具符号链接越出当前 workspace");
  return physical;
}

/** Preserve the original schemas and behavior; enforce isolation at the execution boundary. */
export function wrapExperimentTool<T extends ToolDefinition<any, any, any>>(
  tool: T, options: ExperimentToolIsolationOptions,
): T {
  boundaries(options);
  const pathFields: Record<string, string> = {
    read: "path", edit: "path", write: "path", ls: "path", find: "path", grep: "path",
    record_dataset_read: "file", complete_research_plan: "verificationFile", check_official_data_source: "uploadedPath",
  };
  return { ...tool,
    // Sharing one workspace also requires edits and shell calls to serialize within a session.
    executionMode: "sequential",
    async execute(id, params, signal, onUpdate, context) {
      options.beforeExecute?.();
      if (["run_remote_command", "local_powershell", "powershell"].includes(tool.name)) {
        throw new Error("实验隔离禁止远程或非沙箱 Shell 工具");
      }
      const field = pathFields[tool.name];
      let safeParams = params;
      if (field) {
        if (!params || typeof params !== "object" || Array.isArray(params)) throw new Error("实验工具参数必须是对象");
        const input = (params as Record<string, unknown>)[field];
        const isOptional = ["ls", "find", "grep", "check_official_data_source"].includes(tool.name);
        if (input === undefined && !isOptional || input !== undefined && typeof input !== "string") {
          throw new Error(`实验工具 ${field} 必须是路径字符串`);
        }
        if (input !== undefined || tool.name !== "check_official_data_source") {
          safeParams = { ...params, [field]: containedExperimentPath(options.workspace, input as string | undefined ?? ".") };
        }
      }
      return tool.execute(id, safeParams, signal, onUpdate, context);
    },
  } as T;
}

function readRuntimePaths(options: ExperimentToolIsolationOptions): string[] {
  const appRoot = physicalPath(options.applicationRoot ?? resolve(import.meta.dirname, "../.."));
  const roots = [...(options.runtimeReadPaths ?? [])];
  for (const name of ["node_modules", ".venv"]) {
    const path = resolve(appRoot, name);
    if (existsSync(path)) roots.push(path);
  }
  for (const executable of [options.pythonExecutable, options.nodeExecutable ?? process.execPath]) {
    if (!executable) continue;
    const originalRoot = dirname(dirname(resolve(executable)));
    if (existsSync(resolve(originalRoot, "pyvenv.cfg"))) roots.push(originalRoot);
    const path = physicalPath(executable);
    // A selected Python/Node installation contains its executable, framework and stdlib.
    if (!["/usr/bin", "/bin", "/usr/sbin", "/sbin"].includes(dirname(path))) roots.push(dirname(dirname(path)));
  }
  const { unitDir } = boundaries(options);
  return [...new Set(roots.map(path => {
    const physical = physicalPath(path);
    if (physical === sep || within(physical, appRoot) || within(physical, unitDir)
      || within(unitDir, physical) || within(resolve(appRoot, "data"), physical)
      || within(resolve(appRoot, "outputs"), physical)) {
      throw new Error("沙箱只读路径必须是独立运行时依赖，不能包含项目或实验数据");
    }
    return physical;
  }))];
}

const SYSTEM_READ_ROOTS = [
  "/System/Library", "/System/Cryptexes", "/usr/lib", "/usr/share", "/usr/bin", "/bin", "/usr/sbin", "/sbin",
  "/private/var/db/dyld", "/private/var/db/timezone", "/Library/Apple/System/Library",
];

/** A deny-by-default macOS profile. There is deliberately no network permission. */
export function buildSandboxProfile(options: ExperimentToolIsolationOptions): string {
  const { workspace, runtimeHome, privateTmp } = boundaries(options);
  const quote = (path: string) => {
    if (path.includes("\0")) throw new Error("沙箱路径包含非法字符");
    return JSON.stringify(path);
  };
  const readRoots = [...new Set([workspace, runtimeHome, privateTmp, ...SYSTEM_READ_ROOTS, ...readRuntimePaths(options)])];
  const subpaths = (paths: string[]) => paths.map(path => `(subpath ${quote(path)})`).join("\n  ");
  // macOS 26 inspects the root directory when starting even /usr/bin/true.
  // Permit only that directory itself, never its descendants.
  return `(version 1)\n(deny default)\n(allow process-exec\n  ${subpaths(readRoots)})\n(allow process-fork)\n(allow signal (target self))\n(allow sysctl-read)\n(allow mach-lookup (global-name "com.apple.system.logger"))\n(allow file-read-data (literal "/"))\n(allow file-read*\n  ${subpaths(readRoots)}\n  (literal "/dev/null") (literal "/dev/random") (literal "/dev/urandom"))\n(allow file-write*\n  ${subpaths([workspace, runtimeHome, privateTmp])}\n  (literal "/dev/null"))\n`;
}

function shellQuote(value: string): string { return `'${value.replaceAll("'", `'\\''`)}'`; }

/** Fail closed on unsupported hosts. The SDK must use shellPath=/bin/bash and no session env. */
export function sandboxBashSpawnHook(options: ExperimentToolIsolationOptions): BashSpawnHook {
  if ((options.platform ?? process.platform) !== "darwin") throw new Error("实验 Bash 需要 macOS sandbox-exec；禁止退回普通 Shell");
  const executable = options.sandboxExecutable ?? "/usr/bin/sandbox-exec";
  try { accessSync(executable, constants.X_OK); } catch { throw new Error("macOS sandbox-exec 不可执行；实验已停止"); }
  const profile = buildSandboxProfile(options);
  const { workspace, runtimeHome, privateTmp } = boundaries(options);
  const runtimeBins = [options.pythonExecutable, options.nodeExecutable ?? process.execPath]
    .filter((path): path is string => !!path).map(path => dirname(resolve(path)));
  return context => {
    const cwd = containedExperimentPath(options.workspace, context.cwd);
    // No inherited credentials, proxy, startup scripts, dynamic loader or user package paths.
    const env: NodeJS.ProcessEnv = {
      PATH: [...new Set([...runtimeBins, "/usr/bin", "/bin", "/usr/sbin", "/sbin"])].join(delimiter),
      HOME: runtimeHome, TMPDIR: `${privateTmp}${sep}`, TMP: privateTmp, TEMP: privateTmp,
      LANG: "en_US.UTF-8", LC_ALL: "en_US.UTF-8", PYTHONNOUSERSITE: "1", PYTHONDONTWRITEBYTECODE: "1",
      PYTHONIOENCODING: "utf-8", MPLBACKEND: "Agg", MPLCONFIGDIR: resolve(workspace, ".cache/matplotlib"),
      GIT_CONFIG_NOSYSTEM: "1", GIT_CONFIG_GLOBAL: "/dev/null",
    };
    if (options.pythonExecutable) {
      // Invoking a venv symlink by its original path preserves that venv's sys.prefix.
      env.OCEAN_PYTHON_PATH = resolve(options.pythonExecutable);
      env.OCEAN_DATA_PYTHON = resolve(options.pythonExecutable);
      const candidate = dirname(dirname(env.OCEAN_PYTHON_PATH));
      if (existsSync(resolve(candidate, "pyvenv.cfg"))) env.VIRTUAL_ENV = candidate;
    }
    return { cwd, env,
      command: `exec ${shellQuote(executable)} -p ${shellQuote(profile)} /bin/bash --noprofile --norc -c ${shellQuote(context.command)}`,
    };
  };
}
