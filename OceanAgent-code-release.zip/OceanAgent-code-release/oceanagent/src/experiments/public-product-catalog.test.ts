import { describe, expect, it } from "vitest";
import type { RagDocument } from "../rag/types.js";
import { bundledPublicProductDocuments, diagnoseDatasetPublicFacts, loadBundledPublicProducts,
  projectStage3PublicDatasetCatalog, publicCatalogProjectionStats, publicFactSnapshotSha256,
  resolveCanonicalProduct, validatePublicProductCatalog } from "./public-product-catalog.js";
import { projectKnowledgeDocument, requireDatasetAccess, requireKnowledgeAccess, resolveAblationPolicy } from "./ablation-policy.js";

const fixture = (): RagDocument => ({ id: "sst__paper_dev_unresolved", cardType: "dataset", title: "old", content: "OLD_PAPER_ANSWER",
  sourceIds: ["paper_dev"], sourcePath: "fixture", sourceHash: "fixture",
  payload: { dataset_id: "sst__paper_dev_unresolved", name: "NOAA Optimum Interpolation SST", product_id: "OISST",
    version: "2.1", processing_variant: "final-avhrr", coverage: { spatial: "global ocean", temporal: "STUDY_WINDOW" },
    aliases: ["OISST", "used with ADT in this study"], fields: [{ raw_name: "sst", source_url: "https://www.ncei.noaa.gov/products/optimum-interpolation-sst", unit: "WRONG_UNIT" },
      { raw_name: "PRIVATE_PAPER_LABEL", source_url: "https://www.ncei.noaa.gov/products/optimum-interpolation-sst", unit: "ANSWER" }],
    description: "Gold paper used SST with PRIVATE_PAPER_LABEL", sources: [{ source_id: "paper_dev", quote: "HELDOUT_ANSWER" }],
    access: [{ url: "https://www.ncei.noaa.gov/products/optimum-interpolation-sst", note: "STUDY_USE" }] } });

describe("independent official public product catalogue", () => {
  it("loads only frozen, hashed provider facts and contains no benchmark/source-paper mapping", () => {
    const catalog = loadBundledPublicProducts();
    expect(catalog.products).toHaveLength(4);
    for (const product of catalog.products) for (const e of product.evidence) expect(e.snapshotSha256).toBe(publicFactSnapshotSha256(e.snapshot));
    expect(JSON.stringify(catalog)).not.toMatch(/query_[a-f0-9]|paper_\d+|gold_dataset|source_group_id/);
    const corrupt = structuredClone(catalog); corrupt.products[0]!.evidence[0]!.snapshot.unverified_change = true;
    expect(() => validatePublicProductCatalog(corrupt)).toThrow("snapshot");
  });

  it("resolves explicit official version/region and service identifiers without stripping paper scopes", () => {
    const product = loadBundledPublicProducts().products[0]!;
    expect(resolveCanonicalProduct({ datasetId: "ncdcOisst21Agg_LonPM180" })).toMatchObject({ status: "matched", canonicalProductId: product.canonicalProductId });
    expect(resolveCanonicalProduct({ productId: "OISST", version: "v2.1", region: "global ocean", variant: "final-avhrr" }).status).toBe("matched");
    expect(resolveCanonicalProduct({ datasetId: "sst__paper_0976_unresolved" }).status).toBe("unresolved");
    expect(resolveCanonicalProduct({ datasetId: "ncdcOisst21Agg_LonPM180（中文说明）" }).status).toBe("unresolved");
  });

  it("does not merge versions, regional scopes or unversioned service releases", () => {
    expect(resolveCanonicalProduct({ productId: "OISST", version: "2.0", region: "global ocean" })).toMatchObject({ status: "unresolved", reason: "version_or_region_conflict" });
    expect(resolveCanonicalProduct({ productId: "OISST", version: "2.1", region: "Gulf of Thailand" }).status).toBe("unresolved");
    expect(resolveCanonicalProduct({ productId: "OISST" })).toMatchObject({ status: "unresolved", reason: "processing_variant_not_identified" });
    expect(resolveCanonicalProduct({ datasetId: "erdQMwind1day" })).toMatchObject({ status: "unresolved", reason: "data_release_unverified_for_service" });
    expect(resolveCanonicalProduct({ datasetId: "G02202" }).status).toBe("unresolved");
  });

  it("keeps a multi-version identity ambiguous until separately supplied evidence disambiguates it", () => {
    const c = structuredClone(loadBundledPublicProducts()), p = structuredClone(c.products[0]!);
    p.canonicalProductId += ":other-release"; p.version = "2.0"; c.products.push(p);
    expect(resolveCanonicalProduct({ productId: "OISST" }, c).status).toBe("ambiguous");
    expect(resolveCanonicalProduct({ productId: "OISST", version: "2.1", region: "global ocean", variant: "final-avhrr" }, c).status).toBe("matched");
  });

  it("uses independent field facts even when legacy sources only contain paper citations, without endorsing unrelated fields", () => {
    const source = fixture(), stats = publicCatalogProjectionStats(), projected = projectStage3PublicDatasetCatalog(source, stats);
    expect(projected.payload.catalog_projection).toMatchObject({ source_evidence: "verified_official_facts" });
    expect(projected.payload.fields).toEqual(expect.arrayContaining([expect.objectContaining({ raw_name: "sst", unit: "degree_C" })]));
    for (const secret of ["HELDOUT_ANSWER", "PRIVATE_PAPER_LABEL", "WRONG_UNIT", "STUDY_WINDOW", "STUDY_USE", "used with"]) expect(JSON.stringify(projected)).not.toContain(secret);
    expect(projected.id).toBe(source.id);
    expect(source.payload.description).toContain("PRIVATE_PAPER_LABEL");
    expect(stats).toMatchObject({ dataset_cards: 1, verified_fact_cards: 1, identity_only_cards: 0, retained_verified_fields: 4, withheld_source_fields: 2 });
  });

  it("does not turn a root/landing URL into verification of every source-card capability", () => {
    const source = fixture(); source.payload.product_id = "unverified"; source.payload.version = "unresolved";
    source.payload.fields = [{ raw_name: "PRIVATE_PAPER_LABEL", source_url: "https://www.noaa.gov", unit: "ANSWER" }];
    source.payload.access = [{ url: "https://www.noaa.gov" }];
    const projected = projectStage3PublicDatasetCatalog(source);
    expect(projected.payload).not.toHaveProperty("fields");
    expect(projected.payload).not.toHaveProperty("coverage");
    expect(projected.payload.catalog_projection).toMatchObject({ source_evidence: "identity_only", official_endpoint_availability: null });
    expect(diagnoseDatasetPublicFacts(source)).toMatchObject({ source_fields_missing: false, source_field_count: 1, official_endpoint_availability: null });
  });

  it("provides identical public facts to all three arms while A0 still rejects private process knowledge", () => {
    const projected = projectStage3PublicDatasetCatalog(fixture());
    const values = ["A0", "A1", "A2"].map(c => projectKnowledgeDocument(projected, resolveAblationPolicy(c, true)).payload);
    expect(values[0]).toEqual(values[1]); expect(values[1]).toEqual(values[2]);
    expect(() => requireDatasetAccess(resolveAblationPolicy("A0", true))).not.toThrow();
    expect(() => requireKnowledgeAccess(resolveAblationPolicy("A0", true))).toThrow("A0 forbids");
    expect(() => requireDatasetAccess(resolveAblationPolicy("A0"))).toThrow("A0 forbids");
  });

  it("offers public service metadata without claiming a verified data release, and projects idempotently", () => {
    const docs = bundledPublicProductDocuments();
    const wind = docs.find(d => d.id.includes("ascat"))!;
    expect(wind.payload.fields).toEqual(expect.arrayContaining([expect.objectContaining({ raw_name: "x_wind", unit: "m s-1" })]));
    expect(wind.payload.canonical_product_id).toBeNull();
    expect(projectStage3PublicDatasetCatalog(wind).payload).toEqual(wind.payload);
    const sst = docs.find(d => d.id.includes("oisst"))!;
    expect(projectStage3PublicDatasetCatalog(sst).payload).toEqual(sst.payload);
  });
});
