import { mkdir, mkdtemp, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createHash } from "node:crypto";
import { afterEach, describe, expect, it } from "vitest";
import { OceanDatabase } from "../db/database.js";
import { RagStore, RetrievalModeUnavailableError } from "../rag/rag-store.js";
import type { RagDocument } from "../rag/types.js";
import { loadTrainDiagnosticSnapshot, retrievalSnapshotHash, retrievalVectorDocumentHash,
  runTrainRetrievalDiagnostic, validateRetrievalVectorArtifact, type RetrievalVectorArtifact } from "./retrieval-diagnostic.js";

// Unit-test-only synthetic vectors below never become diagnostic experiment artifacts.
const sha = (value: string) => createHash("sha256").update(value).digest("hex");
const doc = (id: string, title: string): RagDocument => ({ id, cardType: "problem_solution", title,
  content: title, payload: { card_id: id, paper_id: "train", source_group_id: "train", problem: title },
  sourceIds: ["train"], sourcePath: "unit-test-only", sourceHash: sha(title) });
const scratch: string[] = [];
afterEach(async () => { for (const path of scratch.splice(0)) await rm(path, { recursive: true, force: true }); });

describe("explicit retrieval modes reuse the native store", () => {
  it("bounds full natural-language queries after function words without changing the legacy parser", () => {
    const db = new OceanDatabase(":memory:"), store = new RagStore(db);
    try {
      store.upsertLexical(doc("late", "temperature"));
      const query = "I would like to know how we can use the following observations temperature";
      expect(store.search(query, null, "none", 0, { cardType: "problem_solution" })).toEqual([]);
      expect(store.search(query, null, "none", 0, { cardType: "problem_solution", retrievalMode: "lexical" })[0]?.id).toBe("late");
      expect(store.search("I the AND or how which you we", null, "none", 0,
        { cardType: "problem_solution", retrievalMode: "lexical" })).toEqual([]);
      expect(store.search("   ", null, "none", 0, { cardType: "problem_solution", retrievalMode: "lexical" })).toEqual([]);
      const terms = Array.from({ length: 65 }, (_, index) => `term${index}`);
      store.upsertLexical(doc("beyond-bound", "term64"));
      expect(store.search(terms.join(" "), null, "none", 0,
        { cardType: "problem_solution", retrievalMode: "lexical" })).toEqual([]);
      store.upsertLexical(doc("inside-bound", "term63"));
      expect(store.search(terms.join(" "), null, "none", 0,
        { cardType: "problem_solution", retrievalMode: "lexical" })[0]?.id).toBe("inside-bound");
    } finally { db.close(); }
  });

  it("keeps lexical vector-independent and never represents fallback as dense/hybrid", () => {
    const db = new OceanDatabase(":memory:"), store = new RagStore(db);
    try {
      store.upsertLexical(doc("sst", "coastal temperature SST"));
      expect(store.search("temperature", null, "missing", 3, { cardType: "problem_solution", retrievalMode: "lexical" })[0]?.id).toBe("sst");
      for (const retrievalMode of ["dense", "hybrid"] as const) expect(() => store.search("temperature", null, "missing", 3,
        { cardType: "problem_solution", retrievalMode })).toThrow(RetrievalModeUnavailableError);
    } finally { db.close(); }
  });

  it("dense uses cosine and hybrid uses the existing fusion with identical vectors", () => {
    const db = new OceanDatabase(":memory:"), store = new RagStore(db);
    try {
      store.upsert(doc("literal", "temperature temperature"), [0, 1], "synthetic-unit-test", 2);
      store.upsert(doc("semantic", "remote concept"), [1, 0], "synthetic-unit-test", 2);
      const dense = store.search("temperature", [1, 0], "synthetic-unit-test", 2,
        { cardType: "problem_solution", retrievalMode: "dense", bypassSimilarityGate: true });
      const hybrid = store.search("temperature", [1, 0], "synthetic-unit-test", 2,
        { cardType: "problem_solution", retrievalMode: "hybrid", bypassSimilarityGate: true });
      expect(dense[0]).toMatchObject({ id: "semantic", retrievalMethod: "dense", denseSimilarity: 1 });
      expect(hybrid.every(row => row.fusionScore !== undefined)).toBe(true);
      expect(hybrid.map(row => row.id).sort()).toEqual(["literal", "semantic"]);
      expect(() => store.search("temperature", [1], "synthetic-unit-test", 2,
        { cardType: "problem_solution", retrievalMode: "dense" })).toThrow("query embedding missing");
      store.upsertLexical(doc("not-embedded", "temperature"));
      expect(() => store.search("temperature", [1, 0], "synthetic-unit-test", 2,
        { cardType: "problem_solution", retrievalMode: "hybrid" })).toThrow("coverage incomplete");
    } finally { db.close(); }
  });
});

describe("hash-bound diagnostic vectors", () => {
  function vectorFixture(): { documents: RagDocument[]; artifact: RetrievalVectorArtifact } {
    const documents = [doc("a", "coastal temperature")];
    const artifact: RetrievalVectorArtifact = { schema_version: "stage3-retrieval-vectors-v1",
      provenance_kind: "provider_api", provider: "synthetic-unit-test-only", model: "synthetic-unit-test-only", dimensions: 2,
      endpoint: "https://unit-test.invalid/embeddings", generated_at: "2026-10-30T00:00:00Z",
      snapshot_sha256: retrievalSnapshotHash(documents),
      documents: [{ id: "a", content_sha256: retrievalVectorDocumentHash(documents[0]!), embedding: [1, 0] }],
      queries: [{ query_sha256: sha("a natural-language question"), embedding: [1, 0] }] };
    return { documents, artifact };
  }
  it("validates content/model/dimensions/coverage while rejecting labeled synthetic real-run inputs", () => {
    const { documents, artifact } = vectorFixture();
    expect(validateRetrievalVectorArtifact(artifact, documents, ["a natural-language question"])).toBe(artifact);
    expect(() => validateRetrievalVectorArtifact({ ...artifact, synthetic: true }, documents, ["a natural-language question"])).toThrow("provider-produced");
    expect(() => validateRetrievalVectorArtifact({ ...artifact, model: "" }, documents, ["a natural-language question"])).toThrow("provider/model");
    expect(() => validateRetrievalVectorArtifact({ ...artifact, dimensions: 3 }, documents, ["a natural-language question"])).toThrow("invalid document");
    expect(() => validateRetrievalVectorArtifact(artifact, [{ ...documents[0]!, content: "projected content changed" }], ["a natural-language question"])).toThrow("snapshot differs");
    expect(() => validateRetrievalVectorArtifact({ ...artifact, queries: [] }, documents, ["a natural-language question"])).toThrow("query embedding coverage");
    expect(() => validateRetrievalVectorArtifact({ ...artifact, documents: [] }, documents, ["a natural-language question"])).toThrow("document embedding coverage");
    expect(() => validateRetrievalVectorArtifact({ ...artifact, endpoint: "https://unit-test.invalid/embeddings?key=hidden" }, documents, ["a natural-language question"])).toThrow("credential-bearing");
  });
});

describe("TRAIN-only known-card diagnostics", () => {
  async function fixture() {
    const root = await mkdtemp(join(tmpdir(), "in-kb-diagnostic-")); scratch.push(root);
    await mkdir(join(root, "cards")); await mkdir(join(root, "benchmark", "splits"), { recursive: true });
    await writeFile(join(root, "benchmark", "splits", "train.jsonl"), JSON.stringify({ source_id: "train", source_group_id: "train" }));
    const cards = {
      "dataset_cards.jsonl": [{ dataset_id: "sst", name: "SST" }],
      "problem_solution_cards.jsonl": [
        { card_id: "target", paper_id: "train", source_group_id: "train", problem: "temperature analysis", bundle_id: "bundle" },
        { card_id: "forbidden", paper_id: "heldout", source_group_id: "heldout", problem: "temperature analysis", bundle_id: "leak" },
      ],
      "usage_bundle_cards.jsonl": [{ bundle_id: "bundle", data_usages: [{ dataset_id: "sst" }] }, { bundle_id: "leak" }],
    };
    for (const [file, values] of Object.entries(cards)) await writeFile(join(root, "cards", file), values.map(value => JSON.stringify(value)).join("\n"));
    const casePath = join(root, "cases.json"); await writeFile(casePath, JSON.stringify({ schema_version: "stage3-train-in-kb-cases-v1", cases: [
      { case_id: "one", source_id: "train", source_group_id: "train", query: "Use temperature records to investigate coastal warming",
        target_psc_ids: ["target"], target_ubc_ids: ["bundle"] },
    ] }));
    return { root, casePath };
  }
  it("loads no held-out split, excludes held-out cards, and records unavailable modes as null", async () => {
    const { root, casePath } = await fixture();
    // No DEV/TEST file exists: the diagnostic must not read one.
    const snapshot = await loadTrainDiagnosticSnapshot(root, casePath);
    expect(snapshot.documents.map(row => row.id)).toEqual(expect.arrayContaining(["sst", "target", "bundle"]));
    expect(snapshot.documents.some(row => row.id === "forbidden" || row.id === "leak")).toBe(false);
    const report = runTrainRetrievalDiagnostic(snapshot); const cases = report.cases as Array<Record<string, unknown>>;
    expect(cases[0]).toMatchObject({ mode: "lexical", status: "completed", "PSC_Recall@5": 1, target_ubc_reachable_at_10: true, dataset_card_reachability: 1 });
    for (const row of cases.slice(1)) expect(row).toMatchObject({ status: "unavailable", "PSC_Recall@5": null, results: null });
    expect(report.formal_generalization_result).toBe(false);
  });
  it("rejects a case whose target source is held out", async () => {
    const { root, casePath } = await fixture();
    await writeFile(casePath, JSON.stringify({ schema_version: "stage3-train-in-kb-cases-v1", cases: [
      { case_id: "bad", source_id: "heldout", source_group_id: "heldout", query: "Use temperature records to investigate coastal warming",
        target_psc_ids: ["forbidden"], target_ubc_ids: ["leak"] },
    ] }));
    await expect(loadTrainDiagnosticSnapshot(root, casePath)).rejects.toThrow("must originate in TRAIN");
  });
});
