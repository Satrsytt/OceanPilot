/** One isolated DEV arm. No HTTP server and no access to shared conversation/history databases. */
import { createHash } from "node:crypto";
import { createReadStream } from "node:fs";
import { lstat, mkdir, open, readFile, readdir, realpath, unlink, writeFile } from "node:fs/promises";
import { basename, dirname, isAbsolute, join, relative, resolve, sep } from "node:path";
import { fileURLToPath } from "node:url";
import Database from "better-sqlite3";
import { createAppContext, type AppContext } from "../app-context.js";
import type { AppConfig } from "../config.js";
import type { ResearchPlan } from "../contracts.js";
import type { OceanDatabase } from "../db/database.js";
import { ModelSettingsRepository } from "../db/model-settings-repository.js";
import { OceanModelService } from "../agent/model-service.js";
import { selectPlanForExecution } from "../agent/plan-selection.js";
import { loadRagDocuments } from "../rag/normalizer.js";
import type { RagDocument } from "../rag/types.js";
import { createSecretProtector } from "../security/platform-secret-protector.js";
import { redactTelemetry } from "../telemetry/run-telemetry.js";
import { datasetCatalogProjectionStats, projectStage3DatasetCatalog, projectKnowledgeDocument, resolveAblationPolicy,
  projectStage3PublicDatasetCatalog, type DatasetCatalogProjectionStats } from "./ablation-policy.js";
import { scientificProtocol } from "./scientific-protocol.js";
import { KB_ABLATION_PROTOCOL, KB_PLANNING_NON_KB_TOOLS, kbFreePlanningProtocol, kbPlanningToolNames } from "./kb-ablation-protocol.js";
import { loadBundledPublicProducts, bundledPublicProductDocuments, publicCatalogProjectionStats, type PublicCatalogProjectionStats } from "./public-product-catalog.js";
import { buildStage3ChildEnvironment, buildStage3Prompt, sanitizeDevQuery, stage3CanonicalJson, stage3InferenceSourceSnapshot, STAGE3_CONDITIONS, STAGE3_SCHEMA,
  type Stage3ExperimentManifest, type Stage3Mode, type Stage3UnitSpec } from "./paired-dev.js";
import { installExperimentModelBudget, remainingExperimentMs, startExperimentBudget, withExperimentUnit, experimentPlan, experimentRecommendation } from "./runtime-context.js";

const APPLICATION_ROOT = resolve(dirname(fileURLToPath(import.meta.url)), "../..");
const sha = (value: string) => createHash("sha256").update(value).digest("hex");
function assert(value: unknown, message: string): asserts value { if (!value) throw new Error(`Stage3 worker: ${message}`); }
function forbidden(path: string): void { assert(!/(?:^|[\\/])OceanAgent-main(?:[\\/]|$)/i.test(path), "running checkout is forbidden"); }
function within(root: string, path: string): boolean {
  const rel = relative(root, path); return rel === "" || rel !== ".." && !rel.startsWith(`..${sep}`) && !isAbsolute(rel);
}
async function checkedPath(path: string): Promise<void> {
  forbidden(resolve(path)); let current = resolve(path);
  if (process.platform === "darwin") current = current.replace(/^\/var(?=\/|$)/, "/private/var").replace(/^\/tmp(?=\/|$)/, "/private/tmp");
  for (;;) {
    try { const info = await lstat(current); assert(!info.isSymbolicLink(), "symbolic links are forbidden");
      if (info.isFile()) assert(info.nlink === 1, "hard-linked files are forbidden"); }
    catch (error) { if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error; }
    const parent = dirname(current); if (parent === current) break; current = parent;
  }
}
async function fileHash(path: string): Promise<string> {
  const digest = createHash("sha256"); for await (const chunk of createReadStream(path)) digest.update(chunk); return digest.digest("hex");
}
async function absent(path: string): Promise<void> {
  try { await lstat(path); throw new Error("Stage3 worker: existing execution state cannot be reused; prepare a new experiment"); }
  catch (error) { if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error; }
}
async function assertFreshWorkspace(unit: Stage3UnitSpec): Promise<void> {
  const approved = new Set(unit.inputs.map(input => input.path));
  const directories = new Set([join(unit.paths.workspace, "data"), unit.paths.cache,
    ...(unit.inputs.length ? [join(unit.paths.workspace, "data", "inputs")] : []),
    unit.paths.runtime_home, ...["tmp", ".cache", ".config"].map(name => join(unit.paths.runtime_home, name))]);
  const visit = async (path: string) => {
    await checkedPath(path);
    for (const entry of await readdir(path, { withFileTypes: true })) {
      const next = join(path, entry.name); await checkedPath(next);
      if (entry.isDirectory()) { assert(directories.has(next), "unexpected pre-existing runtime/workspace directory"); await visit(next); }
      else assert(approved.has(next), "workspace contains an unapproved pre-existing artifact");
    }
  };
  await visit(unit.paths.workspace);
  await visit(dirname(unit.paths.database));
}

/** The outer manifest is authoritative; inference never reads benchmark answer rows. */
export async function loadValidatedStage3Unit(unitPath: string, applicationRoot = APPLICATION_ROOT): Promise<Stage3UnitSpec> {
  assert(isAbsolute(unitPath) && basename(unitPath) === "unit.json", "--unit must be an absolute unit.json path");
  await checkedPath(applicationRoot); const root = await realpath(applicationRoot);
  assert(basename(root) === "OceanAgent-exp-dev", "worker is restricted to the development checkout");
  assert(within(join(root, "outputs", "stage3"), resolve(unitPath)), "unit leaves development outputs");
  await checkedPath(unitPath);
  const unit = JSON.parse(await readFile(unitPath, "utf8")) as Stage3UnitSpec;
  assert(unit.schema_version === STAGE3_SCHEMA && STAGE3_CONDITIONS.includes(unit.condition), "invalid namespace/condition");
  const expectedDir = join(root, "outputs", "stage3", unit.experiment_id, unit.query_id,
    `replicate-${String(unit.replicate_id).padStart(3, "0")}`, unit.condition);
  assert(resolve(dirname(unitPath)) === expectedDir && unit.paths.unit_dir === expectedDir, "unit identity/path mismatch");
  const manifestPath = join(root, "outputs", "stage3", unit.experiment_id, "experiment.json"); await checkedPath(manifestPath);
  const manifest = JSON.parse(await readFile(manifestPath, "utf8")) as Stage3ExperimentManifest;
  const { fingerprint, created_at: _created, ...stable } = manifest;
  assert(manifest.schema_version === STAGE3_SCHEMA && manifest.split === "DEV" && manifest.development_root === root
    && manifest.experiment_dir === dirname(manifestPath) && sha(stage3CanonicalJson(stable)) === fingerprint, "invalid DEV manifest fingerprint/root");
  const records = manifest.units.filter(row => row.unit_id === unit.unit_id);
  assert(records.length === 1 && records[0]!.unit_path === unitPath
    && records[0]!.result_path === join(expectedDir, "unit-result.json")
    && records[0]!.unit_sha256 === sha(stage3CanonicalJson(unit)), "unit changed after preparation");
  for (const key of ["pair_id", "query_id", "replicate_id", "condition", "seed", "input_sha256", "config_sha256", "knowledge_snapshot_id", "data_snapshot_id"] as const) {
    assert(records[0]![key] === unit[key], `manifest binding mismatch: ${key}`);
  }
  assert(stage3CanonicalJson(unit.query) === stage3CanonicalJson(sanitizeDevQuery(unit.query))
    && unit.query.query_id === unit.query_id, "inference input contains non-query benchmark fields");
  const mode = unit.runtime_config.mode as Stage3Mode;
  assert(["recommendation", "plan", "end_to_end"].includes(mode)
    && Number.isSafeInteger(unit.runtime_config.max_execution_rounds) && Number(unit.runtime_config.max_execution_rounds) >= 1
    && Number(unit.runtime_config.max_execution_rounds) <= 10, "invalid execution scope");
  assert(Object.values(unit.budget).every(value => Number.isSafeInteger(value) && value > 0)
    && unit.budget.max_download_bytes <= 64 * 1024 * 1024, "invalid bounded budget");
  assert(sha(buildStage3Prompt(unit.query, mode, unit.runtime_config)) === unit.input_sha256, "sanitized prompt hash mismatch");
  if (scientificProtocol(unit.runtime_config)) {
    assert(unit.runtime_config.inference_source_sha256 === await stage3InferenceSourceSnapshot(), "inference source changed after preparation");
    assert(unit.runtime_config.public_catalog_sha256 === sha(stage3CanonicalJson(loadBundledPublicProducts())), "public product facts changed after preparation");
    assert(unit.runtime_config.retrieval_mode === "lexical", "this paired protocol requires a frozen available lexical index; dense/hybrid are separately diagnosed");
    if (mode === "plan") {
      assert(unit.runtime_config.fixed_planning_content_sha256 === sha(stage3CanonicalJson(unit.runtime_config.fixed_planning)), "fixed planning content changed");
      if (typeof unit.runtime_config.fixed_planning_path === "string") {
        await checkedPath(unit.runtime_config.fixed_planning_path);
        assert(await fileHash(unit.runtime_config.fixed_planning_path) === unit.runtime_config.fixed_planning_file_sha256, "fixed planning source file changed");
      }
    }
  }
  if (kbFreePlanningProtocol(unit.runtime_config)) {
    assert(unit.condition === "A0" || unit.condition === "A1", "free planning has only KB-off and FullKB arms");
    assert(mode === "plan" && unit.runtime_config.planning_only === true && !unit.runtime_config.fixed_planning
      && !unit.inputs.length, "free planning cannot receive fixed answers or scientific input artifacts");
    assert(unit.runtime_config.inference_source_sha256 === await stage3InferenceSourceSnapshot(), "free-planning inference source drift");
    assert(unit.runtime_config.retrieval_mode === "lexical", "free planning uses a frozen lexical KB view");
  }
  const configHash = sha(stage3CanonicalJson({ namespace: STAGE3_SCHEMA, model: unit.model, budget: unit.budget, runtime_config: unit.runtime_config }));
  assert(configHash === unit.config_sha256 && configHash === manifest.shared_config_sha256
    && stage3CanonicalJson(unit.model) === stage3CanonicalJson(manifest.model), "paired model/config drift");
  const expectedPaths = { unit_dir: expectedDir, workspace: join(expectedDir, "workspace"), database: join(expectedDir, "runtime", "ocean-agent.sqlite"),
    cache: join(expectedDir, "workspace", "data", "scientific-cache"), logs: join(expectedDir, "eval_logs"),
    artifacts: join(expectedDir, "artifacts"), runtime_home: join(expectedDir, "runtime", "home") };
  assert(stage3CanonicalJson(unit.paths) === stage3CanonicalJson(expectedPaths), "runtime paths are not isolated");
  for (const path of Object.values(unit.paths)) await checkedPath(path);
  for (const input of unit.inputs) {
    assert(within(join(unit.paths.workspace, "data", "inputs"), input.path), "input is outside this arm");
    await checkedPath(input.path); const info = await lstat(input.path);
    assert(info.isFile() && info.size === input.bytes && await fileHash(input.path) === input.sha256, "input copy integrity failed");
  }
  assert(sha(stage3CanonicalJson(unit.inputs.map(input => ({ name: basename(input.path), sha256: input.sha256, bytes: input.bytes })))) === unit.data_snapshot_id, "data snapshot drift");
  if (unit.condition === "A0") assert(scientificProtocol(unit.runtime_config)
    ? Object.keys(unit.knowledge).every(key => ["dataset_cards_path", "source_sha256"].includes(key))
      && Object.keys(unit.knowledge.source_sha256 ?? {}).every(key => key === "dataset_cards_path")
    : Object.keys(unit.knowledge).length === 0, "A0 cannot receive private research knowledge paths");
  if (unit.condition === "A2") assert(!unit.knowledge.usage_bundle_cards_path && !unit.knowledge.source_sha256?.usage_bundle_cards_path, "A2 cannot receive UBC source paths");
  return unit;
}

/** Only train-visible PSC and their exact linked UBC enter the private retrieval/provenance view. */
export async function loadStage3Knowledge(unit: Stage3UnitSpec, loader = loadRagDocuments,
  catalogStats?: DatasetCatalogProjectionStats | PublicCatalogProjectionStats): Promise<RagDocument[]> {
  const v2 = scientificProtocol(unit.runtime_config);
  if (unit.condition === "A0" && !v2) return [];
  const sourceIds = new Set(unit.knowledge.allowed_source_ids ?? []), groups = new Set(unit.knowledge.allowed_source_group_ids ?? []);
  if (unit.condition !== "A0") assert(sourceIds.size + groups.size > 0, "train visibility whitelist missing");
  const read = async (key: "dataset_cards_path" | "problem_solution_cards_path" | "usage_bundle_cards_path") => {
    const path = unit.knowledge[key], digest = unit.knowledge.source_sha256?.[key];
    assert(path && /^[a-f0-9]{64}$/.test(digest ?? ""), "knowledge source hash missing"); await checkedPath(path);
    assert(basename(path) === key.replace(/_path$/, ".jsonl") && basename(dirname(path)) === "cards"
      && !/(?:^|[\\/])outputs[\\/]stage3(?:[\\/]|$)/i.test(path), "knowledge source is not a base card snapshot");
    assert(await fileHash(path) === digest, "knowledge source changed since preparation"); return loader(path);
  };
  const datasets = await read("dataset_cards_path");
  const project = (document: RagDocument) => v2
    ? projectStage3PublicDatasetCatalog(document, catalogStats as PublicCatalogProjectionStats | undefined)
    : projectStage3DatasetCatalog(document, catalogStats as DatasetCatalogProjectionStats | undefined);
  const publicDocs = datasets.map(project);
  if (v2) {
    const present = new Set(publicDocs.map(doc => doc.id));
    publicDocs.push(...bundledPublicProductDocuments().filter(doc => !present.has(doc.id)).map(project));
  }
  if (unit.condition === "A0") return publicDocs;
  const allPsc = await read("problem_solution_cards_path");
  const psc = allPsc.filter(doc => {
    const identities = [doc.payload.paper_id, doc.payload.source_id].filter((id): id is string => typeof id === "string");
    return identities.length > 0 && identities.every(id => sourceIds.has(id))
      && (typeof doc.payload.source_group_id !== "string" || groups.has(doc.payload.source_group_id));
  });
  const policy = resolveAblationPolicy(unit.condition, v2);
  const docs = [...publicDocs, ...psc];
  if (unit.condition === "A1") {
    const bundleIds = new Set(psc.map(doc => doc.payload.bundle_id).filter((id): id is string => typeof id === "string"));
    docs.push(...(await read("usage_bundle_cards_path")).filter(doc => bundleIds.has(doc.id)));
  }
  return docs.map(doc => projectKnowledgeDocument(doc, policy));
}

async function privateKnowledgeView(unit: Stage3UnitSpec, documents: RagDocument[]): Promise<RagDocument[]> {
  const cards = join(unit.paths.unit_dir, "runtime", "knowledge-view", "cards"); await mkdir(cards, { recursive: true });
  const files = { dataset: "dataset_cards.jsonl", problem_solution: "problem_solution_cards.jsonl", usage_bundle: "usage_bundle_cards.jsonl" } as const;
  const privateDocs: RagDocument[] = [];
  for (const [type, name] of Object.entries(files)) {
    const path = join(cards, name);
    await writeFile(path, documents.filter(doc => doc.cardType === type).map(doc => JSON.stringify(doc.payload)).join("\n"), { flag: "wx", mode: 0o400 });
    // Re-normalize only our projected view so no upstream sourcePath/content is retained.
    privateDocs.push(...await loadRagDocuments(path));
  }
  return privateDocs;
}

async function developmentModels(root: string): Promise<{ models: OceanModelService; close: () => void }> {
  const source = join(root, "data", "ocean-agent.sqlite"); await checkedPath(source);
  if (process.platform !== "win32") {
    const key = join(root, "data", ".credentials", "master.key"); await checkedPath(key);
    try { assert(((await lstat(key)).mode & 0o077) === 0, "local credential permissions require repair in development settings"); }
    catch (error) { if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error; }
  }
  const raw = new Database(source, { readonly: true, fileMustExist: true }); raw.pragma("query_only = ON");
  try {
    const settings = new ModelSettingsRepository({ raw } as OceanDatabase, createSecretProtector(root));
    const models = await OceanModelService.create(settings);
    return { models, close: () => raw.close() };
  } catch (error) { raw.close(); throw error; }
}
function isolatedConfig(unit: Stage3UnitSpec, root: string): AppConfig {
  const knowledgeRoot = join(unit.paths.unit_dir, "runtime", "knowledge-view");
  return { rootDir: root, host: "127.0.0.1", port: 0, databasePath: unit.paths.database, experiment: unit,
    ragRoot: knowledgeRoot, knowledgeGraphRoot: knowledgeRoot, ragAutoSync: false,
    adaptiveRetrievalEnabled: unit.runtime_config.adaptive_retrieval === true,
    // Native candidate planning currently depends on retrieval state, unavailable to A0.
    multiplePlansEnabled: false,
    maxCandidatePlans: Math.min(5, Math.max(1, Number(unit.runtime_config.max_candidate_plans) || 3)),
    frontendDist: join(root, "frontend", "dist"), timeouts: { idleMs: unit.budget.max_agent_ms, hardMs: unit.budget.max_agent_ms },
    remoteSsh: { pythonPath: "python", connectTimeoutMs: 20000, commandTimeoutMs: unit.budget.max_agent_ms, strictHostKey: true } };
}
async function metricsForRuns(root: string, runIds: string[]): Promise<string[]> {
  const found: string[] = [];
  async function visit(path: string): Promise<void> {
    await checkedPath(path);
    for (const entry of await readdir(path, { withFileTypes: true })) {
      const next = join(path, entry.name); await checkedPath(next);
      if (entry.isDirectory()) await visit(next);
      else if (entry.name === "metrics.json") {
        const metric = JSON.parse(await readFile(next, "utf8")) as Record<string, unknown>;
        if (typeof metric.run_id === "string" && runIds.includes(metric.run_id)) found.push(next);
      }
    }
  }
  await visit(root); return found.sort();
}
export interface Stage3WorkerDependencies {
  applicationRoot?: string;
  loadModels?: typeof developmentModels;
  createContext?: typeof createAppContext;
}

export async function runExperimentUnit(unitPath: string, dependencies: Stage3WorkerDependencies = {}): Promise<Record<string, unknown>> {
  forbidden(resolve(dependencies.applicationRoot ?? APPLICATION_ROOT));
  const root = await realpath(dependencies.applicationRoot ?? APPLICATION_ROOT);
  const unit = await loadValidatedStage3Unit(unitPath, root), resultPath = join(unit.paths.unit_dir, "unit-result.json");
  await absent(resultPath); await absent(unit.paths.database); await absent(join(unit.paths.unit_dir, "runtime", "knowledge-view"));
  for (const path of [unit.paths.logs, unit.paths.cache, unit.paths.artifacts]) assert((await readdir(path)).length === 0, "previous arm outputs/caches cannot be reused");
  await assertFreshWorkspace(unit);
  const lockPath = join(unit.paths.unit_dir, "worker.lock"), lock = await open(lockPath, "wx", 0o600);
  try {
  // Recheck under the lock: another process may have committed while our validation was pending.
  await absent(resultPath); await absent(unit.paths.database); await absent(join(unit.paths.unit_dir, "runtime", "knowledge-view"));
  await assertFreshWorkspace(unit);
  const runIds: string[] = [], started = new Date().toISOString(); let app: AppContext | undefined;
  let closeModels: (() => void) | undefined, plan: ResearchPlan | undefined, terminal = "failed", errorType: string | null = null;
  let modelConfigHash: string | null = null, deadlineExceeded = false;
  const catalogStats = scientificProtocol(unit.runtime_config) ? publicCatalogProjectionStats() : datasetCatalogProjectionStats();
  let catalogProjection: Record<string, unknown> | null = null;
  let visibleCardCounts = { dataset: 0, problem_solution: 0, usage_bundle: 0 };
  let visibleViewSha256: string | null = null;
  try {
    await withExperimentUnit(unit, async () => {
      startExperimentBudget(unit);
      const visible = await loadStage3Knowledge(unit, loadRagDocuments, catalogStats);
      visibleCardCounts = { dataset: visible.filter(d => d.cardType === "dataset").length,
        problem_solution: visible.filter(d => d.cardType === "problem_solution").length,
        usage_bundle: visible.filter(d => d.cardType === "usage_bundle").length };
      visibleViewSha256 = sha(stage3CanonicalJson(visible.map(d => ({ id: d.id, cardType: d.cardType, payload: d.payload }))
        .sort((a, b) => a.id.localeCompare(b.id))));
      const projectionPath = join(unit.paths.unit_dir, "runtime", "catalog-projection.json");
      catalogProjection = { ...catalogStats, catalog_sha256: sha(stage3CanonicalJson(visible
        .filter(document => document.cardType === "dataset").map(document => ({ id: document.id, payload: document.payload })))),
        output_path: projectionPath };
      await writeFile(projectionPath, JSON.stringify(catalogProjection, null, 2) + "\n", { flag: "wx", mode: 0o400 });
      const documents = await privateKnowledgeView(unit, visible);
      const loaded = await (dependencies.loadModels ?? developmentModels)(root); closeModels = loaded.close;
      const modelValue = loaded.models.runModelValue(unit.model), selectedModel = loaded.models.resolveRunModel(modelValue);
      modelConfigHash = sha(stage3CanonicalJson(redactTelemetry({ provider: selectedModel.provider, id: selectedModel.id,
        api: selectedModel.api, baseUrl: selectedModel.baseUrl, contextWindow: selectedModel.contextWindow,
        maxTokens: selectedModel.maxTokens, reasoning: selectedModel.reasoning, input: selectedModel.input,
        cost: selectedModel.cost, samplingParams: selectedModel.samplingParams, compat: selectedModel.compat,
        headers: selectedModel.headers })));
      installExperimentModelBudget(loaded.models.runtime);
      app = await (dependencies.createContext ?? createAppContext)(isolatedConfig(unit, root), { models: loaded.models,
        initializeRag: async store => { for (const document of documents) store.upsertLexical(document);
          store.setMeta("index_mode", "stage3-private-lexical"); store.setMeta("index_version", unit.knowledge_snapshot_id);
          store.setMeta("dataset_catalog_projection", catalogStats.version);
          store.setMeta("indexed_at", new Date().toISOString()); } });
      const context = app, model = loaded.models.runModelValue(unit.model);
      const conversation = context.conversations.create(`DEV ${unit.query_id}`);
      const input = context.conversations.addNode({ conversationId: conversation.id, role: "user", parentId: null,
        content: buildStage3Prompt(unit.query, unit.runtime_config.mode as Stage3Mode, unit.runtime_config) });
      const execute = async (runId: string) => {
        if (remainingExperimentMs(unit) <= 0) throw new Error("STAGE3_TIME_BUDGET_EXHAUSTED");
        runIds.push(runId);
        const timer = setTimeout(() => { deadlineExceeded = true; void context.runner.abort(runId, "hard_timeout"); }, Math.max(1, remainingExperimentMs(unit)));
        try { await context.runner.execute(runId); } finally { clearTimeout(timer); }
      };
      const initial = context.runs.create(conversation.id, input.id, model); await execute(initial.id);
      const proposed = context.plans.list(conversation.id).filter(item => item.nodeId && item.status !== "rejected")
        .sort((a, b) => b.version - a.version || (a.candidateRank ?? 0) - (b.candidateRank ?? 0));
      plan = proposed.find(item => item.status === "awaiting_approval") ?? proposed[0];
      if (unit.runtime_config.mode === "end_to_end" && plan?.status === "awaiting_approval") {
        const selected = selectPlanForExecution(plan, context, model); await execute(selected.run.id);
        for (let round = 1; round < Number(unit.runtime_config.max_execution_rounds); round++) {
          plan = context.plans.get(plan.id) ?? plan;
          const last = context.runs.get(runIds.at(-1)!);
          if (!["partial", "interrupted"].includes(plan.status) || last?.outcome === "failed" || remainingExperimentMs(unit) <= 0) break;
          const resume = context.conversations.addNode({ conversationId: conversation.id, role: "user", content: "继续执行当前已批准的科研规划；遵守原有数据与工具预算。",
            metadata: { approvedPlanId: plan.id, selected_plan_id: plan.id } });
          const next = context.runs.create(conversation.id, resume.id, model); context.plans.updateStatus(plan.id, "executing"); await execute(next.id);
        }
      }
      if (plan) plan = context.plans.get(plan.id) ?? plan;
      const last = context.runs.get(runIds.at(-1)!);
      assert(last && !["queued", "running"].includes(last.status), "native runner did not settle");
      terminal = last.outcome;
      if (last.error) errorType = last.status === "failed" ? "native_run_failure" : null;
    });
  } catch (error) {
    terminal = "failed"; errorType = error instanceof Error && /^STAGE3_[A-Z_]+$/.test(error.message)
      ? error.message : error instanceof Error ? error.name : "UnknownError";
    if (errorType === "STAGE3_TIME_BUDGET_EXHAUSTED") deadlineExceeded = true;
  } finally { app?.close(); closeModels?.(); }
  if (!plan && experimentPlan(unit)) plan = experimentPlan(unit);
  const metricsPaths = await metricsForRuns(unit.paths.logs, runIds);
  let planOutput: ResearchPlan | null = null, planPath: string | null = null, planRunId: string | null = null;
  if (plan) for (const metric of metricsPaths) {
    const path = join(dirname(metric), "plan.json");
    try {
      const persisted = JSON.parse(await readFile(path, "utf8")) as ResearchPlan;
      if (persisted.id === plan.id) {
        planOutput = persisted; planPath = path;
        const metadata = JSON.parse(await readFile(metric, "utf8")) as { run_id?: string };
        planRunId = metadata.run_id ?? null;
      }
    } catch (error) { if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error; }
  }
  const recommendation = experimentRecommendation(unit);
  const result: Record<string, unknown> = {
    schema_version: STAGE3_SCHEMA, experiment_id: unit.experiment_id, unit_id: unit.unit_id, pair_id: unit.pair_id,
    query_id: unit.query_id, replicate_id: unit.replicate_id, condition: unit.condition, seed: unit.seed,
    input_sha256: unit.input_sha256, config_sha256: unit.config_sha256, model: unit.model,
    model_config_sha256: modelConfigHash,
    dataset_catalog_projection: catalogProjection,
    knowledge_snapshot_id: unit.knowledge_snapshot_id, data_snapshot_id: unit.data_snapshot_id,
    run_ids: runIds, metrics_paths: metricsPaths, terminal_status: terminal,
    plan_id: plan?.id ?? null, plan_status: plan?.status ?? null,
    ...(kbFreePlanningProtocol(unit.runtime_config) ? { protocol_version: unit.runtime_config.protocol_version,
      planning_only: true, fixed_planning_input: null,
      knowledge_mode: unit.condition === "A0" ? "off" : "full",
      visible_card_counts: visibleCardCounts,
      knowledge_view_sha256: visibleViewSha256,
      non_kb_tool_names: [...KB_PLANNING_NON_KB_TOOLS],
      permitted_tool_names: kbPlanningToolNames(unit.condition),
      plan_output: planOutput, plan_path: planPath, plan_run_id: planRunId,
      plan_sha256: planOutput ? sha(stage3CanonicalJson(planOutput)) : null,
      plan_hash_semantics: "persisted_redacted_canonical_json_v1",
      plan_contract_version: "free-selected-plan-v1" } : {}),
    predicted_dataset_ids: recommendation ? recommendation.candidates.map(item => item.dataset_id)
      : scientificProtocol(unit.runtime_config) && unit.runtime_config.mode === "recommendation" ? null
      : plan ? [...new Set(plan.datasets)] : null,
    ...(scientificProtocol(unit.runtime_config) ? { recommendation_output: recommendation ?? null,
      ordered_candidates: recommendation?.candidates ?? null,
      recommendation_contract_version: recommendation?.schema_version ?? null,
      recommendation_hash: recommendation?.candidate_sha256 ?? null,
      recommendation_valid: recommendation !== undefined, recommendation_missing_reason: recommendation ? null : "not_submitted",
      public_catalog_sha256: unit.runtime_config.public_catalog_sha256,
      planning_input: unit.runtime_config.fixed_planning ?? null,
      ...(unit.runtime_config.mode === "plan" ? { plan_output: planOutput, plan_path: planPath, plan_run_id: planRunId,
        plan_sha256: planOutput ? sha(stage3CanonicalJson(planOutput)) : null,
        plan_hash_semantics: "persisted_redacted_canonical_json_v1", plan_contract_version: "stage3-fixed-plan-v1" } : {}) } : {}),
    verified_data_sources: plan?.verifiedDataSources ?? [], started_at: started, finished_at: new Date().toISOString(),
    error_type: errorType, deadline_exceeded: deadlineExceeded, timeout_kind: deadlineExceeded ? "hard_timeout" : null,
  };
  await writeFile(resultPath, JSON.stringify(redactTelemetry(result), null, 2) + "\n", { flag: "wx", mode: 0o600 });
  return result;
  } finally { await lock.close(); await unlink(lockPath); }
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const args = process.argv.slice(2);
  if (args.length !== 2 || args[0] !== "--unit" || !args[1]) { console.error("worker --unit /absolute/path/unit.json"); process.exitCode = 1; }
  else loadValidatedStage3Unit(args[1]).then(unit => {
    // Direct worker invocation receives the same clean environment as coordinator dispatch.
    const clean = buildStage3ChildEnvironment(unit); for (const key of Object.keys(process.env)) delete process.env[key]; Object.assign(process.env, clean);
    return runExperimentUnit(args[1]!);
  }).then(result => { console.log(JSON.stringify({ unit_id: result.unit_id, terminal_status: result.terminal_status }));
    if (result.terminal_status === "failed") process.exitCode = 1;
  }).catch(error => { console.error(error instanceof Error ? error.name : "WorkerError"); process.exitCode = 1; });
}
