import { describe, expect, it, vi } from "vitest";
import { mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { resolve } from "node:path";
import { contextAblationPolicy, prepareNoBundleSystemPrompt, projectKnowledgeDocument,
  resolveAblationPolicy, projectStage3DatasetCatalog, datasetCatalogProjectionStats } from "./ablation-policy.js";
import { RagService } from "../rag/rag-service.js";
import type { RagStore } from "../rag/rag-store.js";
import type { RagDocument } from "../rag/types.js";
import type { RagSearchResult } from "../contracts.js";
import type { OceanToolContext } from "../agent/tool-context.js";
import { createOceanKnowledgeTools } from "../agent/tools/search-ocean-knowledge.js";
import { loadRagDocuments } from "../rag/normalizer.js";

const settings = { providerId: "unused", baseUrl: "https://example.org", modelId: "unused", dimensions: 8 };
function card(id: string, variable: string): RagDocument {
  return { id, cardType: "dataset", title: id, content: id, sourceIds: [id], sourcePath: "fixture", sourceHash: id,
    payload: { fields: [{ raw_name: variable, unit: "m/s" }],
      coverage: { spatial: "Global", temporal: "1990-2020", vertical: "Surface" },
      resolution: { spatial: "1 km", temporal: "daily" }, public_availability: "public",
      access: [{ url: `https://example.org/${id}`, status: "active" }] } };
}
const problem: RagDocument = { id: "psc", cardType: "problem_solution", title: "Research precedent",
  sourceIds: ["paper", "secret_ubc"], sourcePath: "fixture", sourceHash: "psc",
  content: "Problem text; Bundle ID: secret_ubc; SECRET_DAG",
  payload: { card_id: "psc", paper_id: "paper", bundle_id: "secret_ubc", problem: "A research problem",
    solution_summary: "Estimate the seasonal change", evidence: { quote: "Research evidence", refs: ["secret_ubc", "paper"] },
    usage_bundle_reference: { steps: ["SECRET_DAG"] },
    workflow_dag: { nodes: ["EMBEDDED_DAG"], edges: ["HISTORICAL_EDGE"] },
    data_usages: [{ dataset_id: "HISTORICAL_CO_USAGE" }] } };
function hit(document: RagDocument): RagSearchResult {
  return { id: document.id, cardType: document.cardType, title: document.title, excerpt: document.content,
    sourceIds: document.sourceIds, payload: document.payload, score: 1, retrievalMethod: "lexical",
    scoreSemantics: "synthetic" };
}
function service() {
  const datasets = [card("temperature", "sea surface temperature"), card("wind", "wind speed")];
  const store = { count: vi.fn(() => 4), countByType: vi.fn(() => 1), getMeta: vi.fn(() => "fixture"),
    search: vi.fn((_q: string, _e: unknown, _m: string, _d: number, options: { cardType: string }) =>
      options.cardType === "problem_solution" ? [hit(problem)] : datasets.map(hit)),
    getDocument: vi.fn((id: string, type: string) => type === "problem_solution" ? problem
      : type === "dataset" ? datasets.find(d => d.id === id) : { ...problem, id: "secret_ubc", cardType: "usage_bundle" }) };
  return { store, rag: new RagService(store as unknown as RagStore, settings, async () => null, () => false) };
}
function context(condition: "A0" | "A1" | "A2"): OceanToolContext {
  return { workspacePath: "/unused", requiresDataValidation: true, dataDiscoveryOnly: false,
    knowledgeGroundingRequired: true, knowledgeGrounded: false, adaptiveRetrievalEnabled: true,
    ablationPolicy: resolveAblationPolicy(condition), webSearchAttempted: false, dataSourceChecks: new Map(),
    addCitation: vi.fn(), setTerminalAction: vi.fn(), createPlan() { throw new Error("not executed"); } };
}

describe("immutable Stage 3 knowledge views", () => {
  it("uses an identical public product projection without paper quotations or use descriptions in both KB arms", () => {
    const source = { ...card("dataset_shared", "sst"), payload: {
      dataset_id: "dataset_shared", name: "Sea surface temperature", aliases: ["SST", "used with ADT in this study"],
      description: "SST used with ADT as CNN input", provider: "NOAA", version: "v2.1",
      coverage: { spatial: "Global", temporal: "1981-present" }, resolution: { spatial: "0.25 degree" },
      fields: [{ raw_name: "sst", unit: "degree_C", dimensions: ["time", "latitude", "longitude"],
        description: "PAPER_SHARED_COMBINATION", source_url: "https://www.noaa.gov/data/metadata" }],
      sources: [{ source_id: "paper_dev", quote: "HELDOUT_SST_ADT_COMBINATION" },
        { source_id: "paper_train", quote: "TRAIN_SST_ADT_COMBINATION" },
        { url: "https://www.noaa.gov/data/metadata", quote: "FREE_FORM_QUOTE", supports: ["FREE_FORM_SUPPORTS"] },
        { url: "https://arxiv.org/abs/1234.5678", quote: "PUBLISHED_PAPER" }],
      source_refs: ["paper_dev"], search_record: { notes: "HELDOUT_CONTEXT", search_terms: ["HELDOUT_QUERY"] },
      access: [{ type: "official_product_page", url: "https://www.noaa.gov/data/product", note: "PAPER_USE_NOTE", authentication: "none" },
        { type: "paper_period_direct_file_example", url: "https://www.noaa.gov/data/2020.nc" }],
    } } as RagDocument;
    const stats = datasetCatalogProjectionStats();
    const projected = projectStage3DatasetCatalog(source, stats);
    const a1 = projectKnowledgeDocument(projected, resolveAblationPolicy("A1"));
    const a2 = projectKnowledgeDocument(projected, resolveAblationPolicy("A2"));
    expect(a1.payload).toEqual(a2.payload);
    expect(projected.payload).toMatchObject({ dataset_id: "dataset_shared", name: "Sea surface temperature",
      aliases: ["SST"], provider: "NOAA", version: "v2.1", coverage: { spatial: "Global" },
      fields: [{ raw_name: "sst", unit: "degree_C", dimensions: ["time", "latitude", "longitude"] }],
      sources: [{ url: "https://www.noaa.gov/data/metadata" }],
      access: [{ type: "official_product_page", url: "https://www.noaa.gov/data/product", authentication: "none" }] });
    const serialized = JSON.stringify(projected);
    for (const hidden of ["paper_dev", "paper_train", "HELDOUT_", "TRAIN_SST", "PAPER_SHARED", "FREE_FORM_", "PUBLISHED_PAPER", "PAPER_USE_NOTE", "CNN", "2020.nc"]) expect(serialized).not.toContain(hidden);
    expect(stats).toMatchObject({ dataset_cards: 1, product_metadata_cards: 1, identity_only_cards: 0,
      removed_paper_sources: 2, removed_other_sources: 1, retained_product_source_urls: 1, removed_descriptions: 1 });
    expect(source.payload).toHaveProperty("search_record");
    expect(projectStage3DatasetCatalog(projected).payload).toEqual(projected.payload);
  });

  it("keeps the candidate namespace for paper-only products without promoting unsupported facts to public metadata", () => {
    const document = { ...card("sst__paper_0979_unresolved", "sst"), payload: {
      dataset_id: "sst__paper_0979_unresolved", name: "Along-track observations", description: "CNN_INPUT_COMBINATION",
      provider: "PAPER_ONLY_PROVIDER", coverage: { temporal: "PAPER_WINDOW" }, fields: [{ raw_name: "paper_only_var" }],
      sources: [{ source_id: "paper_0979", quote: "HELDOUT_COMBINATION" }],
      access: [{ url: "https://www.noaa.gov/data/product", authentication: "none" }],
    } } as RagDocument;
    const stats = datasetCatalogProjectionStats(), projected = projectStage3DatasetCatalog(document, stats);
    expect(projected.id).toBe(document.id); expect(projected.payload.dataset_id).toBe(document.id);
    expect(projected.payload.name).toBe(document.payload.name);
    expect(projected.payload.catalog_projection).toMatchObject({ source_evidence: "identity_only" });
    expect(stats.identity_only_cards).toBe(1);
    for (const key of ["description", "provider", "coverage", "fields"]) expect(projected.payload).not.toHaveProperty(key);
    expect(JSON.stringify(projected)).not.toContain("PAPER_ONLY_PROVIDER");
    expect(JSON.stringify(projected)).not.toContain("HELDOUT_COMBINATION");
    expect(projected.payload.access).toEqual([{ url: "https://www.noaa.gov/data/product", authentication: "none" }]);
  });

  it("defines distinct policies without consulting or mutating process environment", () => {
    expect(resolveAblationPolicy("A0")).toMatchObject({ knowledgeMode: "off", knowledgeAccessEnabled: false, bundleAccessEnabled: false });
    expect(resolveAblationPolicy("A1")).toMatchObject({ knowledgeMode: "on", knowledgeAccessEnabled: true, bundleAccessEnabled: true });
    expect(resolveAblationPolicy("A2")).toMatchObject({ knowledgeMode: "on", knowledgeAccessEnabled: true, bundleAccessEnabled: false });
    expect(Object.isFrozen(resolveAblationPolicy("A2"))).toBe(true);
    expect(() => resolveAblationPolicy("A3")).toThrow("Unknown");
    expect(contextAblationPolicy({ knowledgeAccessEnabled: false }).condition).toBe("A0");
  });

  it("removes UBC pointers, rendered text and nested evidence references without mutating A1", () => {
    const a2 = projectKnowledgeDocument(problem, resolveAblationPolicy("A2"));
    const text = JSON.stringify(a2);
    expect(text).not.toContain("secret_ubc"); expect(text).not.toContain("SECRET_DAG");
    expect(text).not.toContain("EMBEDDED_DAG"); expect(text).not.toContain("HISTORICAL_EDGE");
    expect(text).not.toContain("HISTORICAL_CO_USAGE");
    expect(text).not.toContain("bundle_id"); expect(a2.payload.solution_summary).toBe("Estimate the seasonal change");
    expect(a2.sourceIds).toEqual(["paper"]);
    expect(projectKnowledgeDocument(problem, resolveAblationPolicy("A1"))).toBe(problem);
    expect(problem.payload.bundle_id).toBe("secret_ubc");
  });

  it("A0 refuses explicit and implicit access without reading the store", async () => {
    const { rag, store } = service(); const off = rag.withAblationPolicy(resolveAblationPolicy("A0"));
    expect(off.getStatus().documents).toBe(0);
    await expect(off.searchResearchCases("question", [], "low")).rejects.toThrow("A0 forbids");
    await expect(off.searchDatasets("sst")).rejects.toThrow("A0 forbids");
    expect(() => off.getDatasetCards(["temperature"])).toThrow("A0 forbids");
    await off.refreshLocalIndex();
    expect(createOceanKnowledgeTools(rag, context("A0"))).toEqual([]);
    for (const method of Object.values(store)) expect(method).not.toHaveBeenCalled();
  });

  it("uses the original normalizer text for clean PSC and DatasetCard payloads", async () => {
    const directory = await mkdtemp(resolve(tmpdir(), "ocean-clean-card-"));
    try {
      for (const [filename, document] of [["problem_solution_cards.jsonl", problem],
        ["dataset_cards.jsonl", card("temperature", "sea surface temperature")]] as const) {
        const projected = projectKnowledgeDocument(document, resolveAblationPolicy("A2"));
        const path = resolve(directory, filename); await writeFile(path, JSON.stringify(projected.payload) + "\n");
        const normalized = (await loadRagDocuments(path))[0]!;
        expect(projected.content).toBe(normalized.content);
        const cleanAgain = projectKnowledgeDocument(normalized, resolveAblationPolicy("A2"));
        expect(cleanAgain.content).toBe(normalized.content);
        expect(projected.content).not.toContain("secret_ubc"); expect(projected.content).not.toContain("SECRET_DAG");
      }
    } finally { await rm(directory, { recursive: true, force: true }); }
  });

  it("A2 expands full PSC only and hides historical graph, including tool details and citations", async () => {
    const { rag, store } = service(); const ctx = context("A2");
    const tools = createOceanKnowledgeTools(rag, ctx);
    expect(tools.some(tool => tool.name === "trace_global_knowledge_graph")).toBe(false);
    const search = await tools.find(tool => tool.name === "search_research_cases")!.execute("search", { query: "question" }, undefined, undefined, {} as never);
    const expanded = await tools.find(tool => tool.name === "expand_research_case")!.execute("expand", { cardId: "psc" }, undefined, undefined, {} as never);
    const serialized = JSON.stringify({ search, expanded, citations: vi.mocked(ctx.addCitation).mock.calls });
    expect(serialized).not.toContain("secret_ubc"); expect(serialized).not.toContain("SECRET_DAG");
    expect(serialized).toContain("Estimate the seasonal change");
    const a2 = rag.withAblationPolicy(resolveAblationPolicy("A2"));
    expect(() => a2.expandResearchCase("psc")).toThrow("A2 forbids");
    expect(() => a2.getUsageBundleCards(["secret_ubc"])).toThrow("A2 forbids");
    expect(() => a2.traceGlobalDatasetRelations(["temperature"])).toThrow("A2 forbids");
    expect(store.getDocument.mock.calls.some(([, type]) => type === "usage_bundle")).toBe(false);
  });

  it("retains DatasetCard-derived runtime combinations and avoids hidden UBC recovery", async () => {
    const { rag, store } = service(); const a2 = rag.withAblationPolicy(resolveAblationPolicy("A2"));
    const decision = await a2.assessDatasetRoutes("q", { researchGoal: "temperature and wind",
      requirements: [{ id: "t", variable: "sea surface temperature", role: "target" },
        { id: "w", variable: "wind speed", role: "predictor" }] });
    expect(decision.bundles[0]?.datasetIds).toEqual(["temperature", "wind"]);
    await a2.assessDatasetRoutes("missing", { researchGoal: "waves", requirements: [{ id: "wave", variable: "wave height", role: "target" }] });
    expect(store.getDocument.mock.calls.some(([, type]) => type === "usage_bundle")).toBe(false);
    expect(store.search.mock.calls.every(call => call[4].cardType === "dataset")).toBe(true);
  });

  it("concurrent A1 and A2 views cannot change each other's policy", async () => {
    const { rag } = service(); const a2 = rag.withAblationPolicy(resolveAblationPolicy("A2"));
    const [full, stripped] = await Promise.all([rag.searchResearchCases("q", [], "low"), a2.searchResearchCases("q", [], "low")]);
    expect(JSON.stringify(full)).toContain("secret_ubc"); expect(JSON.stringify(stripped)).not.toContain("secret_ubc");
  });

  it("No-Bundle prompt preserves real scientific rules while removing historical DAG instructions", async () => {
    const template = await readFile(resolve(import.meta.dirname, "../../.pi/SYSTEM.md"), "utf8");
    const prompt = prepareNoBundleSystemPrompt(template);
    expect(prompt).toContain("acquire_scientific_data"); expect(prompt).toContain("checks");
    expect(prompt).toContain("真实退出码"); expect(prompt).not.toContain("trace_global_knowledge_graph");
    expect(prompt).toContain("仍须依据当前任务与DatasetCard生成并验证新的数据组合");
  });
});
