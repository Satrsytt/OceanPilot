import { createHash } from "node:crypto";
import { chmod, lstat, mkdir, mkdtemp, readFile, rm, symlink, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { dirname, join } from "node:path";
import https from "node:https";
import { afterEach, describe, expect, it, vi } from "vitest";
import { buildStage3ChildEnvironment, buildStage3Prompt, executePreparedStage3, prepareStage3Experiment, sanitizeDevQuery, stage3ConditionOrder,
  normalizeAllowedDataHosts, type PrepareStage3Options, type Stage3UnitSpec } from "./paired-dev.js";

const scratch: string[] = [];
afterEach(async () => {
  vi.restoreAllMocks(); vi.unstubAllEnvs(); vi.doUnmock("node:dns/promises"); vi.resetModules();
  for (const path of scratch.splice(0)) await rm(path, { recursive: true, force: true });
});
async function fixture(): Promise<PrepareStage3Options> {
  const container = await mkdtemp(join(tmpdir(), "stage3-dev-")); scratch.push(container);
  const developmentRoot = join(container, "OceanAgent-exp-dev"), knowledgeRoot = join(container, "Ocean-RAG");
  await mkdir(developmentRoot); await mkdir(join(knowledgeRoot, "benchmark", "splits"), { recursive: true });
  await mkdir(join(knowledgeRoot, "cards"));
  await writeFile(join(knowledgeRoot, "benchmark", "splits", "dev.jsonl"), [
    { query_id: "q_1", query: "Which temperature and wind observations answer this question?", source_id: "HELDOUT_DEV_PAPER", source_group_id: "heldout_dev_group", gold_dataset_ids: ["SECRET_GOLD_DATASET"], usage_bundle_card_ids: ["SECRET_ANSWER_BUNDLE"], evidence_refs: [{ quote: "SECRET_EVIDENCE" }] },
    { query_id: "q_2", query: "How can I evaluate coastal temperature variability?", source_id: "heldout_second", source_group_id: "heldout_second_group" },
  ].map(row => JSON.stringify(row)).join("\n"));
  await writeFile(join(knowledgeRoot, "benchmark", "splits", "train.jsonl"), JSON.stringify({ query_id: "train_q", query: "train", source_id: "train_paper", source_group_id: "train_group", gold_dataset_ids: ["TRAIN_GOLD_MUST_NOT_BE_COPIED"] }));
  // If any preparer reads TEST, the malformed sentinel makes the test fail.
  await writeFile(join(knowledgeRoot, "benchmark", "splits", "test.jsonl"), "DO NOT READ TEST");
  for (const name of ["dataset_cards.jsonl", "problem_solution_cards.jsonl", "usage_bundle_cards.jsonl"]) await writeFile(join(knowledgeRoot, "cards", name), JSON.stringify({ id: name }));
  return { developmentRoot, knowledgeRoot, experimentId: "paired-test", model: { providerId: "deepseek", modelId: "deepseek-flash" }, limit: 1, seed: 9 };
}
async function unit(path: string): Promise<Stage3UnitSpec> { return JSON.parse(await readFile(path, "utf8")); }
const hash = (text: string) => createHash("sha256").update(text).digest("hex");

describe("stage3 isolated DEV pair preparation", () => {
  it("keeps fixed Gold planning inputs identical across arms and rejects recommendation answer injection", async () => {
    const options = await fixture();
    const fixed = { schema_version: "stage3-fixed-planning-v1", independent: true, reviewer_id: "benchmark_gold",
      kind: "fixed_gold", datasets_by_query: { q_1: ["SECRET_GOLD_DATASET"] } };
    await expect(prepareStage3Experiment({ ...options, runtimeConfig: { protocol_version: "stage3-scientific-v2",
      mode: "recommendation", fixed_planning: fixed } })).rejects.toThrow("planning-only");
    await expect(prepareStage3Experiment({ ...options, runtimeConfig: { protocol_version: "stage3-scientific-v2",
      mode: "plan", fixed_planning: { ...fixed, datasets_by_query: { q_1: ["INCORRECT_PRODUCT"] } } } })).rejects.toThrow("unchanged DEV Gold");
    const manifest = await prepareStage3Experiment({ ...options, runtimeConfig: { protocol_version: "stage3-scientific-v2", mode: "plan", fixed_planning: fixed } });
    const specs = await Promise.all(manifest.units.map(row => unit(row.unit_path)));
    expect(new Set(specs.map(spec => spec.input_sha256)).size).toBe(1);
    for (const spec of specs) expect(buildStage3Prompt(spec.query, "plan", spec.runtime_config)).toContain("SECRET_GOLD_DATASET");
    expect(specs.find(spec => spec.condition === "A0")!.knowledge).not.toHaveProperty("problem_solution_cards_path");
  });
  it.each([undefined, 2, 3])("uses frozen concurrency %s, preserves queue/result order and runs each independent unit once", async concurrency => {
    const options = await fixture(), manifest = await prepareStage3Experiment({ ...options, replicates: 2,
      ...(concurrency ? { runtimeConfig: { execution_concurrency: concurrency } } : {}) });
    const configured = concurrency ?? 1;
    expect(manifest.runtime_config.execution_concurrency ?? 1).toBe(configured);
    const specs = await Promise.all(manifest.units.map(row => unit(row.unit_path)));
    expect(specs.every(spec => (spec.runtime_config.execution_concurrency ?? 1) === configured)).toBe(true);
    expect(new Set(specs.map(spec => spec.config_sha256)).size).toBe(1);
    const started: string[] = []; let active = 0, peak = 0;
    const results = await executePreparedStage3(join(manifest.experiment_dir, "experiment.json"), {
      executeUnit: async path => {
        const index = manifest.units.findIndex(row => row.unit_path === path);
        started.push(path); active++; peak = Math.max(peak, active);
        try {
          await new Promise(resolve => setTimeout(resolve, index === 0 ? 20 : 1));
          if (index === 1) throw new TypeError("fixture dispatch failure, never a model request");
          return index === 2 ? 7 : 0;
        } finally { active--; }
      },
    });
    expect(peak).toBe(configured); expect(active).toBe(0);
    expect(started).toEqual(manifest.units.map(row => row.unit_path));
    expect(new Set(started).size).toBe(manifest.units.length);
    expect(results.map(row => row.unit_id)).toEqual(manifest.units.map(row => row.unit_id));
    expect(results[1]).toMatchObject({ status: "worker_failed", exit_code: 1, error_type: "TypeError" });
    expect(results[2]).toMatchObject({ status: "worker_failed", exit_code: 7 });
    expect(results.filter(row => row.status === "worker_exited")).toHaveLength(4);
  });

  it("rejects invalid concurrency and rejects resume changes to frozen scheduling", async () => {
    const options = await fixture();
    for (const value of [0, 4, 1.5, "2", null]) await expect(prepareStage3Experiment({ ...options,
      runtimeConfig: { execution_concurrency: value } })).rejects.toThrow("integer from 1 to 3");
    await prepareStage3Experiment({ ...options, runtimeConfig: { execution_concurrency: 2 } });
    await expect(prepareStage3Experiment({ ...options, resume: true,
      runtimeConfig: { execution_concurrency: 3 } })).rejects.toThrow("drifted");
  });

  it("freezes a normalized exact-host allowlist equally in all arms without inheriting operator environment", async () => {
    const options = await fixture();
    const runtimeConfig = { allowed_data_hosts: ["storage.googleapis.com", "CDS.CLIMATE.COPERNICUS.EU", "storage.googleapis.com"] };
    const manifest = await prepareStage3Experiment({ ...options, runtimeConfig });
    const specs = await Promise.all(manifest.units.map(row => unit(row.unit_path)));
    expect(manifest.runtime_config.allowed_data_hosts).toEqual(["cds.climate.copernicus.eu", "storage.googleapis.com"]);
    expect(new Set(specs.map(spec => spec.config_sha256)).size).toBe(1);
    for (const spec of specs) {
      expect(spec.runtime_config.allowed_data_hosts).toEqual(manifest.runtime_config.allowed_data_hosts);
      expect(buildStage3ChildEnvironment(spec, { OCEAN_DATA_ALLOWED_HOSTS: "untrusted-parent.example.org" }).OCEAN_DATA_ALLOWED_HOSTS)
        .toBe("cds.climate.copernicus.eu,storage.googleapis.com");
    }
    expect((await prepareStage3Experiment({ ...options, runtimeConfig: { allowed_data_hosts: ["cds.climate.copernicus.eu", "storage.googleapis.com"] }, resume: true })).fingerprint)
      .toBe(manifest.fingerprint);
    await expect(prepareStage3Experiment({ ...options, runtimeConfig: { allowed_data_hosts: ["storage.googleapis.com"] }, resume: true })).rejects.toThrow("drifted");
    const without = { ...specs[0]!, runtime_config: {} };
    expect(buildStage3ChildEnvironment(without, { OCEAN_DATA_ALLOWED_HOSTS: "untrusted-parent.example.org" }).OCEAN_DATA_ALLOWED_HOSTS).toBe("");
  });

  it("rejects malformed, credentialed, local, wildcard and IP allowlist entries before preparing units", async () => {
    for (const host of ["127.0.0.1", "10.0.0.1", "::1", "[::1]", "2130706433", "127.1", "localhost", "metadata.google.internal", "host.local",
      "https://cds.climate.copernicus.eu", "user:password@data.example.org", "data.example.org/path", "data.example.org:443", "*.example.org", "a..org", "-a.org", "a-.org", "", "data.example.org,other.example.org"]) {
      expect(() => normalizeAllowedDataHosts([host]), host).toThrow("exact public domain");
    }
    for (const invalid of ["data.example.org", [null], [7], { host: "data.example.org" }]) expect(() => normalizeAllowedDataHosts(invalid)).toThrow();
    const options = await fixture();
    await expect(prepareStage3Experiment({ ...options, runtimeConfig: { allowed_data_hosts: ["127.0.0.1"] } })).rejects.toThrow("exact public domain");
    await expect(lstat(join(options.developmentRoot, "outputs", "stage3", options.experimentId))).rejects.toMatchObject({ code: "ENOENT" });
  });

  it("keeps the transport DNS private-network guard for a syntactically valid frozen operator host", async () => {
    const options = await fixture(), manifest = await prepareStage3Experiment({ ...options,
      runtimeConfig: { allowed_data_hosts: ["public-data.example.org"] } });
    const spec = await unit(manifest.units[0]!.unit_path);
    vi.stubEnv("OCEAN_DATA_ALLOWED_HOSTS", buildStage3ChildEnvironment(spec).OCEAN_DATA_ALLOWED_HOSTS!);
    vi.doMock("node:dns/promises", () => ({ lookup: vi.fn(async () => [{ address: "10.0.0.1", family: 4 }]) }));
    const request = vi.spyOn(https, "request");
    const { approvedDataUrl, safeFetch } = await import("../data-access/safe-http.js");
    expect(approvedDataUrl("https://public-data.example.org/data").hostname).toBe("public-data.example.org");
    await expect(safeFetch("https://public-data.example.org/data", { maxBytes: 16, budget: { used: 0, limit: 32 }, retries: 0 }))
      .rejects.toMatchObject({ code: "PRIVATE_NETWORK" });
    expect(request).not.toHaveBeenCalled();
  });

  it("keeps only the user question, balances three arms and records actual common prompt hashes", async () => {
    const options = await fixture(); const manifest = await prepareStage3Experiment(options);
    expect(manifest.schema_version).toBe("stage3-ablation-v1"); expect(manifest.split).toBe("DEV");
    expect(manifest.units).toHaveLength(3); expect(new Set(manifest.units.map(x => x.pair_id)).size).toBe(1);
    expect(new Set(manifest.units.map(x => x.condition))).toEqual(new Set(["A0", "A1", "A2"]));
    expect(new Set(manifest.units.map(x => x.config_sha256)).size).toBe(1);
    const specs = await Promise.all(manifest.units.map(x => unit(x.unit_path)));
    for (const spec of specs) {
      const text = JSON.stringify(spec);
      for (const forbidden of ["SECRET_GOLD_DATASET", "SECRET_ANSWER_BUNDLE", "SECRET_EVIDENCE", "HELDOUT_DEV_PAPER", "TRAIN_GOLD_MUST_NOT_BE_COPIED", "gold_dataset_ids", "evidence_refs"]) expect(text).not.toContain(forbidden);
      expect(Object.keys(spec.query).sort()).toEqual(["query", "query_id"]);
      expect(spec.input_sha256).toBe(hash(buildStage3Prompt(spec.query, "recommendation")));
      expect(spec.runtime_config).toMatchObject({ mode: "recommendation", max_execution_rounds: 1 });
      await expect(lstat(spec.paths.database)).rejects.toMatchObject({ code: "ENOENT" });
    }
    expect(specs.find(x => x.condition === "A0")?.knowledge).toEqual({});
    expect(specs.find(x => x.condition === "A1")?.knowledge.usage_bundle_cards_path).toContain("usage_bundle_cards.jsonl");
    expect(Object.keys(specs.find(x => x.condition === "A1")!.knowledge.source_sha256!).sort()).toEqual(["dataset_cards_path", "problem_solution_cards_path", "usage_bundle_cards_path"]);
    expect(specs.find(x => x.condition === "A2")?.knowledge.usage_bundle_cards_path).toBeUndefined();
    expect(Object.keys(specs.find(x => x.condition === "A2")!.knowledge.source_sha256!).sort()).toEqual(["dataset_cards_path", "problem_solution_cards_path"]);
    expect(specs.find(x => x.condition === "A2")?.knowledge.allowed_source_ids).toEqual(["train_paper"]);
    expect(specs.find(x => x.condition === "A2")?.knowledge.allowed_source_group_ids).toEqual(["train_group"]);
  });

  it("creates actual input copies and separate workspaces/caches rather than links", async () => {
    const options = await fixture(); const input = join(options.developmentRoot, "approved-input.nc"); await writeFile(input, "controlled-input");
    const manifest = await prepareStage3Experiment({ ...options, dataInputs: [input] });
    const specs = await Promise.all(manifest.units.map(x => unit(x.unit_path)));
    expect(new Set(specs.map(s => s.paths.workspace)).size).toBe(3); expect(new Set(specs.map(s => s.paths.cache)).size).toBe(3);
    for (const spec of specs) {
      expect((await lstat(spec.inputs[0]!.path)).nlink).toBe(1);
      expect(await readFile(spec.inputs[0]!.path, "utf8")).toBe("controlled-input");
    }
    await chmod(specs[0]!.inputs[0]!.path, 0o600); await writeFile(specs[0]!.inputs[0]!.path, "arm-local change");
    expect(await readFile(specs[1]!.inputs[0]!.path, "utf8")).toBe("controlled-input");
    expect(await readFile(input, "utf8")).toBe("controlled-input");
    await expect(prepareStage3Experiment({ ...options, experimentId: "leak-attempt", dataInputs: [specs[1]!.inputs[0]!.path] })).rejects.toThrow("cannot seed another arm");
    await expect(prepareStage3Experiment({ ...options, experimentId: "kb-input-leak", dataInputs: [join(options.knowledgeRoot, "cards", "dataset_cards.jsonl")] })).rejects.toThrow("cannot be supplied as scientific data");
  });

  it("resumes identical manifests without duplicating units and rejects any common input drift", async () => {
    const options = await fixture(); const first = await prepareStage3Experiment(options);
    await expect(prepareStage3Experiment(options)).rejects.toThrow("use --resume");
    const resumed = await prepareStage3Experiment({ ...options, resume: true });
    expect(resumed.fingerprint).toBe(first.fingerprint); expect(resumed.created_at).toBe(first.created_at);
    await expect(prepareStage3Experiment({ ...options, resume: true, model: { ...options.model, modelId: "changed" } })).rejects.toThrow("drifted");
    await expect(prepareStage3Experiment({ ...options, resume: true, runtimeConfig: { mode: "plan" } })).rejects.toThrow("drifted");
    await writeFile(join(options.knowledgeRoot, "cards", "dataset_cards.jsonl"), "changed snapshot");
    await expect(prepareStage3Experiment({ ...options, resume: true })).rejects.toThrow("drifted");
  });

  it("rejects train/DEV evidence overlap and escaping/symlink output roots before writing arms", async () => {
    const options = await fixture();
    await writeFile(join(options.knowledgeRoot, "benchmark", "splits", "train.jsonl"), JSON.stringify({ source_id: "HELDOUT_DEV_PAPER", source_group_id: "bad" }));
    await expect(prepareStage3Experiment(options)).rejects.toThrow("Train/DEV source overlap");
    const other = await fixture(); const external = join(dirname(other.developmentRoot), "external"); await mkdir(external);
    await symlink(external, join(other.developmentRoot, "outputs"), "dir");
    await expect(prepareStage3Experiment(other)).rejects.toThrow("Symbolic link forbidden");
    await expect(lstat(join(external, "stage3"))).rejects.toMatchObject({ code: "ENOENT" });
    expect(() => sanitizeDevQuery({ query_id: "../escape", query: "Q" })).toThrow("safe stable identifier");
  });

  it("dispatches only explicit execution, skips terminal units on resume and rejects changed unit paths", async () => {
    const manifest = await prepareStage3Experiment({ ...await fixture(), runtimeConfig: { execution_concurrency: 3 } });
    const manifestPath = join(manifest.experiment_dir, "experiment.json");
    const first = manifest.units[0]!;
    await writeFile(first.result_path, JSON.stringify({ ...first, terminal_status: "failed" }));
    let calls = 0;
    await expect(executePreparedStage3(manifestPath, { executeUnit: async () => { calls++; return 0; } })).rejects.toThrow("Result exists");
    expect(calls).toBe(0);
    const results = await executePreparedStage3(manifestPath, { resume: true, executeUnit: async () => { calls++; return 0; } });
    expect(results.map(x => x.status)).toEqual(["skipped_existing", "worker_exited", "worker_exited"]); expect(calls).toBe(2);
    const changed = await unit(manifest.units[1]!.unit_path); changed.paths.database = join(manifest.experiment_dir, "shared.sqlite");
    await writeFile(manifest.units[1]!.unit_path, JSON.stringify(changed));
    calls = 0;
    await expect(executePreparedStage3(manifestPath, { resume: true, executeUnit: async () => { calls++; return 0; } })).rejects.toThrow("changed after preparation");
    expect(calls).toBe(0);
  });

  it("uses all six condition orders and gives each replicate a fresh but within-pair shared seed", async () => {
    expect(new Set(Array.from({ length: 6 }, (_, i) => stage3ConditionOrder(i, 0).join("/"))).size).toBe(6);
    const options = await fixture(); const manifest = await prepareStage3Experiment({ ...options, replicates: 6 });
    expect(manifest.units).toHaveLength(18);
    for (let i = 0; i < 6; i++) {
      const pair = manifest.units.slice(i * 3, i * 3 + 3);
      expect(new Set(pair.map(x => x.seed)).size).toBe(1); expect(new Set(pair.map(x => x.replicate_id))).toEqual(new Set([i + 1]));
    }
    expect(new Set(manifest.units.map(x => x.seed)).size).toBe(6);
    expect(buildStage3Prompt({ query_id: "q", query: "Question" }, "plan")).not.toContain("A1");
    await expect(prepareStage3Experiment({ ...options, experimentId: "non-dev", queryIds: ["not_in_dev"] })).rejects.toThrow("outside DEV");
  });

  it("does not inherit a running application's credentials, DB, Python or Node preload configuration", async () => {
    const manifest = await prepareStage3Experiment(await fixture()); const spec = await unit(manifest.units[0]!.unit_path);
    const separator = process.platform === "win32" ? ";" : ":";
    const env = buildStage3ChildEnvironment(spec, { PATH: ["/usr/bin", "/some/OceanAgent-main/.venv/bin", "/tmp/outputs/stage3/other/A1/bin"].join(separator),
      LANG: "en_US.UTF-8", HOME: "/shared", DEEPSEEK_API_KEY: "not-a-real-key", OCEAN_DB_PATH: "/shared/main.sqlite",
      OCEAN_PYTHON_PATH: "/some/OceanAgent-main/.venv/bin/python", OCEAN_PYTHON_VENV: "/shared/venv", OCEAN_DATA_PYTHON: "/shared/python",
      VIRTUAL_ENV: "/shared/venv", PYTHONPATH: "/shared/modules", NODE_OPTIONS: "--import=/shared/hook.mjs", NODE_PATH: "/shared/node_modules" });
    expect(env.HOME).toBe(spec.paths.runtime_home); expect(env.OCEAN_DB_PATH).toBe(spec.paths.database);
    expect(env.PATH).not.toContain("OceanAgent-main"); expect(env.PATH).not.toContain("outputs/stage3"); expect(env.LANG).toBe("en_US.UTF-8");
    for (const key of ["DEEPSEEK_API_KEY", "OCEAN_PYTHON_PATH", "OCEAN_PYTHON_VENV", "OCEAN_DATA_PYTHON", "VIRTUAL_ENV", "PYTHONPATH", "NODE_OPTIONS", "NODE_PATH"]) expect(env[key]).toBeUndefined();
    expect(env.TMPDIR).toBe(join(spec.paths.runtime_home, "tmp"));
  });
});
