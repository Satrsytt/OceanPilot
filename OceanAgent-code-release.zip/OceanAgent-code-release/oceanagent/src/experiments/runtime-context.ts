import { AsyncLocalStorage } from "node:async_hooks";
import { resolve } from "node:path";
import type { Stage3UnitSpec } from "./paired-dev.js";
import type { ModelRuntime } from "@earendil-works/pi-coding-agent";
import type { DatasetRecommendation } from "./scientific-protocol.js";
import type { ResearchPlan } from "../contracts.js";
import { currentTelemetry } from "../telemetry/run-telemetry.js";
import { kbFreePlanningProtocol } from "./kb-ablation-protocol.js";
import { auditKbPlanningRequest } from "./kb-ablation-request-audit.js";

// Immutable run identity is also available to subagent/model calls through the existing async chain.
const scope = new AsyncLocalStorage<Stage3UnitSpec>();
export function withExperimentUnit<T>(unit: Stage3UnitSpec, work: () => Promise<T>): Promise<T> {
  return scope.run(unit, work);
}
export function currentExperimentUnit(): Stage3UnitSpec | undefined { return scope.getStore(); }
const states = new WeakMap<Stage3UnitSpec, { started: number; tools: number; toolLimitReached?: boolean; download: { used: number; limit: number } }>();
const recommendations = new WeakMap<Stage3UnitSpec, DatasetRecommendation>();
const submittedPlans = new WeakMap<Stage3UnitSpec, ResearchPlan>();
export function recordExperimentPlan(unit: Stage3UnitSpec, value: ResearchPlan): void {
  if (submittedPlans.has(unit)) throw new Error("STAGE3_PLAN_ALREADY_SUBMITTED");
  submittedPlans.set(unit, value);
}
export function experimentPlan(unit: Stage3UnitSpec): ResearchPlan | undefined { return submittedPlans.get(unit); }
export function recordExperimentRecommendation(unit: Stage3UnitSpec, value: DatasetRecommendation): void {
  if (recommendations.has(unit)) throw new Error("STAGE3_RECOMMENDATION_ALREADY_SUBMITTED");
  recommendations.set(unit, value);
}
export function experimentRecommendation(unit: Stage3UnitSpec): DatasetRecommendation | undefined {
  return recommendations.get(unit);
}
export function startExperimentBudget(unit: Stage3UnitSpec): void {
  states.set(unit, { started: performance.now(), tools: 0, download: { used: 0, limit: unit.budget.max_download_bytes } });
}
export function experimentDownloadBudget(unit: Stage3UnitSpec): { used: number; limit: number } {
  if (!states.has(unit)) startExperimentBudget(unit);
  return states.get(unit)!.download;
}
export function remainingExperimentMs(unit: Stage3UnitSpec): number {
  if (!states.has(unit)) startExperimentBudget(unit);
  return Math.max(0, unit.budget.max_agent_ms - (performance.now() - states.get(unit)!.started));
}
export function experimentBudgetProgress(unit: Stage3UnitSpec): { tools: number; elapsed_ms: number; remaining_ms: number } {
  const remaining = remainingExperimentMs(unit);
  return { tools: states.get(unit)!.tools, elapsed_ms: unit.budget.max_agent_ms - remaining, remaining_ms: remaining };
}
export function consumeExperimentTool(unit: Stage3UnitSpec): void {
  if (!states.has(unit)) startExperimentBudget(unit);
  const state = states.get(unit)!;
  if (remainingExperimentMs(unit) <= 0) throw new Error("STAGE3_TIME_BUDGET_EXHAUSTED");
  if (state.tools >= unit.budget.max_tool_calls) {
    state.toolLimitReached = true;
    throw new Error("STAGE3_TOOL_BUDGET_EXHAUSTED");
  }
  state.tools += 1;
}
const boundedRuntimes = new WeakSet<ModelRuntime>();
/** Per-unit request options cover main, subagent and compaction calls without changing stored models. */
export function installExperimentModelBudget(runtime: ModelRuntime): void {
  if (boundedRuntimes.has(runtime)) return;
  boundedRuntimes.add(runtime);
  const original = runtime.streamSimple.bind(runtime);
  runtime.streamSimple = ((model, context, options) => {
    const unit = currentExperimentUnit();
    if (!unit) return original(model, context, options);
    const remaining = remainingExperimentMs(unit);
    if (remaining <= 0) throw new Error("STAGE3_TIME_BUDGET_EXHAUSTED");
    if (states.get(unit)?.toolLimitReached) throw new Error("STAGE3_TOOL_BUDGET_EXHAUSTED");
    if (kbFreePlanningProtocol(unit.runtime_config)) {
      const audit = auditKbPlanningRequest(unit, context);
      currentTelemetry()?.trace.emit("kb_ablation.request_audit", audit);
      if (!audit.passed) throw new Error("KB_ABLATION_REQUEST_ISOLATION_VIOLATION");
    }
    const deadline = AbortSignal.timeout(Math.max(1, Math.ceil(remaining)));
    const temperature = typeof unit.runtime_config.temperature === "number" ? unit.runtime_config.temperature : 0;
    return original(model, context, { ...options,
      maxTokens: Math.min(options?.maxTokens ?? unit.budget.max_output_tokens, unit.budget.max_output_tokens),
      temperature, cacheRetention: "none",
      signal: options?.signal ? AbortSignal.any([options.signal, deadline]) : deadline });
  }) as ModelRuntime["streamSimple"];
}
export function experimentMetadata(unit: Stage3UnitSpec): Record<string, unknown> {
  return { schema_version: unit.schema_version, experiment_id: unit.experiment_id, pair_id: unit.pair_id,
    unit_id: unit.unit_id, query_id: unit.query_id, replicate_id: unit.replicate_id, condition: unit.condition,
    seed: unit.seed, seed_scope: "condition_order_only", model: unit.model,
    input_sha256: unit.input_sha256, config_sha256: unit.config_sha256,
    knowledge_snapshot_id: unit.knowledge_snapshot_id, data_snapshot_id: unit.data_snapshot_id,
    mode: unit.runtime_config.mode, budget: unit.budget, unit_dir: resolve(unit.paths.unit_dir) };
}
