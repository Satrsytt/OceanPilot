import { describe, expect, it } from "vitest";
import { auditKbPlanningRequest } from "./kb-ablation-request-audit.js";
import type { Stage3UnitSpec } from "./paired-dev.js";
import { KB_PLANNING_NON_KB_TOOLS } from "./kb-ablation-protocol.js";

const unit = { condition: "A0", query: { query_id: "q", query: "Design an SST plan" } } as Stage3UnitSpec;
const context = { systemPrompt: "Use scientific reasoning and official facts; no knowledge card context is provided.",
  tools: KB_PLANNING_NON_KB_TOOLS.map(name => ({ name })), messages: [{ role: "user", content: unit.query.query }] };
describe("actual free-planning model request audit", () => {
  it("permits the shared query and equal non-KB tools", () => {
    expect(auditKbPlanningRequest(unit, context)).toMatchObject({ passed: true, knowledge_tool_names: [], known_card_id_hits: [] });
  });
  it("rejects a KB tool that somehow reaches the actual off request", () => {
    expect(auditKbPlanningRequest(unit, { ...context, tools: [...context.tools, { name: "get_dataset_facts" }] }).passed).toBe(false);
  });
  it("detects nested text-encoded card payloads and KB tool results", () => {
    const messages = [...context.messages, { role: "toolResult", toolName: "get_dataset_facts", content: [
      { type: "text", text: JSON.stringify({ cardType: "dataset", dataset_id: "DatasetCard:private", payload: { bundle_id: "UBC:private" } }) },
    ] }];
    const audit = auditKbPlanningRequest(unit, { ...context, messages });
    expect(audit.passed).toBe(false); expect(audit.known_card_id_hits).toContain("DatasetCard:private");
    expect(audit.injected_card_payload_message_indices).toEqual([1]);
  });
  it("rejects forced KB system instructions and injected system card IDs", () => {
    expect(auditKbPlanningRequest(unit, { ...context, systemPrompt: "必须先实际调用 Ocean-RAG" }).passed).toBe(false);
    expect(auditKbPlanningRequest(unit, { ...context, systemPrompt: "Prior evidence PSC:private" }).passed).toBe(false);
  });
  it("does not mistake public product identities or assistant hypotheses for control-plane card injection", () => {
    expect(auditKbPlanningRequest(unit, { ...context, messages: [...context.messages,
      { role: "assistant", content: "Consider OISST, unknown availability" },
      { role: "toolResult", toolName: "search_official_web", content: [{ type: "text", text: "Official OISST product metadata" }] },
    ] }).passed).toBe(true);
  });
});
