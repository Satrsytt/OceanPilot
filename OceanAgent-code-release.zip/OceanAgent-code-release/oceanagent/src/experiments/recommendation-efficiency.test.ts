import { mkdir, mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import type { ToolDefinition } from "@earendil-works/pi-coding-agent";
import { Type } from "typebox";
import { afterEach, describe, expect, it, vi } from "vitest";
import { createRecommendationToolCoordinator } from "./recommendation-efficiency.js";
import { wrapExperimentTool } from "./tool-isolation.js";
import { startExperimentBudget, withExperimentUnit } from "./runtime-context.js";
import type { Stage3UnitSpec } from "./paired-dev.js";

const scratch: string[] = [];
afterEach(async () => { vi.restoreAllMocks(); for (const root of scratch.splice(0)) await rm(root, { recursive: true, force: true }); });
const result = () => ({ content: [{ type: "text" as const, text: "full frozen evidence" }],
  details: { documents: [{ id: "dataset-a", cardType: "dataset" }] } });
const execute = (tool: ToolDefinition<any, any, any>, params: unknown, id = "call") => tool.execute(id, params,
  undefined, undefined, {} as never);
const tool = (name: string, handler = vi.fn(async () => result())) => ({ name, label: name,
  description: name, parameters: Type.Object({ query: Type.String() }), execute: handler } as ToolDefinition<any, any, any>);

describe("Scientific V2 recommendation read reuse", () => {
  it("reuses identical successful reads with explicit origin, stable evidence and unchanged schema", async () => {
    const original = tool("expand_research_case"), wrap = createRecommendationToolCoordinator(), cached = wrap(original);
    expect(cached.parameters).toBe(original.parameters);
    const first = await execute(cached, { query: "one", field: "x" }, "first");
    first.content[0].text = "consumer mutation";
    const second = await execute(cached, { field: "x", query: "one" }, "second");
    expect(original.execute).toHaveBeenCalledTimes(1);
    expect(second.content[0].text).toBe("full frozen evidence");
    expect(second.details).toMatchObject({ recommendation_cache_hit: true, cache_scope: "agent_session",
      original_tool_call_id: "first", documents: [{ id: "dataset-a" }] });
    await execute(cached, { query: "different", field: "x" });
    expect(original.execute).toHaveBeenCalledTimes(2);
  });

  it("never shares evidence between sessions, conditions, or tool names", async () => {
    const original = tool("get_dataset_facts"), a = createRecommendationToolCoordinator(), b = createRecommendationToolCoordinator();
    await execute(a(original), { query: "same" });
    await execute(b(original), { query: "same" });
    expect(original.execute).toHaveBeenCalledTimes(2);
    const different = tool("search_ocean_datasets"); await execute(a(different), { query: "same" });
    expect(different.execute).toHaveBeenCalledTimes(1);
  });

  it("does not reissue identical empty official searches, and never caches exceptions or error results", async () => {
    const handler = vi.fn(async () => ({ content: [{ type: "text" as const, text: "no results" }], details: { results: [] } }));
    const search = createRecommendationToolCoordinator()(tool("search_official_web", handler as any));
    await execute(search, { query: "official metadata" }); await execute(search, { query: "official metadata" });
    expect(handler).toHaveBeenCalledTimes(1);
    const fail = vi.fn(async () => { throw new Error("transient failure"); });
    const failed = createRecommendationToolCoordinator()(tool("get_dataset_facts", fail as any));
    await expect(execute(failed, { query: "same" })).rejects.toThrow("transient");
    await expect(execute(failed, { query: "same" })).rejects.toThrow("transient");
    expect(fail).toHaveBeenCalledTimes(2);
    const error = vi.fn(async () => ({ ...result(), isError: true }));
    const errored = createRecommendationToolCoordinator()(tool("get_dataset_facts", error as any));
    await execute(errored, { query: "same" }); await execute(errored, { query: "same" });
    expect(error).toHaveBeenCalledTimes(2);
  });

  it("charges repeated cached calls to the unchanged outer per-call budget", async () => {
    const root = await mkdtemp(join(tmpdir(), "recommendation-cache-")); scratch.push(root);
    const workspace = join(root, "workspace"), runtimeHome = join(root, "home");
    await mkdir(workspace); await mkdir(runtimeHome);
    let count = 0;
    const options = { unitDir: root, workspace, runtimeHome,
      beforeExecute: () => { if (++count > 2) throw new Error("tool budget"); } };
    const original = tool("get_dataset_facts");
    const wrapped = wrapExperimentTool(createRecommendationToolCoordinator()(original), options);
    await execute(wrapped, { query: "same" }); await execute(wrapped, { query: "same" });
    await expect(execute(wrapped, { query: "same" })).rejects.toThrow("tool budget");
    expect(count).toBe(3); expect(original.execute).toHaveBeenCalledTimes(1);
  });

  it("preserves terminal submission results and never memoizes writes or submission", async () => {
    const submit = vi.fn(async () => ({ ...result(), terminate: true }));
    const wrapped = createRecommendationToolCoordinator()(tool("submit_dataset_recommendation", submit as any));
    expect(await execute(wrapped, { query: "same" })).toMatchObject({ terminate: true });
    await execute(wrapped, { query: "same" }); expect(submit).toHaveBeenCalledTimes(2);
    const write = tool("write"), wrappedWrite = createRecommendationToolCoordinator()(write);
    await execute(wrappedWrite, { query: "same" }); await execute(wrappedWrite, { query: "same" });
    expect(write.execute).toHaveBeenCalledTimes(2);
  });

  it("adds a common near-deadline submission reminder without discarding evidence", async () => {
    const clock = vi.spyOn(performance, "now").mockReturnValue(0);
    const unit = { budget: { max_agent_ms: 180000, max_tool_calls: 24, max_download_bytes: 100 },
      runtime_config: { mode: "recommendation", protocol_version: "stage3-scientific-v2" } } as Stage3UnitSpec;
    startExperimentBudget(unit); clock.mockReturnValue(140000);
    await withExperimentUnit(unit, async () => {
      const output = await execute(createRecommendationToolCoordinator()(tool("get_dataset_facts")), { query: "same" });
      expect(output.content[0].text).toBe("full frozen evidence");
      expect(output.content.at(-1).text).toContain("立即基于已有证据调用submit_dataset_recommendation");
    });
  });
});
