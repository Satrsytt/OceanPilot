import { mkdir, mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { dirname, join, resolve } from "node:path";
import { createRequire } from "node:module";
import { pathToFileURL } from "node:url";
import { afterEach, expect, it, vi } from "vitest";
import { Type } from "typebox";
import type { AppConfig } from "../config.js";
import type { OceanModelService } from "../agent/model-service.js";
import type { Stage3UnitSpec } from "./paired-dev.js";
const { sessionOptions, previousStopHook } = vi.hoisted(() => {
  const previousStopHook = vi.fn(async () => false);
  return { previousStopHook, sessionOptions: vi.fn(async _options => ({
    session: { agent: { shouldStopAfterTurn: previousStopHook } },
  })) };
});
vi.mock("@earendil-works/pi-coding-agent", async () => ({
  ...await vi.importActual("@earendil-works/pi-coding-agent"), createAgentSession: sessionOptions,
}));
import { OceanSessionFactory } from "../agent/session-factory.js";
import { recordExperimentPlan, recordExperimentRecommendation, startExperimentBudget } from "./runtime-context.js";
import { KB_ABLATION_PROTOCOL, KB_ABLATION_REPAIR_PROTOCOL, kbPlanningToolNames } from "./kb-ablation-protocol.js";

const roots: string[] = [];
afterEach(async () => { vi.unstubAllEnvs(); for (const root of roots.splice(0)) await rm(root, { recursive: true, force: true }); });
it("wires private session storage, core-tool boundaries and one shared budget into the native factory", async () => {
  const root = await mkdtemp(join(tmpdir(), "stage3-session-")); roots.push(root);
  const unitDir = join(root, "outputs", "A0"), workspace = join(unitDir, "workspace"), runtimeHome = join(unitDir, "runtime", "home");
  for (const dir of [workspace, runtimeHome, join(unitDir, "tmp"), join(root, ".pi")]) await mkdir(dir, { recursive: true });
  await writeFile(join(root, ".pi", "SYSTEM.md"), "科学数据分析；仅使用当前工作区。");
  await writeFile(join(workspace, "local.txt"), "local data");
  await writeFile(join(root, "other-arm.txt"), "must be inaccessible");
  vi.stubEnv("OCEAN_PYTHON_PATH", "/usr/bin/true");
  const unit = { condition: "A0", paths: { unit_dir: unitDir, workspace, runtime_home: runtimeHome },
    budget: { max_tool_calls: 2, max_agent_ms: 10000, max_download_bytes: 100, max_output_tokens: 32 } } as Stage3UnitSpec;
  const models = { resolveRunModel: () => ({ id: "offline" }), enabledModels: () => [], runtime: {} } as unknown as OceanModelService;
  const factory = await OceanSessionFactory.create({ rootDir: root, experiment: unit } as AppConfig, models);
  startExperimentBudget(unit);
  await factory.createSession({} as never, [], workspace, ["read", "write"]);
  const options = sessionOptions.mock.calls.at(-1)![0];
  expect(options.agentDir).toBe(join(runtimeHome, "pi-runtime"));
  expect(options.customTools.map((tool: any) => tool.name)).toEqual(["read", "bash", "edit", "write"]);
  const read = options.customTools.find((tool: any) => tool.name === "read");
  await expect(read.execute("escape", { path: "../../other-arm.txt" }, undefined, undefined, {})).rejects.toThrow("越出");
  const result = await read.execute("local", { path: "local.txt" }, undefined, undefined, {});
  expect(result.content[0].text).toContain("local data");
  const write = options.customTools.find((tool: any) => tool.name === "write");
  await expect(write.execute("limit", { path: "out.txt", content: "no" }, undefined, undefined, {})).rejects.toThrow("TOOL_BUDGET");
  await expect(readFile(join(workspace, "out.txt"))).rejects.toMatchObject({ code: "ENOENT" });
});

it.each([KB_ABLATION_PROTOCOL, KB_ABLATION_REPAIR_PROTOCOL].flatMap(protocol_version => ["A0", "A1"].map(condition => ({protocol_version,condition}))))("registers only the free-planning tool permissions for $condition/$protocol_version, including factory-level KB-off defense", async ({condition,protocol_version}) => {
  const root = await mkdtemp(join(tmpdir(), "kb-free-session-")); roots.push(root);
  const unitDir = join(root, "unit"), workspace = join(unitDir, "workspace"), runtimeHome = join(unitDir, "home");
  for (const dir of [workspace, runtimeHome, join(unitDir, "tmp"), join(root, ".pi")]) await mkdir(dir, { recursive: true });
  await writeFile(join(root, ".pi", "SYSTEM.md"), "OceanAgent Planner, unknown scientific facts stay unknown. GENERAL_EXECUTION_SENTINEL acquire_scientific_data");
  vi.stubEnv("OCEAN_PYTHON_PATH", "/usr/bin/true");
  const unit = { condition, runtime_config: { mode: "plan", protocol_version },
    paths: { unit_dir: unitDir, workspace, runtime_home: runtimeHome },
    budget: { max_agent_ms: 10000, max_tool_calls: 20, max_download_bytes: 100, max_output_tokens: 4096 } } as Stage3UnitSpec;
  const names = [...kbPlanningToolNames("A1"), "read", "write", "bash", "acquire_scientific_data", "subagent"];
  const custom = names.map(name => ({ name, label: name, description: name, parameters: Type.Object({}),
    execute: vi.fn(async () => ({ content: [{ type: "text" as const, text: "local fixture only" }] })) }));
  const models = { resolveRunModel: () => ({ id: "offline" }), enabledModels: () => [], runtime: {} } as unknown as OceanModelService;
  const factory = await OceanSessionFactory.create({ rootDir: root, experiment: unit } as AppConfig, models);
  startExperimentBudget(unit);
  const created = await factory.createSession({} as never, custom, workspace, names);
  const options = sessionOptions.mock.calls.at(-1)![0];
  expect(options.tools).toEqual(kbPlanningToolNames(condition));
  expect(options.customTools.map((tool: any) => tool.name)).toEqual(kbPlanningToolNames(condition));
  expect(created.session.agent.shouldStopAfterTurn).not.toBe(previousStopHook);
  if(protocol_version===KB_ABLATION_REPAIR_PROTOCOL){
    expect(options.resourceLoader.getSystemPrompt()).not.toContain("GENERAL_EXECUTION_SENTINEL");
    expect(options.resourceLoader.getSystemPrompt()).toContain("最多8次工具调用或90秒");
  }
});

it.each([
  { mode: "recommendation", protocol_version: "stage3-scientific-v2", expectedCalls: 1 },
  { mode: "plan", protocol_version: "stage3-scientific-v2", expectedCalls: 1 },
  { mode: "recommendation", expectedCalls: 2 },
])("scopes read reuse to Scientific V2 recommendation/Plan ($mode, $protocol_version)", async runtime => {
  const root = await mkdtemp(join(tmpdir(), "stage3-session-cache-")); roots.push(root);
  const unitDir = join(root, "outputs", "A0"), workspace = join(unitDir, "workspace"), runtimeHome = join(unitDir, "runtime", "home");
  for (const dir of [workspace, runtimeHome, join(unitDir, "tmp"), join(root, ".pi")]) await mkdir(dir, { recursive: true });
  await writeFile(join(root, ".pi", "SYSTEM.md"), "科学数据分析；仅使用当前工作区。");
  vi.stubEnv("OCEAN_PYTHON_PATH", "/usr/bin/true");
  const unit = { condition: "A0", runtime_config: { mode: runtime.mode,
    ...(runtime.protocol_version ? { protocol_version: runtime.protocol_version } : {}) },
    paths: { unit_dir: unitDir, workspace, runtime_home: runtimeHome },
    budget: { max_tool_calls: 2, max_agent_ms: 10000, max_download_bytes: 100, max_output_tokens: 32 } } as Stage3UnitSpec;
  const models = { resolveRunModel: () => ({ id: "offline" }), enabledModels: () => [], runtime: {} } as unknown as OceanModelService;
  const original = vi.fn(async () => ({ content: [{ type: "text" as const, text: "official evidence" }], details: {} }));
  const custom = { name: "get_dataset_facts", label: "facts", description: "facts", parameters: Type.Object({}), execute: original };
  const factory = await OceanSessionFactory.create({ rootDir: root, experiment: unit } as AppConfig, models);
  startExperimentBudget(unit);
  const created = await factory.createSession({} as never, [custom], workspace, ["get_dataset_facts"]);
  expect(created.session.agent.shouldStopAfterTurn === previousStopHook).toBe(runtime.expectedCalls === 2);
  const registered = sessionOptions.mock.calls.at(-1)![0].customTools.find((tool: any) => tool.name === "get_dataset_facts");
  await registered.execute("one", {}, undefined, undefined, {});
  await registered.execute("two", {}, undefined, undefined, {});
  expect(original).toHaveBeenCalledTimes(runtime.expectedCalls);
  await expect(registered.execute("three", {}, undefined, undefined, {})).rejects.toThrow("TOOL_BUDGET");
});

it.each(["recommendation", "plan"])("uses the real SDK stop hook to end mixed report/%s batches without another model request", async mode => {
  const root = await mkdtemp(join(tmpdir(), "stage3-terminal-batch-")); roots.push(root);
  const unitDir = join(root, "unit"), workspace = join(unitDir, "workspace"), runtimeHome = join(unitDir, "home");
  for (const dir of [workspace, runtimeHome, join(unitDir, "tmp"), join(root, ".pi")]) await mkdir(dir, { recursive: true });
  await writeFile(join(root, ".pi", "SYSTEM.md"), "Test only; no provider call.");
  vi.stubEnv("OCEAN_PYTHON_PATH", "/usr/bin/true");
  const unit = { condition: "A0", runtime_config: { mode, protocol_version: "stage3-scientific-v2" },
    paths: { unit_dir: unitDir, workspace, runtime_home: runtimeHome },
    budget: { max_agent_ms: 10000, max_tool_calls: 24, max_download_bytes: 100, max_output_tokens: 4096 } } as Stage3UnitSpec;
  const models = { resolveRunModel: () => ({ id: "not-a-live-model" }), enabledModels: () => [], runtime: {} } as unknown as OceanModelService;
  const factory = await OceanSessionFactory.create({ rootDir: root, experiment: unit } as AppConfig, models);
  const created = await factory.createSession({} as never, [], workspace, []);
  const stop = created.session.agent.shouldStopAfterTurn!;
  previousStopHook.mockClear();
  expect(await stop({} as never)).toBe(false);
  expect(previousStopHook).toHaveBeenCalledTimes(1);

  // Resolve the exact core SDK installed beneath the coding-agent package, rather than
  // a hand-written loop or a second dependency. Every stream below is deterministic/local.
  const sdkRequire = createRequire(import.meta.resolve("@earendil-works/pi-coding-agent"));
  const corePackage = sdkRequire.resolve("@earendil-works/pi-agent-core/package.json");
  const coreMetadata = JSON.parse(await readFile(corePackage, "utf8"));
  const { runAgentLoop } = await import(pathToFileURL(resolve(dirname(corePackage), coreMetadata.main)).href);
  async function run(installStop: boolean) {
    let calls = 0;
    const submit = mode === "plan" ? "propose_research_plan" : "submit_dataset_recommendation";
    const tools = ["report_research_reasoning", submit].map(name => ({
      name, description: name, parameters: Type.Object({}), executionMode: "sequential",
      execute: async () => {
        if (name === submit && installStop && mode === "plan") recordExperimentPlan(unit, { id: "unit-test-only" } as never);
        if (name === submit && installStop && mode === "recommendation") recordExperimentRecommendation(unit, {
          schema_version: "stage3-recommendation-v2", ranking_semantics: "explicit_model_priority_not_retrieval_score",
          candidates: [], candidate_sha256: "unit-test-only", capability_semantics: "model_claims_require_independent_judgment", submitted_at: "unit-test-only",
        });
        return { content: [{ type: "text", text: "local test only" }], details: {},
          ...(name === submit ? { terminate: true } : {}) };
      },
    }));
    const fakeStream = async () => {
      calls++;
      const message = { role: "assistant", api: "openai-completions", provider: "local-unit-test", model: "not-a-live-model", timestamp: 0,
        content: calls === 1 ? tools.map((t, i) => ({ type: "toolCall", id: `call-${i}`, name: t.name, arguments: {} }))
          : [{ type: "text", text: "unnecessary final response" }], stopReason: calls === 1 ? "toolUse" : "stop",
        usage: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0, totalTokens: 0, cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0, total: 0 } } };
      return { [Symbol.asyncIterator]: async function* () { yield { type: "done", message }; }, result: async () => message };
    };
    const rows = await runAgentLoop([{ role: "user", content: "test only", timestamp: 0 }],
      { systemPrompt: "test only", messages: [], tools },
      { model: { id: "not-a-live-model", provider: "local-unit-test", api: "openai-completions" }, convertToLlm: (x: unknown) => x,
        ...(installStop ? { shouldStopAfterTurn: stop } : {}) }, () => {}, undefined, fakeStream);
    return { calls, tools: rows.filter((r: any) => r.role === "toolResult").map((r: any) => r.toolName) };
  }
  const submit = mode === "plan" ? "propose_research_plan" : "submit_dataset_recommendation";
  expect(await run(false)).toEqual({ calls: 2, tools: ["report_research_reasoning", submit] });
  expect(await run(true)).toEqual({ calls: 1, tools: ["report_research_reasoning", submit] });
  // Submission short-circuits only after a valid application-side stored recommendation.
  expect(previousStopHook).toHaveBeenCalledTimes(1);
});
