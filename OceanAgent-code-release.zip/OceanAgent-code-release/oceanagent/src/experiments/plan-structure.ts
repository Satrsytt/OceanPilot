/** Fixed-input Plan submission contract checks. */
import { validatePublicEvidenceUrl } from "../agent/tools/submit-dataset-recommendation.js";
import { hasPlanDependencyCycle } from "../agent/candidate-plans.js";

type Row = Record<string, unknown>;
const object = (v: unknown): v is Row => !!v && typeof v === "object" && !Array.isArray(v);
const text = (v: unknown): v is string => typeof v === "string" && !!v.trim();
const list = (v: unknown): v is string[] => Array.isArray(v) && v.every(text);
const same = (a: string[], b: readonly string[]) => a.length === b.length && a.every(x => b.includes(x));

export function fixedPlanStructureErrors(value: unknown, fixedDatasets: readonly string[], options: {
  knownEvidenceIds?: ReadonlySet<string>;
} = {}): string[] {
  const errors: string[] = [];
  if (!object(value)) return ["plan_must_be_object"];
  if (!text(value.objective)) errors.push("objective_missing");
  if (!list(value.datasets) || new Set(value.datasets).size !== value.datasets.length || !same(value.datasets, fixedDatasets)) errors.push("fixed_dataset_set_differs");
  const roles = object(value.datasetRoles) ? value.datasetRoles : {};
  if (!same(Object.keys(roles), fixedDatasets) || Object.values(roles).some(v => !text(v))) errors.push("dataset_roles_must_cover_exact_fixed_set");
  if (!list(value.deliverables) || !value.deliverables.length) errors.push("deliverables_missing");
  if (!Array.isArray(value.steps) || value.steps.length < 1 || value.steps.length > 20) return [...errors, "steps_must_have_1_to_20_items"];
  const steps = value.steps.filter(object), byId = new Map(steps.filter(s => text(s.id)).map(s => [s.id as string, s]));
  if (steps.length !== value.steps.length || byId.size !== steps.length) errors.push("step_ids_missing_or_duplicate");
  const used = new Set<string>();
  function evidence(refs: unknown, path: string) {
    if (refs === undefined) return;
    if (!list(refs)) { errors.push(`${path}:invalid_evidence_refs`); return; }
    for (const ref of refs) {
      if (/^https?:/i.test(ref)) {
        try { validatePublicEvidenceUrl(ref); } catch { errors.push(`${path}:unsafe_evidence_url`); }
      } else if (options.knownEvidenceIds && !options.knownEvidenceIds.has(ref)) errors.push(`${path}:unretrieved_evidence_id:${ref}`);
    }
  }
  evidence(value.evidenceRefs, "plan");
  for (const step of steps) {
    const id = String(step.id);
    if (!text(step.id) || !text(step.title) || !text(step.description)) errors.push(`${id}:step_text_missing`);
    if (!["data", "analysis", "validation", "artifact"].includes(String(step.phase))) errors.push(`${id}:phase_missing_or_invalid`);
    if (!list(step.expectedOutputs) || !step.expectedOutputs.length) errors.push(`${id}:outputs_missing`);
    if (!list(step.dependsOn)) errors.push(`${id}:dependencies_must_be_array`);
    const deps = list(step.dependsOn) ? step.dependsOn : [];
    if (new Set(deps).size !== deps.length || deps.includes(id)) errors.push(`${id}:duplicate_or_self_dependency`);
    for (const dep of deps) if (!byId.has(dep)) errors.push(`${id}:unknown_dependency:${dep}`);
    const inputs = object(step.inputs) ? step.inputs : {};
    if (!Object.keys(inputs).length) errors.push(`${id}:inputs_missing`);
    if (inputs.datasetIds !== undefined) {
      if (!list(inputs.datasetIds) || new Set(inputs.datasetIds).size !== inputs.datasetIds.length) errors.push(`${id}:invalid_dataset_refs`);
      else for (const dataset of inputs.datasetIds) {
        if (!fixedDatasets.includes(dataset)) errors.push(`${id}:unknown_dataset:${dataset}`); else used.add(dataset);
      }
    }
    if (inputs.fromSteps !== undefined && (!list(inputs.fromSteps) || inputs.fromSteps.some(ref => !deps.includes(ref)))) errors.push(`${id}:input_step_not_dependency`);
    evidence(inputs.evidenceRefs, id);
  }
  if (fixedDatasets.some(id => !used.has(id))) errors.push("fixed_dataset_not_referenced_by_steps");
  if (hasPlanDependencyCycle([...byId].map(([id, step]) => ({ id, dependsOn: list(step.dependsOn) ? step.dependsOn : [] })))) errors.push("dependency_cycle");
  const ancestors = (id: string, seen = new Set<string>()): Set<string> => {
    for (const dep of (list(byId.get(id)?.dependsOn) ? byId.get(id)!.dependsOn : []) as string[]) if (!seen.has(dep) && byId.has(dep)) { seen.add(dep); ancestors(dep, seen); }
    return seen;
  };
  const declaredPath = steps.some(s => s.phase === "validation" && text(s.id) && [...ancestors(s.id)].some(a => {
    const analysis = byId.get(a); return analysis?.phase === "analysis" && [...ancestors(a)].some(d => byId.get(d)?.phase === "data");
  }));
  if (!declaredPath) errors.push("declared_data_analysis_validation_path_missing");
  return [...new Set(errors)];
}
