/** Opt-in protocol: legacy manifests and their prompt hashes retain their original meaning. */
export const SCIENTIFIC_PROTOCOL = "stage3-scientific-v2";
export const RECOMMENDATION_CONTRACT = "stage3-recommendation-v2";
export function scientificProtocol(config?: Record<string, unknown>): boolean {
  return config?.protocol_version === SCIENTIFIC_PROTOCOL;
}

export interface OrderedProductCandidate {
  rank: number;
  dataset_id: string;
  canonical_product_id: string | null;
  identity_status: "verified" | "ambiguous" | "unresolved";
  evidence_urls: string[];
  capabilities: string[];
  roles: string[];
  rationale: string;
  evidence_ids: string[];
}
export interface DatasetRecommendation {
  schema_version: typeof RECOMMENDATION_CONTRACT;
  ranking_semantics: "explicit_model_priority_not_retrieval_score";
  candidates: OrderedProductCandidate[];
  candidate_sha256: string;
  candidate_hash_semantics?: "redacted_canonical_json_v1";
  capability_semantics: "model_claims_require_independent_judgment";
  submitted_at: string;
}
