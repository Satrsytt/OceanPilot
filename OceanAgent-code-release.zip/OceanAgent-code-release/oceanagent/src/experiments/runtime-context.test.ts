import { afterEach, describe, expect, it, vi } from "vitest";
import type { ModelRuntime } from "@earendil-works/pi-coding-agent";
import type { Stage3UnitSpec } from "./paired-dev.js";
import { consumeExperimentTool, currentExperimentUnit, experimentDownloadBudget, experimentMetadata,
  installExperimentModelBudget, remainingExperimentMs, startExperimentBudget, withExperimentUnit } from "./runtime-context.js";
import { withRunTelemetry } from "../telemetry/run-telemetry.js";
import { KB_ABLATION_PROTOCOL } from "./kb-ablation-protocol.js";

function unit(id = "A0"): Stage3UnitSpec {
  return { schema_version: "stage3-ablation-v1", unit_id: id, condition: id,
    budget: { max_agent_ms: 1000, max_tool_calls: 2, max_download_bytes: 100, max_output_tokens: 32 },
    runtime_config: { mode: "recommendation", temperature: 0 }, paths: { unit_dir: `/tmp/${id}` },
  } as Stage3UnitSpec;
}
afterEach(() => vi.restoreAllMocks());
describe("shared stage3 run budget", () => {
  it("isolates async unit identities and leaves normal calls unscoped", async () => {
    const a = unit("A0"), b = unit("A1");
    await Promise.all([a, b].map(spec => withExperimentUnit(spec, async () => {
      await Promise.resolve(); expect(currentExperimentUnit()).toBe(spec);
    })));
    expect(currentExperimentUnit()).toBeUndefined();
    expect(experimentMetadata(a).seed_scope).toBe("condition_order_only");
  });
  it("shares tool counts and time limits across sessions", () => {
    let now = 0; vi.spyOn(performance, "now").mockImplementation(() => now);
    const spec = unit(); startExperimentBudget(spec);
    consumeExperimentTool(spec); consumeExperimentTool(spec);
    expect(() => consumeExperimentTool(spec)).toThrow("TOOL_BUDGET");
    const next = unit("A1"); startExperimentBudget(next); now = 1001;
    expect(remainingExperimentMs(next)).toBe(0);
    expect(() => consumeExperimentTool(next)).toThrow("TIME_BUDGET");
  });
  it("keeps download accounting across planning and execution without crossing arms", () => {
    const a = unit("A0"), b = unit("A1");
    experimentDownloadBudget(a).used += 12;
    expect(experimentDownloadBudget(a)).toEqual({ used: 12, limit: 100 });
    expect(experimentDownloadBudget(b)).toEqual({ used: 0, limit: 100 });
  });
  it("caps actual model options only within the scoped experiment", async () => {
    const original = vi.fn(() => ({})); const runtime = { streamSimple: original } as unknown as ModelRuntime;
    installExperimentModelBudget(runtime); installExperimentModelBudget(runtime);
    const invoke = runtime.streamSimple as (...args: any[]) => unknown;
    invoke({}, {}, { maxTokens: 200 });
    expect(original.mock.calls[0]?.[2]).toEqual({ maxTokens: 200 });
    await withExperimentUnit(unit(), async () => {
      invoke({}, {}, { maxTokens: 200, temperature: 1 });
      expect(original.mock.calls[1]?.[2]).toMatchObject({ maxTokens: 32, temperature: 0, cacheRetention: "none" });
      expect(original.mock.calls[1]?.[2]?.signal).toBeInstanceOf(AbortSignal);
    });
    const exhausted = unit(); consumeExperimentTool(exhausted); consumeExperimentTool(exhausted);
    expect(() => consumeExperimentTool(exhausted)).toThrow("TOOL_BUDGET");
    await withExperimentUnit(exhausted, async () => {
      expect(() => invoke({}, {}, {})).toThrow("TOOL_BUDGET");
    });
  });
  it("audits each actual free-planning request and blocks KB leakage before the model transport", async () => {
    const original = vi.fn(() => ({})), emit = vi.fn();
    const runtime = { streamSimple: original } as unknown as ModelRuntime;
    installExperimentModelBudget(runtime);
    const spec = { ...unit(), query: { query_id: "q", query: "Design an SST plan" },
      runtime_config: { protocol_version: KB_ABLATION_PROTOCOL, mode: "plan" } } as Stage3UnitSpec;
    const invoke = runtime.streamSimple as (...args: any[]) => unknown;
    await withExperimentUnit(spec, () => withRunTelemetry({ emit } as never, async () => {
      invoke({}, { systemPrompt: "Reason from public facts", tools: [{ name: "propose_research_plan" }],
        messages: [{ role: "user", content: spec.query.query }] }, {});
      expect(original).toHaveBeenCalledTimes(1);
      expect(emit).toHaveBeenLastCalledWith("kb_ablation.request_audit", expect.objectContaining({ passed: true }));
      expect(() => invoke({}, { tools: [{ name: "get_dataset_facts" }] }, {})).toThrow("REQUEST_ISOLATION");
      expect(original).toHaveBeenCalledTimes(1);
      expect(emit).toHaveBeenLastCalledWith("kb_ablation.request_audit", expect.objectContaining({ passed: false }));
    }));
  });
});
