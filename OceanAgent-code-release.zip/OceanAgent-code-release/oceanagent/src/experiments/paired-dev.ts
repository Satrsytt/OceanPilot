/** DEV-only orchestration. Preparation never starts an Agent, opens an app DB, or reads Gold/TEST files. */
import { createHash } from "node:crypto";
import { spawn } from "node:child_process";
import { constants, createReadStream } from "node:fs";
import { chmod, copyFile, lstat, mkdir, readFile, realpath, readdir, writeFile } from "node:fs/promises";
import { basename, dirname, isAbsolute, join, relative, resolve, sep } from "node:path";
import { fileURLToPath } from "node:url";
import { isIP } from "node:net";
import { SCIENTIFIC_PROTOCOL, scientificProtocol } from "./scientific-protocol.js";
import { loadBundledPublicProducts, PUBLIC_PRODUCT_CATALOG_VERSION } from "./public-product-catalog.js";
import { KB_ABLATION_PROTOCOL, kbPlanningInstruction, kbFreePlanningProtocol } from "./kb-ablation-protocol.js";

export const STAGE3_SCHEMA = "stage3-ablation-v1" as const;
export const STAGE3_CONDITIONS = ["A0", "A1", "A2"] as const;
export type Stage3Condition = typeof STAGE3_CONDITIONS[number];
export type Stage3Mode = "recommendation" | "plan" | "end_to_end";
export interface Stage3Budget {
  max_agent_ms: number; max_tool_calls: number; max_download_bytes: number; max_output_tokens: number;
}
export interface Stage3Model { providerId: string; modelId: string }
export interface Stage3Knowledge {
  dataset_cards_path?: string; problem_solution_cards_path?: string; usage_bundle_cards_path?: string;
  source_sha256?: Record<string, string>;
  allowed_source_ids?: string[]; allowed_source_group_ids?: string[];
}
export interface Stage3UnitSpec {
  schema_version: typeof STAGE3_SCHEMA; experiment_id: string; unit_id: string; pair_id: string;
  query_id: string; replicate_id: number; condition: Stage3Condition; seed: number; condition_order_index: number;
  query: { query_id: string; query: string }; model: Stage3Model; budget: Stage3Budget;
  runtime_config: Record<string, unknown>; input_sha256: string; config_sha256: string;
  knowledge_snapshot_id: string; data_snapshot_id: string; knowledge: Stage3Knowledge;
  inputs: Array<{ path: string; sha256: string; bytes: number }>;
  paths: { unit_dir: string; workspace: string; database: string; cache: string; logs: string; artifacts: string; runtime_home: string };
}
export interface Stage3ManifestUnit {
  unit_id: string; pair_id: string; query_id: string; replicate_id: number; condition: Stage3Condition;
  seed: number; order_index: number; unit_path: string; result_path: string; input_sha256: string;
  unit_sha256: string;
  config_sha256: string; model: Stage3Model; knowledge_snapshot_id: string; data_snapshot_id: string;
}
export interface Stage3ExperimentManifest {
  schema_version: typeof STAGE3_SCHEMA; experiment_id: string; split: "DEV"; created_at: string;
  development_root: string; experiment_dir: string; fingerprint: string; dev_sha256: string; train_sha256: string;
  shared_config_sha256: string; model: Stage3Model; budget: Stage3Budget; runtime_config: Record<string, unknown>;
  knowledge_snapshot_id: string; data_snapshot_id: string; units: Stage3ManifestUnit[];
}
export interface PrepareStage3Options {
  developmentRoot: string; experimentId: string; knowledgeRoot: string; benchmarkRoot?: string;
  model: Stage3Model; budget?: Partial<Stage3Budget>; runtimeConfig?: Record<string, unknown>;
  queryIds?: string[]; limit?: number; replicates?: number; seed?: number; dataInputs?: string[]; resume?: boolean;
  /** Only the opt-in free-planning protocol may supply independent, label-free tasks and two arms. */
  queryRows?: Array<{ query_id: string; query: string }>;
  conditions?: readonly Stage3Condition[];
}
type SafeQuery = { query_id: string; query: string };
const hash = (value: string) => createHash("sha256").update(value).digest("hex");
export const stage3CanonicalJson = (value: unknown): string => JSON.stringify(canonical(value));
/** Freeze the inference source, not tests, credentials, data or prior outputs. */
export async function stage3InferenceSourceSnapshot(): Promise<string> {
  const root = resolve(dirname(fileURLToPath(import.meta.url)), "../..");
  const paths: string[] = [];
  const walk = async (path: string): Promise<void> => {
    for (const entry of await readdir(path, { withFileTypes: true })) {
      const next = join(path, entry.name);
      if (entry.isDirectory()) await walk(next);
      else if (/\.(?:ts|py|json)$/.test(entry.name) && !entry.name.endsWith(".test.ts")) paths.push(next);
    }
  };
  await walk(join(root, "src")); paths.push(join(root, ".pi", "SYSTEM.md"), join(root, "package-lock.json"));
  const records = await Promise.all(paths.sort().map(async path => [relative(root, path), await fileHash(path)]));
  return hash(stage3CanonicalJson(records));
}
function canonical(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(canonical);
  return value && typeof value === "object" ? Object.fromEntries(Object.entries(value).sort(([a], [b]) => a.localeCompare(b)).map(([k, v]) => [k, canonical(v)])) : value;
}
function assert(value: unknown, message: string): asserts value { if (!value) throw new Error(message); }
/** Exact public DNS hostnames only. DNS answers remain checked by safe-http for every request/redirect. */
export function normalizeAllowedDataHosts(value: unknown): string[] {
  assert(Array.isArray(value) && value.length <= 64, "allowed_data_hosts must be an array of at most 64 exact domain names");
  const hosts = value.map(item => {
    assert(typeof item === "string", "Each allowed data host must be a domain name");
    const host = item.trim().toLowerCase(), labels = host.split(".");
    assert(host.length <= 253 && labels.length >= 2 && !isIP(host)
      && labels.every(label => /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(label))
      && /[a-z]/.test(labels.at(-1)!)
      && !/(?:^|\.)(?:localhost|local|internal|lan|invalid|test)$/.test(host)
      && !/(?:^|\.)home\.arpa$/.test(host),
    "Allowed data host must be an exact public domain, without IP, localhost, credentials, wildcard, port or path");
    return host;
  });
  return [...new Set(hosts)].sort();
}
function executionConcurrency(value: unknown = 1): number {
  assert(typeof value === "number" && Number.isSafeInteger(value) && value >= 1 && value <= 3,
    "execution_concurrency must be an integer from 1 to 3");
  return value;
}
function safeId(value: string, label: string): string {
  assert(/^[A-Za-z0-9][A-Za-z0-9_.-]{0,119}$/.test(value) && !value.includes(".."), `${label} must be a safe stable identifier`);
  return value;
}
function noMain(path: string): void {
  assert(!/(?:^|[\\/])OceanAgent-main(?:[\\/]|$)/i.test(path), "The running OceanAgent-main checkout is forbidden");
}
function inside(root: string, path: string): boolean {
  const rel = relative(root, path); return rel === "" || rel !== ".." && !rel.startsWith(`..${sep}`) && !isAbsolute(rel);
}
async function noSymlinks(path: string): Promise<void> {
  let current = resolve(path);
  // macOS exposes its system temporary directories through these fixed OS aliases.
  if (process.platform === "darwin") current = current.replace(/^\/var(?=\/|$)/, "/private/var").replace(/^\/tmp(?=\/|$)/, "/private/tmp");
  for (;;) {
    try { assert(!(await lstat(current)).isSymbolicLink(), `Symbolic link forbidden in experiment path: ${current}`); }
    catch (error) { if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error; }
    const parent = dirname(current); if (parent === current) break; current = parent;
  }
}
async function sourceFile(path: string): Promise<string> {
  noMain(resolve(path)); await noSymlinks(path); const physical = await realpath(path); noMain(physical);
  assert((await lstat(physical)).isFile(), "Expected a read-only source file"); return physical;
}
async function fileHash(path: string): Promise<string> {
  const digest = createHash("sha256"); for await (const chunk of createReadStream(path)) digest.update(chunk); return digest.digest("hex");
}
async function rows(path: string): Promise<Record<string, unknown>[]> {
  return (await readFile(path, "utf8")).split(/\r?\n/).filter(line => line.trim()).map((line, i) => {
    let value: unknown; try { value = JSON.parse(line); } catch { throw new Error(`Invalid benchmark JSON at line ${i + 1}`); }
    assert(value && typeof value === "object" && !Array.isArray(value), "Benchmark rows must be objects");
    return value as Record<string, unknown>;
  });
}
/** Project exactly these fields; DEV evidence, paper IDs and answer labels must not enter an arm. */
export function sanitizeDevQuery(row: Record<string, unknown>): SafeQuery {
  assert(typeof row.query_id === "string" && typeof row.query === "string" && row.query.trim(), "DEV query_id/query required");
  return { query_id: safeId(row.query_id, "query_id"), query: row.query };
}
export function buildStage3Prompt(query: SafeQuery, mode: Stage3Mode = "recommendation", runtime: Record<string, unknown> = {}): string {
  if (kbFreePlanningProtocol(runtime)) return `${query.query}\n\n【统一实验契约 ${runtime?.protocol_version}】${kbPlanningInstruction(runtime)}`;
  if (scientificProtocol(runtime)) {
    const fixed = (runtime.fixed_planning as { datasets_by_query?: Record<string, string[]> } | undefined)?.datasets_by_query?.[query.query_id];
    return `${query.query}\n\n【统一实验契约 stage3-scientific-v2】${mode === "recommendation"
      ? "本轮只评价数据推荐。使用有权限访问的公共产品目录与研究知识，按当前任务必要数据角色选择有序候选，不需要枚举所有检索命中。调用submit_dataset_recommendation提交：datasetId只能是独立ID，解释写rationale，逐项给出sourceUrls、capabilities、roles和实际检索的evidenceIds；没有时用空数组。不要把候选返回顺序当科学排名。能力/角色声明待独立评价。每项rationale尽量不超过120字，capabilities和roles各用1至3个简短条目，避免长篇论证耗尽输出预算。相同查询、PSC展开和DatasetCard事实不重复读取；必要时复用已返回的证据。已有官方事实不重复联网；只有影响产品选择的关键事实缺失才查询官方网页，不为可达性、下载或补全所有未知字段反复检索。无需下载、核验端点可达或提交Plan；未知身份/证据缺口保持未知，不阻止提交。请在有限预算内尽早提交最终推荐。"
      : "本轮只做固定数据组合的Oracle科研规划，不评价推荐、不下载或执行分析。必须调用propose_research_plan提交一个有向无环Plan，datasets恰为给定ID，datasetRoles按这些ID逐项说明角色。用5至10个简短步骤覆盖预处理、分析、结果验证及产物：每步给id/title/description、phase(data|analysis|validation|artifact)、inputs、dependsOn、expectedOutputs；inputs.datasetIds引用固定ID，inputs.fromSteps只能引用本步依赖，所有固定数据集至少被一个步骤显式使用。声明data→analysis→validation依赖路径；每步预期输出非空。evidenceRefs只用本run真实检索Card ID或公开HTTPS URL，未知则空数组并列evidenceNeeds。作者生成数据、不可获取版本与未核验字段写assumptions，不声称已获取或验证。每步说明尽量不超120字，必要的命令/方法写清，不长篇汇报推理；相同卡片不重复读取，尽早一次性提交。结构和阶段声明不等于科学正确。"}${fixed ? `\n固定规划输入（所有条件相同）：${JSON.stringify(fixed)}` : ""}\n不伪造官方事实、替代产品有效性或科研结果。`;
  }
  const modes: Record<Stage3Mode, string> = {
    recommendation: "本轮仅完成数据推荐，调用 propose_research_plan 提交真实选用的数据及获取/分析计划，不下载数据或执行科学计算。datasets 按推荐优先级列出真实选用的数据集标识，可包含必要的数据组合；不要把检索命中直接当成推荐预测。",
    plan: "本轮完成数据推荐和可执行规划：根据官方元数据自动取得必要的小规模切片、验证数据及组合兼容性，随后调用 propose_research_plan 提交 Plan 并停止；不执行完整科学分析。datasets 按推荐优先级列出真实选用的数据集标识，不把检索命中当成推荐预测。",
    end_to_end: "本轮要求完成数据推荐、必要的小规模自动获取、可执行 Plan、实际分析和可验证报告。请提出 Plan 后自动执行授权范围内的分析；保留数据验证、执行证据与产物。datasets 按推荐优先级列出真实选用的数据集标识，不把检索命中当成推荐预测。",
  };
  assert(Object.hasOwn(modes, mode), "Unknown stage3 execution mode");
  return `${query.query}\n\n【统一实验任务范围】${modes[mode]}\n所有数据获取遵守当前运行的受控域名、超时及字节预算；不能在数据或执行失败时伪造结果。`;
}
function rejectSecrets(value: unknown): void {
  if (!value || typeof value !== "object") return;
  for (const [key, child] of Object.entries(value)) {
    assert(!/api.?key|password|authorization|credential|secret|token$/i.test(key), "Credentials cannot be stored in experiment configuration");
    rejectSecrets(child);
  }
}
const orders: readonly (readonly Stage3Condition[])[] = [
  ["A0", "A1", "A2"], ["A0", "A2", "A1"], ["A1", "A0", "A2"],
  ["A1", "A2", "A0"], ["A2", "A0", "A1"], ["A2", "A1", "A0"],
];
export function stage3ConditionOrder(pairIndex: number, seed: number): readonly Stage3Condition[] {
  return orders[((pairIndex + seed) % orders.length + orders.length) % orders.length]!;
}
/** Do not inherit model credentials, a different app DB, virtualenvs, preload hooks or result caches. */
export function buildStage3ChildEnvironment(spec: Stage3UnitSpec, inherited: NodeJS.ProcessEnv = process.env): NodeJS.ProcessEnv {
  const env: NodeJS.ProcessEnv = {};
  for (const key of ["LANG", "LC_ALL", "LC_CTYPE", "TZ", "TERM", "SystemRoot", "WINDIR", "COMSPEC", "PATHEXT"]) {
    if (inherited[key] !== undefined) env[key] = inherited[key];
  }
  const pathKey = Object.keys(inherited).find(key => key.toLowerCase() === "path") ?? "PATH";
  const systemBins = new Set(["/usr/bin", "/bin", "/usr/sbin", "/sbin", "/usr/local/bin", "/opt/homebrew/bin"]);
  const cleanPath = (inherited[pathKey] ?? "").split(process.platform === "win32" ? ";" : ":").filter(path => path
    && !/(?:^|[\\/])OceanAgent-main(?:[\\/]|$)/i.test(path)
    && !/(?:^|[\\/])outputs[\\/]stage3(?:[\\/]|$)/i.test(path)
    && (process.platform === "win32" || systemBins.has(path) || path === dirname(process.execPath)));
  env.PATH = [...new Set([dirname(process.execPath), ...cleanPath])].join(process.platform === "win32" ? ";" : ":");
  return { ...env, HOME: spec.paths.runtime_home,
    XDG_CACHE_HOME: join(spec.paths.runtime_home, ".cache"), XDG_CONFIG_HOME: join(spec.paths.runtime_home, ".config"),
    TMPDIR: join(spec.paths.runtime_home, "tmp"), TMP: join(spec.paths.runtime_home, "tmp"), TEMP: join(spec.paths.runtime_home, "tmp"),
    MPLCONFIGDIR: join(spec.paths.workspace, ".cache", "matplotlib"), MPLBACKEND: "Agg",
    OCEAN_DB_PATH: spec.paths.database, OCEAN_RAG_ROOT: join(spec.paths.unit_dir, "runtime", "knowledge-view"),
    OCEAN_DATA_ALLOWED_HOSTS: normalizeAllowedDataHosts(spec.runtime_config.allowed_data_hosts ?? []).join(","),
    OCEANAGENT_KNOWLEDGE_MODE: spec.condition === "A0" ? "off" : "on", OCEAN_ABLATION_CONDITION: spec.condition,
    OCEANAGENT_RUN_KIND: "agent", OCEAN_RAG_AUTO_SYNC: "false" };
}
async function writeNewOrMatch(path: string, value: unknown, resume: boolean): Promise<void> {
  const data = stage3CanonicalJson(value);
  try { await writeFile(path, JSON.stringify(value, null, 2) + "\n", { flag: "wx", mode: 0o600 }); }
  catch (error) {
    if ((error as NodeJS.ErrnoException).code !== "EEXIST" || !resume) throw error;
    assert(stage3CanonicalJson(JSON.parse(await readFile(path, "utf8"))) === data, "Resume rejected: existing unit configuration drift");
  }
}

export async function prepareStage3Experiment(options: PrepareStage3Options): Promise<Stage3ExperimentManifest> {
  await noSymlinks(options.developmentRoot); const root = await realpath(options.developmentRoot); noMain(root);
  assert(["OceanAgent-exp-dev", "oceanagent"].includes(basename(root)), "Stage 3 writes are restricted to the paper checkout (OceanAgent-exp-dev or oceanagent)");
  const experimentId = safeId(options.experimentId, "experimentId");
  const experimentDir = resolve(root, "outputs", "stage3", experimentId); await noSymlinks(experimentDir);
  const benchmarkRoot = resolve(options.benchmarkRoot ?? join(options.knowledgeRoot, "benchmark")); noMain(benchmarkRoot);
  const freePlanning = kbFreePlanningProtocol(options.runtimeConfig);
  assert(!options.queryRows || freePlanning, "Independent tasks are restricted to kb-free-planning-v1");
  assert(!options.conditions || freePlanning, "Custom condition sets are restricted to kb-free-planning-v1");
  const devPath = options.queryRows ? undefined : await sourceFile(join(benchmarkRoot, "splits", "dev.jsonl"));
  const trainPath = await sourceFile(join(benchmarkRoot, "splits", "train.jsonl"));
  assert((!devPath || basename(devPath) === "dev.jsonl") && basename(trainPath) === "train.jsonl", "Only DEV and train visibility membership may be read");
  const devRows: Record<string, unknown>[] = options.queryRows ? options.queryRows.map(sanitizeDevQuery) : await rows(devPath!);
  const trainRows = await rows(trainPath);
  const allQueries = devRows.map(sanitizeDevQuery);
  assert(new Set(allQueries.map(q => q.query_id)).size === allQueries.length, "Duplicate DEV query_id");
  const allowedSources = [...new Set(trainRows.map(row => row.source_id).filter((x): x is string => typeof x === "string" && !!x))].sort();
  const allowedGroups = [...new Set(trainRows.map(row => row.source_group_id).filter((x): x is string => typeof x === "string" && !!x))].sort();
  assert(allowedSources.length > 0, "Train visibility must include explicit source IDs");
  const allowedSourceSet = new Set(allowedSources), allowedGroupSet = new Set(allowedGroups);
  assert(devRows.every(row => !allowedSourceSet.has(String(row.source_id ?? "")) && !allowedGroupSet.has(String(row.source_group_id ?? ""))), "Train/DEV source overlap would leak held-out evidence");
  const queryIds = options.queryIds && new Set(options.queryIds);
  if (queryIds) assert([...queryIds].every(id => allQueries.some(q => q.query_id === id)), "Requested query is outside DEV");
  let queries = allQueries.filter(q => !queryIds || queryIds.has(q.query_id));
  if (options.limit !== undefined) { assert(Number.isInteger(options.limit) && options.limit > 0, "limit must be positive"); queries = queries.slice(0, options.limit); }
  assert(queries.length > 0, "DEV selection is empty");
  const replicates = options.replicates ?? 1, seed = options.seed ?? 0;
  assert(Number.isSafeInteger(replicates) && replicates > 0 && replicates <= 100 && Number.isSafeInteger(seed), "Invalid replicate count or seed");
  assert(options.model.providerId.trim() && options.model.modelId.trim(), "Explicit provider and model required");
  rejectSecrets(options.model); rejectSecrets(options.budget);
  const runtimeConfig = { mode: "recommendation", max_execution_rounds: 1, ...options.runtimeConfig }; rejectSecrets(runtimeConfig);
  if (Object.hasOwn(runtimeConfig, "protocol_version")) assert(scientificProtocol(runtimeConfig) || freePlanning, "Unknown stage3 protocol version");
  if (freePlanning) {
    assert(runtimeConfig.mode === "plan" && !Object.hasOwn(runtimeConfig, "fixed_planning")
      && !(options.dataInputs?.length), "Free planning forbids fixed answers and pre-existing scientific input artifacts");
    assert(options.queryRows?.length && options.conditions?.length === 2 && options.conditions.includes("A0")
      && options.conditions.includes("A1"), "Free planning requires explicit label-free tasks and A0/A1 only");
    Object.assign(runtimeConfig, { retrieval_mode: "lexical", inference_source_sha256: await stage3InferenceSourceSnapshot(),
      planning_only: true, max_execution_rounds: 1, knowledge_visibility: "frozen_train_psc_linked_ubc_projected_dataset_cards",
      query_set_sha256: hash(stage3CanonicalJson(allQueries)) });
  }
  if (scientificProtocol(runtimeConfig)) {
    Object.assign(runtimeConfig, { public_catalog_version: PUBLIC_PRODUCT_CATALOG_VERSION,
      public_catalog_sha256: hash(stage3CanonicalJson(loadBundledPublicProducts())), retrieval_mode: "lexical",
      inference_source_sha256: await stage3InferenceSourceSnapshot() });
    assert(runtimeConfig.mode !== "end_to_end", "scientific-v2 separates recommendation and fixed-input planning; use legacy end_to_end only for execution diagnostics");
    if (runtimeConfig.mode === "plan") assert(Object.hasOwn(runtimeConfig, "fixed_planning"), "scientific-v2 plan requires --planning-datasets with independent fixed inputs");
    const fixed = (runtimeConfig as Record<string, unknown>).fixed_planning as Record<string, unknown> | undefined;
    if (fixed) {
      Object.assign(runtimeConfig, { fixed_planning_content_sha256: hash(stage3CanonicalJson(fixed)) });
      assert(runtimeConfig.mode === "plan" && fixed.schema_version === "stage3-fixed-planning-v1" && fixed.independent === true
        && typeof fixed.reviewer_id === "string" && fixed.reviewer_id.trim()
        && ["fixed_gold", "verified_fixed_combination"].includes(String(fixed.kind))
        && fixed.datasets_by_query && typeof fixed.datasets_by_query === "object", "fixed inputs are independently annotated planning-only inputs, never recommendation answers");
      const combinations = fixed.datasets_by_query as Record<string, unknown>;
      for (const query of queries) {
        const ids = combinations[query.query_id];
        assert(Array.isArray(ids) && ids.length > 0 && ids.length <= 20 && ids.every(id => typeof id === "string" && /^[A-Za-z0-9][A-Za-z0-9._:/?&=+%#@~-]{0,299}$/.test(id))
          && new Set(ids).size === ids.length, "every planning query needs an explicit clean fixed dataset set");
        if (fixed.kind === "fixed_gold") assert(stage3CanonicalJson([...ids].sort())
          === stage3CanonicalJson([...(devRows.find(row => row.query_id === query.query_id)?.gold_dataset_ids as string[] ?? [])].sort()), "fixed_gold inputs do not match the unchanged DEV Gold set");
      }
      if (fixed.kind === "verified_fixed_combination") assert(fixed.independent === true && typeof fixed.reviewer_id === "string"
        && !/^(?:llm|model|deepseek|gpt)(?:$|[-_:])/i.test(fixed.reviewer_id)
        && ["human_expert", "independent_program"].includes(String(fixed.review_method))
        && Array.isArray(fixed.evidence_urls) && fixed.evidence_urls.length > 0
        && fixed.evidence_urls.every(url => typeof url === "string" && url.startsWith("https://")), "verified planning combination requires independent reviewer and evidence");
    }
  }
  if (Object.hasOwn(runtimeConfig, "allowed_data_hosts")) {
    (runtimeConfig as Record<string, unknown>).allowed_data_hosts = normalizeAllowedDataHosts((runtimeConfig as Record<string, unknown>).allowed_data_hosts);
  }
  if (Object.hasOwn(runtimeConfig, "execution_concurrency")) executionConcurrency((runtimeConfig as Record<string, unknown>).execution_concurrency);
  assert(["recommendation", "plan", "end_to_end"].includes(String(runtimeConfig.mode))
    && Number.isSafeInteger(runtimeConfig.max_execution_rounds) && Number(runtimeConfig.max_execution_rounds) > 0
    && Number(runtimeConfig.max_execution_rounds) <= 10, "Invalid execution mode or continuation-round limit");
  const budget: Stage3Budget = { max_agent_ms: 600000, max_tool_calls: 80, max_download_bytes: 16 * 1024 * 1024, max_output_tokens: 4096, ...options.budget };
  assert(Object.values(budget).every(n => Number.isSafeInteger(n) && n > 0) && budget.max_download_bytes <= 64 * 1024 * 1024, "Budgets must be positive bounded integers (download <=64 MiB)");
  const knowledgePaths = {
    dataset_cards_path: await sourceFile(join(options.knowledgeRoot, "cards", "dataset_cards.jsonl")),
    problem_solution_cards_path: await sourceFile(join(options.knowledgeRoot, "cards", "problem_solution_cards.jsonl")),
    usage_bundle_cards_path: await sourceFile(join(options.knowledgeRoot, "cards", "usage_bundle_cards.jsonl")),
  };
  const devSha = devPath ? await fileHash(devPath) : hash(stage3CanonicalJson(allQueries)), trainSha = await fileHash(trainPath);
  const knowledgeHashes: Record<string, string> = Object.fromEntries(await Promise.all(Object.entries(knowledgePaths).map(async ([key, path]) => [key, await fileHash(path)] as const)));
  const knowledgeSnapshot = hash(stage3CanonicalJson({ policy: freePlanning ? KB_ABLATION_PROTOCOL : scientificProtocol(runtimeConfig) ? SCIENTIFIC_PROTOCOL : "train-source-visible-v1",
    train_sha256: trainSha, ...knowledgeHashes,
    ...(scientificProtocol(runtimeConfig) ? { public_catalog_sha256: (runtimeConfig as Record<string, unknown>).public_catalog_sha256 } : {}) }));
  const inputs = await Promise.all((options.dataInputs ?? []).map(async (path, i) => {
    const physical = await sourceFile(path);
    assert(!inside(await realpath(options.knowledgeRoot), physical) && !inside(await realpath(benchmarkRoot), physical), "Knowledge/benchmark files cannot be supplied as scientific data inputs");
    assert(!inside(resolve(root, "outputs"), physical) && !/(?:^|[\\/])(?:artifacts|scientific-cache|tool-logs|eval_logs|stage3)(?:[\\/]|$)/i.test(physical), "Experimental artifacts and caches cannot seed another arm");
    return { source: physical, name: `input-${String(i + 1).padStart(3, "0")}-${basename(physical)}`, sha256: await fileHash(physical), bytes: (await lstat(physical)).size };
  }));
  const dataSnapshot = hash(stage3CanonicalJson(inputs.map(({ name, sha256, bytes }) => ({ name, sha256, bytes }))));
  const configSha = hash(stage3CanonicalJson({ namespace: STAGE3_SCHEMA, model: options.model, budget, runtime_config: runtimeConfig }));
  const specs: Stage3UnitSpec[] = [], units: Stage3ManifestUnit[] = [];
  let pairIndex = 0;
  for (const query of queries) for (let replicate = 1; replicate <= replicates; replicate++) {
    const pairId = `pair_${hash(`${STAGE3_SCHEMA}|${experimentId}|${query.query_id}|${replicate}`).slice(0, 20)}`;
    const pairSeed = Number.parseInt(hash(`${seed}|${pairId}`).slice(0, 8), 16) % 2147483647;
    const pairOrder = pairIndex++;
    const order = freePlanning ? (pairOrder + seed) % 2 === 0 ? ["A0", "A1"] as const : ["A1", "A0"] as const
      : stage3ConditionOrder(pairOrder, seed);
    for (const [orderIndex, condition] of order.entries()) {
      const unitDir = join(experimentDir, query.query_id, `replicate-${String(replicate).padStart(3, "0")}`, condition);
      const paths = { unit_dir: unitDir, workspace: join(unitDir, "workspace"), database: join(unitDir, "runtime", "ocean-agent.sqlite"), cache: join(unitDir, "workspace", "data", "scientific-cache"), logs: join(unitDir, "eval_logs"), artifacts: join(unitDir, "artifacts"), runtime_home: join(unitDir, "runtime", "home") };
      const unitId = `${pairId}_${condition}`;
      const spec: Stage3UnitSpec = { schema_version: STAGE3_SCHEMA, experiment_id: experimentId, unit_id: unitId, pair_id: pairId,
        query_id: query.query_id, replicate_id: replicate, condition, seed: pairSeed, condition_order_index: orderIndex,
        query, model: { ...options.model }, budget, runtime_config: runtimeConfig,
        input_sha256: hash(buildStage3Prompt(query, runtimeConfig.mode as Stage3Mode, runtimeConfig)), config_sha256: configSha,
        knowledge_snapshot_id: knowledgeSnapshot, data_snapshot_id: dataSnapshot,
        knowledge: condition === "A0" ? scientificProtocol(runtimeConfig) ? { dataset_cards_path: knowledgePaths.dataset_cards_path,
          source_sha256: { dataset_cards_path: knowledgeHashes.dataset_cards_path! } } : {} : { dataset_cards_path: knowledgePaths.dataset_cards_path,
          problem_solution_cards_path: knowledgePaths.problem_solution_cards_path,
          ...(condition === "A1" ? { usage_bundle_cards_path: knowledgePaths.usage_bundle_cards_path } : {}),
          source_sha256: Object.fromEntries(Object.entries(knowledgeHashes).filter(([key]) => condition === "A1" || key !== "usage_bundle_cards_path")),
          allowed_source_ids: allowedSources, allowed_source_group_ids: allowedGroups },
        inputs: inputs.map(({ name, sha256, bytes }) => ({ path: join(paths.workspace, "data", "inputs", name), sha256, bytes })), paths };
      specs.push(spec); units.push({ unit_id: unitId, pair_id: pairId, query_id: query.query_id, replicate_id: replicate, condition, seed: pairSeed,
        order_index: units.length, unit_path: join(unitDir, "unit.json"), result_path: join(unitDir, "unit-result.json"),
        unit_sha256: hash(stage3CanonicalJson(spec)), input_sha256: spec.input_sha256, config_sha256: configSha,
        model: spec.model, knowledge_snapshot_id: knowledgeSnapshot, data_snapshot_id: dataSnapshot });
    }
  }
  const stable = { schema_version: STAGE3_SCHEMA, experiment_id: experimentId, split: "DEV" as const, development_root: root,
    experiment_dir: experimentDir, dev_sha256: devSha, train_sha256: trainSha, shared_config_sha256: configSha,
    model: options.model, budget, runtime_config: runtimeConfig, knowledge_snapshot_id: knowledgeSnapshot, data_snapshot_id: dataSnapshot, units };
  const fingerprint = hash(stage3CanonicalJson(stable));
  let createdAt = new Date().toISOString();
  try {
    const existing = JSON.parse(await readFile(join(experimentDir, "experiment.json"), "utf8")) as Stage3ExperimentManifest;
    assert(options.resume, "Experiment exists; use --resume explicitly (completed units are never automatically rerun)");
    assert(existing.schema_version === STAGE3_SCHEMA && existing.fingerprint === fingerprint, "Resume rejected: inputs/model/config/snapshots drifted"); createdAt = existing.created_at;
  } catch (error) { if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error; }
  await mkdir(experimentDir, { recursive: true });
  const manifest: Stage3ExperimentManifest = { ...stable, created_at: createdAt, fingerprint };
  await writeNewOrMatch(join(experimentDir, "experiment.json"), manifest, !!options.resume);
  for (const spec of specs) {
    await noSymlinks(spec.paths.unit_dir);
    for (const path of [spec.paths.workspace, dirname(spec.paths.database), spec.paths.cache, spec.paths.logs, spec.paths.artifacts, spec.paths.runtime_home,
      join(spec.paths.runtime_home, "tmp"), join(spec.paths.runtime_home, ".cache"), join(spec.paths.runtime_home, ".config")]) await mkdir(path, { recursive: true });
    for (const [i, input] of inputs.entries()) {
      const destination = spec.inputs[i]!.path; await mkdir(dirname(destination), { recursive: true }); await noSymlinks(destination);
      try { await copyFile(input.source, destination, constants.COPYFILE_EXCL); await chmod(destination, 0o444); }
      catch (error) { if ((error as NodeJS.ErrnoException).code !== "EEXIST" || !options.resume) throw error; }
      const info = await lstat(destination); assert(info.isFile() && info.nlink === 1 && await fileHash(destination) === input.sha256, "Input copy integrity/isolation check failed");
    }
    await writeNewOrMatch(join(spec.paths.unit_dir, "unit.json"), spec, !!options.resume);
  }
  return manifest;
}

export async function executePreparedStage3(manifestPath: string, options: {
  executeUnit?: (unitPath: string) => Promise<number>; resume?: boolean; nodePath?: string;
  queryIds?: readonly string[]; unitIds?: readonly string[];
} = {}): Promise<Array<{ unit_id: string; status: string; exit_code?: number; error_type?: string }>> {
  await noSymlinks(manifestPath); noMain(resolve(manifestPath));
  const manifest = JSON.parse(await readFile(manifestPath, "utf8")) as Stage3ExperimentManifest;
  assert(manifest.schema_version === STAGE3_SCHEMA && manifest.split === "DEV", "Only stage3 DEV manifests are executable");
  const { created_at: _created, fingerprint, ...stable } = manifest;
  assert(hash(stage3CanonicalJson(stable)) === fingerprint, "Experiment manifest changed after preparation");
  const concurrency = executionConcurrency(manifest.runtime_config.execution_concurrency);
  const root = await realpath(manifest.development_root); assert(["OceanAgent-exp-dev", "oceanagent"].includes(basename(root)), "Wrong development checkout");
  const expectedRoot = join(root, "outputs", "stage3", safeId(manifest.experiment_id, "experimentId"));
  assert(resolve(manifest.experiment_dir) === expectedRoot && resolve(dirname(manifestPath)) === expectedRoot, "Experiment path escaped its development root");
  const worker = join(root, "dist", "experiments", "worker.js");
  const execute = options.executeUnit ?? (async (unitPath: string) => {
    const spec = JSON.parse(await readFile(unitPath, "utf8")) as Stage3UnitSpec;
    return new Promise<number>((done, reject) => {
      const env = buildStage3ChildEnvironment(spec);
      const child = spawn(options.nodePath ?? process.execPath, [worker, "--unit", unitPath], { cwd: root, env, stdio: "inherit" });
      child.once("error", reject); child.once("exit", code => done(code ?? 1));
    });
  });
  const ordered = [...manifest.units].sort((a, b) => a.order_index - b.order_index);
  if (options.queryIds || options.unitIds) {
    assert(kbFreePlanningProtocol(manifest.runtime_config), "Partial queue dispatch is opt-in free-planning only");
    assert(!options.queryIds || options.queryIds.length && options.queryIds.every(id => ordered.some(unit => unit.query_id === id)), "Unknown or empty query dispatch selection");
    assert(!options.unitIds || options.unitIds.length && options.unitIds.every(id => ordered.some(unit => unit.unit_id === id)), "Unknown or empty unit dispatch selection");
  }
  const seen = new Set<string>(), results: Array<{ unit_id: string; status: string; exit_code?: number; error_type?: string }> =
    ordered.map(unit => ({ unit_id: unit.unit_id, status: "not_dispatched" }));
  const pending: Array<{ unit: Stage3ManifestUnit; index: number }> = [];
  // Validate the entire queue before starting any worker. A bad later unit must
  // not reject Promise.all while earlier model processes keep running unseen.
  for (const [index, unit] of ordered.entries()) {
    assert(!seen.has(unit.unit_id), "Duplicate unit would be executed twice"); seen.add(unit.unit_id);
    if (options.queryIds && !options.queryIds.includes(unit.query_id) || options.unitIds && !options.unitIds.includes(unit.unit_id)) {
      results[index] = { unit_id: unit.unit_id, status: "not_selected" }; continue;
    }
    const directory = dirname(unit.unit_path); assert(inside(expectedRoot, directory) && inside(directory, unit.result_path) && basename(unit.unit_path) === "unit.json", "Unit/result path escaped experiment");
    await noSymlinks(unit.unit_path); await noSymlinks(unit.result_path);
    try {
      const result = JSON.parse(await readFile(unit.result_path, "utf8")) as Record<string, unknown>;
      assert(options.resume, "Result exists; use --resume to skip, never silently rerun a unit");
      assert(result.unit_id === unit.unit_id && result.pair_id === unit.pair_id && result.condition === unit.condition
        && result.input_sha256 === unit.input_sha256 && result.config_sha256 === unit.config_sha256
        && result.knowledge_snapshot_id === unit.knowledge_snapshot_id && result.data_snapshot_id === unit.data_snapshot_id
        && result.query_id === unit.query_id && result.replicate_id === unit.replicate_id
        && typeof result.terminal_status === "string" && !["running", "queued"].includes(result.terminal_status), "Existing result identity/parity mismatch");
      results[index] = { unit_id: unit.unit_id, status: "skipped_existing" }; continue;
    } catch (error) { if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error; }
    const spec = JSON.parse(await readFile(unit.unit_path, "utf8")) as Stage3UnitSpec;
    assert(hash(stage3CanonicalJson(spec)) === unit.unit_sha256
      && spec.unit_id === unit.unit_id && spec.config_sha256 === unit.config_sha256
      && spec.input_sha256 === hash(buildStage3Prompt(spec.query, spec.runtime_config.mode as Stage3Mode, spec.runtime_config))
      && spec.input_sha256 === unit.input_sha256 && spec.condition === unit.condition && spec.paths.unit_dir === directory,
    "Unit specification changed after preparation");
    pending.push({ unit, index });
  }
  let cursor = 0;
  await Promise.all(Array.from({ length: Math.min(concurrency, pending.length) }, async () => {
    for (;;) {
      const next = pending[cursor++]; if (!next) return;
      const { unit, index } = next;
      try {
        const exitCode = await execute(unit.unit_path);
        results[index] = { unit_id: unit.unit_id, status: exitCode === 0 ? "worker_exited" : "worker_failed", exit_code: exitCode };
      } catch (error) {
        // Preserve a dispatch failure and continue other independent units. Never
        // retry a model run or synthesize its unit-result/logs here.
        results[index] = { unit_id: unit.unit_id, status: "worker_failed", exit_code: 1,
          error_type: error instanceof Error ? error.name : "WorkerDispatchError" };
      }
    }
  }));
  return results;
}

async function cli(): Promise<void> {
  const args = process.argv.slice(2); const values = new Map<string, string[]>();
  const allowed = new Set(["--help", "--experiment", "--model", "--knowledge-root", "--benchmark-root", "--query-id", "--limit", "--replicates", "--seed", "--data-input", "--resume", "--execute", "--dry-run", "--mode", "--max-execution-rounds", "--max-agent-ms", "--max-tool-calls", "--max-download-bytes", "--max-output-tokens", "--allowed-data-host", "--concurrency", "--protocol", "--planning-datasets"]);
  for (let i = 0; i < args.length; i++) {
    const key = args[i]!; assert(allowed.has(key), `Unknown stage3 CLI flag: ${key}`);
    const val = args[i + 1] && !args[i + 1]!.startsWith("--") ? args[++i]! : "true";
    values.set(key, [...values.get(key) ?? [], val]);
  }
  const one = (name: string) => values.get(name)?.at(-1);
  assert(!(values.has("--execute") && values.has("--dry-run")), "--execute and --dry-run are mutually exclusive");
  const root = resolve(dirname(fileURLToPath(import.meta.url)), "../..");
  if (values.has("--help")) { console.log("paired-dev --experiment ID --model provider::model [--protocol scientific-v2] [--knowledge-root PATH] [--query-id DEV_ID] [--limit N] [--replicates N] [--seed N] [--data-input FILE] [--allowed-data-host HOST (repeatable)] [--concurrency 1..3 (default 1)] [--mode recommendation|plan|end_to_end] [--planning-datasets INDEPENDENT.json] [--resume] [--execute]\nDefault: prepare only. v2 recommendation is independent of Plan/download. v2 plan requires frozen independent fixed dataset inputs. No service or TEST access."); return; }
  const model = one("--model")?.split("::"); assert(model?.length === 2 && model.every(Boolean), "--model provider::model is required");
  const experiment = one("--experiment"); assert(experiment, "--experiment is required");
  const knowledgeRoot = resolve(one("--knowledge-root") ?? join(root, "../benchmark/knowledge_snapshot"));
  const protocol = one("--protocol"); assert(!protocol || protocol === "scientific-v2", "--protocol supports scientific-v2; omit for legacy-v1");
  let fixedPlanning: Record<string, unknown> | undefined;
  let fixedPlanningPath: string | undefined, fixedPlanningFileSha: string | undefined;
  if (one("--planning-datasets")) {
    assert(protocol === "scientific-v2" && one("--mode") === "plan", "fixed inputs only apply to scientific-v2 plan");
    const file = await sourceFile(resolve(one("--planning-datasets")!));
    fixedPlanningPath = file; fixedPlanningFileSha = await fileHash(file);
    assert(!/(?:^|[\\/])(?:test|gold)\.(?:jsonl|json)$/i.test(file), "provide a dedicated fixed-planning annotation, never a raw TEST/Gold file");
    fixedPlanning = JSON.parse(await readFile(file, "utf8"));
    assert(fixedPlanning?.schema_version === "stage3-fixed-planning-v1" && fixedPlanning.independent === true
      && typeof fixedPlanning.reviewer_id === "string" && ["fixed_gold", "verified_fixed_combination"].includes(String(fixedPlanning.kind))
      && fixedPlanning.datasets_by_query && typeof fixedPlanning.datasets_by_query === "object", "fixed planning needs independent author, kind and per-query dataset arrays");
  }
  const manifest = await prepareStage3Experiment({ developmentRoot: root, experimentId: experiment, knowledgeRoot,
    benchmarkRoot: one("--benchmark-root"), model: { providerId: model[0]!, modelId: model[1]! },
    queryIds: values.get("--query-id"), limit: one("--limit") ? Number(one("--limit")) : undefined,
    replicates: one("--replicates") ? Number(one("--replicates")) : undefined, seed: one("--seed") ? Number(one("--seed")) : undefined,
    dataInputs: values.get("--data-input"), resume: values.has("--resume"), runtimeConfig: {
      mode: one("--mode") ?? "recommendation", max_execution_rounds: Number(one("--max-execution-rounds") ?? 1),
      ...(protocol ? { protocol_version: SCIENTIFIC_PROTOCOL } : {}),
      ...(fixedPlanning ? { fixed_planning: fixedPlanning } : {}),
      ...(fixedPlanningPath ? { fixed_planning_path: fixedPlanningPath, fixed_planning_file_sha256: fixedPlanningFileSha } : {}),
      ...(values.has("--allowed-data-host") ? { allowed_data_hosts: values.get("--allowed-data-host") } : {}),
      ...(values.has("--concurrency") ? { execution_concurrency: Number(one("--concurrency")) } : {}),
    }, budget: {
      ...(one("--max-agent-ms") ? { max_agent_ms: Number(one("--max-agent-ms")) } : {}),
      ...(one("--max-tool-calls") ? { max_tool_calls: Number(one("--max-tool-calls")) } : {}),
      ...(one("--max-download-bytes") ? { max_download_bytes: Number(one("--max-download-bytes")) } : {}),
      ...(one("--max-output-tokens") ? { max_output_tokens: Number(one("--max-output-tokens")) } : {}),
    } });
  console.log(JSON.stringify({ prepared: true, manifest: join(manifest.experiment_dir, "experiment.json"), units: manifest.units.length, model_requests: 0 }));
  if (values.has("--execute")) console.log(JSON.stringify(await executePreparedStage3(join(manifest.experiment_dir, "experiment.json"), { resume: values.has("--resume") })));
}
if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  cli().catch(error => { console.error(error instanceof Error ? error.message : String(error)); process.exitCode = 1; });
}
