import type { RagSearchResult } from "../contracts.js";
import type { RagDocument } from "../rag/types.js";
import { renderRagContent } from "../rag/normalizer.js";

export type AblationCondition = "A0" | "A1" | "A2";
export interface AblationPolicy {
  readonly condition: AblationCondition;
  readonly knowledgeMode: "on" | "off";
  readonly knowledgeAccessEnabled: boolean;
  readonly bundleAccessEnabled: boolean;
  /** V2 only: the same frozen public product facts remain available in every arm. */
  readonly publicDatasetAccessEnabled?: boolean;
}

/** A condition is resolved once per application/run, never by mutating process-wide environment. */
export function resolveAblationPolicy(condition: string = "A1", publicCatalog = false): AblationPolicy {
  if (!["A0", "A1", "A2"].includes(condition)) throw new Error(`Unknown ablation condition: ${condition}`);
  return Object.freeze({ condition: condition as AblationCondition,
    knowledgeMode: condition === "A0" ? "off" : "on",
    knowledgeAccessEnabled: condition !== "A0", bundleAccessEnabled: condition === "A1",
    publicDatasetAccessEnabled: publicCatalog });
}

export function contextAblationPolicy(context: {
  ablationPolicy?: AblationPolicy; knowledgeAccessEnabled?: boolean; bundleAccessEnabled?: boolean;
}): AblationPolicy {
  return context.ablationPolicy ?? resolveAblationPolicy(context.knowledgeAccessEnabled === false ? "A0"
    : context.bundleAccessEnabled === false ? "A2" : "A1");
}

export function requireKnowledgeAccess(policy: AblationPolicy, bundle = false): void {
  if (!policy.knowledgeAccessEnabled) throw new Error("A0 forbids all knowledge-base access");
  if (bundle && !policy.bundleAccessEnabled) throw new Error("A2 forbids UsageBundleCard, historical DAG and co-usage graph access");
}

export function requireDatasetAccess(policy: AblationPolicy): void {
  if (!policy.knowledgeAccessEnabled && !policy.publicDatasetAccessEnabled) throw new Error("A0 forbids all knowledge-base access");
}

export { projectStage3PublicDatasetCatalog, publicCatalogProjectionStats,
  PUBLIC_PRODUCT_CATALOG_VERSION } from "./public-product-catalog.js";

export const DATASET_CATALOG_PROJECTION = "stage3-product-catalog-v1";
export interface DatasetCatalogProjectionStats {
  version: typeof DATASET_CATALOG_PROJECTION;
  dataset_cards: number;
  product_metadata_cards: number;
  identity_only_cards: number;
  removed_paper_sources: number;
  removed_other_sources: number;
  retained_product_source_urls: number;
  removed_descriptions: number;
}
export function datasetCatalogProjectionStats(): DatasetCatalogProjectionStats {
  return { version: DATASET_CATALOG_PROJECTION, dataset_cards: 0, product_metadata_cards: 0,
    identity_only_cards: 0, removed_paper_sources: 0, removed_other_sources: 0,
    retained_product_source_urls: 0, removed_descriptions: 0 };
}

// DatasetCard sources can contain held-out paper quotations and explicit co-usage.
// A public product URL is an existing evidence pointer, not a new verification claim.
function productMetadataUrl(value: unknown): string | undefined {
  if (typeof value !== "string") return undefined;
  try {
    const url = new URL(value);
    if (url.protocol !== "https:" || url.username || url.password || url.port && url.port !== "443") return undefined;
    if (/^(?:localhost|.*\.localhost)$/.test(url.hostname) || /^\d+(?:\.\d+){3}$/.test(url.hostname) || url.hostname.includes(":")) return undefined;
    for (const key of url.searchParams.keys()) if (/token|secret|pass|api.?key|signature|credential|auth|session|access.?key|^key$/i.test(key)) return undefined;
    if (/(?:^|\.)(?:doi\.org|arxiv\.org|ojs\.aaai\.org|acm\.org|ieee\.org|ieeexplore\.ieee\.org|sciencedirect\.com|springer\.com|springerlink\.com|nature\.com|scipub\.org|tandfonline\.com|wiley\.com|frontiersin\.org|mdpi\.com|aclanthology\.org|thecvf\.com|ifaamas\.org|openreview\.net)$/.test(url.hostname)
      || /\/(?:articles?|abstracts?|papers?|proceedings|publication)(?:\/|$)/i.test(url.pathname)) return undefined;
    url.hash = ""; return url.toString();
  } catch { return undefined; }
}
const paperUsageText = /\b(?:paper[_\s-]?\d+|in (?:this|the) (?:paper|study)|(?:used|combined|jointly|co[- ]?used)\s+(?:as|with|to|for|in|together)|training (?:set|data)|test (?:set|data)|experimental (?:slice|subset|setting)|usagebundle|usage_bundle|ubc[:_])\b/i;
function catalogFact(value: unknown): unknown {
  if (typeof value === "string") return paperUsageText.test(value) ? undefined : value;
  if (Array.isArray(value)) return value.map(catalogFact).filter(item => item !== undefined);
  if (value && typeof value === "object") return Object.fromEntries(Object.entries(value)
    .filter(([key]) => !/description|note|quote|evidence|source_ref|paper|bundle|dag|usage|co_usage|supports|search/i.test(key))
    .map(([key, item]) => [key, catalogFact(item)]).filter(([, item]) => item !== undefined));
  return value;
}

/** Identical A1/A2 product directory. Never expose a paper's data-use statement through a DatasetCard. */
export function projectStage3DatasetCatalog<T extends RagDocument>(document: T,
  stats?: DatasetCatalogProjectionStats): T {
  if (document.cardType !== "dataset") return document;
  const original = document.payload, sourceRows = Array.isArray(original.sources) ? original.sources : [];
  const urls = new Set<string>();
  let removedPaper = 0, removedOther = 0;
  for (const row of sourceRows) {
    if (!row || typeof row !== "object") { removedOther++; continue; }
    const source = row as Record<string, unknown>;
    if (typeof source.source_id === "string" && /^paper(?:[_:\s-]|$)/i.test(source.source_id)) { removedPaper++; continue; }
    const url = productMetadataUrl(source.url ?? source.source_url ?? source.source_id);
    if (url) urls.add(url); else removedOther++;
  }
  const payload: Record<string, unknown> = { dataset_id: original.dataset_id ?? document.id };
  // Candidate identity remains available even for unresolved, paper-only products.
  for (const key of ["schema_version", "name", "product_id", "aliases"] as const) {
    const value = catalogFact(original[key]); if (value !== undefined) payload[key] = value;
  }
  if (urls.size) {
    for (const key of ["provider", "version", "coverage", "resolution", "license", "public_availability"] as const) {
      const value = catalogFact(original[key]); if (value !== undefined) payload[key] = value;
    }
    if (Array.isArray(original.fields)) payload.fields = original.fields.flatMap(item => {
      if (!item || typeof item !== "object") return [];
      const field = item as Record<string, unknown>;
      const sourceUrl = productMetadataUrl(field.source_url);
      if (field.source_url && !sourceUrl) return [];
      const projected: Record<string, unknown> = {};
      for (const key of ["raw_name", "unit", "dimensions", "quality_field", "quality_rule", "valid_range"] as const) {
        const value = catalogFact(field[key]); if (value !== undefined) projected[key] = value;
      }
      if (sourceUrl) projected.source_url = sourceUrl;
      return Object.keys(projected).length ? [projected] : [];
    });
  }
  if (Array.isArray(original.access)) payload.access = original.access.flatMap(item => {
    if (!item || typeof item !== "object") return [];
    const access = item as Record<string, unknown>;
    if (typeof access.type === "string" && /paper|study|experiment|slice|subset/i.test(access.type)) return [];
    const url = productMetadataUrl(access.url); if (!url) return [];
    const projected: Record<string, unknown> = { url };
    if (typeof access.type === "string" && !paperUsageText.test(access.type)) projected.type = access.type;
    if (typeof access.authentication === "string" && /^(?:none|public|no|no authentication|anonymous|required)$/i.test(access.authentication.trim())) projected.authentication = access.authentication;
    return [projected];
  });
  payload.sources = [...urls].sort().map(url => ({ url }));
  payload.catalog_projection = { version: DATASET_CATALOG_PROJECTION,
    source_evidence: urls.size ? "external_product_metadata_pointer" : "identity_only",
    withheld: "Paper quotations, study-use descriptions and extraction/search records are unavailable in this experiment view; product URLs have not been revalidated by this projection." };
  if (stats) {
    stats.dataset_cards++; stats.product_metadata_cards += Number(urls.size > 0); stats.identity_only_cards += Number(!urls.size);
    stats.removed_paper_sources += removedPaper; stats.removed_other_sources += removedOther;
    stats.retained_product_source_urls += urls.size; stats.removed_descriptions += Number(original.description !== undefined);
  }
  return { ...document, payload, sourceIds: [String(payload.dataset_id), ...urls],
    title: typeof payload.name === "string" ? payload.name : String(payload.dataset_id),
    content: renderRagContent("dataset", payload) };
}

const bundleKey = /(?:^|_)(?:usage_?)?bundle(?:s|_?id|_?ids|_?reference|_?card|_?cards)?(?:$|_)/i;
const camelBundleKey = /^(?:usageBundle|usageBundleReference|usageBundleCard|usageBundleCards|bundleId|bundleIds|bundleReference|graphTrace)$/;
const historicalRelationKey = /^(?:dag|workflow_dag|workflowDag|edges|data_usages|dataUsages|co_usage|coUsage|co_usage_relations|historical_workflow|historicalWorkflow|graph_trace)$/i;
const bundleReference = /^(?:UsageBundleCard:|UBC[:_]|usage_bundle[:_])/i;

/** Remove linked UBC identity/content before rendering, citations or telemetry receive a card. */
function withoutBundleFields(value: unknown, hiddenIds: Set<string>): unknown {
  if (Array.isArray(value)) return value.map(item => withoutBundleFields(item, hiddenIds));
  if (!value || typeof value !== "object") return value;
  const output: Record<string, unknown> = {};
  for (const [key, item] of Object.entries(value)) {
    if (bundleKey.test(key) || camelBundleKey.test(key) || historicalRelationKey.test(key)) {
      const collect = (node: unknown): void => {
        if (typeof node === "string") hiddenIds.add(node);
        else if (Array.isArray(node)) node.forEach(collect);
      };
      collect(item); continue;
    }
    output[key] = withoutBundleFields(item, hiddenIds);
  }
  return output;
}

export function projectKnowledgeDocument<T extends RagDocument>(document: T, policy: AblationPolicy): T {
  if (document.cardType === "dataset") requireDatasetAccess(policy);
  else requireKnowledgeAccess(policy, document.cardType === "usage_bundle");
  if (policy.bundleAccessEnabled) return document;
  const hiddenIds = new Set<string>();
  const projected = withoutBundleFields(document.payload, hiddenIds);
  const stripRefs = (value: unknown): unknown => {
    if (typeof value === "string") return hiddenIds.has(value) || bundleReference.test(value) ? undefined : value;
    if (Array.isArray(value)) return value.map(stripRefs).filter(item => item !== undefined);
    if (value && typeof value === "object") return Object.fromEntries(Object.entries(value)
      .map(([key, item]) => [key, stripRefs(item)]).filter(([, item]) => item !== undefined));
    return value;
  };
  const payload = stripRefs(projected) as Record<string, unknown>;
  const sourceIds = document.sourceIds.filter(id => !hiddenIds.has(id) && !bundleReference.test(id));
  // Original rendered text can contain Bundle ID and relation lines even after payload projection.
  return { ...document, payload, sourceIds, content: renderRagContent(document.cardType, payload) };
}

export function projectKnowledgeSearchResult(result: RagSearchResult, policy: AblationPolicy): RagSearchResult {
  if (result.cardType === "dataset") requireDatasetAccess(policy);
  else requireKnowledgeAccess(policy, result.cardType === "usage_bundle");
  if (policy.bundleAccessEnabled) return result;
  const document = projectKnowledgeDocument({ ...result, content: result.excerpt,
    sourcePath: "", sourceHash: "" }, policy);
  return { ...result, payload: document.payload, sourceIds: document.sourceIds, excerpt: document.content.slice(0, 1600) };
}

/** A2 changes only UBC availability, not scientific execution or DatasetCard-derived route synthesis. */
export function prepareNoBundleSystemPrompt(prompt: string): string {
  const bundleOnly = /UsageBundleCard|trace_global_knowledge_graph|全局知识图谱证据|共同使用的数据集|PSC→UBC|PSC.*→.*UBC/;
  const output = prompt.split(/\r?\n/).filter(line => !bundleOnly.test(line)).map(line => line
    .replace(/先调用 `expand_research_case` 按ID读取对应 UsageBundleCard/g, "调用 `expand_research_case` 读取问题与方法证据")
    .replace(/card_id、bundle_id、paper_id/g, "card_id、paper_id")
    .replace(/、bundle_id/g, ""));
  return "【A2 No-Bundle】允许 ProblemSolutionCard 与 DatasetCard；expand_research_case 只展开PSC。禁止读取或推断UsageBundleCard、其历史DAG和数据共用关系。仍须依据当前任务与DatasetCard生成并验证新的数据组合，不得把实时组合误当被禁用的历史Bundle。\n\n" + output.join("\n");
}
