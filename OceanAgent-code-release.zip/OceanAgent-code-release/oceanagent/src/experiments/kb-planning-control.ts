import { createHash } from "node:crypto";
import type { ToolDefinition } from "@earendil-works/pi-coding-agent";
import type { Stage3UnitSpec } from "./paired-dev.js";
import { KB_PLANNING_CONTROL, kbPlanningRepairProtocol } from "./kb-ablation-protocol.js";
import { experimentBudgetProgress, experimentPlan } from "./runtime-context.js";
import { currentTelemetry } from "../telemetry/run-telemetry.js";

const finalizing = new WeakSet<Stage3UnitSpec>();
export function kbPlanIsFinalizing(unit: Stage3UnitSpec): boolean { return finalizing.has(unit); }
export function shouldFinalizeKbPlanning(unit: Stage3UnitSpec): boolean {
  if (!kbPlanningRepairProtocol(unit.runtime_config) || finalizing.has(unit) || experimentPlan(unit)) return false;
  const progress = experimentBudgetProgress(unit);
  return progress.tools >= Math.min(KB_PLANNING_CONTROL.exploration_tool_calls, Math.max(1, unit.budget.max_tool_calls - 4))
    || progress.elapsed_ms >= Math.min(KB_PLANNING_CONTROL.exploration_ms, unit.budget.max_agent_ms / 2);
}
export function beginKbPlanFinalization(unit: Stage3UnitSpec): void {
  finalizing.add(unit);
  currentTelemetry()?.trace.emit("kb_planning.finalization", { ...experimentBudgetProgress(unit),
    policy: KB_PLANNING_CONTROL, reason: "bounded evidence collection; reserve existing hard budget for structured submission" });
}
const READ_ONLY = new Set(["search_research_cases", "expand_research_case", "search_ocean_datasets",
  "get_dataset_facts", "trace_global_knowledge_graph", "search_official_web", "check_official_data_source"]);
const EXTERNAL = new Set(["search_official_web", "check_official_data_source"]);
function productPageIdentity(params: any): unknown {
  if (params?.uploadedPath) return params;
  try {
    const page = new URL(String(params.pageUrl)); page.hash = "";
    for (const key of [...page.searchParams.keys()]) if (key === "tab" || key.startsWith("utm_")) page.searchParams.delete(key);
    page.searchParams.sort(); page.pathname = page.pathname.replace(/\/$/, "") || "/";
    return { dataset: params.dataset, pageUrl: page.href, scope: "same product page; alternate download URLs remain unverified" };
  } catch { return params; }
}
const canonical = (v: unknown): unknown => Array.isArray(v) ? v.map(canonical)
  : v && typeof v === "object" ? Object.fromEntries(Object.entries(v).sort(([a], [b]) => a.localeCompare(b))
    .map(([k, value]) => [k, canonical(value)])) : typeof v === "string" ? v.trim() : v;

/** Per-session only. Every attempt (including cache/refusal) is charged by the outer isolation wrapper. */
export function createKbPlanningToolCoordinator(unit: Stage3UnitSpec) {
  const cache = new Map<string, { callId: string; result: any }>();
  let externalCalls = 0;
  return <T extends ToolDefinition<any, any, any>>(tool: T): T => ({ ...tool,
    async execute(id, params, signal, onUpdate, context) {
      const progress = experimentBudgetProgress(unit);
      const emit = (payload: Record<string, unknown>) => currentTelemetry()?.trace.emit("kb_planning.tool_control", {
        tool: tool.name, call_id: id, ...progress, ...payload });
      if (tool.name !== "propose_research_plan" && (finalizing.has(unit) || shouldFinalizeKbPlanning(unit))) {
        emit({ executed: false, reason: "submission_reserve" });
        return { content: [{ type: "text" as const, text: "证据采集阶段已结束；本次未执行额外核验。现在调用propose_research_plan；未知事实写evidenceNeeds/assumptions，不能声称已核实。" }],
          details: { limited: true, executed: false, reason: "submission_reserve" } };
      }
      const key = READ_ONLY.has(tool.name) ? createHash("sha256").update(`${tool.name}|${JSON.stringify(canonical(
        tool.name === "check_official_data_source" ? productPageIdentity(params) : params))}`).digest("hex") : null;
      const saved = key ? cache.get(key) : undefined;
      if (saved) {
        emit({ executed: false, cache_hit: true, original_tool_call_id: saved.callId });
        const result = structuredClone(saved.result);
        result.details = { ...result.details, planning_cache_hit: true, cache_scope: "agent_session", original_tool_call_id: saved.callId,
          ...(tool.name === "check_official_data_source" ? { requested_alternate_data_url_not_checked: true } : {}) };
        return { ...result, content: [...result.content, { type: "text" as const,
          text: "同一请求/产品页已有记录，复用首次真实结果（含空结果/失败），未再次联网。替代dataUrl未重新检查，不能把首次结果当作新URL可用性的证据；若仍缺证据，在Plan中保留缺口。" }] };
      }
      if (EXTERNAL.has(tool.name) && externalCalls >= KB_PLANNING_CONTROL.external_unique_calls) {
        emit({ executed: false, reason: "external_unique_limit" });
        return { content: [{ type: "text" as const, text: "公开核验的统一不同请求上限已达；本次未联网。依据已得证据提交Plan，未证实内容写入缺口。" }],
          details: { limited: true, executed: false, reason: "external_unique_limit" } };
      }
      const external = EXTERNAL.has(tool.name);
      if (external) externalCalls++;
      const bounded = external ? AbortSignal.timeout(Math.max(1, Math.min(KB_PLANNING_CONTROL.external_call_ms, Math.ceil(progress.remaining_ms)))) : undefined;
      let result;
      try {
        result = await tool.execute(id, params, bounded ? signal ? AbortSignal.any([signal, bounded]) : bounded : signal, onUpdate, context);
      } catch (error) {
        if (tool.name === "propose_research_plan") beginKbPlanFinalization(unit);
        if (!external || signal?.aborted) throw error;
        const reason = error instanceof Error ? `${error.name}: ${error.message}` : String(error);
        result = { content: [{ type: "text" as const, text: `公开核验失败，未验证任何科学事实：${reason}。将缺口记录到Plan，不重复同一请求。` }],
          details: { status: "unavailable", error: reason, timed_out: bounded?.aborted ?? false }, isError: true };
      }
      if (key) cache.set(key, { callId: id, result: structuredClone(result) });
      emit({ executed: true, external, external_unique_calls: externalCalls, is_error: (result as { isError?: boolean }).isError === true,
        result_status: result.details?.status ?? null });
      return { ...result, content: [...result.content, { type: "text" as const,
        text: `【规划预算】已用${experimentBudgetProgress(unit).tools}/${unit.budget.max_tool_calls}次工具；证据采集最多${KB_PLANNING_CONTROL.exploration_tool_calls}次或90秒。已有关键依据或核验遇阻即提交Plan；其余事实写缺口，不用继续探测全部下载地址。` }] };
    },
  } as T);
}
