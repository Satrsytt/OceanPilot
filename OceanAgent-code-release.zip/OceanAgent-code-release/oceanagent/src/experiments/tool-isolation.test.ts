import { mkdir, mkdtemp, readFile, rm, symlink, writeFile } from "node:fs/promises";
import { realpathSync } from "node:fs";
import { tmpdir } from "node:os";
import { resolve } from "node:path";
import type { ToolDefinition } from "@earendil-works/pi-coding-agent";
import { Type } from "typebox";
import { afterEach, describe, expect, it, vi } from "vitest";
import { buildSandboxProfile, containedExperimentPath, sandboxBashSpawnHook, wrapExperimentTool,
  type ExperimentToolIsolationOptions } from "./tool-isolation.js";

const roots: string[] = [];
afterEach(async () => { for (const root of roots.splice(0)) await rm(root, { recursive: true, force: true }); });
async function fixture(): Promise<ExperimentToolIsolationOptions> {
  const root = await mkdtemp(resolve(tmpdir(), "ocean-isolation-")); roots.push(root);
  const unitDir = resolve(root, "A0"), workspace = resolve(unitDir, "workspace"), runtimeHome = resolve(unitDir, "home");
  const applicationRoot = resolve(root, "application"), nodeExecutable = resolve(root, "runtime/bin/node");
  for (const path of [workspace, runtimeHome, resolve(unitDir, "tmp"), resolve(applicationRoot, "node_modules"),
    resolve(root, "runtime/bin"), resolve(root, "A1/workspace")]) await mkdir(path, { recursive: true });
  await writeFile(nodeExecutable, "test runtime, never executed");
  return { unitDir, workspace, runtimeHome, applicationRoot, nodeExecutable };
}
const execute = (tool: ToolDefinition<any, any, any>, params: unknown) => tool.execute("test", params,
  undefined, undefined, {} as never);

describe("per-unit experiment tool isolation", () => {
  it("allows current workspace files and creation, rejects traversal and cross-arm symlinks", async () => {
    const options = await fixture();
    const outside = resolve(options.unitDir, "../A1/workspace/secret.txt"); await writeFile(outside, "other arm");
    const inside = resolve(options.workspace, "input.txt"); await writeFile(inside, "current arm");
    expect(containedExperimentPath(options.workspace, "input.txt")).toBe(realpathSync(inside));
    expect(containedExperimentPath(options.workspace, "new/result.txt")).toBe(resolve(realpathSync(options.workspace), "new/result.txt"));
    expect(() => containedExperimentPath(options.workspace, "../../A1/workspace/secret.txt")).toThrow("越出");
    await symlink(outside, resolve(options.workspace, "leak"));
    expect(() => containedExperimentPath(options.workspace, "leak")).toThrow("符号链接");
    await symlink(resolve(options.unitDir, "../A1/workspace/missing"), resolve(options.workspace, "broken"));
    expect(() => containedExperimentPath(options.workspace, "broken")).toThrow();
  });

  it("preserves schema and original execution while using the caller's shared budget", async () => {
    const options = await fixture(); let calls = 0;
    const beforeExecute = vi.fn(() => { if (++calls > 2) throw new Error("shared budget"); });
    const original = vi.fn(async (_id, params) => {
      await mkdir(resolve(params.path, ".."), { recursive: true }); await writeFile(params.path, params.content);
      return { content: [{ type: "text" as const, text: "ok" }], details: { path: params.path } };
    });
    const tool = { name: "write", label: "write", description: "write",
      parameters: Type.Object({ path: Type.String(), content: Type.String() }), execute: original } as ToolDefinition<any, any, any>;
    const first = wrapExperimentTool(tool, { ...options, beforeExecute });
    const second = wrapExperimentTool(tool, { ...options, beforeExecute });
    expect(first.parameters).toBe(tool.parameters);
    await execute(first, { path: "new/result.txt", content: "one" });
    expect(await readFile(resolve(options.workspace, "new/result.txt"), "utf8")).toBe("one");
    await expect(execute(second, { path: "../home/forbidden", content: "no" })).rejects.toThrow("越出");
    await expect(execute(first, { path: "second.txt", content: "no" })).rejects.toThrow("shared budget");
    expect(beforeExecute).toHaveBeenCalledTimes(3); expect(original).toHaveBeenCalledTimes(1);
  });

  it("denies shell alternatives and external scientific verification files", async () => {
    const options = await fixture();
    for (const name of ["run_remote_command", "local_powershell", "powershell"]) {
      const tool = { name, execute: vi.fn() } as unknown as ToolDefinition<any, any, any>;
      await expect(execute(wrapExperimentTool(tool, options), {})).rejects.toThrow("禁止");
      expect(tool.execute).not.toHaveBeenCalled();
    }
    const tool = { name: "record_dataset_read", execute: vi.fn() } as unknown as ToolDefinition<any, any, any>;
    await expect(execute(wrapExperimentTool(tool, options), { file: "../other.csv" })).rejects.toThrow("越出");
  });

  it("builds a deny-default profile with writes confined to current workspace, HOME and temp", async () => {
    const options = await fixture(); const profile = buildSandboxProfile(options);
    expect(profile).toContain("(deny default)"); expect(profile).not.toContain("allow network");
    expect(profile).toContain('(allow file-read-data (literal "/"))');
    expect(profile).not.toContain('(subpath "/")');
    expect(profile).not.toContain('(subpath "/System")');
    expect(profile).toContain(`(subpath ${JSON.stringify(realpathSync(options.workspace))})`);
    expect(profile).toContain(`(subpath ${JSON.stringify(resolve(realpathSync(options.applicationRoot!), "node_modules"))})`);
    expect(profile).not.toContain(`(subpath ${JSON.stringify(realpathSync(options.unitDir))})`);
    expect(profile).not.toContain("A1/workspace"); expect(profile).not.toContain("application/data");
    const writes = profile.slice(profile.indexOf("(allow file-write*"));
    expect(writes).not.toContain("node_modules"); expect(writes).not.toContain("runtime/bin");
    expect(writes).toContain("/workspace"); expect(writes).toContain("/home"); expect(writes).toContain("/tmp");
    expect(() => buildSandboxProfile({ ...options, runtimeReadPaths: [options.unitDir] })).toThrow("只读路径");
    expect(() => buildSandboxProfile({ ...options, runtimeReadPaths: [resolve(options.applicationRoot!, "data")] })).toThrow("只读路径");
  });

  it("fails closed for unsupported hosts or unavailable sandbox-exec", async () => {
    const options = await fixture();
    expect(() => sandboxBashSpawnHook({ ...options, platform: "linux" })).toThrow("禁止退回");
    expect(() => sandboxBashSpawnHook({ ...options, platform: "darwin", sandboxExecutable: resolve(options.workspace, "missing") })).toThrow("已停止");
    expect(() => buildSandboxProfile({ ...options, runtimeHome: resolve(options.unitDir, "../A1/home") })).toThrow("独立位于");
  });

  it("quotes commands and discards inherited credentials/startup/environment state", async () => {
    const options = await fixture();
    const hook = sandboxBashSpawnHook({ ...options, platform: "darwin", sandboxExecutable: process.execPath });
    const result = hook({ cwd: options.workspace, command: "printf '%s' '$HOME'; echo done", env: {
      DEEPSEEK_API_KEY: "secret", BASH_ENV: "/other/startup", NODE_OPTIONS: "--inspect", PYTHONPATH: "/other/arm",
      HTTPS_PROXY: "http://credential@proxy", SSH_AUTH_SOCK: "/socket", HOME: "/original/home",
    } });
    expect(result.command).toContain(`exec '${process.execPath}' -p '`);
    expect(result.command).toContain("/bin/bash --noprofile --norc -c");
    expect(result.command).toContain("'\\''");
    expect(result.env.HOME).toBe(realpathSync(options.runtimeHome)); expect(result.env.PYTHONNOUSERSITE).toBe("1");
    for (const key of ["DEEPSEEK_API_KEY", "BASH_ENV", "NODE_OPTIONS", "PYTHONPATH", "HTTPS_PROXY", "SSH_AUTH_SOCK"]) {
      expect(result.env[key]).toBeUndefined();
    }
    expect(() => hook({ cwd: resolve(options.unitDir, ".."), command: "pwd", env: {} })).toThrow("越出");
  });
});
