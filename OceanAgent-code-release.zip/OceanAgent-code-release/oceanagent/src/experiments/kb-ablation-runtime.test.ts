import { afterEach, describe, expect, it, vi } from "vitest";
import { mkdir, mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { prepareKbAblationUnits, runKbAblationUnits } from "./kb-ablation-runtime.js";
import { KB_ABLATION_PROTOCOL, KB_PLANNING_NON_KB_TOOLS, kbPlanningToolNames } from "./kb-ablation-protocol.js";
import { buildStage3Prompt, stage3CanonicalJson, type Stage3UnitSpec } from "./paired-dev.js";
import { loadStage3Knowledge, loadValidatedStage3Unit } from "./worker.js";
import { createProposeResearchPlanTool } from "../agent/tools/workflow-tools.js";
import type { OceanToolContext } from "../agent/tool-context.js";
import { experimentPlan, withExperimentUnit } from "./runtime-context.js";

const scratch: string[] = [];
afterEach(async () => { for (const path of scratch.splice(0)) await rm(path, { recursive: true, force: true }); });
async function fixture() {
  const parent = await mkdtemp(join(tmpdir(), "kb-free-planning-")); scratch.push(parent);
  const developmentRoot = join(parent, "OceanAgent-exp-dev"), knowledgeRoot = join(parent, "Ocean-RAG");
  await mkdir(developmentRoot); await mkdir(join(knowledgeRoot, "cards"), { recursive: true });
  await mkdir(join(knowledgeRoot, "benchmark", "splits"), { recursive: true });
  // Reading DEV/TEST answers would fail. Only explicit queryRows and TRAIN
  // visibility membership are permitted in the new opt-in preparer.
  await writeFile(join(knowledgeRoot, "benchmark", "splits", "dev.jsonl"), "DEV_ANSWER_READ_IS_FORBIDDEN");
  await writeFile(join(knowledgeRoot, "benchmark", "splits", "test.jsonl"), "TEST_ANSWER_READ_IS_FORBIDDEN");
  await writeFile(join(knowledgeRoot, "benchmark", "splits", "train.jsonl"), JSON.stringify({ source_id: "train", source_group_id: "train-group", gold_dataset_ids: ["TRAIN_GOLD_SENTINEL"] }));
  const cards = {
    "dataset_cards.jsonl": [{ dataset_id: "sst", name: "SST", description: "HELDOUT_PAPER_USAGE_SENTINEL",
      sources: [{ source_id: "paper_heldout", url: "https://doi.org/10.1234/heldout", quote: "HELDOUT_GOLD_SENTINEL" },
        { url: "https://coastwatch.noaa.gov/product" }], coverage: { spatial: "global" } }],
    "problem_solution_cards.jsonl": [
      { card_id: "train-psc", paper_id: "train", source_group_id: "train-group", bundle_id: "train-ubc", problem: "SST" },
      { card_id: "heldout-psc", paper_id: "dev", source_group_id: "dev-group", bundle_id: "heldout-ubc", problem: "heldout" }],
    "usage_bundle_cards.jsonl": [{ bundle_id: "train-ubc", steps: ["train-method"] }, { bundle_id: "heldout-ubc", steps: ["HELDOUT_DAG_SENTINEL"] }],
  };
  for (const [name, values] of Object.entries(cards)) await writeFile(join(knowledgeRoot, "cards", name), values.map(v => JSON.stringify(v)).join("\n"));
  return { developmentRoot, knowledgeRoot, experimentId: "free-test", model: { providerId: "fixture", modelId: "never-called" },
    queries: [{ query_id: "full", query: "Design an SST analysis plan" }, { query_id: "partial", query: "Design an alternative SST plan" }] };
}

describe("opt-in FullKB versus physically empty KB free planning", () => {
  it("keeps paired prompts/models/budgets identical without fixed answers or shared catalog", async () => {
    const options = await fixture();
    const manifest = await prepareKbAblationUnits({ ...options, queries: options.queries.map(q => ({ ...q, gold_dataset_ids: ["MUST_NOT_ENTER_AGENT"] })) });
    expect(manifest.units).toHaveLength(4);
    expect(new Set(manifest.units.map(u => u.condition))).toEqual(new Set(["A0", "A1"]));
    const specs: Stage3UnitSpec[] = await Promise.all(manifest.units.map(async u => JSON.parse(await readFile(u.unit_path, "utf8"))));
    expect(new Set(specs.map(u => u.config_sha256)).size).toBe(1);
    expect(specs[0]!.runtime_config).toMatchObject({ protocol_version: KB_ABLATION_PROTOCOL, planning_only: true });
    expect(specs[0]!.runtime_config).not.toHaveProperty("fixed_planning");
    expect(specs[0]!.runtime_config).not.toHaveProperty("public_catalog_sha256");
    for (const spec of specs) {
      const serialized = stage3CanonicalJson(spec);
      expect(serialized).not.toContain("MUST_NOT_ENTER_AGENT");
      expect(serialized).not.toContain("TRAIN_GOLD_SENTINEL");
      if (spec.condition === "A0") expect(spec.knowledge).toEqual({});
      expect(buildStage3Prompt(spec.query, "plan", spec.runtime_config)).toContain("自由选择");
      await expect(loadValidatedStage3Unit(join(spec.paths.unit_dir, "unit.json"), options.developmentRoot)).resolves.toMatchObject({ unit_id: spec.unit_id });
    }
    for (const query of options.queries) expect(new Set(specs.filter(u => u.query_id === query.query_id).map(u => u.input_sha256)).size).toBe(1);
    expect(kbPlanningToolNames("A0")).toEqual([...KB_PLANNING_NON_KB_TOOLS]);
    expect(kbPlanningToolNames("A1").filter(name => !["search_research_cases", "expand_research_case", "search_ocean_datasets", "get_dataset_facts", "trace_global_knowledge_graph"].includes(name)))
      .toEqual(kbPlanningToolNames("A0"));
  });

  it("never loads any card in A0 and strips held-out paper usage from A1 datasets", async () => {
    const options = await fixture(), manifest = await prepareKbAblationUnits(options);
    const a0 = JSON.parse(await readFile(manifest.units.find(u => u.condition === "A0")!.unit_path, "utf8"));
    const a1 = JSON.parse(await readFile(manifest.units.find(u => u.condition === "A1")!.unit_path, "utf8"));
    const neverRead = vi.fn();
    expect(await loadStage3Knowledge(a0, neverRead)).toEqual([]); expect(neverRead).not.toHaveBeenCalled();
    const visible = await loadStage3Knowledge(a1);
    expect(new Set(visible.map(d => d.id))).toEqual(new Set(["sst", "train-psc", "train-ubc"]));
    expect(JSON.stringify(visible)).not.toContain("HELDOUT_");
    expect(visible.find(d => d.id === "sst")!.payload).not.toHaveProperty("description");
    expect(JSON.stringify(visible)).toContain("coastwatch.noaa.gov");
  });

  it("dispatches a Smoke subset then resumes the same manifest without rerunning either arm", async () => {
    const options = await fixture(), manifest = await prepareKbAblationUnits(options);
    const seen: string[] = [];
    const executeUnit = async (path: string) => {
      const spec: Stage3UnitSpec = JSON.parse(await readFile(path, "utf8")); seen.push(spec.unit_id);
      await writeFile(join(spec.paths.unit_dir, "unit-result.json"), JSON.stringify({ ...spec, terminal_status: "awaiting_approval" }));
      return 0;
    };
    const path = join(manifest.experiment_dir, "experiment.json");
    const smoke = await runKbAblationUnits(path, { queryIds: ["full"], executeUnit });
    expect(smoke.filter(r => r.status === "worker_exited")).toHaveLength(2);
    expect(smoke.filter(r => r.status === "not_selected")).toHaveLength(2);
    const formal = await runKbAblationUnits(path, { resume: true, executeUnit });
    expect(formal.filter(r => r.status === "skipped_existing")).toHaveLength(2);
    expect(new Set(seen).size).toBe(4); expect(seen).toHaveLength(4);
    await expect(runKbAblationUnits(path, { queryIds: ["not-in-manifest"], executeUnit })).rejects.toThrow("Unknown");
  });

  it("submits a real freely chosen Plan through the existing Plan tool without downloading", async () => {
    const context = { planningOnly: true, requiresDataValidation: false, dataDownloadAllowed: false,
      adaptiveRetrievalEnabled: false, knowledgeGroundingRequired: false, dataSourceChecks: new Map(),
      createPlan: (input: any) => ({ ...input, id: "plan", conversationId: "c", version: 1, status: "awaiting_approval", createdAt: "now" }),
      setTerminalAction: vi.fn() } as unknown as OceanToolContext;
    const unit = { runtime_config: { mode: "plan", protocol_version: KB_ABLATION_PROTOCOL } } as Stage3UnitSpec;
    const params = { objective: "Freely chosen method", datasets: ["model-selected-product"], datasetRoles: { "model-selected-product": "target" },
      assumptions: ["Product availability remains to be independently checked"], evidenceNeeds: ["coverage"], evidenceRefs: [],
      deliverables: ["validated report"], steps: [
        { id: "D", title: "prepare", description: "preprocess", phase: "data" as const, inputs: { datasetIds: ["model-selected-product"] }, dependsOn: [], expectedOutputs: ["clean"], risks: [] },
        { id: "A", title: "analyze", description: "estimate", phase: "analysis" as const, inputs: { fromSteps: ["D"] }, dependsOn: ["D"], expectedOutputs: ["estimate"], risks: [] },
        { id: "V", title: "validate", description: "compare held-out results", phase: "validation" as const, inputs: { fromSteps: ["A"] }, dependsOn: ["A"], expectedOutputs: ["validation"], risks: [] },
        { id: "O", title: "report", description: "deliver report", phase: "artifact" as const, inputs: { fromSteps: ["V"] }, dependsOn: ["V"], expectedOutputs: ["report"], risks: [] },
      ] };
    const tool = createProposeResearchPlanTool(context);
    const out = await withExperimentUnit(unit, () => tool.execute("submit", params, undefined, undefined, {} as never));
    expect(out.terminate).toBe(true); expect(experimentPlan(unit)?.datasets).toEqual(["model-selected-product"]);
    expect(context.dataSourceChecks.size).toBe(0);
    await expect(withExperimentUnit(unit, () => tool.execute("duplicate", params, undefined, undefined, {} as never))).rejects.toThrow("ALREADY_SUBMITTED");
  });
});
