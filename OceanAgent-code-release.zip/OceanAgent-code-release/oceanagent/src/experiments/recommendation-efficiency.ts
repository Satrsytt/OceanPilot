import { createHash } from "node:crypto";
import type { ToolDefinition } from "@earendil-works/pi-coding-agent";
import { currentExperimentUnit, remainingExperimentMs } from "./runtime-context.js";
import { kbFreePlanningProtocol } from "./kb-ablation-protocol.js";

// These tools only read a frozen local snapshot or official search results. Never memoize
// submit, file writes, acquisition, or tools whose execution changes scientific state.
const READ_ONLY = new Set(["search_research_cases", "expand_research_case", "search_ocean_datasets",
  "get_dataset_facts", "trace_global_knowledge_graph", "search_official_web"]);
const canonical = (v: unknown): unknown => Array.isArray(v) ? v.map(canonical)
  : v && typeof v === "object" ? Object.fromEntries(Object.entries(v).sort(([a], [b]) => a.localeCompare(b))
    .map(([k, value]) => [k, canonical(value)])) : v;

/** Construct once per Agent session, inside the usual per-call isolation/budget wrapper.
 * Identical successful read calls reuse the same evidence, including empty official search
 * results; they do not silently retry the network or consume a tool's unique-query quota.
 * Full evidence remains available after context compaction. No persisted/shared cache exists.
 */
export function createRecommendationToolCoordinator(mode: "recommendation" | "plan" = "recommendation") {
  const cache = new Map<string, { callId: string; result: any }>();
  return <T extends ToolDefinition<any, any, any>>(tool: T): T => ({ ...tool,
    async execute(id, params, signal, onUpdate, context) {
      const key = READ_ONLY.has(tool.name)
        ? createHash("sha256").update(`${tool.name}|${JSON.stringify(canonical(params))}`).digest("hex") : null;
      const saved = key ? cache.get(key) : undefined;
      let result;
      if (saved) {
        result = structuredClone(saved.result);
        result.details = { ...result.details, recommendation_cache_hit: true,
          cache_scope: "agent_session", original_tool_call_id: saved.callId };
      } else {
        result = await tool.execute(id, params, signal, onUpdate, context);
        if (key && (result as { isError?: boolean }).isError !== true) {
          cache.set(key, { callId: id, result: structuredClone(result) });
        }
      }
      const unit = currentExperimentUnit();
      const remaining = unit ? remainingExperimentMs(unit) : null;
      if (remaining !== null && remaining <= Math.min(mode === "plan" ? 60_000 : 45_000, unit!.budget.max_agent_ms / 3)
        && tool.name !== (mode === "plan" ? "propose_research_plan" : "submit_dataset_recommendation")) {
        return { ...result, content: [...result.content, { type: "text" as const,
          text: mode === "plan"
            ? kbFreePlanningProtocol(unit?.runtime_config)
              ? "【统一自由规划预算提醒】总时间预算已接近上限。立即根据任务自由选择数据和方法调用propose_research_plan；写明datasetRoles、phase、inputs.datasetIds/fromSteps、dependsOn、expectedOutputs和结果验证。未知项列假设与缺口，不下载、不反复联网。"
              : "【统一规划预算提醒】总时间预算已接近上限。立即基于固定数据集调用propose_research_plan；写明datasetRoles、phase、inputs.datasetIds/fromSteps、dependsOn、expectedOutputs和结果验证。未知版本或作者生成数据写入assumptions/evidenceNeeds，不再下载或反复联网。"
            : "【统一推荐预算提醒】总时间预算已接近上限。立即基于已有证据调用submit_dataset_recommendation；不要再展开或联网补齐非关键事实，未知身份/覆盖如实保留，理由简短。" }] };
      }
      return result;
    },
  } as T);
}
