import { describe, expect, it } from "vitest";
import { fixedPlanStructureErrors } from "./plan-structure.js";

export const fixedPlanFixture = () => ({ objective: "A scientific planning test", datasets: ["fixed"], datasetRoles: { fixed: "target observations" }, evidenceRefs: [],
  deliverables: ["report"], steps: [
    { id: "S1", title: "prepare", description: "planned preprocessing", phase: "data", inputs: { datasetIds: ["fixed"] }, dependsOn: [], expectedOutputs: ["clean"], risks: [] },
    { id: "S2", title: "analyze", description: "planned analysis", phase: "analysis", inputs: { fromSteps: ["S1"] }, dependsOn: ["S1"], expectedOutputs: ["estimate"], risks: [] },
    { id: "S3", title: "validate", description: "planned held-out verification", phase: "validation", inputs: { fromSteps: ["S2"] }, dependsOn: ["S2"], expectedOutputs: ["report"], risks: [] },
  ] });
describe("fixed Plan structural contract, not scientific correctness", () => {
  it("accepts an explicit fixed-data DAG and refuses fixed set/role/input replacement", () => {
    const p = fixedPlanFixture(); expect(fixedPlanStructureErrors(p, ["fixed"])).toEqual([]);
    expect(fixedPlanStructureErrors({ ...p, datasets: ["different"] }, ["fixed"])).toContain("fixed_dataset_set_differs");
    expect(fixedPlanStructureErrors({ ...p, datasetRoles: {} }, ["fixed"])).toContain("dataset_roles_must_cover_exact_fixed_set");
    p.steps[0]!.inputs = { datasetIds: ["other"] };
    expect(fixedPlanStructureErrors(p, ["fixed"])).toContain("S1:unknown_dataset:other");
  });
  it("rejects cycles, unknown edges and input references outside declared dependencies", () => {
    const p = fixedPlanFixture(); p.steps[0]!.dependsOn = ["S3"];
    expect(fixedPlanStructureErrors(p, ["fixed"])).toContain("dependency_cycle");
    p.steps[0]!.dependsOn = ["missing"];
    expect(fixedPlanStructureErrors(p, ["fixed"])).toContain("S1:unknown_dependency:missing");
    p.steps[1]!.inputs = { fromSteps: ["S3"] };
    expect(fixedPlanStructureErrors(p, ["fixed"])).toContain("S2:input_step_not_dependency");
  });
  it("requires declared I/O and a data-analysis-validation path without calling it scientifically adequate", () => {
    const p = fixedPlanFixture(); p.steps[1]!.expectedOutputs = [];
    expect(fixedPlanStructureErrors(p, ["fixed"])).toContain("S2:outputs_missing");
    p.steps[2]!.dependsOn = ["S1"];
    expect(fixedPlanStructureErrors(p, ["fixed"])).toContain("declared_data_analysis_validation_path_missing");
  });
  it("rejects unretrieved card citations and credential-bearing URL evidence", () => {
    const p = { ...fixedPlanFixture(), evidenceRefs: ["not_retrieved", "https://noaa.gov/data?api_key=synthetic"] };
    const errors = fixedPlanStructureErrors(p, ["fixed"], { knownEvidenceIds: new Set() });
    expect(errors).toContain("plan:unretrieved_evidence_id:not_retrieved"); expect(errors).toContain("plan:unsafe_evidence_url");
    expect(fixedPlanStructureErrors({ ...p, evidenceRefs: ["retrieved", "https://www.noaa.gov/"] }, ["fixed"], { knownEvidenceIds: new Set(["retrieved"]) })).toEqual([]);
  });
});
