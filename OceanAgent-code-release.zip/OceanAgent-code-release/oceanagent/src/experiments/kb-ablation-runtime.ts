/** Thin entry point into the existing isolated OceanAgent experiment worker. */
import { readFile } from "node:fs/promises";
import { join } from "node:path";
import { prepareStage3Experiment, executePreparedStage3, type Stage3Budget, type Stage3ExperimentManifest,
  type Stage3Model } from "./paired-dev.js";
import { KB_ABLATION_PROTOCOL, kbFreePlanningProtocol } from "./kb-ablation-protocol.js";
export { KB_ABLATION_PROTOCOL } from "./kb-ablation-protocol.js";

export interface PrepareKbAblationOptions {
  developmentRoot: string; experimentId: string; knowledgeRoot: string; benchmarkRoot?: string;
  queries: Array<{ query_id: string; query: string }>;
  model: Stage3Model; budget?: Partial<Stage3Budget>; replicates?: number; seed?: number;
  resume?: boolean; concurrency?: number;
  protocolVersion?: "kb-free-planning-v1" | "kb-free-planning-v2";
}
export function prepareKbAblationUnits(options: PrepareKbAblationOptions): Promise<Stage3ExperimentManifest> {
  return prepareStage3Experiment({ ...options, queryRows: options.queries, conditions: ["A0", "A1"],
    runtimeConfig: { protocol_version: options.protocolVersion ?? KB_ABLATION_PROTOCOL, mode: "plan", temperature: 0,
      adaptive_retrieval: false, max_execution_rounds: 1, execution_concurrency: options.concurrency ?? 1 } });
}
export function runKbAblationUnits(manifestPath: string, options: {
  resume?: boolean; executeUnit?: (unitPath: string) => Promise<number>; nodePath?: string;
  queryIds?: readonly string[]; unitIds?: readonly string[];
} = {}) {
  return executePreparedStage3(manifestPath, options);
}
export async function readKbAblationUnitResult(unitDir: string): Promise<Record<string, unknown>> {
  const result = JSON.parse(await readFile(join(unitDir, "unit-result.json"), "utf8"));
  if (!kbFreePlanningProtocol({ protocol_version: result.protocol_version })) throw new Error("Not a free-planning KB ablation result");
  return result;
}
