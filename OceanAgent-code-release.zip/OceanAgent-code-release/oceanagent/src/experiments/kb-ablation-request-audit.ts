import { createHash } from "node:crypto";
import type { Stage3UnitSpec } from "./paired-dev.js";
import { KB_PLANNING_KB_TOOLS, kbPlanningToolNames } from "./kb-ablation-protocol.js";

const record = (value: unknown): Record<string, unknown> => value && typeof value === "object"
  ? value as Record<string, unknown> : {};
/** Inspect the actual model context, not a predicted list from configuration.
 * No KB files/ID dictionary are opened in KB-off to perform this audit. Product
 * names learned by the model or obtained from an allowed official page are not
 * classified as leaked cards merely because a KB happens to use the same ID. */
export function auditKbPlanningRequest(unit: Stage3UnitSpec, context: unknown): Record<string, unknown> & { passed: boolean } {
  const value = record(context), allowed = new Set(kbPlanningToolNames(unit.condition));
  const tools = Array.isArray(value.tools) ? value.tools.map(tool => String(record(tool).name ?? "")) : [];
  const knowledgeTools = tools.filter(name => [...KB_PLANNING_KB_TOOLS, "assess_dataset_routes"].includes(name as never));
  const unexpectedTools = tools.filter(name => !allowed.has(name));
  const system = typeof value.systemPrompt === "string" ? value.systemPrompt : JSON.stringify(value.systemPrompt ?? "");
  const knowledgeInstructions = /必须先实际调用 Ocean-RAG|先调用[^\n]*(?:search_research_cases|expand_research_case)|读取 DatasetCard|知识库使用记录[”"]/g;
  const activeKnowledgeInstructions = unit.condition === "A0" ? [...system.matchAll(knowledgeInstructions)].map(match => match[0]) : [];
  const cardPayload = /"(?:cardType|card_type)"\s*:\s*"(?:dataset|problem_solution|usage_bundle)"|"(?:problemSolutionReference|usageBundleReference|publication_quality|bundle_id)"\s*:/;
  const cardId = /\b(?:PSC|UBC|ProblemSolutionCard|UsageBundleCard|DatasetCard)[:_][A-Za-z0-9_.:-]+/g;
  const injectedCardIds = new Set<string>(), payloadMessageIndices: number[] = [], knowledgeResultIndices: number[] = [];
  const systemPayload = unit.condition === "A0" && cardPayload.test(system);
  if (unit.condition === "A0") for (const match of system.matchAll(cardId)) injectedCardIds.add(match[0]);
  const messages = Array.isArray(value.messages) ? value.messages : [];
  const maskQuery = (node: unknown): unknown => typeof node === "string" ? node.split(unit.query.query).join("[shared user query]")
    : Array.isArray(node) ? node.map(maskQuery)
      : node && typeof node === "object" ? Object.fromEntries(Object.entries(node).map(([key, child]) => [key, maskQuery(child)])) : node;
  const strings = (node: unknown): string[] => typeof node === "string" ? [node]
    : Array.isArray(node) ? node.flatMap(strings) : node && typeof node === "object" ? Object.values(node).flatMap(strings) : [];
  if (unit.condition === "A0") {
    for (const [index, item] of messages.entries()) {
      const message = record(item);
      // Assistant-authored hypotheses are unverified content, not treated
      // as a control-plane injection. User query text is shared across arms.
      if (message.role === "assistant") continue;
      const masked = maskQuery(message);
      const serialized = `${JSON.stringify(masked)}\n${strings(masked).join("\n")}`;
      const name = String(message.toolName ?? message.name ?? "");
      if ([...KB_PLANNING_KB_TOOLS, "assess_dataset_routes"].includes(name as never)) knowledgeResultIndices.push(index);
      if (cardPayload.test(serialized)) {
        payloadMessageIndices.push(index);
        for (const match of serialized.matchAll(cardId)) injectedCardIds.add(match[0]);
      }
    }
  }
  const passed = !unexpectedTools.length && !activeKnowledgeInstructions.length && !systemPayload && !injectedCardIds.size && !payloadMessageIndices.length
    && !knowledgeResultIndices.length && (unit.condition !== "A0" || !knowledgeTools.length);
  return { passed, condition: unit.condition, actual_tool_names: tools, knowledge_tool_names: knowledgeTools,
    unexpected_tool_names: unexpectedTools, active_knowledge_instruction_hits: activeKnowledgeInstructions,
    system_card_payload_detected: systemPayload,
    known_card_id_hits: [...injectedCardIds], injected_card_payload_message_indices: payloadMessageIndices,
    knowledge_tool_result_message_indices: knowledgeResultIndices,
    system_sha256: createHash("sha256").update(system).digest("hex"),
    context_sha256: createHash("sha256").update(JSON.stringify(value)).digest("hex"), message_count: messages.length,
    scan_semantics: "actual tool allowlist and injected structured card context; no KB read or global identity dictionary; assistant hypotheses and common public product names are not proof of leakage" };
}
