import { mkdir, mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { basename, join } from "node:path";
import { randomUUID } from "node:crypto";
import { afterEach, describe, expect, it, vi } from "vitest";
import type { AppContext } from "../app-context.js";
import type { ResearchPlan } from "../contracts.js";
import { OceanDatabase } from "../db/database.js";
import { ConversationRepository } from "../db/conversation-repository.js";
import { PlanRepository } from "../db/plan-repository.js";
import { ProjectRepository } from "../db/project-repository.js";
import { RunRepository } from "../db/run-repository.js";
import type { OceanModelService } from "../agent/model-service.js";
import { RagStore } from "../rag/rag-store.js";
import { loadRagDocuments } from "../rag/normalizer.js";
import { RunTelemetry } from "../telemetry/run-telemetry.js";
import { experimentMetadata, recordExperimentPlan, recordExperimentRecommendation } from "./runtime-context.js";
import { SCIENTIFIC_PROTOCOL, RECOMMENDATION_CONTRACT, type DatasetRecommendation } from "./scientific-protocol.js";
import { buildStage3Prompt, prepareStage3Experiment, stage3CanonicalJson, type Stage3Condition, type Stage3Mode, type Stage3UnitSpec } from "./paired-dev.js";
import { createHash } from "node:crypto";
import { loadStage3Knowledge, loadValidatedStage3Unit, runExperimentUnit, type Stage3WorkerDependencies } from "./worker.js";

const scratch: string[] = [];
afterEach(async () => { for (const path of scratch.splice(0)) await rm(path, { recursive: true, force: true }); });
async function fixture(mode: Stage3Mode = "recommendation", rounds = 1, v2 = false, maxAgentMs = 600000) {
  const container = await mkdtemp(join(tmpdir(), "stage3-worker-")); scratch.push(container);
  const root = join(container, "OceanAgent-exp-dev"), kb = join(container, "Ocean-RAG"); await mkdir(root);
  await mkdir(join(kb, "cards"), { recursive: true }); await mkdir(join(kb, "benchmark", "splits"), { recursive: true });
  await writeFile(join(kb, "benchmark", "splits", "dev.jsonl"), JSON.stringify({ query_id: "dev_1", query: "Recommend coastal SST and wind datasets", source_id: "dev_paper", source_group_id: "dev_group", gold_dataset_ids: ["GOLD_MUST_NOT_REACH_AGENT"] }));
  await writeFile(join(kb, "benchmark", "splits", "train.jsonl"), JSON.stringify({ source_id: "train_paper", source_group_id: "train_group" }));
  const cards = {
    "dataset_cards.jsonl": [{ dataset_id: "sst", name: "SST", description: "Globally visible dataset" }],
    "problem_solution_cards.jsonl": [
      { card_id: "train_psc", paper_id: "train_paper", source_group_id: "train_group", bundle_id: "train_ubc", problem: "coastal temperature", solution_summary: "join observations" },
      { card_id: "dev_psc", paper_id: "dev_paper", source_group_id: "dev_group", bundle_id: "dev_ubc", problem: "held-out answer" },
      { card_id: "group_only_bypass", paper_id: "dev_paper", source_group_id: "train_group", bundle_id: "bypass_ubc" },
      { card_id: "source_only_bypass", paper_id: "train_paper", source_group_id: "dev_group", bundle_id: "bypass_ubc" },
    ],
    "usage_bundle_cards.jsonl": [{ bundle_id: "train_ubc", steps: ["TRAIN_WORKFLOW"] }, { bundle_id: "dev_ubc", steps: ["HELDOUT_WORKFLOW"] }, { bundle_id: "bypass_ubc", steps: ["FORBIDDEN_BYPASS"] }],
  };
  for (const [name, rows] of Object.entries(cards)) await writeFile(join(kb, "cards", name), rows.map(row => JSON.stringify(row)).join("\n"));
  const fixed = { schema_version: "stage3-fixed-planning-v1", independent: true,
    reviewer_id: "fixed-gold-test", kind: "fixed_gold", datasets_by_query: { dev_1: ["GOLD_MUST_NOT_REACH_AGENT"] } };
  const fixedPath = join(root, "oracle.json"), fixedBytes = JSON.stringify(fixed);
  if (v2 && mode === "plan") await writeFile(fixedPath, fixedBytes);
  const manifest = await prepareStage3Experiment({ developmentRoot: root, experimentId: "fixture", knowledgeRoot: kb,
    model: { providerId: "fixture", modelId: "offline" }, budget: { max_agent_ms: maxAgentMs }, runtimeConfig: { mode, max_execution_rounds: rounds,
      ...(v2 ? { protocol_version: SCIENTIFIC_PROTOCOL } : {}),
      ...(v2 && mode === "plan" ? { fixed_planning: fixed, fixed_planning_path: fixedPath,
        fixed_planning_file_sha256: createHash("sha256").update(fixedBytes).digest("hex") } : {}) } });
  const units = new Map<Stage3Condition, { path: string; spec: Stage3UnitSpec }>();
  for (const unit of manifest.units) units.set(unit.condition, { path: unit.unit_path, spec: JSON.parse(await readFile(unit.unit_path, "utf8")) });
  return { root, kb, manifest, units };
}

function offlineRuntime(options: { noPlan?: boolean; executionPartial?: boolean; submittedThenFailed?: boolean; planThenFailed?: boolean } = {}) {
  const seen: { inputs: string[]; approved: boolean[]; docs: Record<string, unknown>[]; configs: AppContext["config"][] } = { inputs: [], approved: [], docs: [], configs: [] };
  const models = { runtime: { streamSimple: () => { throw new Error("Offline fixture must never call a model"); } },
    runModelValue: () => "fixture::offline", resolveRunModel: () => ({ provider: "fixture", id: "offline", api: "fixture", baseUrl: "https://example.invalid", contextWindow: 4096, maxTokens: 1000 }) } as unknown as OceanModelService;
  const loadModels: Stage3WorkerDependencies["loadModels"] = async () => ({ models, close: () => undefined });
  const createContext: Stage3WorkerDependencies["createContext"] = async (config, supplied) => {
    seen.configs.push(config!); const unit = config!.experiment!;
    const database = new OceanDatabase(config!.databasePath, unit.paths.workspace);
    const projects = new ProjectRepository(database); projects.ensureDefault();
    const conversations = new ConversationRepository(database), runs = new RunRepository(database), plans = new PlanRepository(database);
    await supplied?.initializeRag?.(new RagStore(database));
    seen.docs.push(...database.raw.prepare("SELECT card_type, payload_json, source_path FROM rag_documents").all() as Record<string, unknown>[]);
    let executions = 0;
    const runner = { abort: vi.fn(async () => true), execute: async (runId: string) => {
      const run = runs.get(runId)!, input = conversations.getNode(run.userNodeId)!;
      seen.inputs.push(input.content); const approved = typeof input.metadata.approvedPlanId === "string"; seen.approved.push(approved);
      const trace = new RunTelemetry(unit.paths.logs, { taskId: "fixture-task", runId, inputHash: unit.input_sha256, configHash: unit.config_sha256,
        model: "fixture::offline", provider: "fixture", gitCommit: null, datasetSnapshot: unit.data_snapshot_id,
        knowledgeSnapshot: unit.knowledge_snapshot_id, knowledgeMode: unit.condition === "A0" ? "off" : "on",
        runKind: "deterministic_integration", experiment: experimentMetadata(unit) });
      runs.update(runId, { status: "running" });
      if (approved) {
        executions++; const status = options.executionPartial && executions === 1 ? "partial" : "completed";
        plans.updateStatus(String(input.metadata.approvedPlanId), status); runs.update(runId, { status: "settled", outcome: status }); trace.finish(status);
      } else if (options.submittedThenFailed) {
        const output: DatasetRecommendation = { schema_version: RECOMMENDATION_CONTRACT,
          candidates: [{ rank: 1, dataset_id: "sst", canonical_product_id: null, identity_status: "unresolved",
            evidence_urls: [], capabilities: [], roles: [], rationale: "offline test", evidence_ids: [] }],
          candidate_sha256: "test-hash", ranking_semantics: "explicit_model_priority_not_retrieval_score",
          capability_semantics: "model_claims_require_independent_judgment", submitted_at: new Date().toISOString() };
        recordExperimentRecommendation(unit, output); trace.recommendationSubmitted(output);
        trace.toolStarted("public", "get_dataset_facts", { ids: ["sst"] });
        trace.toolEnded("public", false, { datasets: [{ id: "sst", cardType: "dataset" }] });
        runs.update(runId, { status: "failed", outcome: "failed" }); trace.finish("failed");
      } else if (options.noPlan) {
        trace.toolStarted("retrieval-only", "search_ocean_datasets", { query: "SST" });
        trace.toolEnded("retrieval-only", false, { results: [{ id: "retrieval_hit_is_not_prediction", cardType: "dataset" }] });
        runs.update(runId, { status: "settled", outcome: "completed" }); trace.finish("completed");
      } else {
        const node = conversations.addNode({ conversationId: run.conversationId, role: "assistant", parentId: input.id, content: "Plan fixture" });
        const plan: ResearchPlan = { id: randomUUID(), conversationId: run.conversationId, nodeId: node.id, version: 1, status: "awaiting_approval",
          objective: unit.runtime_config.fixed_planning ? "DEV query https://www.noaa.gov/，未验证" : "DEV query", assumptions: [], requiredInputs: [],
          datasets: unit.runtime_config.mode === "plan" && unit.runtime_config.fixed_planning
            ? (unit.runtime_config.fixed_planning as any).datasets_by_query[unit.query_id] : ["sst", "wind"], evidenceNeeds: [],
          verifiedDataSources: [{ dataset: "sst", pageUrl: "https://example.invalid/metadata", status: "metadata_only", reason: "fixture", checkedAt: new Date().toISOString() }],
          steps: [], deliverables: [], risks: [], createdAt: new Date().toISOString(), ablationCondition: unit.condition };
        plans.save(plan);
        if (unit.runtime_config.mode === "plan" && unit.runtime_config.fixed_planning) {
          const proposal = { ...plan }; delete proposal.nodeId;
          trace.planGenerated(proposal); recordExperimentPlan(unit, proposal);
        } else trace.planGenerated(plan);
        runs.update(runId, options.planThenFailed ? { status: "failed", outcome: "failed" } : { status: "settled", outcome: "awaiting_approval" });
        trace.finish(options.planThenFailed ? "failed" : "awaiting_approval");
      }
    } };
    return { config, database, projects, conversations, runs, plans, runner, models, close: () => database.close() } as unknown as AppContext;
  };
  return { seen, dependencies: { loadModels, createContext } };
}

describe("isolated Stage3 inference worker", () => {
  it.each([false, true])("binds fixed Plan SHA to redacted native proposal, including later failure=%s", async planThenFailed => {
    const data = await fixture("plan", 1, true), unit = data.units.get("A0")!;
    const result = await runExperimentUnit(unit.path, { applicationRoot: data.root, ...offlineRuntime({ planThenFailed }).dependencies });
    const native = JSON.parse(await readFile(String(result.plan_path), "utf8"));
    const persistedResult = JSON.parse(await readFile(join(unit.spec.paths.unit_dir, "unit-result.json"), "utf8"));
    expect(result.plan_output).toEqual(native); expect(native.nodeId).toBeUndefined();
    expect(persistedResult.plan_output).toEqual(native); expect(persistedResult.plan_sha256).toBe(result.plan_sha256);
    expect(result.plan_id).toBe(native.id);
    expect(result.plan_sha256).toBe(createHash("sha256").update(stage3CanonicalJson(native)).digest("hex"));
    expect(result.run_ids).toContain(result.plan_run_id);
    expect(result.terminal_status).toBe(planThenFailed ? "failed" : "awaiting_approval");
    expect(result.plan_contract_version).toBe("stage3-fixed-plan-v1");
  });
  it("rejects Oracle file changes before loading a model", async () => {
    const data = await fixture("plan", 1, true), unit = data.units.get("A0")!, loadModels = vi.fn();
    await writeFile(String(unit.spec.runtime_config.fixed_planning_path), "changed source");
    await expect(runExperimentUnit(unit.path, { applicationRoot: data.root, loadModels })).rejects.toThrow("fixed planning source file changed");
    expect(loadModels).not.toHaveBeenCalled();
  });
  it("v2 shares the exact public facts across A0/A1/A2 while retaining private source isolation", async () => {
    const data = await fixture("recommendation", 1, true);
    const all = await Promise.all(["A0", "A1", "A2"].map(c => loadStage3Knowledge(data.units.get(c as Stage3Condition)!.spec)));
    const publicFacts = all.map(docs => JSON.stringify(docs.filter(doc => doc.cardType === "dataset").map(doc => doc.payload)));
    expect(new Set(publicFacts).size).toBe(1);
    expect(all[0]!.every(doc => doc.cardType === "dataset")).toBe(true);
    expect(all[1]!.some(doc => doc.id === "train_ubc")).toBe(true);
    expect(JSON.stringify(all[2])).not.toContain("train_ubc");
    expect(JSON.stringify(all)).not.toContain("HELDOUT_WORKFLOW");
    expect(all[0]!.some(doc => doc.payload.catalog_projection && JSON.stringify(doc.payload.catalog_projection).includes("verified_official_facts"))).toBe(true);
  });
  it("v2 retains a submitted recommendation even when a later run fails without Plan", async () => {
    const data = await fixture("recommendation", 1, true), unit = data.units.get("A0")!;
    const result = await runExperimentUnit(unit.path, { applicationRoot: data.root, ...offlineRuntime({ submittedThenFailed: true }).dependencies });
    expect(result.terminal_status).toBe("failed"); expect(result.plan_id).toBeNull();
    expect(result.deadline_exceeded).toBe(false); expect(result.timeout_kind).toBeNull();
    expect(result.predicted_dataset_ids).toEqual(["sst"]); expect(result.recommendation_valid).toBe(true);
  });
  it("records an actually exhausted total deadline without treating every failure as a timeout", async () => {
    const data = await fixture("recommendation", 1, true, 1), unit = data.units.get("A0")!;
    const offline = offlineRuntime({ noPlan: true });
    const result = await runExperimentUnit(unit.path, { applicationRoot: data.root, ...offline.dependencies,
      loadModels: async root => { await new Promise(resolve => setTimeout(resolve, 5)); return offline.dependencies.loadModels!(root); } });
    expect(result).toMatchObject({ terminal_status: "failed", error_type: "STAGE3_TIME_BUDGET_EXHAUSTED",
      deadline_exceeded: true, timeout_kind: "hard_timeout", recommendation_valid: false });
    expect(offline.seen.inputs).toEqual([]);
  });
  it("validates frozen unit identity, paths and sanitized input before any application/model work", async () => {
    const fixtureData = await fixture(), unit = fixtureData.units.get("A1")!;
    await expect(loadValidatedStage3Unit(unit.path, fixtureData.root)).resolves.toMatchObject({ condition: "A1" });
    const loadModels = vi.fn(); unit.spec.query = { ...unit.spec.query, gold_dataset_ids: ["LEAK"] } as Stage3UnitSpec["query"];
    await writeFile(unit.path, JSON.stringify(unit.spec));
    await expect(runExperimentUnit(unit.path, { applicationRoot: fixtureData.root, loadModels })).rejects.toThrow("changed after preparation");
    expect(loadModels).not.toHaveBeenCalled();
  });

  it("A0 never opens knowledge and A1 admits only train source+group PSC and exact linked UBC", async () => {
    const data = await fixture(), forbiddenLoader = vi.fn(async () => { throw new Error("must not read KB"); });
    expect(await loadStage3Knowledge(data.units.get("A0")!.spec, forbiddenLoader)).toEqual([]); expect(forbiddenLoader).not.toHaveBeenCalled();
    const docs = await loadStage3Knowledge(data.units.get("A1")!.spec);
    expect(docs.map(doc => doc.id)).toEqual(["sst", "train_psc", "train_ubc"]);
    expect(docs[0]!.payload).not.toHaveProperty("description");
    expect(docs[0]!.payload).toMatchObject({ dataset_id: "sst", name: "SST",
      catalog_projection: { version: "stage3-product-catalog-v1", source_evidence: "identity_only" } });
    expect(JSON.stringify(docs)).not.toContain("HELDOUT_WORKFLOW"); expect(JSON.stringify(docs)).not.toContain("FORBIDDEN_BYPASS");
  });

  it("A2 does not read UBC and projects bundle identity/content before private indexing", async () => {
    const data = await fixture(), calls: string[] = [];
    const spec = data.units.get("A2")!.spec;
    const docs = await loadStage3Knowledge(spec, async path => { calls.push(basename(path)); return loadRagDocuments(path); });
    expect(calls).toEqual(["dataset_cards.jsonl", "problem_solution_cards.jsonl"]);
    expect(docs.map(doc => doc.id)).toEqual(["sst", "train_psc"]); expect(JSON.stringify(docs)).not.toContain("train_ubc");
    expect(docs[1]!.payload).not.toHaveProperty("bundle_id");
    await writeFile(spec.knowledge.dataset_cards_path!, "changed source");
    await expect(loadStage3Knowledge(spec)).rejects.toThrow("source changed");
  });

  it.each(["recommendation", "plan"] as const)("%s uses a fresh native DB and native logs, then stops at approval", async mode => {
    const data = await fixture(mode), unit = data.units.get("A2")!, offline = offlineRuntime();
    const result = await runExperimentUnit(unit.path, { applicationRoot: data.root, ...offline.dependencies });
    expect(result.terminal_status).toBe("awaiting_approval"); expect(result.predicted_dataset_ids).toEqual(["sst", "wind"]);
    expect(result.dataset_catalog_projection).toMatchObject({ version: "stage3-product-catalog-v1", dataset_cards: 1,
      product_metadata_cards: 0, identity_only_cards: 1, removed_descriptions: 1 });
    expect(offline.seen.inputs).toEqual([buildStage3Prompt(unit.spec.query, mode)]); expect(offline.seen.approved).toEqual([false]);
    expect(offline.seen.configs[0]!.multiplePlansEnabled).toBe(false);
    expect(offline.seen.docs.every(doc => String(doc.source_path).startsWith(join(unit.spec.paths.unit_dir, "runtime", "knowledge-view")))).toBe(true);
    expect(JSON.stringify(offline.seen.docs)).not.toContain("train_ubc");
    const metrics = result.metrics_paths as string[]; expect(metrics).toHaveLength(1);
    const metric = JSON.parse(await readFile(metrics[0]!, "utf8")); expect(metric.experiment.unit_id).toBe(unit.spec.unit_id);
    expect(metric.run_kind).toBe("deterministic_integration"); expect(metric.input_sha256).toBe(unit.spec.input_sha256);
    expect(JSON.stringify(result)).not.toContain("GOLD_MUST_NOT_REACH_AGENT");
    await expect(runExperimentUnit(unit.path, { applicationRoot: data.root, ...offline.dependencies })).rejects.toThrow("existing execution state");
  });

  it("does not promote retrieval hits into predictions when the Agent produced no Plan", async () => {
    const data = await fixture(), unit = data.units.get("A0")!, offline = offlineRuntime({ noPlan: true });
    const result = await runExperimentUnit(unit.path, { applicationRoot: data.root, ...offline.dependencies });
    expect(result.predicted_dataset_ids).toBeNull(); expect(result.plan_id).toBeNull(); expect(offline.seen.docs).toEqual([]);
    expect(result.metrics_paths).toHaveLength(1);
  });

  it("records unavailable credentials as an initialization failure without leaking error text or fabricating metrics", async () => {
    const data = await fixture(), unit = data.units.get("A0")!;
    const result = await runExperimentUnit(unit.path, { applicationRoot: data.root,
      loadModels: async () => { throw new Error("api_key=DO_NOT_LOG_THIS"); } });
    expect(result.terminal_status).toBe("failed"); expect(result.error_type).toBe("Error");
    expect(result.predicted_dataset_ids).toBeNull(); expect(result.model_config_sha256).toBeNull();
    expect(result.run_ids).toEqual([]); expect(result.metrics_paths).toEqual([]);
    expect(await readFile(join(unit.spec.paths.unit_dir, "unit-result.json"), "utf8")).not.toContain("DO_NOT_LOG_THIS");
  });

  it("refuses pre-seeded workspace or runtime state before loading models", async () => {
    for (const destination of ["workspace", "runtime"] as const) {
      const data = await fixture(), unit = data.units.get("A0")!, loadModels = vi.fn();
      const target = destination === "workspace" ? unit.spec.paths.workspace : join(unit.spec.paths.unit_dir, "runtime");
      await writeFile(join(target, "copied-arm-result.json"), "foreign arm output");
      await expect(runExperimentUnit(unit.path, { applicationRoot: data.root, loadModels })).rejects.toThrow("unapproved pre-existing artifact");
      expect(loadModels).not.toHaveBeenCalled();
    }
  });

  it("end_to_end explicitly approves the selected Plan and obeys the frozen round cap", async () => {
    const data = await fixture("end_to_end", 2), unit = data.units.get("A1")!, offline = offlineRuntime({ executionPartial: true });
    const result = await runExperimentUnit(unit.path, { applicationRoot: data.root, ...offline.dependencies });
    expect(offline.seen.approved).toEqual([false, true, true]); expect(result.run_ids).toHaveLength(3);
    expect(result.metrics_paths).toHaveLength(3); expect(result.terminal_status).toBe("completed"); expect(result.plan_status).toBe("completed");
    expect(result.model_config_sha256).toMatch(/^[a-f0-9]{64}$/);
  });
});
