/** A frozen public-fact layer. It contains no query, paper or benchmark-answer links. */
import { createHash } from "node:crypto";
import { existsSync, readFileSync } from "node:fs";
import type { RagDocument } from "../rag/types.js";
import { renderRagContent } from "../rag/normalizer.js";

export const PUBLIC_PRODUCT_CATALOG_VERSION = "stage3-public-products-v2" as const;
export interface PublicProductEvidence {
  url: string; retrievedAt: string; locator: string;
  snapshot: Record<string, unknown>; snapshotSha256: string;
  sourceResponseSha256?: string;
}
export interface PublicProductRecord {
  canonicalProductId: string; productId: string; name: string; provider: string;
  /** null is deliberate: a current service or product family is not a verified data release. */
  version: string | null; region: string; identifiers: string[]; sourceUrls: string[];
  variant?: string;
  identityScope: "versioned_product" | "unversioned_service";
  facts: Record<string, unknown>; evidence: PublicProductEvidence[];
  factEvidence: Array<{ path: string; url: string; locator: string }>;
}
export interface PublicProductCatalog {
  schema_version: typeof PUBLIC_PRODUCT_CATALOG_VERSION; version: string;
  products: PublicProductRecord[];
}
export interface PublicProductCandidate {
  datasetId?: string; productId?: string; version?: string; region?: string;
  variant?: string;
  sourceUrls?: string[];
}
export interface CanonicalProductResolution {
  status: "matched" | "ambiguous" | "unresolved";
  canonicalProductId: string | null; candidateProductIds: string[];
  evidenceUrls: string[]; reason: string;
}
export interface PublicCatalogProjectionStats {
  version: typeof PUBLIC_PRODUCT_CATALOG_VERSION; dataset_cards: number;
  verified_fact_cards: number; identity_only_cards: number;
  retained_verified_fields: number; withheld_source_fields: number;
}
const object = (value: unknown): value is Record<string, unknown> => !!value && typeof value === "object" && !Array.isArray(value);
const canonical = (value: unknown): unknown => Array.isArray(value) ? value.map(canonical)
  : object(value) ? Object.fromEntries(Object.entries(value).sort(([a], [b]) => a.localeCompare(b)).map(([k, v]) => [k, canonical(v)])) : value;
export const publicFactSnapshotSha256 = (value: unknown): string => createHash("sha256").update(JSON.stringify(canonical(value))).digest("hex");

/** Allow evidence pointers only; this does not itself verify the pointed-to facts. */
export function publicEvidenceUrl(value: unknown): string | undefined {
  if (typeof value !== "string") return undefined;
  try {
    const url = new URL(value);
    if (url.protocol !== "https:" || url.username || url.password || url.port && url.port !== "443") return undefined;
    if (!/(?:^|\.)(?:noaa\.gov|nsidc\.org|ecmwf\.int|copernicus\.eu|eumetsat\.int|nasa\.gov|metoffice\.gov\.uk|psmsl\.org)$/.test(url.hostname)) return undefined;
    for (const key of url.searchParams.keys()) if (/token|secret|pass|key|signature|credential|auth|session/i.test(key)) return undefined;
    url.hash = ""; return url.toString();
  } catch { return undefined; }
}

export function validatePublicProductCatalog(value: unknown): PublicProductCatalog {
  if (!object(value) || value.schema_version !== PUBLIC_PRODUCT_CATALOG_VERSION || typeof value.version !== "string" || !Array.isArray(value.products)) throw new Error("Invalid public product catalogue");
  const seen = new Set<string>();
  for (const product of value.products) {
    if (!object(product) || typeof product.canonicalProductId !== "string" || seen.has(product.canonicalProductId)
      || !/^[A-Za-z0-9][A-Za-z0-9:._/-]+$/.test(product.canonicalProductId)
      || typeof product.productId !== "string" || typeof product.name !== "string" || typeof product.provider !== "string"
      || !(typeof product.version === "string" || product.version === null) || typeof product.region !== "string"
      || !["versioned_product", "unversioned_service"].includes(String(product.identityScope))
      || !Array.isArray(product.identifiers) || !product.identifiers.every(x => typeof x === "string")
      || !Array.isArray(product.sourceUrls) || !product.sourceUrls.length || !product.sourceUrls.every(x => publicEvidenceUrl(x) === x)
      || !object(product.facts) || !Array.isArray(product.evidence) || !product.evidence.length || !Array.isArray(product.factEvidence)) throw new Error("Invalid public product record");
    for (const evidence of product.evidence) {
      if (!object(evidence) || publicEvidenceUrl(evidence.url) !== evidence.url || typeof evidence.retrievedAt !== "string"
        || !Number.isFinite(Date.parse(evidence.retrievedAt)) || typeof evidence.locator !== "string" || !object(evidence.snapshot)
        || evidence.snapshotSha256 !== publicFactSnapshotSha256(evidence.snapshot)) throw new Error("Invalid or changed official fact snapshot");
    }
    for (const fact of product.factEvidence) {
      if (!object(fact) || typeof fact.path !== "string" || typeof fact.locator !== "string"
        || !product.evidence.some(e => object(e) && e.url === fact.url)) throw new Error("Public fact lacks independent provider evidence");
    }
    const factEvidence = product.factEvidence;
    if (Object.keys(product.facts).some(key => !factEvidence.some(x => object(x) && x.path === key))) throw new Error("Public fact block has no evidence");
    if (product.identityScope === "versioned_product" && !product.version) throw new Error("Versioned product needs an official version");
    seen.add(product.canonicalProductId);
  }
  return value as unknown as PublicProductCatalog;
}

let bundled: PublicProductCatalog | undefined;
function bundledPath(): URL {
  const compiled = new URL("./fixtures/public-products-v2.json", import.meta.url);
  return existsSync(compiled) ? compiled : new URL("../../src/experiments/fixtures/public-products-v2.json", import.meta.url);
}
export function loadBundledPublicProducts(): PublicProductCatalog {
  return bundled ??= validatePublicProductCatalog(JSON.parse(readFileSync(bundledPath(), "utf8")));
}
export function publicProductCatalogSha256(catalog = loadBundledPublicProducts()): string { return publicFactSnapshotSha256(catalog); }

const token = (value: string | undefined) => value?.normalize("NFKC").trim().toLowerCase();
const versionToken = (value: string | undefined) => value && !/^(?:unresolved|unknown|not reported)$/i.test(value.trim())
  ? token(value)?.replace(/^v(?:ersion)?\s*/, "") : undefined;
/** No paper-suffix stripping, fuzzy matching, URL guessing or version/region collapsing. */
export function resolveCanonicalProduct(candidate: PublicProductCandidate,
  catalog = loadBundledPublicProducts()): CanonicalProductResolution {
  const direct = catalog.products.filter(p => p.canonicalProductId === candidate.datasetId);
  const identifiers = [token(candidate.datasetId), token(candidate.productId)].filter((x): x is string => !!x);
  const urls = (candidate.sourceUrls ?? []).map(publicEvidenceUrl).filter((x): x is string => !!x);
  let products = direct.length ? direct : catalog.products.filter(p =>
    [p.productId, ...p.identifiers].some(id => identifiers.includes(token(id)!))
    || p.sourceUrls.some(url => urls.includes(url)));
  if (!products.length) return { status: "unresolved", canonicalProductId: null, candidateProductIds: [], evidenceUrls: [], reason: "no_exact_official_identity_evidence" };
  const version = versionToken(candidate.version), region = token(candidate.region);
  const explicitlyIncompatible = products.filter(p => (version && version !== versionToken(p.version ?? undefined))
    || (region && region !== token(p.region)) || (candidate.variant && token(candidate.variant) !== token(p.variant)));
  products = products.filter(p => !explicitlyIncompatible.includes(p));
  if (!products.length) return { status: "unresolved", canonicalProductId: null,
    candidateProductIds: explicitlyIncompatible.map(p => p.canonicalProductId).sort(), evidenceUrls: [], reason: "version_or_region_conflict" };
  const ids = products.map(p => p.canonicalProductId).sort();
  if (products.length > 1) return { status: "ambiguous", canonicalProductId: null, candidateProductIds: ids,
    evidenceUrls: [], reason: "multiple_official_products_or_versions" };
  const p = products[0]!;
  if (p.identityScope === "unversioned_service") return { status: "unresolved", canonicalProductId: null,
    candidateProductIds: ids, evidenceUrls: p.evidence.map(e => e.url), reason: "data_release_unverified_for_service" };
  // A canonical ID or official service identifier is intrinsically scoped. A broad product/family
  // label with no explicit release cannot silently acquire the current version from a landing page.
  const scopedIdentifier = direct.length > 0 || p.identifiers.some(id => token(id) === token(candidate.datasetId));
  if (!scopedIdentifier && p.variant && token(candidate.variant) !== token(p.variant)) return {
    status: "unresolved", canonicalProductId: null, candidateProductIds: ids, evidenceUrls: p.evidence.map(e => e.url),
    reason: "processing_variant_not_identified" };
  if (!scopedIdentifier && (p.identityScope !== "versioned_product" || !version || !region)) return {
    status: "unresolved", canonicalProductId: null, candidateProductIds: ids, evidenceUrls: p.evidence.map(e => e.url),
    reason: "explicit_version_and_region_required" };
  return { status: "matched", canonicalProductId: p.canonicalProductId, candidateProductIds: ids,
    evidenceUrls: [...new Set(p.evidence.map(e => e.url))].sort(), reason: "exact_official_identity_version_region" };
}

function sourceUrls(payload: Record<string, unknown>): string[] {
  return [...(Array.isArray(payload.sources) ? payload.sources : []), ...(Array.isArray(payload.access) ? payload.access : []),
    ...(Array.isArray(payload.fields) ? payload.fields : [])].flatMap(row => object(row)
      ? [publicEvidenceUrl(row.url ?? row.source_url ?? row.source_id)].filter((x): x is string => !!x) : []);
}
function candidateFromDocument(document: RagDocument): PublicProductCandidate {
  const p = document.payload, coverage = object(p.coverage) ? p.coverage : {};
  return { datasetId: document.id, productId: typeof p.product_id === "string" ? p.product_id : undefined,
    version: typeof p.version === "string" ? p.version : undefined,
    variant: typeof p.processing_variant === "string" ? p.processing_variant : undefined,
    region: typeof p.identity_region === "string" ? p.identity_region : typeof coverage.spatial === "string" ? coverage.spatial : undefined, sourceUrls: sourceUrls(p) };
}
export function publicCatalogProjectionStats(): PublicCatalogProjectionStats {
  return { version: PUBLIC_PRODUCT_CATALOG_VERSION, dataset_cards: 0, verified_fact_cards: 0, identity_only_cards: 0,
    retained_verified_fields: 0, withheld_source_fields: 0 };
}

/** Only registry facts enter top-level capabilities; one source URL never endorses other source-card facts. */
export function projectStage3PublicDatasetCatalog<T extends RagDocument>(document: T,
  stats?: PublicCatalogProjectionStats, catalog = loadBundledPublicProducts()): T {
  if (document.cardType !== "dataset") return document;
  const original = document.payload, resolution = resolveCanonicalProduct(candidateFromDocument(document), catalog);
  const previous = object(original.catalog_projection) && original.catalog_projection.version === PUBLIC_PRODUCT_CATALOG_VERSION
    ? original.catalog_projection : {};
  const sourceFieldCount = typeof previous.withheld_source_field_count === "number" ? previous.withheld_source_field_count
    : Array.isArray(original.fields) ? original.fields.length : 0;
  const verified = resolution.status === "matched" ? catalog.products.find(p => p.canonicalProductId === resolution.canonicalProductId)
    : catalog.products.find(p => p.canonicalProductId === document.id);
  const payload: Record<string, unknown> = { dataset_id: original.dataset_id ?? document.id };
  // These are catalogue identity claims, not claims of verified capabilities or equivalence.
  for (const key of ["schema_version", "name", "product_id", "aliases"] as const) {
    const safeIdentity = (value: unknown): unknown => typeof value === "string"
      ? /(?:\bpaper[_\s-]?\d+\b|\b(?:used|combined|jointly|training|testing)\b|usage_bundle|workflow_dag)/i.test(value) ? undefined : value
      : Array.isArray(value) ? value.map(safeIdentity).filter(v => v !== undefined) : undefined;
    const value = safeIdentity(original[key]); if (value !== undefined) payload[key] = value;
  }
  const pointers = [...new Set(sourceUrls(original))].sort();
  if (verified) {
    Object.assign(payload, structuredClone(verified.facts), { name: verified.name, provider: verified.provider,
      product_id: verified.productId, version: verified.version,
      canonical_product_id: resolution.canonicalProductId, public_catalog_record_id: verified.canonicalProductId,
      identity_region: verified.region, ...(verified.variant ? { processing_variant: verified.variant } : {}),
      public_fact_evidence: structuredClone(verified.factEvidence) });
  }
  payload.sources = verified ? verified.evidence.map(e => ({ url: e.url, snapshot_sha256: e.snapshotSha256 })) : [];
  payload.access = [...new Set([...(verified?.sourceUrls ?? []), ...pointers])].map(url => ({ url, type: "public_metadata_pointer" }));
  payload.catalog_projection = { version: PUBLIC_PRODUCT_CATALOG_VERSION,
    source_evidence: verified ? "verified_official_facts" : "identity_only",
    canonical_resolution: resolution, withheld_source_field_count: sourceFieldCount,
    official_pointer_count: typeof previous.official_pointer_count === "number" ? previous.official_pointer_count : pointers.length,
    official_endpoint_availability: null,
    withheld: "Paper text, roles, study subsets, workflow relations and unverified field values are unavailable. Public pointers alone are not fact verification." };
  if (stats) {
    stats.dataset_cards++; stats.verified_fact_cards += Number(!!verified); stats.identity_only_cards += Number(!verified);
    stats.retained_verified_fields += Array.isArray(payload.fields) ? payload.fields.length : 0;
    stats.withheld_source_fields += sourceFieldCount;
  }
  return { ...document, payload, title: String(payload.name ?? payload.dataset_id),
    sourceIds: [String(payload.dataset_id), ...(verified ? resolution.evidenceUrls : [])],
    content: renderRagContent("dataset", payload) };
}

/** Public directory entries are common inputs in A0/A1/A2, never benchmark-specific answers. */
export function bundledPublicProductDocuments(catalog = loadBundledPublicProducts()): RagDocument[] {
  return catalog.products.map(product => {
    const document: RagDocument = { id: product.canonicalProductId, cardType: "dataset", title: product.name,
      sourceIds: [], sourcePath: "bundled-public-products-v2", sourceHash: publicProductCatalogSha256(catalog), content: "",
      payload: { dataset_id: product.canonicalProductId, product_id: product.productId, name: product.name,
        version: product.version, ...(product.variant ? { processing_variant: product.variant } : {}),
        coverage: { spatial: product.region } } };
    return projectStage3PublicDatasetCatalog(document, undefined, catalog);
  });
}

/** Separate source absence, projection withholding and unavailable verification; no guessed endpoint outage. */
export function diagnoseDatasetPublicFacts(document: RagDocument): Record<string, unknown> {
  const p = document.payload, fields = Array.isArray(p.fields) ? p.fields : [], pointers = sourceUrls(p);
  const fieldPointers = fields.filter(f => object(f) && !!publicEvidenceUrl(f.source_url));
  return { dataset_id: document.id, source_field_count: fields.length, source_fields_missing: fields.length === 0,
    official_field_pointer_count: fieldPointers.length, official_pointer_count: pointers.length,
    verification_status: resolveCanonicalProduct(candidateFromDocument(document)).status,
    official_endpoint_availability: null,
    reason: fields.length === 0 ? "source_fields_missing" : fieldPointers.length ? "field_pointers_need_product_scoped_verification"
      : pointers.length ? "access_pointer_does_not_verify_field_values" : "paper_only_fields_without_official_evidence" };
}
