import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { mkdtemp, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createHash } from "node:crypto";
import { acquireDatasets, alignDatasets, checkCompatibility, normalizeLongitude, parseErddapMetadata, validateDatasetBbox, validateTable, type DatasetMetadata, type DatasetRequest, type VerifiedDataset } from "./acquire.js";
import { DataAccessError, safeFetch } from "./safe-http.js";
vi.mock("./safe-http.js",async()=>({...await vi.importActual<typeof import("./safe-http.js")>("./safe-http.js"),safeFetch:vi.fn()}));
const request:DatasetRequest={datasetId:"fixture",urls:["https://coastwatch.pfeg.noaa.gov/erddap/griddap/fixture"],variables:["sst"],timeStart:"2022-05-01T00:00:00Z",timeEnd:"2022-05-02T23:59:59Z",bbox:[-124,35,-122,37]};
const meta:DatasetMetadata={title:"test",attrs:{},dimensions:[
  {name:"time",count:2,range:[1651406400,1651492800],units:"seconds since 1970-01-01T00:00:00Z",attrs:{standard_name:"time"},spacing:86400},
  {name:"latitude",count:2,range:[35.125,35.375],units:"degrees_north",attrs:{standard_name:"latitude"},spacing:.25},
  {name:"longitude",count:2,range:[236.875,237.125],units:"degrees_east",attrs:{standard_name:"longitude"},spacing:.25},
],variables:[{name:"sst",dimensions:["time","latitude","longitude"],units:"K",attrs:{standard_name:"sea_surface_temperature",_FillValue:"-999"}}]};
const table={columnNames:["time","latitude","longitude","sst"],columnUnits:["UTC","degrees_north","degrees_east","K"],rows:[["2022-05-01T12:00:00Z",35.125,236.875,290],["2022-05-02T12:00:00Z",35.375,237.125,-999]]};
let dir:string;
beforeEach(async()=>{dir=await mkdtemp(join(tmpdir(),"ocean-access-test-"));vi.mocked(safeFetch).mockReset();});
afterEach(async()=>{await rm(dir,{recursive:true,force:true});});
function erddapMeta(){const rows:unknown[][]=[];for(const d of meta.dimensions){rows.push(["dimension",d.name,"","double",`nValues=${d.count}`],["attribute",d.name,"actual_range","double",d.range.join(",")],["attribute",d.name,"units","String",d.units]);}for(const v of meta.variables){rows.push(["variable",v.name,"","float",v.dimensions.join(", ")],["attribute",v.name,"units","String",v.units],["attribute",v.name,"_FillValue","float",v.attrs._FillValue]);}return {table:{rows}};}
describe("bounded data acquisition",()=>{
  it("keeps exact four-number bbox semantics, including explicitly crossing the dateline",()=>{
    expect(()=>validateDatasetBbox(request.bbox)).not.toThrow();
    expect(()=>validateDatasetBbox([170,-10,-170,10])).not.toThrow();
  });
  it("rejects malformed bbox lengths, numeric types and coordinate bounds before network access",async()=>{
    const invalid:unknown[]=[[-124,35,-122],[-124,35,-122,37,0],[-124,"35",-122,37],[-124,null,-122,37],[-124,true,-122,37],[-124,NaN,-122,37],[-124,Infinity,-122,37],new Array(4),null,{0:-124,1:35,2:-122,3:37,length:4},[-181,35,-122,37],[-124,-91,-122,37],[-124,38,-122,37]];
    for(const bbox of invalid) await expect(acquireDatasets([{...request,bbox:bbox as DatasetRequest["bbox"]}],{cacheDir:dir})).rejects.toMatchObject({code:"INVALID_REQUEST"});
    expect(safeFetch).not.toHaveBeenCalled();
  });
  it("inspects metadata and normalizes physical units, missing values and 0–360 longitude",()=>{
    const parsed=parseErddapMetadata(erddapMeta());expect(parsed.variables[0]?.name).toBe("sst");
    const result=validateTable(table,meta,request);expect(result.table.rows[0]?.[2]).toBe(-123.125);expect(result.table.rows[0]?.[3]).toBeCloseTo(16.85);expect(result.table.rows[1]?.[3]).toBeNull();expect(result.validation.validSamples.sst).toBe(1);expect(result.validation.jointValidSamples).toBe(1);expect(result.validation.units.sst).toBe("degree_C");expect(normalizeLongitude(360)).toBe(0);
  });
  it("preserves valid physical zeros when missing_value is absent",()=>{
    const zero={...table,rows:[["2022-05-01T12:00:00Z",35.125,236.875,0]]};const m={...meta,variables:[{...meta.variables[0]!,units:"m s-1",attrs:{}}]};zero.columnUnits=["UTC","degrees_north","degrees_east","m s-1"];expect(validateTable(zero,m,request).validation.validSamples.sst).toBe(1);
  });
  it("rejects variables that have no valid joint observations",()=>{
    const r={...request,variables:["sst","wind"]};const m={...meta,variables:[...meta.variables,{name:"wind",dimensions:["time","latitude","longitude"],units:"m s-1",attrs:{}}]};
    expect(()=>validateTable({...table,columnNames:[...table.columnNames,"wind"],columnUnits:[...table.columnUnits,"m s-1"],rows:table.rows.map((r,i)=>[...r,i===0?null:2])},m,r)).toThrow(/共同有效样本/);
  });
  it("reads metadata then pilot then bounded slices and validates cache without network",async()=>{
    const calls:string[]=[];
    vi.mocked(safeFetch).mockImplementation(async(url,opts)=>{
      calls.push(url);const data=url.includes("/info/")?erddapMeta():/\.json\?time\[/.test(url)?{table:{columnNames:["time"],columnUnits:["UTC"],rows:[["2022-05-01T12:00:00Z"],["2022-05-02T12:00:00Z"]]}}:{table};const body=Buffer.from(JSON.stringify(data));opts.budget.used+=body.length;return {status:200,url,contentType:"application/json",body,bytes:body.length,headers:{}};
    });
    const source={...request,stride:2,urls:["https://www.ncei.noaa.gov/product-description",...request.urls]};
    const budget={used:0,limit:1024*1024};const result=await acquireDatasets([source],{cacheDir:dir,budget});
    expect(calls[0]).toContain("/info/");expect(calls.length).toBe(4);expect(calls[3]).toContain("sst[(2022-05-01T12:00:00.000Z):1:(2022-05-02T12:00:00.000Z)]");expect(result.datasets[0]?.cacheHit).toBe(false);expect(budget.used).toBeGreaterThan(0);
    expect(calls.some(url=>url.includes("product-description"))).toBe(false);
    const count=calls.length;const cached=await acquireDatasets([source],{cacheDir:dir,budget});expect(calls.length).toBe(count);expect(cached.datasets[0]?.cacheHit).toBe(true);expect(cached.downloadedBytes).toBe(0);
  });
  it("discovers an official product-page alternative after known services fail",async()=>{
    const calls:string[]=[],page="https://www.ncei.noaa.gov/product-description";
    vi.mocked(safeFetch).mockImplementation(async(url,opts)=>{
      calls.push(url);
      if(url.includes("/info/fixture/")) throw new DataAccessError("NOT_FOUND","HTTP 404");
      const data=url===page?'<a href="https://coastwatch.pfeg.noaa.gov/erddap/griddap/backup">official alternate</a>':url.includes("/info/")?erddapMeta():/\.json\?time\[/.test(url)?{table:{columnNames:["time"],columnUnits:["UTC"],rows:[["2022-05-01T12:00:00Z"],["2022-05-02T12:00:00Z"]]}}:{table};
      const body=Buffer.from(typeof data==="string"?data:JSON.stringify(data));opts.budget.used+=body.length;
      return {status:200,url,contentType:url===page?"text/html":"application/json",body,bytes:body.length,headers:{}};
    });
    const result=await acquireDatasets([{...request,urls:[page,...request.urls]}],{cacheDir:dir});
    expect(calls.slice(0,2).every(url=>url.includes("/info/fixture/"))).toBe(true);
    expect(calls[2]).toBe(page);
    expect(calls[3]).toContain("/info/backup/");
    expect(result.datasets[0]?.sourceUrl).toContain("/griddap/backup");
  });
  it("constrains OPeNDAP science arrays using inspected DDS/DAS and actual axes",async()=>{
    const dds="Dataset {\nGrid { ARRAY: Float32 sst[time = 2][latitude = 2][longitude = 2]; MAPS: Float64 time[time = 2]; Float32 latitude[latitude = 2]; Float32 longitude[longitude = 2]; } sst; } fixture;";
    const das='Attributes {\ntime { String units "seconds since 1970-01-01T00:00:00Z"; String standard_name "time"; }\nlatitude { String units "degrees_north"; }\nlongitude { String units "degrees_east"; }\nsst { String units "K"; Float32 _FillValue -999; }\n}';
    const calls:string[]=[];
    vi.mocked(safeFetch).mockImplementation(async(url,opts)=>{
      calls.push(url);const text=url.endsWith(".dds")?dds:url.endsWith(".das")?das:url.includes("?time[")?"time, 1651406400, 1651492800":url.includes("?latitude[")?"latitude, 35.125, 35.375":url.includes("?longitude[")?"longitude, 236.875, 237.125":"sst.sst[0][0][0], 290, 291\nsst.sst[0][1][0], 292, 293\nsst.sst[1][0][0], 294, 295\nsst.sst[1][1][0], 296, 297";const body=Buffer.from(text);opts.budget.used+=body.length;return {status:200,url,contentType:"text/plain",body,bytes:body.length,headers:{}};
    });
    const result=await acquireDatasets([{...request,urls:["https://thredds.jpl.nasa.gov/dodsC/fixture"]}],{cacheDir:dir});
    expect(calls[0]).toMatch(/\.dds$/);expect(calls[1]).toMatch(/\.das$/);expect(calls.at(-1)).toContain(".ascii?sst[0:1:1][0:1:1][0:1:1]");expect(result.datasets[0]?.protocol).toBe("opendap");expect(result.datasets[0]?.validation.validSamples.sst).toBe(8);
  });
  it("requests authentication only when every inspected product page proves it is required",async()=>{
    vi.mocked(safeFetch).mockRejectedValue(new DataAccessError("AUTH_REQUIRED","Official login required",true));
    await expect(acquireDatasets([{...request,urls:["https://www.ncei.noaa.gov/product-a","https://www.ncei.noaa.gov/product-b"]}],{cacheDir:dir})).rejects.toMatchObject({code:"AUTH_REQUIRED",requiresAuthentication:true,datasetId:"fixture"});
    vi.mocked(safeFetch).mockRejectedValue(new DataAccessError("ACCESS_DENIED","HTTP 403"));
    await expect(acquireDatasets([{...request,urls:["https://www.ncei.noaa.gov/product-a"]}],{cacheDir:dir})).rejects.toMatchObject({code:"NO_ACCESS_ENDPOINT",requiresAuthentication:false});
    vi.mocked(safeFetch).mockImplementation(async(url)=>{if(url.endsWith("product-a"))throw new DataAccessError("AUTH_REQUIRED","Login",true);const body=Buffer.from("<html>public description without data links</html>");return {status:200,url,contentType:"text/html",body,bytes:body.length,headers:{}};});
    await expect(acquireDatasets([{...request,urls:["https://www.ncei.noaa.gov/product-a","https://www.ncei.noaa.gov/product-b"]}],{cacheDir:dir})).rejects.toMatchObject({code:"NO_ACCESS_ENDPOINT",requiresAuthentication:false});
  });
  it("creates a real nearest-neighbour collocation artifact for shifted native grids",async()=>{
    const one=validateTable({...table,rows:[table.rows[0]!] },meta,request);const body=Buffer.from(JSON.stringify({table:one.table}));const path=join(dir,"one.json");const {writeFile}=await import("node:fs/promises");await writeFile(path,body);
    const first:VerifiedDataset={datasetId:"sst",path,sha256:createHash("sha256").update(body).digest("hex"),bytes:body.length,sourceUrl:request.urls[0]!,protocol:"griddap",variables:["sst"],metadata:meta,validation:one.validation,transformations:one.transformations,cacheHit:false};
    const secondTable={...one.table,rows:[["2022-05-01T12:00:00.000Z",35.25,-123,5]]};const body2=Buffer.from(JSON.stringify({table:secondTable}));const path2=join(dir,"two.json");await writeFile(path2,body2);
    const second={...first,datasetId:"wind",path:path2,sha256:createHash("sha256").update(body2).digest("hex"),validation:{...one.validation,bbox:[-123,35.25,-123,35.25] as [number,number,number,number]}};
    // Actual observed bounding boxes must overlap; single-point boxes correctly fail before collocation.
    expect(()=>checkCompatibility([first,second])).toThrow(/经纬度覆盖/);
    second.validation.bbox=[-124,35,-122,37];first.validation.bbox=[-124,35,-122,37];
    const aligned=await alignDatasets([first,second],dir);const artifact=JSON.parse(await readFile(aligned.path,"utf8"));expect(artifact.table.rows).toHaveLength(1);expect(artifact.metrics.offsets[1].max_longitude_offset_degrees).toBe(.125);expect(artifact.method).toBe("nearest_time_and_space_no_extrapolation");
  });
});
