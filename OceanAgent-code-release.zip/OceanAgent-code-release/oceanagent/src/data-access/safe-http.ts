/** Bounded public-data transport. DNS results are checked and pinned for each redirect. */
import { lookup } from "node:dns/promises";
import https from "node:https";
import { isIP } from "node:net";

export class DataAccessError extends Error {
  readonly requiresAuthentication: boolean;
  datasetId?: string;
  partialDatasets?: unknown[];
  causes?: Array<{code:string;url:string;message:string}>;
  constructor(readonly code: string, message: string, auth = false) {
    super(message); this.name = "DataAccessError"; this.requiresAuthentication = auth;
  }
}
export interface ByteBudget { used: number; limit: number }
export interface HttpResult { status: number; url: string; contentType: string; body: Buffer; bytes: number; headers: Record<string, string | string[] | undefined> }
export type DataEvent = (event: string, context: Record<string, unknown>) => void;
export interface HttpOptions { maxBytes: number; budget: ByteBudget; signal?: AbortSignal; timeoutMs?: number; retries?: number; onEvent?: DataEvent; datasetId?: string; method?: "GET" | "HEAD"; preview?: boolean }
const suffixes = ["noaa.gov", "nasa.gov", "usgs.gov", "nsidc.org", "marine.copernicus.eu", "cmems-du.eu", "metoffice.gov.uk", "data.marine.copernicus.eu", "ecmwf.int", "pangaea.de", "bodc.ac.uk", "aviso.altimetry.fr", "ifremer.fr", "data.gov.au", "nci.org.au", "aodn.org.au"];
// Additional exact hostnames are an operator setting; URLs/tool arguments cannot expand this policy.
const operatorHosts = (process.env.OCEAN_DATA_ALLOWED_HOSTS ?? "").split(",").map(s => s.trim().toLowerCase()).filter(Boolean);
export const allowedDataDomains = [...suffixes, ...operatorHosts];
export function redactDataUrl(value: string): string {
  try {
    const u = new URL(value); u.username = ""; u.password = "";
    for (const k of [...u.searchParams.keys()]) if (/token|secret|pass|api.?key|signature|credential|authorization|auth|session|access.?key/i.test(k)) u.searchParams.set(k, "REDACTED");
    return u.toString();
  } catch { return "invalid URL"; }
}
export function approvedDataUrl(value: string): URL {
  let u: URL; try { u = new URL(value); } catch { throw new DataAccessError("UNSAFE_URL", "数据入口不是有效 URL"); }
  const h = u.hostname.toLowerCase();
  if (u.protocol !== "https:" || u.username || u.password || (u.port && u.port !== "443") || isIP(h.replace(/^\[|\]$/g, "")) || ![...suffixes].some(s => h === s || h.endsWith(`.${s}`)) && !operatorHosts.includes(h)) {
    throw new DataAccessError("UNSAFE_URL", "数据入口必须是受控官方域名的 HTTPS URL（不接受凭据、IP 或非标准端口）；可由部署者配置 OCEAN_DATA_ALLOWED_HOSTS");
  }
  // Signed/access credentials are never sent or persisted by this public-data tool.
  for (const key of [...u.searchParams.keys()]) if (/token|secret|password|api.?key|signature|credential|authorization|auth|session|access.?key/i.test(key) || /^(key|username|user|passwd)$/i.test(key)) throw new DataAccessError("AUTH_REQUIRED", "此入口带认证参数，需要授权的独立认证流程", true);
  u.hash = ""; return u;
}
export function isPublicAddress(address: string): boolean {
  if (isIP(address) === 4) {
    const a = address.split(".").map(Number); const x = a[0]!, y = a[1]!;
    return !(x === 0 || x === 10 || x === 127 || x >= 224 || x === 169 && y === 254 || x === 172 && y >= 16 && y <= 31 || x === 192 && (y === 168 || y === 0) || x === 100 && y >= 64 && y <= 127 || x === 198 && (y === 18 || y === 19) || x === 192 && y === 0 || x === 198 && y === 51 || x === 203 && y === 0);
  }
  if (isIP(address) === 6) {
    const s = address.toLowerCase();
    if (s.startsWith("::ffff:")) return isPublicAddress(s.slice(7));
    // Accept only global unicast 2000::/3; excludes loopback, link/unique local and mapped forms.
    return /^[23][0-9a-f]{0,3}:/.test(s) && !s.startsWith("2001:db8:") && !s.startsWith("2001:0:");
  }
  return false;
}
async function once(url: URL, options: HttpOptions): Promise<HttpResult> {
  options.signal?.throwIfAborted();
  const addresses = await new Promise<Awaited<ReturnType<typeof lookup>> | Array<{address:string;family:number}>>((resolve,reject) => {
    const timer=setTimeout(()=>reject(new DataAccessError("TIMEOUT", "数据域名解析超时")),options.timeoutMs??30_000);
    const abort=()=>{clearTimeout(timer);reject(options.signal?.reason??new DataAccessError("CANCELLED","请求已取消"));};
    options.signal?.addEventListener("abort",abort,{once:true});
    lookup(url.hostname,{all:true,verbatim:true}).then(resolve,reject).finally(()=>{clearTimeout(timer);options.signal?.removeEventListener("abort",abort);});
  }) as Array<{address:string;family:number}>;
  if (!addresses.length || addresses.some(a => !isPublicAddress(a.address))) throw new DataAccessError("PRIVATE_NETWORK", "数据域名解析到了非公开网络地址，已拒绝请求");
  const selected = addresses.find(a => a.family === 4) ?? addresses[0]!;
  return new Promise((resolve, reject) => {
    let settled = false, bytes = 0; const chunks: Buffer[] = [];
    const fail = (error: Error) => { if (!settled) { settled = true; reject(error); } };
    const req = https.request(url, {
      method: options.method ?? "GET", signal: options.signal,
      agent: false, family: selected.family,
      headers: { "User-Agent": "OceanAgent/0.1 bounded scientific data acquisition", "Accept-Encoding": "identity" },
      lookup: ((_hostname: string, _opts: unknown, callback: (error: Error | null, address: string, family: number) => void) => callback(null, selected.address, selected.family)) as never,
    }, response => {
      const status = response.statusCode ?? 0;
      const result = () => ({ status, url: redactDataUrl(url.toString()), contentType: String(response.headers["content-type"] ?? ""), body: Buffer.concat(chunks), bytes, headers: response.headers });
      if ([301, 302, 303, 307, 308].includes(status) || options.method === "HEAD") {
        if (!settled) { settled = true; resolve(result()); } response.destroy(); return;
      }
      const length = Number(response.headers["content-length"]);
      if (!options.preview && Number.isFinite(length) && (length > options.maxBytes || length > options.budget.limit - options.budget.used)) {
        fail(new DataAccessError("SIZE_LIMIT", "服务端文件大小超过本次受控下载预算")); response.destroy(); return;
      }
      response.on("data", (chunk: Buffer) => {
        bytes += chunk.length; options.budget.used += chunk.length;
        if (options.budget.used > options.budget.limit) { fail(new DataAccessError("TOTAL_BYTE_LIMIT", "本次运行总下载预算已耗尽")); response.destroy(); return; }
        if (bytes > options.maxBytes) {
          if (options.preview) {
            const remaining = Math.max(0, options.maxBytes - (bytes - chunk.length)); if (remaining) chunks.push(chunk.subarray(0, remaining));
            // destroy() may synchronously emit aborted on Node. Settle the
            // intentional preview before closing, retaining the actual byte count.
            if (!settled) { settled = true; resolve(result()); } response.destroy();
          } else { fail(new DataAccessError("SIZE_LIMIT", "响应超过单文件大小限制，已中止并清理")); response.destroy(); }
          return;
        }
        chunks.push(chunk);
      });
      response.on("end", () => { if (!settled) { settled = true; resolve(result()); } });
      response.on("error", fail);
      response.on("aborted", () => fail(new DataAccessError("INCOMPLETE_RESPONSE", "HTTP 响应不完整")));
    });
    const timer = setTimeout(() => req.destroy(new DataAccessError("TIMEOUT", "数据请求超时")), options.timeoutMs ?? 30_000);
    req.on("close", () => clearTimeout(timer)); req.on("error", fail); req.end();
  });
}
export async function safeFetch(value: string, options: HttpOptions): Promise<HttpResult> {
  if(!Number.isFinite(options.maxBytes)||options.maxBytes<0||options.maxBytes>16*1024*1024)throw new DataAccessError("INVALID_BUDGET","HTTP 单请求预算必须有限且不超过 16 MiB");
  if(!Number.isFinite(options.budget.limit)||options.budget.used>=options.budget.limit)throw new DataAccessError("TOTAL_BYTE_LIMIT","本次运行总下载预算已耗尽");
  const retries = Math.min(2, Math.max(0, options.retries ?? 1));
  for (let retry = 0; ; retry++) {
    let u = approvedDataUrl(value); const started = performance.now();
    try {
      for (let redirects = 0; redirects <= 4; redirects++) {
        options.signal?.throwIfAborted();
        options.onEvent?.("download_attempt", { dataset_id: options.datasetId, url: redactDataUrl(u.toString()), retry_count: retry, redirect_count: redirects, status: "started" });
        const result = await once(u, options);
        options.onEvent?.("download_attempt", { dataset_id: options.datasetId, url: result.url, retry_count: retry, http_status: result.status, downloaded_bytes: result.bytes, downloaded_bytes_total: options.budget.used, duration_ms: performance.now() - started, status: "response" });
        if ([301, 302, 303, 307, 308].includes(result.status)) {
          const location = result.headers.location; if (!location || Array.isArray(location)) throw new DataAccessError("REDIRECT_ERROR", "入口跳转缺少有效目标");
          const next = new URL(location, u);
          if (/urs\.earthdata\.nasa\.gov|(?:^|\/)oauth|(?:^|\/)login|(?:^|\/)signin/i.test(next.toString())) throw new DataAccessError("AUTH_REQUIRED", "官方入口要求登录授权", true);
          u = approvedDataUrl(next.toString()); continue;
        }
        if (result.status === 401) throw new DataAccessError("AUTH_REQUIRED", "官方入口返回 HTTP 401，需要用户认证", true);
        if (result.status < 200 || result.status >= 300) {
          const e = new DataAccessError(result.status === 403 ? "ACCESS_DENIED" : result.status === 404 ? "NOT_FOUND" : "HTTP_ERROR", `官方入口 HTTP ${result.status}`);
          if ((result.status === 429 || result.status >= 500) && retry < retries) throw e;
          throw Object.assign(e, { noRetry: true });
        }
        return result;
      }
      throw new DataAccessError("REDIRECT_LIMIT", "官方入口跳转超过 4 次");
    } catch (error) {
      const e = error as Error & { code?: string; noRetry?: boolean };
      options.onEvent?.("download_attempt", { dataset_id: options.datasetId, url: redactDataUrl(u.toString()), retry_count: retry, downloaded_bytes_total: options.budget.used, duration_ms: performance.now() - started, error_type: e.code ?? e.name, status: "failed" });
      if (options.signal?.aborted || retry >= retries || e.noRetry || e instanceof DataAccessError && !["HTTP_ERROR", "TIMEOUT", "INCOMPLETE_RESPONSE"].includes(e.code)) throw error;
      await new Promise<void>((resolve, reject) => { const timer = setTimeout(resolve, 250 * (retry + 1)); options.signal?.addEventListener("abort", () => { clearTimeout(timer); reject(options.signal?.reason); }, { once: true }); });
    }
  }
}
export async function safeProbe(value: string, signal?: AbortSignal): Promise<{status:number;url:string;contentType:string;preview:string}> {
  const r = await safeFetch(value, { maxBytes: 4096, budget: { used: 0, limit: 128 * 1024 }, signal, timeoutMs: 15_000, retries: 0, preview: true });
  return { status: r.status, url: r.url, contentType: r.contentType, preview: r.body.toString("utf8") };
}
