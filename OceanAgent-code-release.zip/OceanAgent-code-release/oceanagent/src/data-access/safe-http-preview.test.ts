import { EventEmitter } from "node:events";
import https from "node:https";
import { afterEach, describe, expect, it, vi } from "vitest";
vi.mock("node:dns/promises", () => ({ lookup: vi.fn(async () => [{ address: "140.90.1.1", family: 4 }]) }));
import { safeFetch } from "./safe-http.js";

afterEach(() => vi.restoreAllMocks());
function transport(abortEarly = false) {
  vi.spyOn(https, "request").mockImplementation(((_url: unknown, _options: unknown, connected: (r: any) => void) => {
    const request = new EventEmitter() as any;
    request.end = () => queueMicrotask(() => {
      const response = new EventEmitter() as any;
      response.statusCode = 200; response.headers = { "content-type": "text/html" };
      response.destroy = () => { response.emit("aborted"); request.emit("close"); };
      connected(response);
      if (abortEarly) response.emit("aborted");
      else { response.emit("data", Buffer.from("0123456789")); response.emit("end"); }
      request.emit("close");
    });
    request.destroy = (error: Error) => { request.emit("error", error); request.emit("close"); };
    return request;
  }) as never);
}
const url = "https://psl.noaa.gov/public-metadata";
describe("bounded HTTP intentional truncation", () => {
  it("accepts a preview before synchronous aborted and accounts actual received bytes", async () => {
    transport(); const budget = { used: 0, limit: 100 };
    const response = await safeFetch(url, { maxBytes: 4, budget, preview: true, retries: 0 });
    expect(response.body.toString()).toBe("0123"); expect(response.bytes).toBe(10); expect(budget.used).toBe(10);
  });
  it("retains the precise size/total-byte error when deliberately closing a response", async () => {
    transport();
    await expect(safeFetch(url, { maxBytes: 4, budget: { used: 0, limit: 100 }, retries: 0 })).rejects.toMatchObject({ code: "SIZE_LIMIT" });
    await expect(safeFetch(url, { maxBytes: 16, budget: { used: 0, limit: 5 }, retries: 0 })).rejects.toMatchObject({ code: "TOTAL_BYTE_LIMIT" });
  });
  it("still rejects an unexpectedly aborted response", async () => {
    transport(true);
    await expect(safeFetch(url, { maxBytes: 4, budget: { used: 0, limit: 100 }, preview: true, retries: 0 })).rejects.toMatchObject({ code: "INCOMPLETE_RESPONSE" });
  });
});
