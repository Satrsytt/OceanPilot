import { describe, expect, it } from "vitest";
import { approvedDataUrl, isPublicAddress, redactDataUrl } from "./safe-http.js";
describe("public-data transport policy",()=>{
  it("allows official https hosts and denies credentialed or arbitrary URLs",()=>{
    expect(approvedDataUrl("https://coastwatch.pfeg.noaa.gov/erddap/").hostname).toBe("coastwatch.pfeg.noaa.gov");
    for(const url of ["http://coastwatch.noaa.gov/","https://127.0.0.1/","https://evil.noaa.gov.example.org/","https://u:p@coastwatch.noaa.gov/","https://coastwatch.noaa.gov/?auth=secret"] )expect(()=>approvedDataUrl(url)).toThrow();
    expect(redactDataUrl("https://coastwatch.noaa.gov/?token=secret")).not.toContain("secret");
  });
  it("rejects loopback, local, mapped and reserved IPv4/IPv6 DNS answers",()=>{
    for(const ip of ["127.0.0.1","10.0.0.1","172.16.0.1","192.168.1.1","169.254.169.254","100.64.0.1","198.18.0.1","::1","fe80::1","fc00::1","::ffff:127.0.0.1","2001:db8::1"])expect(isPublicAddress(ip),ip).toBe(false);
    expect(isPublicAddress("140.90.1.1")).toBe(true);expect(isPublicAddress("2001:4860:4860::8888")).toBe(true);
  });
});
