/** Public scientific-data acquisition; all network IO uses the bounded pinned transport. */
import { createHash, randomUUID } from "node:crypto";
import { mkdir, readFile, rename, rm, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { fileURLToPath } from "node:url";
import { existsSync } from "node:fs";
import { approvedDataUrl, DataAccessError, redactDataUrl, safeFetch, type ByteBudget, type DataEvent } from "./safe-http.js";
export { DataAccessError } from "./safe-http.js";

export interface DatasetRequest {
  datasetId: string; urls: string[]; variables: string[]; timeStart: string; timeEnd: string;
  /** west,south,east,north in -180..180. west>east explicitly selects the dateline. */
  bbox: [number, number, number, number]; maxBytes?: number; stride?: number;
}
export interface AcquireOptions { cacheDir: string; maxTotalBytes?: number; maxFileBytes?: number; budget?: ByteBudget; timeoutMs?: number; signal?: AbortSignal; onEvent?: DataEvent; pythonPath?: string }
interface Dimension { name: string; count: number; range: [number, number]; units: string; attrs: Record<string, string>; spacing: number }
interface Variable { name: string; dimensions: string[]; units: string; attrs: Record<string, string> }
export interface DatasetMetadata { title: string; dimensions: Dimension[]; variables: Variable[]; attrs: Record<string, string> }
export interface Validation { valid: boolean; rowCount: number; jointValidSamples: number; validSamples: Record<string, number>; missingSamples: Record<string, number>; units: Record<string, string>; timeRange: [string, string]; bbox: [number, number, number, number]; resolution: Record<string, number>; warnings: string[] }
export interface VerifiedDataset {
  datasetId: string; path: string; sha256: string; bytes: number; sourceUrl: string;
  protocol: string; variables: string[]; validation: Validation; metadata: DatasetMetadata;
  transformations: string[]; cacheHit: boolean;
}
export interface AcquisitionResult {
  datasets: VerifiedDataset[]; downloadedBytes: number;
  compatibility: { timeOverlap: [string, string]; bbox: [number, number, number, number]; transformations: string[]; warnings: string[]; alignedPath?: string; method?: string };
}
interface Table { columnNames: string[]; columnTypes?: string[]; columnUnits: string[]; rows: unknown[][] }
interface Endpoint { protocol: "griddap" | "tabledap" | "opendap" | "direct"; base: string; info?: string }
const runFile = promisify(execFile);
const hash = (v: string | Buffer) => createHash("sha256").update(v).digest("hex");
function assert(condition: unknown, code: string, message: string): asserts condition { if (!condition) throw new DataAccessError(code, message); }
const numberList = (s = "") => s.split(",").map(v=>v.trim()).filter(Boolean).map(Number).filter(Number.isFinite);
const axisKind = (d: { name: string; units: string; attrs: Record<string, string> }): string => {
  const n = `${d.name} ${d.attrs.standard_name ?? ""} ${d.attrs.axis ?? ""}`.toLowerCase();
  return /longitude|\blon\b|\bx\b/.test(n) || /degrees_east/.test(d.units) ? "lon"
    : /latitude|\blat\b|\by\b/.test(n) || /degrees_north/.test(d.units) ? "lat"
      : /\btime\b|\bt\b/.test(n) || /since/.test(d.units) ? "time" : "other";
};
export const normalizeLongitude = (v: number) => ((v + 180) % 360 + 360) % 360 - 180;
export function parseErddapMetadata(value: unknown): DatasetMetadata {
  const t = (value as { table?: Table })?.table;
  assert(t && Array.isArray(t.rows), "INVALID_METADATA", "ERDDAP 元数据缺少 table.rows");
  const attrs = new Map<string, Record<string, string>>();
  for (const row of t.rows) if (row[0] === "attribute") {
    const name = String(row[1]); const a = attrs.get(name) ?? {}; a[String(row[2])] = String(row[4]); attrs.set(name, a);
  }
  const dimensions: Dimension[] = [], variables: Variable[] = [];
  for (const row of t.rows) {
    const name = String(row[1]), a = attrs.get(name) ?? {};
    if (row[0] === "dimension") {
      const desc = String(row[4]); const count = Number(/nValues=(\d+)/.exec(desc)?.[1] ?? 0);
      const values = numberList(a.actual_range ?? /onlyValue=([^, ]+)/.exec(desc)?.[1] ?? "");
      assert(count > 0 && values.length > 0, "INVALID_METADATA", `维度 ${name} 缺少范围与样本数`);
      const range: [number, number] = [values[0]!, values.at(-1)!];
      dimensions.push({ name, count, range, attrs: a, units: a.units ?? "", spacing: count > 1 ? Math.abs(range[1] - range[0]) / (count - 1) : 0 });
    } else if (row[0] === "variable") variables.push({ name, dimensions: String(row[4]).split(",").map(s => s.trim()), units: a.units ?? "", attrs: a });
  }
  return { title: attrs.get("NC_GLOBAL")?.title ?? "", dimensions, variables, attrs: attrs.get("NC_GLOBAL") ?? {} };
}
export function identifyEndpoint(value: string): Endpoint {
  const u = approvedDataUrl(value);
  const match = /^(.*\/erddap)\/(griddap|tabledap)\/([^/.?]+)(?:\.[^/]*)?$/.exec(u.pathname);
  if (match) return { protocol: match[2] as "griddap" | "tabledap", base: `${u.origin}${match[1]}/${match[2]}/${match[3]}`, info: `${u.origin}${match[1]}/info/${match[3]}/index.json` };
  const info = /^(.*\/erddap)\/info\/([^/]+)\/index(?:\.[^/]*)?$/.exec(u.pathname);
  if (info) return { protocol: "griddap", base: `${u.origin}${info[1]}/griddap/${info[2]}`, info: `${u.origin}${info[1]}/info/${info[2]}/index.json` };
  if (/\/dodsC\/|\/opendap\//i.test(u.pathname) || /\.(dds|das|dods|ascii)$/.test(u.pathname)) return { protocol: "opendap", base: `${u.origin}${u.pathname.replace(/\.(dds|das|dods|ascii|html)$/i, "")}` };
  return { protocol: "direct", base: u.toString() };
}
/** Keep tuple semantics in the application, independent of provider JSON Schema support/coercion. */
export function validateDatasetBbox(value: unknown): asserts value is DatasetRequest["bbox"] {
  assert(Array.isArray(value) && value.length === 4
    && Array.from(value).every(item => typeof item === "number" && Number.isFinite(item)),
  "INVALID_REQUEST", "bbox 必须按 [west,south,east,north] 提供恰好4个有限数值；不接受字符串、null或布尔值");
  const [west, south, east, north] = value;
  assert(west >= -180 && west <= 180 && east >= -180 && east <= 180
    && south >= -90 && south <= 90 && north >= -90 && north <= 90 && south <= north,
  "INVALID_REQUEST", "bbox 需要有效的 [west,south,east,north] 范围：经度 -180..180、纬度 -90..90、south<=north；west>east 表示跨日期变更线");
}
function validateRequest(r: DatasetRequest): void {
  assert(r.datasetId?.trim() && r.urls.length && r.urls.length <= 12, "INVALID_REQUEST", "需要数据集 ID 和 1–12 个官方候选入口");
  assert(r.variables.length > 0 && r.variables.length <= 12 && r.variables.every(v => /^[A-Za-z_][\w.]*$/.test(v)), "INVALID_REQUEST", "需要明确列出有限的数据变量");
  validateDatasetBbox(r.bbox);
  assert(Number.isFinite(Date.parse(r.timeStart)) && Number.isFinite(Date.parse(r.timeEnd)) && Date.parse(r.timeStart) <= Date.parse(r.timeEnd), "INVALID_REQUEST", "需要明确的有限起止时间");
  assert(r.maxBytes===undefined || Number.isFinite(r.maxBytes)&&r.maxBytes>0,"INVALID_REQUEST","maxBytes 必须是有限正数");
  assert((r.stride ?? 1) >= 1 && Number.isInteger(r.stride ?? 1), "INVALID_REQUEST", "stride 必须是正整数");
}
function normalizeTime(v: unknown, units: string): string {
  let ms: number;
  if (typeof v === "number") {
    const m = /^(seconds?|minutes?|hours?|days?|milliseconds?) since (.+)$/i.exec(units);
    assert(m, "TIME_UNITS", `不支持的数值时间单位 ${units}`);
    const scale = /^milli/i.test(m[1]!) ? 1 : /^sec/i.test(m[1]!) ? 1000 : /^min/i.test(m[1]!) ? 60000 : /^hour/i.test(m[1]!) ? 3600000 : 86400000;
    ms = Date.parse(m[2]!) + v * scale;
  } else ms = Date.parse(String(v));
  assert(Number.isFinite(ms), "INVALID_TIME", "数据包含不可解析的时间坐标"); return new Date(ms).toISOString();
}
function standardUnit(unit: string): { unit: string; convert?: (n: number) => number; note?: string } {
  if (/^(K|kelvin|degree_K|degrees_K)$/i.test(unit)) return { unit: "degree_C", convert: n => n - 273.15, note: "temperature: K → degree_C (subtract 273.15)" };
  if (/^(degree_C|degrees_C|degree_Celsius|degrees_Celsius|celsius|degC|°C)$/i.test(unit)) return { unit: "degree_C" };
  if (/^(m s-1|m s\^-1|m\/s|m s\*\*-1|meter second-1|meters per second)$/i.test(unit)) return { unit: "m s-1" };
  if (/^(cm\/s|cm s-1)$/i.test(unit)) return { unit: "m s-1", convert: n => n / 100, note: "velocity: cm s-1 → m s-1 (divide by 100)" };
  return { unit };
}
function parseTable(body: Buffer): Table {
  let v: { table?: Table }; try { v = JSON.parse(body.toString("utf8")); } catch { throw new DataAccessError("INVALID_DATA", "数据响应不是有效 JSON"); }
  assert(v.table && Array.isArray(v.table.columnNames) && Array.isArray(v.table.rows), "INVALID_DATA", "响应不是 ERDDAP/兼容数据表"); return v.table;
}
export function validateTable(table: Table, meta: DatasetMetadata, request: DatasetRequest): { table: Table; validation: Validation; transformations: string[] } {
  const names = table.columnNames;
  const findAxis = (kind: string) => names.findIndex(name => { const d = meta.dimensions.find(a => a.name === name); return d && axisKind(d) === kind; });
  const ti = findAxis("time"), yi = findAxis("lat"), xi = findAxis("lon");
  assert(ti >= 0 && yi >= 0 && xi >= 0, "MISSING_COORDINATES", "数据表缺少 time/latitude/longitude 坐标");
  const indices = request.variables.map(v => names.indexOf(v));
  assert(indices.every(i => i >= 0), "MISSING_VARIABLE", "下载响应缺少请求变量");
  const units = [...(table.columnUnits ?? [])];
  const transformations = ["time coordinates normalized to ISO 8601 UTC", "longitude normalized to [-180, 180); native grid retained (no interpolation)"];
  const outputUnits: Record<string,string> = {}, valid: Record<string,number> = {}, missing: Record<string,number> = {};
  const converters = request.variables.map((v,i) => {
    const m = meta.variables.find(a => a.name === v); const source = units[indices[i]!] || m?.units || "";
    assert(source, "MISSING_UNITS", `变量 ${v} 缺少单位，不能验证科学语义`);
    const cv = standardUnit(source); outputUnits[v] = cv.unit; units[indices[i]!] = cv.unit;
    if (cv.note) transformations.push(`${v}: ${cv.note}`); valid[v] = 0; missing[v] = 0;
    return { ...cv, fill: numberList(`${m?.attrs._FillValue ?? ""},${m?.attrs.missing_value ?? ""}`) };
  });
  const timeDim = meta.dimensions.find(d => d.name === names[ti]);
  const rows: unknown[][] = []; const seen = new Set<string>();
  const [west,south,east,north] = request.bbox;
  for (const original of table.rows) {
    const row = [...original];
    const time = normalizeTime(row[ti], units[ti] || timeDim?.units || "UTC");
    const lat = Number(row[yi]), rawLon=Number(row[xi]), lon = normalizeLongitude(rawLon);
    assert(Number.isFinite(lat) && Number.isFinite(lon) && lat>=-90 && lat<=90 && rawLon>=-360 && rawLon<=360, "INVALID_COORDINATES", "数据经纬度包含非有限值或超出地理范围");
    // ERDDAP chooses nearest grid values at constraint edges; retain only the requested footprint.
    if (Date.parse(time) < Date.parse(request.timeStart) || Date.parse(time) > Date.parse(request.timeEnd) || lat < south || lat > north || (west <= east ? lon < west || lon > east : lon < west && lon > east)) continue;
    row[ti] = time; row[xi] = lon;
    const key = row.map((v,i) => indices.includes(i) ? "" : String(v)).join("|");
    if (seen.has(key)) continue; seen.add(key);
    for (let i = 0; i < indices.length; i++) {
      const index = indices[i]!, v = request.variables[i]!, cv = converters[i]!;
      const raw = row[index], value = typeof raw === "number" ? raw : Number.NaN;
      if (!Number.isFinite(value) || cv.fill.includes(value)) { row[index] = null; missing[v]!++; }
      else { row[index] = cv.convert ? cv.convert(value) : value; valid[v]!++; }
    }
    rows.push(row);
  }
  assert(rows.length > 0 && request.variables.every(v => valid[v]! > 0), "EMPTY_DATA", "请求范围内缺少有效观测样本（可能为陆地、缺测或时间范围不符）");
  units[ti] = "UTC"; units[xi] = "degrees_east"; units[yi] = "degrees_north";
  const jointRows=rows.filter(row=>indices.every(i=>typeof row[i]==="number"&&Number.isFinite(row[i])));
  assert(jointRows.length>0,"NO_JOINT_SAMPLES","所需变量没有同一时空位置的共同有效样本");
  const times = jointRows.map(r => String(r[ti])).sort();
  const xs = jointRows.map(r => Number(r[xi])), ys = jointRows.map(r => Number(r[yi]));
  const spacing = (values: unknown[]) => { const a = [...new Set(values.map(Number))].sort((a,b) => a-b); let d = Infinity; for(let i=1;i<a.length;i++) d = Math.min(d,a[i]!-a[i-1]!); return Number.isFinite(d) ? d : 0; };
  const resolution = { longitude_degrees: spacing(xs), latitude_degrees: spacing(ys), time_seconds: spacing(times.map(Date.parse)) / 1000 };
  const warnings = request.variables.filter(v => missing[v]! > 0).map(v => `${v}: ${missing[v]} missing values retained as null`);
  return { table: { ...table, columnUnits: units, rows }, transformations, validation: { valid: true, rowCount: rows.length, jointValidSamples:jointRows.length, validSamples: valid, missingSamples: missing, units: outputUnits, timeRange: [times[0]!, times.at(-1)!], bbox: [xs.reduce((a,b)=>Math.min(a,b),Infinity),ys.reduce((a,b)=>Math.min(a,b),Infinity),xs.reduce((a,b)=>Math.max(a,b),-Infinity),ys.reduce((a,b)=>Math.max(a,b),-Infinity)], resolution, warnings } };
}
function longitudeSegments(r: DatasetRequest, d: Dimension): [number,number][] {
  const ranges: [number,number][] = r.bbox[0] <= r.bbox[2] ? [[r.bbox[0],r.bbox[2]]] : [[r.bbox[0],180],[-180,r.bbox[2]]];
  const zero = Math.min(...d.range) >= 0 && Math.max(...d.range) > 180;
  return ranges.flatMap(([w,e]) => {
    if (!zero) return [[w,e] as [number,number]];
    if (w < 0 && e >= 0) return [[w+360,Math.max(...d.range)],[Math.min(...d.range),e]] as [number,number][];
    return [[w < 0 ? w + 360 : w, e < 0 ? e + 360 : e] as [number,number]];
  });
}
function constraint(d: Dimension, low: number | string, high: number | string, stride: number): string {
  const a = typeof low === "number" ? Math.max(Math.min(...d.range), Math.min(Math.max(...d.range), low)) : low;
  const b = typeof high === "number" ? Math.max(Math.min(...d.range), Math.min(Math.max(...d.range), high)) : high;
  if (d.range[0] > d.range[1]) return `[(${b}):${stride}:(${a})]`;
  return `[(${a}):${stride}:(${b})]`;
}
function gridQuery(endpoint: Endpoint, meta: DatasetMetadata, r: DatasetRequest, time: [string,string], lon: [number,number], tiny = false): string {
  const stride = r.stride ?? 1;
  return `${endpoint.base}.json?${r.variables.map(name => {
    const variable = meta.variables.find(v => v.name === name)!;
    const slices = variable.dimensions.map(n => {
      const d = meta.dimensions.find(v => v.name === n); assert(d, "UNKNOWN_DIMENSION", `变量 ${name} 的维度 ${n} 无可验证元数据`);
      const k = axisKind(d);
      if (k === "time") return constraint(d,time[0],tiny ? time[0] : time[1],1);
      if (k === "lat") { const lo=tiny ? (r.bbox[1]+r.bbox[3])/2-Math.max(d.spacing,0.01) : r.bbox[1]; const hi=tiny ? (r.bbox[1]+r.bbox[3])/2+Math.max(d.spacing,0.01) : r.bbox[3]; return constraint(d,lo,hi,tiny ? 1 : stride); }
      if (k === "lon") { const lo=tiny ? (lon[0]+lon[1])/2-Math.max(d.spacing,0.01) : lon[0]; const hi=tiny ? (lon[0]+lon[1])/2+Math.max(d.spacing,0.01) : lon[1]; return constraint(d,lo,hi,tiny ? 1 : stride); }
      assert(d.count === 1, "EXTRA_DIMENSION", `维度 ${n} 有 ${d.count} 个值，需要先明确深度/层选择`); return "[0]";
    }).join("");
    return name+slices;
  }).join(",")}`;
}
function tableQuery(endpoint: Endpoint, meta: DatasetMetadata, r: DatasetRequest, tiny = false): string {
  const dims = ["time","lat","lon"].map(k => meta.dimensions.find(d => axisKind(d) === k));
  assert(dims.every(Boolean), "MISSING_COORDINATES", "tabledap 元数据缺少明确坐标");
  const [t,y,x] = dims as [Dimension,Dimension,Dimension]; const lons = longitudeSegments(r,x);
  assert(lons.length === 1, "DATELINE_TABLE", "跨日期变更线 tabledap 请求需要拆成两次有界调用");
  const [w,e] = lons[0]!; const stride = tiny ? `&orderByLimit("${t.name},${y.name},${x.name}/100")` : "";
  return `${endpoint.base}.json?${[t.name,y.name,x.name,...r.variables].join(",")}&${t.name}>=${r.timeStart}&${t.name}<=${tiny ? r.timeStart : r.timeEnd}&${y.name}>=${r.bbox[1]}&${y.name}<=${r.bbox[3]}&${x.name}>=${w}&${x.name}<=${e}${stride}`;
}
export function checkCompatibility(datasets: VerifiedDataset[]): AcquisitionResult["compatibility"] {
  assert(datasets.length > 0, "NO_DATASETS", "没有已验证数据");
  const start = datasets.map(d => d.validation.timeRange[0]).sort().at(-1)!;
  const end = datasets.map(d => d.validation.timeRange[1]).sort()[0]!;
  const boxes = datasets.map(d => d.validation.bbox);
  const bbox: [number,number,number,number] = [Math.max(...boxes.map(b=>b[0])),Math.max(...boxes.map(b=>b[1])),Math.min(...boxes.map(b=>b[2])),Math.min(...boxes.map(b=>b[3]))];
  assert(start <= end, "TIME_INCOMPATIBLE", "数据组合缺少共同有效时间覆盖");
  assert(bbox[0] <= bbox[2] && bbox[1] <= bbox[3], "SPACE_INCOMPATIBLE", "数据组合缺少共同经纬度覆盖");
  const transformations = [...new Set(datasets.flatMap(d => d.transformations))]; const warnings = datasets.flatMap(d => d.validation.warnings);
  if (datasets.length > 1) {
    const first = datasets[0]!;
    if (datasets.some(d => JSON.stringify(d.validation.resolution) !== JSON.stringify(first.validation.resolution) || d.validation.bbox[0] !== first.validation.bbox[0] || d.validation.bbox[1] !== first.validation.bbox[1])) warnings.push("Native sampling/grid origins differ. Native files retain their original samples; the aligned artifact records nearest-neighbour spatial/time collocation for pointwise analysis.");
    const identities = new Map<string,string>();
    for (const d of datasets) for(const v of d.variables) {
      const unit = d.validation.units[v]!; const identity = d.metadata.variables.find(m=>m.name===v)?.attrs.standard_name || v;
      assert(!identities.has(identity) || identities.get(identity) === unit, "UNITS_INCOMPATIBLE", `同一物理变量 ${identity} 的单位不兼容，需明确转换后分析`); identities.set(identity,unit);
    }
  }
  return { timeOverlap: [start,end], bbox, transformations, warnings };
}
interface Runtime { budget: ByteBudget; options: AcquireOptions; maxBytes: number }
async function get(url: string, rt: Runtime, id: string, maxBytes = rt.maxBytes): Promise<Buffer> {
  return (await safeFetch(url,{ maxBytes, budget: rt.budget, signal: rt.options.signal, onEvent: rt.options.onEvent, datasetId: id, timeoutMs: 30_000, retries: 1 })).body;
}
async function* resolveEndpoints(r: DatasetRequest, rt: Runtime): AsyncGenerator<Endpoint> {
  const endpoints: Endpoint[] = [], pages: string[] = [];
  const pageOutcomes:Array<{code:string;error?:unknown;url:string}>=[];
  for(const url of r.urls) {
    try { const ep = identifyEndpoint(url); if(ep.protocol !== "direct" || /\.(json|csv|nc|nc4|cdf)(?:\?|$)/i.test(url)) endpoints.push(ep); else pages.push(url); }
    catch(error) { rt.options.onEvent?.("access_resolution", {dataset_id:r.datasetId,status:"rejected",error_type:(error as DataAccessError).code, url:redactDataUrl(url)}); }
  }
  const seen = new Set<string>();
  const candidates = (values: Endpoint[]): Endpoint[] => {
    // NOAA official mirrors preserve dataset identity; they do not require reading a product page.
    for(const endpoint of [...values]) if(endpoint.info && /\.noaa\.gov\//.test(endpoint.base)) {
      const u=new URL(endpoint.base); const path=u.pathname.slice(u.pathname.indexOf("/erddap/"));
      for(const host of ["https://coastwatch.pfeg.noaa.gov","https://coastwatch.noaa.gov"]) if(u.origin!==host) values.push(identifyEndpoint(host+path));
    }
    return [...new Map(values.map(e=>[e.base,e])).values()].filter(endpoint=>!seen.has(endpoint.base)).slice(0,16-seen.size);
  };
  for(const endpoint of candidates(endpoints)) { seen.add(endpoint.base); yield endpoint; }
  // This generator reaches product-page discovery only after all known services failed.
  // A successful service closes iteration without an unnecessary page request.
  for(const page of pages.slice(0,3)) {
    if(seen.size>=16) break;
    try {
      const body = (await get(page,rt,r.datasetId,512*1024)).toString("utf8");
      pageOutcomes.push({code:"PUBLIC_METADATA",url:redactDataUrl(page)});
      const links = [...body.matchAll(/(?:href|url)\s*[=:]\s*["']([^"'<>\s]+)["']/gi)].map(m => m[1]!);
      const discovered: Endpoint[] = [];
      for(const link of links.slice(0,150)) {
        try { const found = new URL(link.replace(/&amp;/g,"&"),page);if(found.protocol==="http:")found.protocol="https:";const u=found.toString(); const ep=identifyEndpoint(u); if(ep.protocol!=="direct" || /\.(json|csv|nc|nc4|cdf)(?:\?|$)/i.test(u)) discovered.push(ep); } catch { /* unapproved/non-data links */ }
      }
      for(const endpoint of candidates(discovered)) { seen.add(endpoint.base); yield endpoint; }
    } catch(error) { if(rt.options.signal?.aborted) throw error; pageOutcomes.push({code:(error as DataAccessError).code??"NETWORK_ERROR",error,url:redactDataUrl(page)});rt.options.onEvent?.("access_resolution",{dataset_id:r.datasetId,status:"metadata_page_failed",error_type:(error as DataAccessError).code}); }
  }
  if(!seen.size&&pageOutcomes.length>0&&pageOutcomes.every(p=>p.code==="AUTH_REQUIRED")){
    const error=new DataAccessError("AUTH_REQUIRED","所有已核验的官方产品页均要求登录授权，未发现公开数据入口",true);error.causes=pageOutcomes.map(p=>({code:p.code,url:p.url,message:(p.error as Error)?.message??"Official authentication required"}));throw error;
  }
  assert(seen.size,"NO_ACCESS_ENDPOINT","官方元数据未发现可用数据接口，需继续检索官方服务而不是直接要求上传");
}
async function erddapAcquire(endpoint: Endpoint,r:DatasetRequest,rt:Runtime):Promise<{table:Table;meta:DatasetMetadata}> {
  const json=JSON.parse((await get(endpoint.info!,rt,r.datasetId,2*1024*1024)).toString("utf8"));
  const meta=parseErddapMetadata(json);
  if(endpoint.protocol==="tabledap") {
    // tabledap exposes coordinates as variables rather than grid dimensions.
    for(const v of meta.variables) if(axisKind(v)!=="other" && !meta.dimensions.some(d=>d.name===v.name)) {
      const range=numberList(v.attrs.actual_range); if(range.length) meta.dimensions.push({...v, count:0, range:[range[0]!,range.at(-1)!],spacing:0});
    }
  }
  assert(r.variables.every(v=>meta.variables.some(m=>m.name===v)),"UNKNOWN_VARIABLE",`变量与官方元数据不一致。可用变量：${meta.variables.map(v=>`${v.name} [${v.units}]`).join(", ")}`);
  const time=meta.dimensions.find(d=>axisKind(d)==="time"),lat=meta.dimensions.find(d=>axisKind(d)==="lat"),lon=meta.dimensions.find(d=>axisKind(d)==="lon");
  assert(time&&lat&&lon,"MISSING_COORDINATES","官方元数据缺少可识别的时间/经纬度维度");
  rt.options.onEvent?.("access_resolution",{dataset_id:r.datasetId,status:"resolved",protocol:endpoint.protocol,url:endpoint.base,variables:meta.variables.map(v=>({name:v.name,units:v.units})),dimensions:meta.dimensions.map(d=>({name:d.name,count:d.count,range:d.range,units:d.units}))});
  if(endpoint.protocol==="tabledap") {
    // A bounded first-day pilot; byte caps remain authoritative when record density is unknown.
    const pilotRequest={...r,timeEnd:new Date(Math.min(Date.parse(r.timeEnd),Date.parse(r.timeStart)+86400000)).toISOString()};
    const pilot=parseTable(await get(tableQuery(endpoint,meta,pilotRequest),rt,r.datasetId,Math.min(rt.maxBytes,256*1024)));
    validateTable(pilot,meta,pilotRequest);
    const density=Math.max(1,pilot.rows.length); const days=Math.ceil((Date.parse(r.timeEnd)-Date.parse(r.timeStart))/86400000)+1;
    assert(density*days*128 <= rt.budget.limit-rt.budget.used,"SIZE_ESTIMATE","tabledap 预估样本超过剩余预算，请缩小时间、区域或变量");
    rt.options.onEvent?.("data_validation",{dataset_id:r.datasetId,status:"pilot_valid",row_count:pilot.rows.length});
    return {table:parseTable(await get(tableQuery(endpoint,meta,r),rt,r.datasetId)),meta};
  }
  // Inspect actual time coordinates before estimating or selecting science data. This catches gaps and timestamp conventions.
  const timeQuery=`${endpoint.base}.json?${time.name}${constraint(time,r.timeStart,r.timeEnd,1)}`;
  const timesTable=parseTable(await get(timeQuery,rt,r.datasetId,512*1024));
  const times=timesTable.rows.map(row=>normalizeTime(row[0],timesTable.columnUnits?.[0]||time.units)).filter(t=>Date.parse(t)>=Date.parse(r.timeStart)&&Date.parse(t)<=Date.parse(r.timeEnd));
  assert(times.length>0,"TIME_OUT_OF_COVERAGE","官方实际时间轴不覆盖请求时段");
  const selectedTimes=times;
  const lons=longitudeSegments(r,lon);
  const ny=Math.min(lat.count,Math.ceil((r.bbox[3]-r.bbox[1])/Math.max(lat.spacing,1e-8))+2);
  const nx=lons.reduce((sum,[w,e])=>sum+Math.min(lon.count,Math.ceil((e-w)/Math.max(lon.spacing,1e-8))+2),0);
  const pointsPerTime=Math.ceil(ny/(r.stride??1))*Math.ceil(nx/(r.stride??1));
  const rowEstimate=128+24*r.variables.length;
  const estimate=selectedTimes.length*pointsPerTime*rowEstimate;
  assert(estimate <= rt.budget.limit-rt.budget.used,"SIZE_ESTIMATE",`请求估算 ${estimate} bytes 超过剩余预算；请缩小范围或增加显式 stride`);
  rt.options.onEvent?.("access_resolution",{dataset_id:r.datasetId,status:"bounded_request",estimated_bytes:estimate,time_samples:selectedTimes.length,estimated_rows:selectedTimes.length*pointsPerTime,longitude_segments:lons});
  const pilotTime=selectedTimes[0]!;
  let pilotValid=false;
  for(const longitude of lons) {
    try {
      const pilot=parseTable(await get(gridQuery(endpoint,meta,r,[pilotTime,pilotTime],longitude,true),rt,r.datasetId,Math.min(rt.maxBytes,128*1024)));
      validateTable(pilot,meta,r); pilotValid=true;
      rt.options.onEvent?.("data_validation",{dataset_id:r.datasetId,status:"pilot_valid",row_count:pilot.rows.length}); break;
    }catch(error) { if(rt.options.signal?.aborted) throw error; if(!(error instanceof DataAccessError)||error.code!=="EMPTY_DATA") throw error; }
  }
  assert(pilotValid,"EMPTY_PILOT","极小切片未返回有效样本，未扩大下载。请调整小切片到已知海域");
  const perChunk=Math.max(1,Math.floor(rt.maxBytes/(Math.max(1,pointsPerTime)*rowEstimate)));
  assert(pointsPerTime*rowEstimate<=rt.maxBytes,"SIZE_ESTIMATE","单时次空间切片已超过文件限制，请缩小区域或增加 stride");
  let all:Table|undefined;
  for(let i=0;i<selectedTimes.length;i+=perChunk) for(const longitude of lons) {
    const slice=selectedTimes.slice(i,i+perChunk);
    const chunk=parseTable(await get(gridQuery(endpoint,meta,r,[slice[0]!,slice.at(-1)!],longitude),rt,r.datasetId));
    if(!all) all={...chunk,rows:[]};
    assert(JSON.stringify(chunk.columnNames)===JSON.stringify(all.columnNames),"SCHEMA_CHANGED","分块响应变量顺序发生变化"); all.rows.push(...chunk.rows);
  }
  assert(all,"EMPTY_DATA","数据服务没有返回数据");return {table:all,meta};
}
function parseDapArray(text:string,name:string):number[] {
  const values:number[]=[];
  for(const line of text.split(/\r?\n/)) {
    const m=/^([\w.]+)(?:\[\d+\])*\s*,\s*(.*)$/.exec(line.trim());
    if(m && (m[1]===name||m[1]===`${name}.${name}`)) values.push(...m[2]!.split(",").map(v=>Number(v.trim())));
  }
  return values;
}
async function opendapAcquire(endpoint:Endpoint,r:DatasetRequest,rt:Runtime):Promise<{table:Table;meta:DatasetMetadata}> {
  const dds=(await get(`${endpoint.base}.dds`,rt,r.datasetId,512*1024)).toString("utf8");
  const das=(await get(`${endpoint.base}.das`,rt,r.datasetId,1024*1024)).toString("utf8");
  const attrs=(name:string):Record<string,string>=>{
    const block=new RegExp(`(?:^|\\n)\\s*${name.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}\\s*\\{([^{}]*)\\}`,"m").exec(das)?.[1]??"";
    const a:Record<string,string>={}; for(const m of block.matchAll(/\b\w+\s+(\w+)\s+([^;]+);/g)) a[m[1]!]=m[2]!.trim().replace(/^"|"$/g,""); return a;
  };
  const dimensions=new Map<string,Dimension>(),variables:Variable[]=[];
  for(const m of dds.matchAll(/(?:Float\d+|Int\d+|UInt\d+|Byte)\s+(\w+)\s*((?:\[[^\]]+\])+)/g)) {
    const name=m[1]!, dims=[...m[2]!.matchAll(/\[\s*(\w+)\s*=\s*(\d+)\s*\]/g)];
    const a=attrs(name); variables.push({name,dimensions:dims.map(x=>x[1]!),units:a.units??"",attrs:a});
    for(const d of dims) if(!dimensions.has(d[1]!)) dimensions.set(d[1]!,{name:d[1]!,count:Number(d[2]),range:[0,0],spacing:0,units:attrs(d[1]!).units??"",attrs:attrs(d[1]!)});
  }
  const meta:DatasetMetadata={title:attrs("NC_GLOBAL").title??"",dimensions:[...dimensions.values()],variables,attrs:attrs("NC_GLOBAL")};
  assert(r.variables.every(v=>variables.some(m=>m.name===v)),"UNKNOWN_VARIABLE","OPeNDAP DDS 不包含所需变量");
  const axes=new Map<string,number[]>();
  for(const d of meta.dimensions) {
    assert(/^[A-Za-z_]\w*$/.test(d.name)&&d.count<=50000,"AXIS_SIZE_LIMIT","OPeNDAP 坐标轴过大或不支持；需要官方 ERDDAP/其他子集服务");
    const text=(await get(`${endpoint.base}.ascii?${d.name}[0:1:${d.count-1}]`,rt,r.datasetId,1024*1024)).toString("utf8");
    const values=parseDapArray(text,d.name);assert(values.length===d.count&&values.every(Number.isFinite),"INVALID_METADATA",`不能读取 OPeNDAP 坐标 ${d.name}`);
    d.range=[values[0]!,values.at(-1)!];d.spacing=d.count>1?Math.abs(d.range[1]-d.range[0])/(d.count-1):0;axes.set(d.name,values);
  }
  rt.options.onEvent?.("access_resolution",{dataset_id:r.datasetId,status:"resolved",protocol:"opendap",url:endpoint.base,variables:r.variables,dimensions:meta.dimensions});
  const selected=new Map<string,number[]>();
  for(const d of meta.dimensions) {
    const kind=axisKind(d);const vals=axes.get(d.name)!;
    const indices=vals.flatMap((value,i)=>{
      if(kind==="time") {const t=Date.parse(normalizeTime(value,d.units));return t>=Date.parse(r.timeStart)&&t<=Date.parse(r.timeEnd)?[i]:[];}
      if(kind==="lat")return value>=r.bbox[1]&&value<=r.bbox[3]?[i]:[];
      if(kind==="lon") {const lon=normalizeLongitude(value);return (r.bbox[0]<=r.bbox[2]?lon>=r.bbox[0]&&lon<=r.bbox[2]:lon>=r.bbox[0]||lon<=r.bbox[2])?[i]:[];}
      assert(d.count===1,"EXTRA_DIMENSION",`OPeNDAP 维度 ${d.name} 需明确选择层`);return [i];
    }).filter((_,i)=>!(["lat","lon"].includes(kind))||i%(r.stride??1)===0);
    assert(indices.length,"OUT_OF_COVERAGE",`OPeNDAP 坐标 ${d.name} 无请求范围样本`);
    assert(indices.every((v,i)=>i===0 || v-indices[i-1]! === (["lat","lon"].includes(kind)?r.stride??1:1)),"INVALID_METADATA","坐标轴异常");selected.set(d.name,indices);
  }
  const first=meta.variables.find(v=>v.name===r.variables[0])!;
  assert(r.variables.every(v=>JSON.stringify(meta.variables.find(m=>m.name===v)!.dimensions)===JSON.stringify(first.dimensions)),"GRID_INCOMPATIBLE","OPeNDAP 请求变量必须共用坐标维度");
  const count=first.dimensions.reduce((n,d)=>n*selected.get(d)!.length,1);
  assert(count*(128+24*r.variables.length)<=Math.min(rt.maxBytes,rt.budget.limit-rt.budget.used),"SIZE_ESTIMATE","OPeNDAP 切片超过预算；缩小范围或增大 stride");
  const query=(tiny:boolean)=>r.variables.map(v=>{
    const m=meta.variables.find(x=>x.name===v)!;
    return v+m.dimensions.map(d=>{const ix=selected.get(d)!;const start=tiny?ix[Math.floor(ix.length/2)]!:ix[0]!;const end=tiny?start:ix.at(-1)!;const dmeta=meta.dimensions.find(x=>x.name===d)!;return `[${start}:${["lat","lon"].includes(axisKind(dmeta))?r.stride??1:1}:${end}]`;}).join("");
  }).join(",");
  const pilot=(await get(`${endpoint.base}.ascii?${query(true)}`,rt,r.datasetId,128*1024)).toString("utf8");
  assert(r.variables.every(v=>{const m=meta.variables.find(m=>m.name===v)!;const fill=numberList(`${m.attrs._FillValue??""},${m.attrs.missing_value??""}`);return parseDapArray(pilot,v).some(n=>Number.isFinite(n)&&!fill.includes(n));}),"EMPTY_PILOT","OPeNDAP 极小切片没有非空数据，未扩大下载");
  rt.options.onEvent?.("data_validation",{dataset_id:r.datasetId,status:"pilot_valid",row_count:1});
  const text=(await get(`${endpoint.base}.ascii?${query(false)}`,rt,r.datasetId)).toString("utf8");
  const values=r.variables.map(v=>parseDapArray(text,v));assert(values.every(a=>a.length===count),"INVALID_DATA","OPeNDAP ASCII 响应大小与切片维度不一致");
  const names=[...first.dimensions,...r.variables], units=[...first.dimensions.map(d=>meta.dimensions.find(x=>x.name===d)!.units),...r.variables.map(v=>meta.variables.find(m=>m.name===v)!.units)];
  const rows:unknown[][]=[];
  for(let flat=0;flat<count;flat++) {
    let rem=flat;const coords:number[]=[];
    for(let i=first.dimensions.length-1;i>=0;i--) {const d=first.dimensions[i]!,ix=selected.get(d)!;coords.unshift(axes.get(d)![ix[rem%ix.length]!]!);rem=Math.floor(rem/ix.length);}
    rows.push([...coords,...values.map(a=>a[flat])]);
  }
  return {table:{columnNames:names,columnUnits:units,rows},meta};
}
function metaFromTable(table:Table):DatasetMetadata {
  const variables:Variable[]=table.columnNames.map((name,i)=>({name,dimensions:[],units:table.columnUnits?.[i]??"",attrs:{}}));
  const dimensions:Dimension[]=variables.filter(v=>axisKind(v)!=="other").map(v=>{
    const i=table.columnNames.indexOf(v.name);const values=table.rows.map(r=>typeof r[i]==="number"?Number(r[i]):Date.parse(String(r[i]))/1000).filter(Number.isFinite).sort((a,b)=>a-b);
    return {...v,count:new Set(values).size,range:[values[0]??0,values.at(-1)??0],spacing:0};
  });
  return {title:"Direct bounded table",variables,dimensions,attrs:{}};
}
async function directAcquire(endpoint:Endpoint,r:DatasetRequest,rt:Runtime):Promise<{table:Table;meta:DatasetMetadata}> {
  // A public file is accepted only after HEAD advertises a finite small size. Large global files are never fetched.
  const head=await safeFetch(endpoint.base,{maxBytes:0,budget:rt.budget,signal:rt.options.signal,onEvent:rt.options.onEvent,datasetId:r.datasetId,method:"HEAD",retries:0});
  const size=Number(head.headers["content-length"]);
  assert(Number.isFinite(size)&&size>0&&size<=rt.maxBytes&&size<=rt.budget.limit-rt.budget.used,"UNBOUNDED_FILE","直接文件没有可信的小规模 Content-Length，或文件超过预算；请选择服务端子集入口");
  const body=await get(endpoint.base,rt,r.datasetId);
  if(/\.json(?:\?|$)/i.test(endpoint.base)||/json/i.test(head.contentType)) {const table=parseTable(body);return {table,meta:metaFromTable(table)};}
  if(/\.csv(?:\?|$)/i.test(endpoint.base)||/csv/i.test(head.contentType)) {
    const lines=body.toString("utf8").trim().split(/\r?\n/);assert(lines.length>=3,"INVALID_DATA","CSV 需要表头、单位行和数据行（ERDDAP CSV 格式）");
    const split=(line:string)=>{const values:string[]=[];let value="",quoted=false;for(let i=0;i<line.length;i++){const c=line[i]!;if(c==='"'){if(quoted&&line[i+1]==='"'){value+='"';i++;}else quoted=!quoted;}else if(c===","&&!quoted){values.push(value);value="";}else value+=c;}assert(!quoted,"INVALID_DATA","CSV 引号不完整");values.push(value);return values;};
    const names=split(lines[0]!),units=split(lines[1]!);assert(units.length===names.length,"MISSING_UNITS","CSV 单位行不完整");
    const rows=lines.slice(2).filter(Boolean).map(line=>split(line).map((v,i)=>/time/i.test(names[i]??"")?v:v===""||/^NaN$/i.test(v)?null:Number(v)));
    const table:Table={columnNames:names,columnUnits:units,rows};return {table,meta:metaFromTable(table)};
  }
  if(/\.(nc|nc4|cdf)(?:\?|$)/i.test(endpoint.base)||/netcdf|octet-stream/i.test(head.contentType)) {
    const local=join(rt.options.cacheDir,`${randomUUID()}.source.nc.part`);
    let helper=fileURLToPath(new URL("./read-netcdf.py",import.meta.url));if(!existsSync(helper))helper=fileURLToPath(new URL("../../src/data-access/read-netcdf.py",import.meta.url));
    try {
      await writeFile(local,body,{flag:"wx"});
      let stdout:string;try{({stdout}=await runFile(rt.options.pythonPath??process.env.OCEAN_DATA_PYTHON??"python3",[helper,local,JSON.stringify(r)],{timeout:30000,maxBuffer:32*1024*1024,signal:rt.options.signal}));}catch(error){
        let output:{error?:string;message?:string}={};try{output=JSON.parse(String((error as {stdout?:string}).stdout??""));}catch{}
        throw new DataAccessError(output.error??"READER_UNAVAILABLE",output.message??"直接 NetCDF 验证需要本地 xarray 和 scipy/netCDF4，设置 OCEAN_DATA_PYTHON 指向已安装环境");
      }
      const parsed=JSON.parse(stdout) as {table:Table;meta:DatasetMetadata};assert(parsed.table&&parsed.meta,"INVALID_DATA","本地 NetCDF 验证器返回无效结果");return parsed;
    }finally{await rm(local,{force:true});}
  }
  throw new DataAccessError("UNSUPPORTED_FORMAT","直接文件格式不支持，请继续发现官方 ERDDAP/OPeNDAP 子集入口");
}
export async function acquireDatasets(requests:DatasetRequest[],options:AcquireOptions):Promise<AcquisitionResult> {
  const timeout=AbortSignal.timeout(Math.min(options.timeoutMs??300000,600000));
  options={...options,signal:options.signal?AbortSignal.any([options.signal,timeout]):timeout};
  assert(requests.length>0&&requests.length<=8,"INVALID_REQUEST","每次需要 1–8 个明确数据集");
  for(const request of requests)validateRequest(request);
  const total=Math.min(options.maxTotalBytes??32*1024*1024,64*1024*1024);
  assert(total>0,"TOTAL_BYTE_LIMIT","本次运行总下载预算已耗尽");
  const rt:Runtime={options,budget:options.budget ?? {used:0,limit:total},maxBytes:Math.min(options.maxFileBytes??8*1024*1024,16*1024*1024)};
  assert(Number.isFinite(rt.maxBytes)&&rt.maxBytes>0&&Number.isFinite(rt.budget.limit)&&rt.budget.limit>0&&rt.budget.limit<=64*1024*1024&&Number.isFinite(rt.budget.used)&&rt.budget.used>=0,"INVALID_BUDGET","下载预算必须是有限正数且不超过 64 MiB");
  const initialBytes=rt.budget.used;
  await mkdir(options.cacheDir,{recursive:true});const datasets:VerifiedDataset[]=[];
  for(const r of requests) {
    const key=hash(JSON.stringify({version:2,request:r}));const path=join(options.cacheDir,`${key}.json`),manifest=join(options.cacheDir,`${key}.manifest.json`);
    let cached:VerifiedDataset|undefined;
    try {
      const saved=JSON.parse(await readFile(manifest,"utf8")) as VerifiedDataset;
      const body=await readFile(path);
      assert(saved.sha256===hash(body)&&saved.bytes===body.length&&body.length<=rt.maxBytes,"CACHE_INTEGRITY","缓存完整性检查失败");
      // Re-read and validate scientific fields, not just the cache checksum.
      const valid=validateTable(parseTable(body),saved.metadata,r);
      cached={...saved,path,validation:valid.validation,cacheHit:true};
    }catch { /* Missing, corrupt or incompatible cache is re-acquired safely. */ }
    if(cached) { datasets.push(cached);options.onEvent?.("data_validation",{dataset_id:r.datasetId,status:"cache_valid",path,sha256:cached.sha256,valid_samples:cached.validation.validSamples});continue; }
    const before=rt.budget.used;let lastError:unknown;const causes:Array<{error:unknown;code:string;url:string;message:string}>=[];let acquired:VerifiedDataset|undefined;
    try {
      for await(const endpoint of resolveEndpoints(r,rt)) {
        options.signal?.throwIfAborted();
        try {
          const localRt={...rt,maxBytes:Math.min(rt.maxBytes,r.maxBytes??rt.maxBytes)};
          const {table,meta}=endpoint.protocol==="griddap"||endpoint.protocol==="tabledap"?await erddapAcquire(endpoint,r,localRt):endpoint.protocol==="opendap"?await opendapAcquire(endpoint,r,localRt):await directAcquire(endpoint,r,localRt);
          const verified=validateTable(table,meta,r);const bytes=Buffer.from(JSON.stringify({schema:"ocean-agent-data-v1",datasetId:r.datasetId,table:verified.table,validation:verified.validation,transformations:verified.transformations}));
          assert(bytes.length<=rt.maxBytes,"SIZE_LIMIT","规范化后的缓存文件超过文件预算，请缩小请求");
          const temp=`${path}.${randomUUID()}.part`;
          try {await writeFile(temp,bytes,{flag:"wx"});await rename(temp,path);}finally {await rm(temp,{force:true});}
          acquired={datasetId:r.datasetId,path,sha256:hash(bytes),bytes:bytes.length,sourceUrl:redactDataUrl(endpoint.base),protocol:endpoint.protocol,variables:r.variables,metadata:meta,validation:verified.validation,transformations:verified.transformations,cacheHit:false};
          const metaTemp=`${manifest}.${randomUUID()}.part`;try{await writeFile(metaTemp,JSON.stringify(acquired,null,2),{flag:"wx"});await rename(metaTemp,manifest);}finally{await rm(metaTemp,{force:true});}
          options.onEvent?.("download_complete",{dataset_id:r.datasetId,status:"completed",path,downloaded_bytes:rt.budget.used-before,normalized_bytes:bytes.length,sha256:acquired.sha256,source_url:acquired.sourceUrl});
          options.onEvent?.("data_validation",{dataset_id:r.datasetId,status:"valid",...verified.validation,transformations:verified.transformations,path});break;
        }catch(error) {
          lastError=error;causes.push({error,code:(error as DataAccessError).code??"NETWORK_ERROR",url:redactDataUrl(endpoint.base),message:(error as Error).message});options.onEvent?.("access_resolution",{dataset_id:r.datasetId,status:"failed",protocol:endpoint.protocol,url:endpoint.base,error_type:(error as DataAccessError).code??(error as Error).name});
          if(options.signal?.aborted||error instanceof DataAccessError&&["TOTAL_BYTE_LIMIT","SIZE_ESTIMATE","INVALID_REQUEST"].includes(error.code))throw error;
        }
      }
      if(!acquired) {
        const semantic=["UNKNOWN_VARIABLE","MISSING_COORDINATES","TIME_OUT_OF_COVERAGE","EMPTY_PILOT","EMPTY_DATA","MISSING_UNITS","EXTRA_DIMENSION","NO_JOINT_SAMPLES","OUT_OF_COVERAGE","FORMAT_REQUIRES_SUBSET","READER_UNAVAILABLE"];
        const preferred=causes.find(c=>semantic.includes(c.code));
        const auth=causes.find(c=>c.code==="AUTH_REQUIRED");
        const allKnownAlternativesAuth=Boolean(auth)&&causes.every(c=>["AUTH_REQUIRED","NOT_FOUND"].includes(c.code));
        let chosen=preferred?.error??(allKnownAlternativesAuth?auth!.error:causes.find(c=>c.code!=="AUTH_REQUIRED"&&c.code!=="NOT_FOUND")?.error??lastError);
        if(!chosen)chosen=new DataAccessError("NO_ACCESS_ENDPOINT","所有官方候选入口均失败");
        if(chosen instanceof DataAccessError)chosen.causes=causes.map(({error,...cause})=>cause);
        throw chosen;
      }
      datasets.push(acquired);
    }catch(error) {
      const e=error instanceof DataAccessError?error:new DataAccessError(options.signal?.aborted?"CANCELLED":"ACQUISITION_FAILED",error instanceof Error?error.message:String(error));
      e.datasetId=r.datasetId;e.partialDatasets=datasets;
      Object.assign(e,{downloadedBytes:rt.budget.used});options.onEvent?.("data_validation",{dataset_id:r.datasetId,status:"failed",error_type:e.code,downloaded_bytes_total:rt.budget.used});throw e;
    }
  }
  try {
  const compatibility=checkCompatibility(datasets);
  if(datasets.length>1) {const aligned=await alignDatasets(datasets,options.cacheDir);compatibility.alignedPath=aligned.path;compatibility.method=aligned.method;compatibility.transformations.push(aligned.description);options.onEvent?.("data_validation",{status:"alignment_complete",path:aligned.path,method:aligned.method,...aligned.metrics});}
  options.onEvent?.("data_validation",{status:"combination_valid",dataset_ids:datasets.map(d=>d.datasetId),...compatibility,downloaded_bytes_total:rt.budget.used});
  return {datasets,compatibility,downloadedBytes:rt.budget.used-initialBytes};
  }catch(error){const e=error instanceof DataAccessError?error:new DataAccessError("COMBINATION_FAILED",(error as Error).message);e.partialDatasets=datasets;Object.assign(e,{downloadedBytes:rt.budget.used-initialBytes});options.onEvent?.("data_validation",{dataset_ids:datasets.map(d=>d.datasetId),status:"combination_failed",error_type:e.code,downloaded_bytes_total:rt.budget.used});throw e;}
}
/** Deterministic bounded nearest-neighbour collocation. No extrapolation and no missing-value fill. */
export async function alignDatasets(datasets:VerifiedDataset[],cacheDir:string):Promise<{path:string;method:string;description:string;metrics:Record<string,unknown>}> {
  checkCompatibility(datasets);
  const inputs=await Promise.all(datasets.map(async dataset=>{
    const body=await readFile(dataset.path);assert(hash(body)===dataset.sha256,"CACHE_INTEGRITY","对齐前文件哈希校验失败");const table=parseTable(body);
    const index=(kind:string)=>table.columnNames.findIndex(name=>{const d=dataset.metadata.dimensions.find(d=>d.name===name);return d&&axisKind(d)===kind;});
    const t=index("time"),x=index("lon"),y=index("lat");assert(t>=0&&x>=0&&y>=0,"MISSING_COORDINATES","对齐输入缺少坐标");
    const axes={t:[...new Set(table.rows.map(r=>Date.parse(String(r[t]))))].sort((a,b)=>a-b),x:[...new Set(table.rows.map(r=>Number(r[x])))].sort((a,b)=>a-b),y:[...new Set(table.rows.map(r=>Number(r[y])))].sort((a,b)=>a-b)};
    const key=(tv:number,xv:number,yv:number)=>`${tv}|${xv}|${yv}`;
    const vars=dataset.variables.map(v=>table.columnNames.indexOf(v));
    const lookup=new Map(table.rows.filter(row=>vars.every(i=>typeof row[i]==="number"&&Number.isFinite(row[i]))).map(row=>[key(Date.parse(String(row[t])),Number(row[x]),Number(row[y])),row]));
    const spacing=(k:string)=>dataset.metadata.dimensions.find(d=>axisKind(d)===k)?.spacing??0;
    return {dataset,table,t,x,y,axes,key,vars,lookup,spacing};
  }));
  const target=inputs[0]!;
  const nearest=(a:number[],v:number):number=>{let l=0,h=a.length-1;while(l<h){const m=Math.floor((l+h)/2);if(a[m]!<v)l=m+1;else h=m;}return l>0&&Math.abs(a[l-1]!-v)<=Math.abs(a[l]!-v)?a[l-1]!:a[l]!;};
  const sourceOffsets=inputs.map(()=>({max_time_offset_seconds:0,max_longitude_offset_degrees:0,max_latitude_offset_degrees:0}));
  const rows:unknown[][]=[];let unmatched=0;
  for(const row of target.lookup.values()) {
    const tv=Date.parse(String(row[target.t])),xv=Number(row[target.x]),yv=Number(row[target.y]);const values:unknown[]=[];let match=true;
    for(let i=0;i<inputs.length;i++) {
      const input=inputs[i]!;const st=nearest(input.axes.t,tv),sx=nearest(input.axes.x,xv),sy=nearest(input.axes.y,yv);
      const dt=Math.abs(st-tv)/1000,dx=Math.abs(sx-xv),dy=Math.abs(sy-yv);
      const timeTolerance=Math.max(input.dataset.validation.resolution.time_seconds??0,target.dataset.validation.resolution.time_seconds??0,input.spacing("time"),target.spacing("time"))/2+1e-6;
      const lonTolerance=Math.max(input.dataset.validation.resolution.longitude_degrees??0,input.spacing("lon"))/2+1e-6;
      const latTolerance=Math.max(input.dataset.validation.resolution.latitude_degrees??0,input.spacing("lat"))/2+1e-6;
      const source=input.lookup.get(input.key(st,sx,sy));
      if(!source||dt>timeTolerance||dx>lonTolerance||dy>latTolerance){match=false;break;}
      const offset=sourceOffsets[i]!;offset.max_time_offset_seconds=Math.max(offset.max_time_offset_seconds,dt);offset.max_longitude_offset_degrees=Math.max(offset.max_longitude_offset_degrees,dx);offset.max_latitude_offset_degrees=Math.max(offset.max_latitude_offset_degrees,dy);
      values.push(...input.vars.map(v=>source[v]));
    }
    if(match)rows.push([new Date(tv).toISOString(),yv,xv,...values]);else unmatched++;
  }
  assert(rows.length>0,"NO_COLLOCATED_SAMPLES","数据组合没有容差内共同有效样本，不能作为可执行的联合分析输入");
  const method="nearest_time_and_space_no_extrapolation";
  const description="Joint data collocated onto first dataset native grid/time by nearest neighbour; spatial tolerance half source cell, temporal tolerance half maximum native interval; ties select lower coordinate/earlier time. Missing cells excluded, no extrapolation. Native inputs preserved.";
  const metrics={target_dataset_id:datasets[0]!.datasetId,joint_samples:rows.length,excluded_target_samples:unmatched,offsets:datasets.map((d,i)=>({dataset_id:d.datasetId,...sourceOffsets[i]}))};
  const table:Table={columnNames:["time","latitude","longitude",...datasets.flatMap(d=>d.variables.map(v=>`${d.datasetId}::${v}`))],columnUnits:["UTC","degrees_north","degrees_east",...datasets.flatMap(d=>d.variables.map(v=>d.validation.units[v]!))],rows};
  const data=Buffer.from(JSON.stringify({schema:"ocean-agent-aligned-v1",table,method,description,metrics,sources:datasets.map(d=>({datasetId:d.datasetId,path:d.path,sha256:d.sha256}))}));
  assert(data.length<=32*1024*1024,"SIZE_LIMIT","对齐产物超过 32 MiB 本地限制");
  const path=join(cacheDir,`${hash(JSON.stringify(datasets.map(d=>d.sha256)))}.aligned.json`),temp=`${path}.${randomUUID()}.part`;
  try{await writeFile(temp,data,{flag:"wx"});await rename(temp,path);}finally{await rm(temp,{force:true});}
  return {path,method,description,metrics};
}
