"""Local-only optional NetCDF reader. Network access is deliberately absent."""
import json
import math
import os
import sys

try:
    import numpy as np
    import xarray as xr
except ImportError:
    print(json.dumps({"error": "READER_UNAVAILABLE", "message": "NetCDF direct files require local xarray plus scipy or netCDF4; configure OCEAN_DATA_PYTHON to an installed environment."}))
    sys.exit(2)


def main():
    path, raw_request = sys.argv[1:]
    request = json.loads(raw_request)
    if not os.path.isfile(path) or os.path.getsize(path) > 16 * 1024 * 1024:
        raise ValueError("Local NetCDF exceeds 16 MiB")
    with xr.open_dataset(path, decode_cf=True, mask_and_scale=True) as original:
        def kind(name, var):
            value = (name + " " + str(var.attrs.get("standard_name", ""))).lower()
            units = str(var.attrs.get("units", ""))
            if name.lower() in ("time", "t") or "time" in value:
                return "time"
            if name.lower() in ("lat", "latitude") or "degrees_north" in units:
                return "lat"
            if name.lower() in ("lon", "longitude") or "degrees_east" in units:
                return "lon"
            return "other"

        dimensions = []
        axes = {}
        for name in original.dims:
            coord = original[name]
            if coord.ndim != 1:
                raise ValueError("Curvilinear coordinates require an explicit regridding adapter")
            role = kind(name, coord)
            axes[role] = name if role != "other" else axes.get(role)
            if role == "time":
                values = coord.values.astype("datetime64[s]").astype(np.int64)
                units = "seconds since 1970-01-01T00:00:00Z"
            else:
                values = np.asarray(coord.values, dtype=float)
                units = str(coord.attrs.get("units", ""))
            dimensions.append({"name": name, "count": len(values), "range": [float(values[0]), float(values[-1])], "units": units, "attrs": {"standard_name": str(coord.attrs.get("standard_name", ""))}, "spacing": float(abs(values[-1]-values[0])/(len(values)-1)) if len(values)>1 else 0})
        if not all(axes.get(k) for k in ("time", "lat", "lon")):
            raise ValueError("Missing one-dimensional time/latitude/longitude axes")
        variables = []
        for name in request["variables"]:
            if name not in original.data_vars:
                raise ValueError("Requested variable absent: " + name)
            variable = original[name]
            variables.append({"name": name, "dimensions": list(variable.dims), "units": str(variable.attrs.get("units", "")), "attrs": {"standard_name": str(variable.attrs.get("standard_name", ""))}})
        selected = original[request["variables"]]
        for name in list(selected.dims):
            coord = selected[name]
            role = kind(name, coord)
            values = coord.values
            if role == "time":
                start = np.datetime64(request["timeStart"].rstrip("Z"))
                end = np.datetime64(request["timeEnd"].rstrip("Z"))
                indices = np.flatnonzero((values >= start) & (values <= end))
            elif role == "lat":
                indices = np.flatnonzero((values >= request["bbox"][1]) & (values <= request["bbox"][3]))[::request.get("stride", 1)]
            elif role == "lon":
                values = (values + 180) % 360 - 180
                west, east = request["bbox"][0], request["bbox"][2]
                indices = np.flatnonzero(((values >= west) & (values <= east)) if west <= east else ((values >= west) | (values <= east)))[::request.get("stride", 1)]
            else:
                if selected.sizes[name] != 1:
                    raise ValueError("Unselected depth/extra dimension: " + name)
                indices = np.array([0])
            if not len(indices):
                raise ValueError("No requested samples on axis " + name)
            selected = selected.isel({name: indices})
        count = math.prod(selected.sizes.values())
        if count > 100000:
            raise ValueError("Local decoded subset exceeds 100000 rows")
        columns = list(selected.dims) + request["variables"]
        frame = selected.to_dataframe().reset_index()
        rows = []
        for row in frame[columns].itertuples(index=False, name=None):
            record = []
            for name, value in zip(columns, row):
                if name == axes["time"]:
                    record.append(str(np.datetime64(value, "ms")) + "Z")
                else:
                    number = float(value)
                    record.append(number if math.isfinite(number) else None)
            rows.append(record)
        units = ["UTC" if name == axes["time"] else next(d["units"] for d in dimensions if d["name"] == name) for name in selected.dims] + [v["units"] for v in variables]
        result = {"table": {"columnNames": columns, "columnUnits": units, "rows": rows}, "meta": {"title": str(original.attrs.get("title", "")), "dimensions": dimensions, "variables": variables, "attrs": {}}}
        print(json.dumps(result, allow_nan=False))

try:
    main()
except Exception as exc:
    print(json.dumps({"error": "NETCDF_VALIDATION", "message": str(exc)}))
    sys.exit(2)
