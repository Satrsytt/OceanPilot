import { describe, expect, it } from "vitest";
import type { DataSourceCheck } from "./tool-context.js";
import type { CandidateDraft, CandidateValidationContext } from "./candidate-plans.js";
import { candidateSignature, selectCandidates, validateCandidate } from "./candidate-plans.js";

const source = (dataset: string): DataSourceCheck => ({
  dataset, pageUrl: `https://example.org/${dataset}`, dataUrl: `https://example.org/${dataset}.nc`,
  status: "available", reason: "local mock", checkedAt: "2026-10-26T00:00:00Z",
});

const context: CandidateValidationContext = {
  retrievalDecision: { queryId: "task", state: "bundle_required", reason: "mock",
    bundles: [{ datasetIds: ["sst", "wind"], requirementIds: ["r_sst", "r_wind"],
      evidenceRefs: ["source:sst", "source:wind"],
      score: { coveredEssential: 2, datasetCount: 2, uncertainCapabilities: 0 },
      scientificFeasibility: "supported_by_card_metadata" }],
    missingRequirements: [], uncertainRequirements: [], assessments: [], matches: [],
    recoveryQueries: [], corpusStatus: "supported_by_current_corpus" },
  allowedTools: new Set(["read", "powershell", "complete_research_plan"]),
  dataSourceChecks: new Map([["sst", source("sst")], ["wind", source("wind")]]),
};

function draft(id = "a", methodFamily: CandidateDraft["methodFamily"] = "statistical"): CandidateDraft {
  return {
    draftId: id, title: `Plan ${id}`, objective: "估计海温和风速关系",
    methodFamily, scientificFocus: "trend", executionMode: "lightweight",
    datasets: ["sst", "wind"], datasetRoles: { sst: "target", wind: "predictor" },
    requiredInputs: ["SST", "wind"], assumptions: ["时间网格可对齐"],
    evidenceNeeds: [], evidenceRefs: ["source:sst"],
    steps: [
      { id: "D", title: "读取数据", description: "核对变量和时间", phase: "data", tool: "read",
        dependsOn: [], expectedOutputs: ["数据清单"], risks: [] },
      { id: "A", title: "分析", description: "计算统计量", phase: "analysis", tool: "powershell",
        dependsOn: ["D"], expectedOutputs: ["统计结果"], risks: [] },
      { id: "V", title: "验证", description: "交叉验证", phase: "validation", tool: "powershell",
        dependsOn: ["A"], expectedOutputs: ["验证报告"], risks: [] },
      { id: "O", title: "交付", description: "核验产物", phase: "artifact", tool: "complete_research_plan",
        dependsOn: ["V"], expectedOutputs: ["报告"], risks: [] },
    ],
    deliverables: ["报告"], risks: ["缺测"],
    tradeoffs: { advantages: ["成本低"], risks: ["相关不等于因果"] },
    estimatedResources: { dataGb: 2, computeHours: 1 },
  };
}

describe("candidate plan validation and selection with local mocks", () => {
  it("returns exactly one feasible plan when only one passes", () => {
    const valid = validateCandidate(draft(), context).candidate!;
    expect(selectCandidates([valid])).toHaveLength(1);
  });

  it("preserves different method families on the same data route", () => {
    const first = validateCandidate(draft("a", "statistical"), context).candidate!;
    const second = validateCandidate(draft("b", "mechanistic"), context).candidate!;
    expect(candidateSignature(first)).not.toBe(candidateSignature(second));
    expect(selectCandidates([first, second])).toHaveLength(2);
  });

  it("deduplicates textually different copies of one method and route", () => {
    const first = validateCandidate(draft("a"), context).candidate!;
    const copy = draft("b"); copy.title = "Another wording";
    const second = validateCandidate(copy, context).candidate!;
    expect(selectCandidates([first, second])).toHaveLength(1);
  });

  it("retains different DAG dependency structures", () => {
    const first = validateCandidate(draft("a"), context).candidate!;
    const alternative = draft("b");
    alternative.steps[2]!.dependsOn = ["A", "D"];
    const second = validateCandidate(alternative, context).candidate!;
    expect(candidateSignature(first)).not.toBe(candidateSignature(second));
  });

  it("rejects a plan missing a required dataset", () => {
    const incomplete = draft(); incomplete.datasets = ["sst"]; incomplete.datasetRoles = { sst: "target" };
    expect(validateCandidate(incomplete, context).errors).toContain("数据路线未通过 Requirement/Bundle 能力检查");
  });

  it("rejects tools that do not exist in the execution environment", () => {
    const missing = draft(); missing.steps[1]!.tool = "imaginary_solver";
    expect(validateCandidate(missing, context).errors.some((item) => item.includes("imaginary_solver"))).toBe(true);
  });

  it("rejects cyclic DAGs", () => {
    const cycle = draft(); cycle.steps[0]!.dependsOn = ["O"];
    expect(validateCandidate(cycle, context).errors).toContain("DAG 存在环");
  });

  it("rejects missing scientific validation", () => {
    const missing = draft(); missing.steps[2]!.phase = "analysis";
    expect(validateCandidate(missing, context).errors.some((item) => item.includes("validation"))).toBe(true);
  });

  it("does not accept a search tool as an analysis step", () => {
    const invalid = draft(); invalid.steps[1]!.tool = "search_official_web";
    const errors = validateCandidate(invalid, { ...context,
      allowedTools: new Set([...context.allowedTools, "search_official_web"]) }).errors;
    expect(errors.some((item) => item.includes("不能充当分析"))).toBe(true);
  });

  it("rejects unavailable raw data and unverified evidence", () => {
    const blocked = draft(); blocked.evidenceRefs = ["invented:paper"];
    const checks = new Map(context.dataSourceChecks);
    checks.set("wind", { ...source("wind"), status: "metadata_only" });
    const errors = validateCandidate(blocked, { ...context, dataSourceChecks: checks }).errors;
    expect(errors.some((item) => item.includes("metadata_only"))).toBe(true);
    expect(errors.some((item) => item.includes("invented:paper"))).toBe(true);
  });
});
