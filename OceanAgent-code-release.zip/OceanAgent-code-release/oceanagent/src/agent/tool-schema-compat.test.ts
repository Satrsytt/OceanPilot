import { resolve } from "node:path";
import {
  createEditToolDefinition, createReadToolDefinition, createWriteToolDefinition,
  type ModelRuntime, type ToolDefinition,
} from "@earendil-works/pi-coding-agent";
import { Type } from "typebox";
import { describe, expect, it, vi } from "vitest";
import type { ResearchPlan } from "../contracts.js";
import { loadConfig } from "../config.js";
import type { RagService } from "../rag/rag-service.js";
import type { OfficialWebSearch } from "../web-search.js";
import { createOceanModelRuntime } from "./model.js";
import { createPlatformCoreToolOverrides } from "./session-factory.js";
import type { OceanToolContext } from "./tool-context.js";
import { ACTIVE_TOOL_NAMES, createOceanTools } from "./tools/index.js";
import { createCompleteResearchPlanTool } from "./tools/complete-research-plan.js";
import { createRecordDatasetReadTool } from "./tools/record-dataset-read.js";
import { createSubagentTool } from "./tools/subagent.js";
import {
  installToolSchemaCompatibility, normalizeDeepSeekSchema, normalizeDeepSeekToolPayload,
  scanDeepSeekToolSchemas,
} from "./tool-schema-compat.js";

type JsonObject = Record<string, any>;
const functionPayload = (parameters: unknown, strict = false) => ({ tools: [{ type: "function",
  function: { name: "fixture", parameters, strict } }] });
const bboxSchema = () => Type.Object({ bbox: Type.Tuple([
  Type.Number(), Type.Number(), Type.Number(), Type.Number(),
], { description: "[west,south,east,north]", minItems: 4, maxItems: 4 }) });

/** The actual registration superset, with no tool execution, credentials or card reads. */
function registeredTools(): ToolDefinition[] {
  const root = resolve(import.meta.dirname, "../..");
  const neverExecute = vi.fn(() => { throw new Error("Schema scan must not access data or credentials"); });
  const rag = { getDatasetCards: neverExecute } as unknown as RagService;
  const web = { search: neverExecute } as unknown as OfficialWebSearch;
  const context: OceanToolContext = { workspacePath: root, requiresDataValidation: true,
    recommendationOnly: true,
    dataDiscoveryOnly: false, knowledgeGroundingRequired: true, knowledgeGrounded: false,
    adaptiveRetrievalEnabled: true, multiplePlansEnabled: true, webSearchAttempted: false,
    dataSourceChecks: new Map(), addCitation: neverExecute, createPlan: neverExecute,
    setTerminalAction: neverExecute };
  const config = loadConfig(root);
  return [
    createReadToolDefinition(root), createEditToolDefinition(root), createWriteToolDefinition(root),
    ...createPlatformCoreToolOverrides(root, root),
    ...createOceanTools(rag, web, context, config),
    createSubagentTool({ cwd: root, model: "schema-only", timeoutMs: 1000, projectContext: "",
      toolNames: [], tools: () => [], factory: { createSession: neverExecute } as never }),
    createCompleteResearchPlanTool({ workspace: root, publicationRoot: resolve(root, "data/artifacts"),
      runId: "schema-only", approved: false, local: true, onComplete: neverExecute }),
    createRecordDatasetReadTool(root, { datasets: [], steps: [] } as unknown as ResearchPlan, () => false),
  ];
}

describe("DeepSeek outgoing tool-schema compatibility", () => {
  it("converts numeric tuple items without weakening the original execution schema", () => {
    const original = bboxSchema(); const before = structuredClone(original);
    const normalized = normalizeDeepSeekSchema(original) as JsonObject;
    expect(normalized.properties.bbox.items).toEqual({ type: "number" });
    expect(normalized.properties.bbox).not.toHaveProperty("minItems");
    expect(normalized.properties.bbox).not.toHaveProperty("maxItems");
    expect(normalized.properties.bbox.description).toContain("west,south,east,north");
    expect(original).toEqual(before);
    expect(Array.isArray(original.properties.bbox.items)).toBe(true);
    expect(original.properties.bbox.minItems).toBe(4);
    const implicitTuple = Type.Tuple([Type.Number(), Type.Number(), Type.Number(), Type.Number()]);
    expect((normalizeDeepSeekSchema(implicitTuple) as JsonObject).description).toContain("exactly 4");
    expect(implicitTuple.additionalItems).toBe(false);
  });

  it("removes strict-only bounds from model schemas while retaining numeric and object rules", () => {
    const original = { type: "object", additionalProperties: false, required: ["bbox", "label"], properties: {
      bbox: { type: "array", items: { type: "number", minimum: -180, maximum: 180 }, minItems: 4, maxItems: 4 },
      label: { type: "string", minLength: 1, maxLength: 50 },
    } };
    const payload = normalizeDeepSeekToolPayload(functionPayload(original, true)) as JsonObject;
    const fn = payload.tools[0].function;
    expect(fn.strict).toBe(true);
    expect(fn.parameters).toMatchObject({ type: "object", additionalProperties: false,
      required: ["bbox", "label"], properties: { bbox: { items: { type: "number", minimum: -180, maximum: 180 } }, label: { type: "string" } } });
    expect(fn.parameters.properties.bbox).not.toHaveProperty("minItems");
    expect(fn.parameters.properties.bbox).not.toHaveProperty("maxItems");
    expect(fn.parameters.properties.label).not.toHaveProperty("minLength");
    expect(fn.parameters.properties.label).not.toHaveProperty("maxLength");
    expect(scanDeepSeekToolSchemas(payload, true)).toEqual([]);
    expect(original.properties.bbox.minItems).toBe(4);
    expect(original.properties.label.minLength).toBe(1);
  });

  it("rejects strict arbitrary dictionaries locally rather than silently deleting their meaning", () => {
    const original = { type: "object", additionalProperties: false, required: ["inputs"], properties: {
      inputs: { type: "object", additionalProperties: { type: "number" } },
    } };
    expect(() => normalizeDeepSeekToolPayload(functionPayload(original, true))).toThrow(/additionalProperties/);
    expect(original.properties.inputs.additionalProperties).toEqual({ type: "number" });
  });

  it("does not mistake property names, enum values or default data for schema keywords", () => {
    const data = { items: [{ type: "number" }], minItems: 4, maxLength: 12 };
    const original = { type: "object", properties: {
      minItems: { type: "number", minimum: 4 },
      enum: { type: "object", enum: [data], default: data },
      default: { type: "array", items: { type: "number" }, minItems: 2 },
    } };
    const normalized = normalizeDeepSeekSchema(original) as JsonObject;
    expect(normalized.properties.minItems).toEqual({ type: "number", minimum: 4 });
    expect(normalized.properties.enum.enum).toEqual([data]);
    expect(normalized.properties.enum.default).toEqual(data);
    expect(normalized.properties.default.items).toEqual({ type: "number" });
    expect(normalized.properties.default).not.toHaveProperty("minItems");
    expect(scanDeepSeekToolSchemas(functionPayload(normalized))).toEqual([]);
  });

  it("normalizes after existing callbacks for both stream entry points and leaves other providers alone", async () => {
    const received: Array<{ onPayload?: (payload: unknown, model: unknown) => unknown }> = [];
    const originalStream = vi.fn((_model, _context, options) => { received.push(options); return {} as never; });
    const runtime = { stream: originalStream, streamSimple: originalStream } as unknown as ModelRuntime;
    installToolSchemaCompatibility(runtime); installToolSchemaCompatibility(runtime);
    const model = { provider: "deepseek", baseUrl: "https://api.deepseek.com", api: "openai-completions" } as
      Parameters<ModelRuntime["streamSimple"]>[0];
    const previous = vi.fn(async () => ({ ...functionPayload(bboxSchema()), marker: "previous-callback" }));
    for (const method of ["stream", "streamSimple"] as const) {
      runtime[method](model, { messages: [] }, { onPayload: previous });
      const transformed = await received.at(-1)!.onPayload!({}, model) as JsonObject;
      expect(transformed.marker).toBe("previous-callback");
      expect(transformed.tools[0].function.parameters.properties.bbox.items).toEqual({ type: "number" });
    }
    expect(previous).toHaveBeenCalledTimes(2);
    const options = { onPayload: previous };
    runtime.streamSimple({ ...model, provider: "openai", baseUrl: "https://api.openai.com/v1" }, { messages: [] }, options);
    expect(received.at(-1)).toBe(options);
  });

  it("scans every registered tool after the actual SDK serializes the final HTTP body", async () => {
    const tools = registeredTools();
    expect(tools).toHaveLength(23);
    expect([...tools.map(tool => tool.name)].sort()).toEqual([...ACTIVE_TOOL_NAMES].sort());
    const originalAcquisition = tools.find(tool => tool.name === "acquire_scientific_data")!;
    const executionSchemaBefore = structuredClone(originalAcquisition.parameters);
    const { runtime } = await createOceanModelRuntime();
    const catalogModel = runtime.getModels("deepseek").find(model => model.api === "openai-completions")!;
    expect(catalogModel).toBeDefined();
    let requestBody: JsonObject | undefined, beforeCompatibility: unknown;
    const transport = vi.fn<typeof globalThis.fetch>(async (_input, options) => {
      requestBody = JSON.parse(String(options?.body));
      const chunk = (delta: unknown, finish_reason: string | null) => JSON.stringify({
        id: "schema-fixture", object: "chat.completion.chunk", created: 1, model: catalogModel.id,
        choices: [{ index: 0, delta, finish_reason }],
      });
      return new Response(`data: ${chunk({ role: "assistant", content: "OK" }, null)}\n\ndata: ${chunk({}, "stop")}\n\ndata: [DONE]\n\n`,
        { status: 200, headers: { "Content-Type": "text/event-stream" } });
    });
    const response = await runtime.streamSimple({ ...catalogModel, reasoning: false }, {
      messages: [{ role: "user", content: "Reply OK. Do not call tools.", timestamp: 1 }],
      tools: tools.map(tool => ({ name: tool.name, description: tool.description, parameters: tool.parameters })),
    }, { apiKey: "schema-fixture-not-a-real-key", maxTokens: 32, maxRetries: 0, fetch: transport,
      onPayload(payload) { beforeCompatibility = payload; } }).result();
    expect(transport).toHaveBeenCalledTimes(1);
    expect(response.stopReason).not.toBe("error");
    expect(requestBody?.tools).toHaveLength(23);
    expect(scanDeepSeekToolSchemas(requestBody)).toEqual([]);
    expect(JSON.stringify(requestBody!.tools)).not.toMatch(/"items"\s*:\s*\[/);
    expect(JSON.stringify(requestBody!.tools)).not.toMatch(/"(?:minItems|maxItems)"\s*:/);
    const acquisition = requestBody!.tools.find((tool: JsonObject) => tool.function?.name === "acquire_scientific_data").function;
    expect(acquisition.parameters.properties.datasets.items.properties.bbox.items).toEqual({ type: "number" });
    expect(acquisition.parameters.properties.datasets.items.properties.bbox).not.toHaveProperty("minItems");
    expect(acquisition.parameters.properties.datasets.items.properties.bbox).not.toHaveProperty("maxItems");
    expect(acquisition.strict).toBe(false);
    expect(originalAcquisition.parameters).toEqual(executionSchemaBefore);
    // Capture happens before compatibility, proving the same SDK path used by actual model calls was exercised.
    expect(beforeCompatibility).toBeDefined();
    const beforeAcquire = (beforeCompatibility as JsonObject).tools
      .find((tool: JsonObject) => tool.function?.name === "acquire_scientific_data").function;
    expect(Array.isArray(beforeAcquire.parameters.properties.datasets.items.properties.bbox.items)).toBe(true);
  });
});
