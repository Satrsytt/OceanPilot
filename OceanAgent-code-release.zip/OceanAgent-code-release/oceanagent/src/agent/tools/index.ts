import type { AppConfig } from "../../config.js";
import type { RagService } from "../../rag/rag-service.js";
import type { OfficialWebSearch } from "../../web-search.js";
import type { OceanToolContext } from "../tool-context.js";
import { createOceanKnowledgeTools } from "./search-ocean-knowledge.js";
import { createSearchOfficialWebTool } from "./search-official-web.js";
import { createCheckOfficialDataSourceTool } from "./check-official-data-source.js";
import { createAcquireScientificDataTool } from "./acquire-scientific-data.js";
import { createProposeResearchPlanTool, createReportDataBlockedTool, createRequestClarificationTool } from "./workflow-tools.js";
import { createRunRemoteCommandTool, type ProjectRemoteTarget } from "./run-remote-command.js";
import { createReportResearchReasoningTool } from "./report-research-reasoning.js";
import { createCandidatePlansTool } from "./candidate-plans.js";
import { createSubmitDatasetRecommendationTool } from "./submit-dataset-recommendation.js";

export const OCEAN_TOOL_NAMES = [
  "submit_dataset_recommendation",
  "search_research_cases",
  "expand_research_case",
  "search_ocean_datasets",
  "assess_dataset_routes",
  "get_dataset_facts",
  "trace_global_knowledge_graph",
  "search_official_web",
  "check_official_data_source",
  "acquire_scientific_data",
  "report_research_reasoning",
  "request_clarification",
  "report_data_blocked",
  "propose_research_plan",
  "propose_candidate_plans",
  "run_remote_command",
  "subagent",
  "complete_research_plan",
  "record_dataset_read",
];

export const LOCAL_SHELL_TOOL_NAME = process.platform === "win32" ? "powershell" : "bash";
export const PI_CORE_TOOL_NAMES = ["read", LOCAL_SHELL_TOOL_NAME, "edit", "write"] as const;

export const ACTIVE_TOOL_NAMES = [
  ...PI_CORE_TOOL_NAMES,
  ...OCEAN_TOOL_NAMES,
];

export function createOceanTools(
  rag: RagService,
  webSearch: OfficialWebSearch,
  context: OceanToolContext,
  config: AppConfig,
  remoteTarget?: ProjectRemoteTarget,
) {
  return [
    ...(context.recommendationOnly ? [createSubmitDatasetRecommendationTool(context)] : []),
    ...createOceanKnowledgeTools(rag, context),
    createSearchOfficialWebTool(webSearch, context),
    createCheckOfficialDataSourceTool(context),
    createAcquireScientificDataTool(rag, context, config.rootDir),
    createReportResearchReasoningTool(),
    createRequestClarificationTool(context),
    createReportDataBlockedTool(context),
    createProposeResearchPlanTool(context),
    ...(context.multiplePlansEnabled ? [createCandidatePlansTool(context)] : []),
    createRunRemoteCommandTool(config, remoteTarget),
  ];
}
