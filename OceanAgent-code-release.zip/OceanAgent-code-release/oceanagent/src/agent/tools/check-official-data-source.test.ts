import { beforeEach, describe, expect, it, vi } from "vitest";
import type { ResearchPlan } from "../../contracts.js";
import type { DataSourceCheck, OceanToolContext } from "../tool-context.js";

const { probeMock } = vi.hoisted(() => ({ probeMock: vi.fn() }));
vi.mock("../../data-access/safe-http.js", async importOriginal => ({
  ...await importOriginal<typeof import("../../data-access/safe-http.js")>(), safeProbe: probeMock,
}));
import { createCheckOfficialDataSourceTool } from "./check-official-data-source.js";

beforeEach(() => { probeMock.mockReset(); });
const pageUrl = "https://www.ncei.noaa.gov/products/optimum-interpolation-sst";
const dataUrl = "https://coastwatch.pfeg.noaa.gov/erddap/griddap/ncdcOisst21Agg_LonPM180.json?sst[0][0][0][0]";
const params = { dataset: "sst", pageUrl, dataUrl };
const response = (status: number, url: string, contentType: string) => ({ status, url, contentType, preview: "" });
function context(): OceanToolContext {
  return { workspacePath: "/tmp/ocean-probe-test", requiresDataValidation: true, dataDiscoveryOnly: false,
    knowledgeGroundingRequired: false, knowledgeGrounded: false, webSearchAttempted: false,
    dataSourceChecks: new Map(), addCitation: vi.fn(), setTerminalAction: vi.fn(),
    createPlan: vi.fn(() => ({} as ResearchPlan)) };
}

describe("official data-source probe status", () => {
  it("accepts verified product metadata for discovery while retaining authenticated data status", async () => {
    probeMock.mockResolvedValueOnce(response(200, pageUrl, "text/html"))
      .mockResolvedValueOnce(response(401, dataUrl, "application/json"));
    const ctx = context(); ctx.dataDiscoveryOnly = true;
    const result = await createCheckOfficialDataSourceTool(ctx)
      .execute("discovery", params, undefined, undefined, {} as never);
    expect(result.details.status).toBe("metadata_only");
    expect(result.details.reason).toContain("数据入口 HTTP 401");
    expect(result.details.validated).toBeUndefined();
  });
  it("keeps the authentication gate for real acquisition and execution", async () => {
    probeMock.mockResolvedValueOnce(response(200, pageUrl, "text/html"))
      .mockResolvedValueOnce(response(401, dataUrl, "application/json"));
    const result = await createCheckOfficialDataSourceTool(context())
      .execute("execute", params, undefined, undefined, {} as never);
    expect(result.details.status).toBe("requires_access");
  });
  it("keeps a usable data endpoint when its separate product page is unreachable", async () => {
    probeMock.mockRejectedValueOnce(new Error("product page network failure"))
      .mockResolvedValueOnce(response(200, dataUrl, "application/json"));
    const ctx = context();
    const result = await createCheckOfficialDataSourceTool(ctx)
      .execute("probe", params, undefined, undefined, {} as never);
    expect(result.details.status).toBe("available");
    expect(result.details.reason).toContain("产品页 HTTP 0");
    expect(result.details.reason).toContain("数据入口 HTTP 200");
    expect(result.details.validated).toBeUndefined(); // HTTP availability alone cannot satisfy Plan data validation.
  });

  it("does not present HTTP 403 as proof that user authentication is required", async () => {
    probeMock.mockResolvedValueOnce(response(200, pageUrl, "text/html"))
      .mockResolvedValueOnce(response(403, dataUrl, "text/plain"));
    const ctx = context();
    const result = await createCheckOfficialDataSourceTool(ctx)
      .execute("probe", params, undefined, undefined, {} as never);
    expect(result.details.status).toBe("unavailable");
    expect(result.details.reason).toContain("HTTP 403");
    expect(ctx.addCitation).not.toHaveBeenCalled();
  });

  it("does not downgrade previously validated local data after a later page probe fails", async () => {
    probeMock.mockResolvedValueOnce(response(503, pageUrl, "text/html"))
      .mockResolvedValueOnce(response(404, dataUrl, "text/plain"));
    const ctx = context();
    const verified: DataSourceCheck = { dataset: "sst", pageUrl, dataUrl, status: "available",
      reason: "downloaded and scientifically validated", checkedAt: "2026-10-29T00:00:00Z",
      validated: true, localPath: "/tmp/ocean-probe-test/data/scientific-cache/sst.json", sha256: "verified-sha" };
    ctx.dataSourceChecks.set("sst", verified);
    const result = await createCheckOfficialDataSourceTool(ctx)
      .execute("probe", params, undefined, undefined, {} as never);
    expect(result.details).toBe(verified);
    expect(ctx.dataSourceChecks.get("sst")).toBe(verified);
  });
});
