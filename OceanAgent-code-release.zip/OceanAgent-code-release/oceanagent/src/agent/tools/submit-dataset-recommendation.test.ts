import { mkdtemp, rm, readFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createHash } from "node:crypto";
import { afterEach, describe, expect, it, vi } from "vitest";
import { createSubmitDatasetRecommendationTool, validateDatasetIdentifier } from "./submit-dataset-recommendation.js";
import { experimentRecommendation, withExperimentUnit } from "../../experiments/runtime-context.js";
import type { Stage3UnitSpec } from "../../experiments/paired-dev.js";
import { RunTelemetry, withRunTelemetry, redactTelemetry } from "../../telemetry/run-telemetry.js";
import { stage3CanonicalJson } from "../../experiments/paired-dev.js";
import type { OceanToolContext } from "../tool-context.js";
const dirs: string[] = [];
afterEach(async () => { for (const p of dirs.splice(0)) await rm(p, { recursive: true, force: true }); });
const candidate = { datasetId: "unresolved_product", sourceUrls: [], capabilities: ["surface_temperature"], roles: ["input"], rationale: "Unverified identity", evidenceIds: [] };
async function fixture() {
  const path = await mkdtemp(join(tmpdir(), "stage3-recommendation-")); dirs.push(path);
  const trace = new RunTelemetry(path, { taskId: "test", runId: "test-run", model: "test::not-executed", provider: "test",
    inputHash: "test", configHash: "test", gitCommit: null, datasetSnapshot: null, knowledgeSnapshot: null, knowledgeMode: "off", runKind: "test" });
  const unit = { runtime_config: { protocol_version: "stage3-scientific-v2", mode: "recommendation" } } as Stage3UnitSpec;
  const context = { recommendationOnly: true, setTerminalAction: vi.fn() } as unknown as OceanToolContext;
  const run = (items: typeof candidate[]) => withExperimentUnit(unit, () => withRunTelemetry(trace,
    () => createSubmitDatasetRecommendationTool(context).execute("test", { candidates: items }, undefined, undefined, {} as never)));
  return { unit, context, trace, run };
}
describe("independent ordered recommendation contract", () => {
  it("rejects explanations in IDs instead of silently altering identity", () => {
    expect(() => validateDatasetIdentifier("era5（ERA5单层）")).toThrow("rationale");
    expect(() => validateDatasetIdentifier("era5 (official product)")).toThrow();
    expect(validateDatasetIdentifier("era5_single_levels")).toBe("era5_single_levels");
  });
  it("persists ordered claims, unknown identity and native recommendation independently of Plan", async () => {
    const f = await fixture(); const result = await f.run([candidate]); expect(result.terminate).toBe(true);
    expect(experimentRecommendation(f.unit)?.candidates[0]).toMatchObject({ rank: 1, dataset_id: candidate.datasetId,
      canonical_product_id: null, identity_status: "unresolved" });
    const output = JSON.parse(await readFile(join(f.trace.runDir, "recommendation.json"), "utf8"));
    expect(output.capability_semantics).toBe("model_claims_require_independent_judgment");
    expect(f.context.setTerminalAction).toHaveBeenCalledWith(expect.objectContaining({ type: "recommendation" }));
    expect(await readFile(f.trace.eventsPath, "utf8")).toContain("dataset_recommendation");
  });
  it("distinguishes explicit empty output from missing output and prevents replacement", async () => {
    const f = await fixture(); expect(experimentRecommendation(f.unit)).toBeUndefined();
    await f.run([]); expect(experimentRecommendation(f.unit)?.candidates).toEqual([]);
    await expect(f.run([candidate])).rejects.toThrow("ALREADY_SUBMITTED");
  });
  it("hashes the persisted representation after URL normalization and secret redaction", async () => {
    const f = await fixture();
    const rationale = "来源 https://www.noaa.gov/example）。中文说明；token=fixture-sensitive-value";
    await f.run([{ ...candidate, rationale }]);
    const output = JSON.parse(await readFile(join(f.trace.runDir, "recommendation.json"), "utf8"));
    expect(output.candidate_hash_semantics).toBe("redacted_canonical_json_v1");
    expect(output.candidate_sha256).toBe(createHash("sha256").update(stage3CanonicalJson(output.candidates)).digest("hex"));
    expect(redactTelemetry(output)).toEqual(output);
    expect(JSON.stringify(output)).not.toContain("fixture-sensitive-value");
    expect(experimentRecommendation(f.unit)).toEqual(output);
  });
  it("rejects duplicate IDs, unobserved citations and credentials", async () => {
    const f = await fixture();
    await expect(f.run([candidate, candidate])).rejects.toThrow("重复");
    await expect(f.run([{ ...candidate, evidenceIds: ["unretrieved_psc"] }])).rejects.toThrow("实际检索");
    await expect(f.run([{ ...candidate, sourceUrls: ["https://example.org/data?api_key=hidden"] }])).rejects.toThrow("无凭据");
    expect(experimentRecommendation(f.unit)).toBeUndefined();
  });
});
