import { createHash } from "node:crypto";
import { createReadStream, realpathSync } from "node:fs";
import { stat } from "node:fs/promises";
import { isAbsolute } from "node:path";
import { defineTool } from "@earendil-works/pi-coding-agent";
import { Type } from "typebox";
import type { ResearchPlan } from "../../contracts.js";
import { workspaceFile } from "./complete-research-plan.js";

export type DatasetIdentitySource = "dataset_card" | "validated_public_data";

/** A0 may use verified official data, but must never perform a hidden DatasetCard lookup. */
export function datasetReadIdentity(plan: ResearchPlan, datasetId: string, path: string,
  sha256: string, sizeBytes: number, isDatasetCard: (datasetId: string) => boolean): DatasetIdentitySource {
  const metadata = plan as ResearchPlan & { ablationCondition?: string; experiment?: { condition?: string } };
  const noKnowledge = plan.knowledgeMode === "off" || metadata.ablationCondition === "A0"
    || metadata.experiment?.condition === "A0";
  if (!noKnowledge && isDatasetCard(datasetId)) return "dataset_card";
  const verified = plan.verifiedDataSources?.some(source => {
    if (source.dataset !== datasetId || source.validated !== true || source.status !== "available"
      || !source.localPath || !isAbsolute(source.localPath) || source.sha256 !== sha256
      || source.bytes !== undefined && source.bytes !== sizeBytes) return false;
    try { return realpathSync(source.localPath) === realpathSync(path); } catch { return false; }
  });
  if (verified) return "validated_public_data";
  throw new Error("当前数据既不是可用 DatasetCard，也未与 Plan 中已验证公开数据的路径和 SHA-256 完全匹配");
}

export function createRecordDatasetReadTool(workspace: string, plan: ResearchPlan,
  isDatasetCard: (datasetId: string) => boolean) {
  return defineTool({
    name: "record_dataset_read", label: "核验实际读取的数据产品",
    description: "仅在已批准 Plan 的本地执行中使用。读取项目内真实数据文件的全部字节，计算哈希并记录已选数据身份。身份可来自 DatasetCard，或 Plan 中路径、SHA-256 完全匹配的已验证公开数据；A0不读取知识库。文件无法访问、为空或身份不匹配时失败。",
    parameters: Type.Object({
      datasetId: Type.String({ description: "已批准 Plan.datasets 中的 DatasetCard ID 或已验证官方数据集 ID" }),
      file: Type.String({ description: "项目内实际读取的数据文件路径" }),
      planStepId: Type.Optional(Type.String({ description: "可选；真实对应的 Plan 步骤 ID" })),
    }),
    async execute(_toolCallId, params) {
      if (!plan.datasets.includes(params.datasetId)) throw new Error("该数据产品未进入已批准 Plan");
      if (params.planStepId && !plan.steps.some((step) => step.id === params.planStepId)) {
        throw new Error("Plan 步骤 ID 不存在");
      }
      const file = await workspaceFile(workspace, params.file);
      const info = await stat(file);
      if (!info.size) throw new Error("数据文件为空");
      const hash = createHash("sha256");
      let sizeBytes = 0;
      for await (const chunk of createReadStream(file)) {
        hash.update(chunk as Buffer);
        sizeBytes += (chunk as Buffer).length;
      }
      if (sizeBytes !== info.size) throw new Error("数据文件读取过程中发生变化");
      const sha256 = hash.digest("hex");
      const identity_source = datasetReadIdentity(plan, params.datasetId, file, sha256, sizeBytes, isDatasetCard);
      const details = { datasetId: params.datasetId, path: file, sha256, identity_source,
        sizeBytes, ...(params.planStepId ? { planStepId: params.planStepId } : {}) };
      return { content: [{ type: "text", text: `已读取 ${params.datasetId} 的本地文件并计算 SHA-256。` }], details };
    },
  });
}
