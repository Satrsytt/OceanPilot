import { createHash } from "node:crypto";
import { mkdtemp, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import type { ResearchPlan } from "../../contracts.js";
import type { AcquisitionResult, VerifiedDataset } from "../../data-access/acquire.js";
import { DataAccessError } from "../../data-access/safe-http.js";
import type { RagService } from "../../rag/rag-service.js";
import type { OceanToolContext } from "../tool-context.js";

const { acquireMock } = vi.hoisted(() => ({ acquireMock: vi.fn() }));
vi.mock("../../data-access/acquire.js", async () => ({
  ...await vi.importActual<typeof import("../../data-access/acquire.js")>("../../data-access/acquire.js"),
  acquireDatasets: acquireMock,
  DataAccessError: (await import("../../data-access/safe-http.js")).DataAccessError,
}));

import { cardAccessUrls, createAcquireScientificDataTool } from "./acquire-scientific-data.js";
import { createProposeResearchPlanTool, createReportDataBlockedTool } from "./workflow-tools.js";

const directories: string[] = [];
beforeEach(() => { acquireMock.mockReset(); });
afterEach(async () => { for (const dir of directories.splice(0)) await rm(dir, { recursive: true, force: true }); });

const sourceUrl = "https://coastwatch.pfeg.noaa.gov/erddap/griddap/ncdcOisst21Agg_LonPM180";
const request = { datasetId: "sst", variables: ["sst"], timeStart: "2022-05-01T00:00:00Z",
  timeEnd: "2022-05-02T23:59:59Z", bbox: [-123, 35, -122, 36] as [number, number, number, number] };
const draft = { objective: "检验加州近岸海温", datasets: ["sst"],
  steps: [{ id: "S1", title: "分析", description: "读取已验证切片并计算区域均值" }] };

function context(workspacePath = "/tmp/ocean-test"): OceanToolContext {
  return { workspacePath, requiresDataValidation: true, dataDiscoveryOnly: false,
    knowledgeGroundingRequired: false, knowledgeGrounded: false, webSearchAttempted: false,
    dataSourceChecks: new Map(), addCitation: vi.fn(), setTerminalAction: vi.fn(),
    createPlan: vi.fn(input => ({ ...input, id: "plan", conversationId: "conversation", version: 1,
      status: "awaiting_approval", createdAt: new Date().toISOString() }) as ResearchPlan) };
}
const rag = { getDatasetCards: (ids: string[]) => ids.map(id => ({ id, payload: { access: { url: sourceUrl } } })) } as unknown as RagService;

async function dataset(workspace: string): Promise<VerifiedDataset> {
  const bytes = Buffer.from(JSON.stringify({ table: { columnNames: ["time", "latitude", "longitude", "sst"],
    rows: [["2022-05-01T12:00:00Z", 35.5, -122.5, 15]] } }));
  const path = join(workspace, "sst.json"); await writeFile(path, bytes);
  return { datasetId: "sst", path, bytes: bytes.length, sha256: createHash("sha256").update(bytes).digest("hex"),
    sourceUrl, protocol: "griddap", variables: ["sst"], cacheHit: false, transformations: ["longitude normalized"],
    metadata: { title: "OISST", dimensions: [], attrs: {}, variables: [] },
    validation: { valid: true, rowCount: 1, validSamples: { sst: 1 }, missingSamples: { sst: 0 },
      units: { sst: "degree_C" }, timeRange: ["2022-05-01T12:00:00Z", "2022-05-01T12:00:00Z"],
      bbox: [-122.5, 35.5, -122.5, 35.5], resolution: {}, warnings: [] } };
}
function result(asset: VerifiedDataset): AcquisitionResult {
  return { datasets: [asset], downloadedBytes: asset.bytes, compatibility: {
    timeOverlap: asset.validation.timeRange, bbox: asset.validation.bbox,
    transformations: ["native grid retained; no interpolation"], warnings: [] } };
}

describe("scientific-data tool integration", () => {
  it("preserves raw four-number arguments and rejects malformed bboxes before SDK coercion or side effects", async () => {
    const getDatasetCards = vi.fn(() => { throw new Error("Invalid bbox must be rejected before retrieval"); });
    const ctx = context();
    const tool = createAcquireScientificDataTool({ getDatasetCards } as unknown as RagService, ctx);
    const valid = { datasets: [request] };
    expect(tool.prepareArguments?.(valid)).toBe(valid);
    for (const bbox of [[-123,35,-122],[-123,35,-122,36,0],[-123,"35",-122,36],[-123,null,-122,36],[-123,false,-122,36],[-123,NaN,-122,36],[-123,37,-122,36]]) {
      const invalid = { datasets: [request, { ...request, bbox }] };
      expect(() => tool.prepareArguments?.(invalid)).toThrow(/bbox/);
      await expect(tool.execute("invalid", invalid as never, undefined, undefined, {} as never)).rejects.toThrow(/bbox/);
    }
    expect(getDatasetCards).not.toHaveBeenCalled();
    expect(acquireMock).not.toHaveBeenCalled();
    expect(ctx.dataAcquisitionAttempts).toBeUndefined();
  });
  it("does not read DatasetCards behind the acquisition tool in knowledge-off mode", async () => {
    const workspace = await mkdtemp(join(tmpdir(), "ocean-off-acquire-")); directories.push(workspace);
    const ctx = context(workspace); ctx.knowledgeAccessEnabled = false;
    const getDatasetCards = vi.fn(() => { throw new Error("Knowledge access must be isolated"); });
    acquireMock.mockResolvedValue(result(await dataset(workspace)));
    await createAcquireScientificDataTool({ getDatasetCards } as unknown as RagService, ctx)
      .execute("off-acquire", { datasets: [{ ...request, urls: [sourceUrl] }] }, undefined, undefined, {} as never);
    expect(getDatasetCards).not.toHaveBeenCalled();
    expect(ctx.dataSourceChecks.get("sst")?.validated).toBe(true);
  });
  it("finds nested DatasetCard access URLs without treating credential fields as entrances", () => {
    expect(cardAccessUrls({ access: [{ url: "http://example.noaa.gov/data.nc" },
      { evidence: "Official: https://example.noaa.gov/catalog.html。" }],
      api_key: "https://secret.example.noaa.gov/key", credentials: { url: "https://secret.example.noaa.gov/login" } }))
      .toEqual(["https://example.noaa.gov/data.nc", "https://example.noaa.gov/catalog.html"]);
  });

  it("rejects a URL-only Plan, then passes the acquired local file and verification into Plan", async () => {
    const workspace = await mkdtemp(join(tmpdir(), "ocean-acquire-tool-")); directories.push(workspace);
    const ctx = context(workspace);
    ctx.webSearchAttempted = true;
    ctx.dataSourceChecks.set("sst", { dataset: "sst", pageUrl: sourceUrl, dataUrl: sourceUrl,
      status: "available", checkedAt: new Date().toISOString(), reason: "HTTP 200" });
    const plan = createProposeResearchPlanTool(ctx);
    await expect(plan.execute("plan-before", draft, undefined, undefined, {} as never)).rejects.toThrow("本地验证");
    expect(ctx.createPlan).not.toHaveBeenCalled();

    const asset = await dataset(workspace); acquireMock.mockResolvedValue(result(asset));
    const acquired = await createAcquireScientificDataTool(rag, ctx)
      .execute("acquire", { datasets: [request] }, undefined, undefined, {} as never);
    expect(acquired.details).toMatchObject({ datasets: [{ path: asset.path, sha256: asset.sha256 }] });
    expect(acquireMock.mock.calls[0]?.[0]).toMatchObject([{ datasetId: "sst", urls: [sourceUrl] }]);
    await plan.execute("plan-after", draft, undefined, undefined, {} as never);
    expect(ctx.createPlan).toHaveBeenCalledWith(expect.objectContaining({ verifiedDataSources: [
      expect.objectContaining({ dataset: "sst", validated: true, localPath: asset.path, sha256: asset.sha256,
        validation: { dataset: asset.validation, compatibility: result(asset).compatibility } }),
    ] }));
  });

  it("keeps a public timeout recoverable and rejects passing the download to the user", async () => {
    const ctx = context();
    ctx.dataSourceChecks.set("sst", { dataset: "sst", pageUrl: sourceUrl, status: "available",
      checkedAt: new Date().toISOString(), reason: "a previous smaller request", validated: true,
      localPath: "/tmp/previous-slice.json" });
    acquireMock.mockImplementation(async (_requests, options) => {
      options.budget.used += 2048; // Metadata and failed partial responses consume the same run budget.
      throw new DataAccessError("TIMEOUT", "request timed out");
    });
    const acquire = createAcquireScientificDataTool(rag, ctx);
    const output = await acquire.execute("acquire", { datasets: [request] }, undefined, undefined, {} as never);
    expect(output.details).toMatchObject({ errorType: "TIMEOUT", requiresAuthentication: false });
    expect(ctx.dataSourceChecks.get("sst")?.status).toBe("unavailable");
    expect(ctx.dataSourceChecks.get("sst")?.validated).toBe(false);
    expect(ctx.dataAcquisitionBytes).toBe(2048);
    await acquire.execute("acquire-again", { datasets: [request] }, undefined, undefined, {} as never);
    expect(acquireMock.mock.calls[1]?.[1]).toMatchObject({ maxTotalBytes: 64 * 1024 * 1024 - 2048 });
    expect(ctx.dataAcquisitionBytes).toBe(4096);
    await expect(createProposeResearchPlanTool(ctx).execute("stale-plan", draft,
      undefined, undefined, {} as never)).rejects.toThrow("本地验证");
    await expect(createReportDataBlockedTool(ctx).execute("blocked", { summary: "请自行下载并上传" },
      undefined, undefined, {} as never)).rejects.toThrow("没有真实认证需求");
  });

  it("attributes authentication only to the failed dataset and retains partial files without validating the combination", async () => {
    const workspace = await mkdtemp(join(tmpdir(), "ocean-acquire-partial-")); directories.push(workspace);
    const ctx = context(workspace); const sst = await dataset(workspace);
    const failure = new DataAccessError("AUTH_REQUIRED", "wind requires authorization", true);
    failure.datasetId = "wind"; failure.partialDatasets = [sst]; acquireMock.mockRejectedValue(failure);
    await createAcquireScientificDataTool(rag, ctx).execute("acquire", { datasets: [request,
      { ...request, datasetId: "wind", variables: ["x_wind"] }] }, undefined, undefined, {} as never);
    expect(ctx.dataSourceChecks.get("wind")?.status).toBe("requires_access");
    expect(ctx.dataSourceChecks.get("sst")).toMatchObject({ status: "available", validated: false,
      localPath: sst.path, sha256: sst.sha256 });
    await expect(createProposeResearchPlanTool(ctx).execute("partial-plan", { ...draft, datasets: ["sst", "wind"] },
      undefined, undefined, {} as never)).rejects.toThrow("本地验证");
  });
});
