import { randomUUID } from "node:crypto";
import { defineTool } from "@earendil-works/pi-coding-agent";
import { Type } from "typebox";
import { selectCandidates, validateCandidate } from "../candidate-plans.js";
import type { CandidateDraft } from "../candidate-plans.js";
import type { OceanToolContext } from "../tool-context.js";
import { normalizePlanSteps } from "./workflow-tools.js";

const StringList = Type.Array(Type.String({ minLength: 1, maxLength: 600 }), { maxItems: 20 });
const MethodFamily = Type.Union([
  Type.Literal("statistical"), Type.Literal("event_detection"), Type.Literal("mechanistic"),
  Type.Literal("machine_learning"), Type.Literal("data_assimilation"), Type.Literal("comparative"),
]);
const Focus = Type.Union([
  Type.Literal("trend"), Type.Literal("event"), Type.Literal("attribution"),
  Type.Literal("prediction"), Type.Literal("mapping"), Type.Literal("validation"),
]);
const Mode = Type.Union([
  Type.Literal("lightweight"), Type.Literal("full_resolution"), Type.Literal("ensemble"),
]);

export function createCandidatePlansTool(context: OceanToolContext) {
  return defineTool({
    name: "propose_candidate_plans",
    label: "生成并筛选多条科研规划",
    description: "提交最多六条具有方法或数据路线差异的候选；系统核验 DAG、数据能力、工具、官方来源、验证和产物，仅保留少量可行且不重复的 ResearchPlan。",
    parameters: Type.Object({
      candidates: Type.Array(Type.Object({
        draftId: Type.String({ minLength: 1, maxLength: 80 }),
        title: Type.String({ minLength: 1, maxLength: 120 }),
        objective: Type.String({ minLength: 1, maxLength: 1200 }),
        methodFamily: MethodFamily,
        scientificFocus: Focus,
        executionMode: Mode,
        datasets: Type.Array(Type.String({ minLength: 1 }), { maxItems: 6 }),
        datasetRoles: Type.Record(Type.String(), Type.String({ minLength: 1, maxLength: 120 })),
        requiredInputs: StringList,
        assumptions: StringList,
        evidenceNeeds: StringList,
        evidenceRefs: StringList,
        steps: Type.Array(Type.Object({
          id: Type.String({ minLength: 1, maxLength: 80 }),
          title: Type.String({ minLength: 1, maxLength: 150 }),
          description: Type.String({ minLength: 1, maxLength: 1500 }),
          phase: Type.Union([Type.Literal("data"), Type.Literal("analysis"),
            Type.Literal("validation"), Type.Literal("artifact")]),
          tool: Type.String({ minLength: 1, maxLength: 100 }),
          inputs: Type.Optional(Type.Record(Type.String(), Type.Unknown())),
          dependsOn: Type.Array(Type.String(), { maxItems: 20 }),
          expectedOutputs: StringList,
          risks: StringList,
        }), { minItems: 3, maxItems: 20 }),
        deliverables: StringList,
        risks: StringList,
        tradeoffs: Type.Object({ advantages: StringList, risks: StringList }),
        estimatedResources: Type.Object({
          dataGb: Type.Optional(Type.Number({ minimum: 0 })),
          computeHours: Type.Optional(Type.Number({ minimum: 0 })),
          note: Type.Optional(Type.String({ maxLength: 600 })),
        }),
      }), { minItems: 1, maxItems: 6 }),
    }),
    async execute(_toolCallId, params) {
      if (context.knowledgeGroundingRequired && !context.knowledgeGrounded) {
        throw new Error("多方案规划必须先完成 Ocean-RAG 检索与科学证据核对");
      }
      if (context.requiresDataValidation && !context.webSearchAttempted) {
        throw new Error("多方案规划必须先尝试官方来源检索");
      }
      if (!context.retrievalDecision?.bundles.length) {
        const gaps = context.retrievalDecision?.missingRequirements ?? ["尚无经过检查的 Dataset Bundle"];
        const action = { type: "plan_candidates" as const, plans: [],
          comparisonSummary: "当前没有完整可执行的数据路线；请按缺失能力补充检索或提供可核验的原始数据。", gaps };
        context.setTerminalAction(action);
        return { content: [{ type: "text", text: JSON.stringify(action) }], details: action, terminate: true };
      }
      const allowedTools = context.executableToolNames ?? new Set<string>();
      const accepted = [] as NonNullable<ReturnType<typeof validateCandidate>["candidate"]>[];
      const gaps: string[] = [];
      for (const value of params.candidates) {
        try {
          const draft: CandidateDraft = { ...value,
            steps: normalizePlanSteps(value.steps).map((step, index) => ({
              ...step, phase: value.steps[index]?.phase,
              tool: value.steps[index]?.tool,
              dependsOn: step.dependsOn ?? [], expectedOutputs: step.expectedOutputs ?? [],
              risks: step.risks ?? [],
            })),
          };
          const result = validateCandidate(draft, {
            retrievalDecision: context.retrievalDecision, allowedTools,
            dataSourceChecks: context.dataSourceChecks,
            requireDownloadedData: context.requiresDataValidation && !context.dataDiscoveryOnly,
          });
          if (result.candidate) accepted.push(result.candidate);
          else gaps.push(`${draft.draftId}: ${result.errors.join("；")}`);
        } catch (error) {
          gaps.push(`${value.draftId}: ${error instanceof Error ? error.message : String(error)}`);
        }
      }
      const selected = selectCandidates(accepted, context.maxCandidatePlans ?? 3);
      const groupId = randomUUID();
      const plans = selected.map((candidate, index) => {
        const draft = candidate.draft;
        return context.createPlan({
          title: draft.title, taskId: context.taskId, candidateGroupId: groupId,
          candidateRank: index + 1, methodFamily: draft.methodFamily,
          scientificFocus: draft.scientificFocus,
          feasibilityStatus: candidate.feasibilityStatus,
          coverageReport: {
            satisfiedRequirementIds: candidate.bundle.requirementIds,
            essentialRequirementIds: candidate.bundle.requirementIds,
          },
          datasetRoles: draft.datasetRoles,
          estimatedResources: { ...draft.estimatedResources, toolCalls: candidate.estimatedToolCalls },
          tradeoffs: draft.tradeoffs, evidenceRefs: candidate.evidenceRefs,
          objective: draft.objective, assumptions: draft.assumptions,
          requiredInputs: draft.requiredInputs, datasets: draft.datasets,
          retrievalTrace: {
            queryId: context.retrievalDecision!.queryId,
            decisionState: context.retrievalDecision!.state,
            datasetIds: candidate.bundle.datasetIds,
            requirementIds: candidate.bundle.requirementIds,
            evidenceRefs: candidate.evidenceRefs,
          },
          verifiedDataSources: draft.datasets.map((id) => context.dataSourceChecks.get(id)!)
            .filter((check) => check !== undefined),
          evidenceNeeds: draft.evidenceNeeds, steps: draft.steps,
          deliverables: draft.deliverables, risks: draft.risks,
          estimatedCost: [draft.estimatedResources.dataGb === undefined ? "数据量待核实"
            : `数据约 ${draft.estimatedResources.dataGb} GB`,
          draft.estimatedResources.computeHours === undefined ? "计算时间待核实"
            : `计算约 ${draft.estimatedResources.computeHours} 小时`,
          `工具调用至少 ${candidate.estimatedToolCalls} 次`].join("；"),
        });
      });
      const comparisonSummary = plans.length
        ? plans.map((plan) => `${plan.candidateRank}. ${plan.title}（${plan.methodFamily}/${plan.scientificFocus}；${plan.datasets.join("、")}；${plan.estimatedCost}）`).join("\n")
        : "没有候选通过全部科学、数据和工具检查；请根据下列缺口补充数据来源、修正 DAG 或选择可用工具后重新规划。";
      const action = { type: "plan_candidates" as const, plans, comparisonSummary, gaps };
      context.setTerminalAction(action);
      return { content: [{ type: "text", text: JSON.stringify({ comparisonSummary, gaps,
        planIds: plans.map((plan) => plan.id) }) }], details: action, terminate: true };
    },
  });
}
