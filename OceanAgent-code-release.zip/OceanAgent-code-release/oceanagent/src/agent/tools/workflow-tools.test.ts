import { describe, expect, it } from "vitest";
import { createProposeResearchPlanTool, normalizePlanSteps } from "./workflow-tools.js";
import { normalizeDeepSeekToolPayload, scanDeepSeekToolSchemas } from "../tool-schema-compat.js";
import type { OceanToolContext } from "../tool-context.js";
import { experimentPlan, withExperimentUnit } from "../../experiments/runtime-context.js";
import type { Stage3UnitSpec } from "../../experiments/paired-dev.js";

describe("normalizePlanSteps", () => {
  const step = { id: "S1", title: "准备数据", description: "下载并质控数据" };

  it("keeps a structured step array", () => {
    expect(normalizePlanSteps([step])).toEqual([step]);
  });

  it("recovers a JSON step array accidentally serialized with trailing fields", () => {
    const serialized = `${JSON.stringify([step])}, \"datasets\"> [\"OISST\"]`;
    expect(normalizePlanSteps(serialized)).toEqual([step]);
  });

  it("rejects malformed step objects", () => {
    expect(() => normalizePlanSteps([{ id: "S1" }])).toThrow("缺少id、title或description");
  });
});

describe("fixed-input Plan submission", () => {
  const draft = () => ({ objective: "Test planning", datasets: ["fixed"], datasetRoles: { fixed: "target" }, evidenceRefs: [],
    assumptions: ["Author data availability is unknown"], deliverables: ["validated report"], steps: [
      { id: "S1", title: "prepare", description: "preprocess", phase: "data" as const, inputs: { datasetIds: ["fixed"] }, dependsOn: [], expectedOutputs: ["clean"], risks: [] },
      { id: "S2", title: "analyze", description: "analyze", phase: "analysis" as const, inputs: { fromSteps: ["S1"] }, dependsOn: ["S1"], expectedOutputs: ["estimate"], risks: [] },
      { id: "S3", title: "validate", description: "verify", phase: "validation" as const, inputs: { fromSteps: ["S2"] }, dependsOn: ["S2"], expectedOutputs: ["validated report"], risks: [] },
    ] });
  function context() {
    return { fixedPlanningDatasets: ["fixed"], recommendationOnly: false, requiresDataValidation: false,
      adaptiveRetrievalEnabled: false, knowledgeGroundingRequired: false, dataSourceChecks: new Map(),
      createPlan: (p: any) => ({ ...p, id: "plan", conversationId: "c", version: 1, status: "awaiting_approval", createdAt: "now" }),
      setTerminalAction: () => undefined } as unknown as OceanToolContext;
  }
  it("preserves roles/phases and stops without downloading or claiming scientific success", async () => {
    const c = context(), tool = createProposeResearchPlanTool(c), unit = { runtime_config: { mode: "plan" } } as Stage3UnitSpec;
    const out = await withExperimentUnit(unit, () => tool.execute("submit", draft(), undefined, undefined, {} as never));
    expect(out.terminate).toBe(true);
    expect(out.details.plan.datasetRoles).toEqual({ fixed: "target" });
    expect(out.details.plan.steps.map(s => s.phase)).toEqual(["data", "analysis", "validation"]);
    expect(experimentPlan(unit)?.id).toBe("plan");
    await expect(withExperimentUnit(unit, () => tool.execute("twice", draft(), undefined, undefined, {} as never))).rejects.toThrow("ALREADY_SUBMITTED");
  });
  it("rejects invalid roles and cyclic dependencies and exposes compatible model array schemas", async () => {
    const tool = createProposeResearchPlanTool(context()), invalid = draft();
    invalid.steps[0]!.dependsOn = ["S3"];
    await expect(tool.execute("cycle", invalid, undefined, undefined, {} as never)).rejects.toThrow("dependency_cycle");
    await expect(tool.execute("roles", { ...draft(), datasetRoles: {} }, undefined, undefined, {} as never)).rejects.toThrow("dataset_roles");
    const payload = normalizeDeepSeekToolPayload({ tools: [{ type: "function", function: { name: tool.name, parameters: tool.parameters, strict: false } }] });
    expect(scanDeepSeekToolSchemas(payload)).toEqual([]);
  });
});
