import { mkdtemp, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { resolve } from "node:path";
import { createHash } from "node:crypto";
import { afterEach, describe, expect, it, vi } from "vitest";
import type { ResearchPlan } from "../../contracts.js";
import { createRecordDatasetReadTool } from "./record-dataset-read.js";

const directories: string[] = [];
afterEach(async () => { for (const directory of directories.splice(0)) {
  await rm(directory, { recursive: true, force: true });
} });

describe("observed dataset reads", () => {
  it("reads bytes and records hash only for approved dataset files inside workspace", async () => {
    const workspace = await mkdtemp(resolve(tmpdir(), "ocean-provenance-")); directories.push(workspace);
    await writeFile(resolve(workspace, "sst.csv"), "time,sst\n2020,20\n");
    const plan = { datasets: ["dataset-sst"], steps: [{ id: "read", title: "读取", description: "",
      dependsOn: [], expectedOutputs: [], risks: [] }] } as ResearchPlan;
    const tool = createRecordDatasetReadTool(workspace, plan, (id) => id === "dataset-sst");
    const result = await tool.execute("tool-call", { datasetId: "dataset-sst", file: "sst.csv",
      planStepId: "read" }, undefined, undefined, {} as never);
    expect(result.details.sha256).toBe(createHash("sha256").update("time,sst\n2020,20\n").digest("hex"));
    expect(result.details.identity_source).toBe("dataset_card");
    await expect(tool.execute("tool-call", { datasetId: "other", file: "sst.csv" },
      undefined, undefined, {} as never)).rejects.toThrow("未进入");
    await expect(tool.execute("tool-call", { datasetId: "dataset-sst", file: "missing.csv" },
      undefined, undefined, {} as never)).rejects.toThrow();
  });

  it("records validated public data in A0 without querying the knowledge base", async () => {
    const workspace = await mkdtemp(resolve(tmpdir(), "ocean-official-read-")); directories.push(workspace);
    const body = "time,sst\n2020,20\n", path = resolve(workspace, "sst.csv"); await writeFile(path, body);
    const plan = { knowledgeMode: "off", datasets: ["official-sst"], steps: [{ id: "read" }],
      verifiedDataSources: [{ dataset: "official-sst", validated: true, status: "available", localPath: path,
        sha256: createHash("sha256").update(body).digest("hex"), bytes: Buffer.byteLength(body) }] } as ResearchPlan;
    const lookup = vi.fn(() => { throw new Error("A0 must not query DatasetCards"); });
    const result = await createRecordDatasetReadTool(workspace, plan, lookup).execute("read", {
      datasetId: "official-sst", file: path }, undefined, undefined, {} as never);
    expect(result.details.identity_source).toBe("validated_public_data"); expect(lookup).not.toHaveBeenCalled();
  });

  it("rejects unverified, changed or differently located official files", async () => {
    const workspace = await mkdtemp(resolve(tmpdir(), "ocean-official-reject-")); directories.push(workspace);
    const body = "valid data", path = resolve(workspace, "one.csv"); await writeFile(path, body);
    const other = resolve(workspace, "two.csv"); await writeFile(other, body);
    const source = { dataset: "official", validated: true, status: "available", localPath: path,
      sha256: createHash("sha256").update(body).digest("hex") };
    const lookup = vi.fn(() => false);
    for (const [patch, file] of [[{ validated: false }, path], [{ sha256: "0".repeat(64) }, path], [{}, other]]) {
      const plan = { knowledgeMode: "off", datasets: ["official"], steps: [],
        verifiedDataSources: [{ ...source, ...patch as object }] } as ResearchPlan;
      await expect(createRecordDatasetReadTool(workspace, plan, lookup).execute("read", {
        datasetId: "official", file: file as string }, undefined, undefined, {} as never)).rejects.toThrow("完全匹配");
    }
    expect(lookup).not.toHaveBeenCalled();
  });
});
