import { spawn } from "node:child_process";
import { closeSync, existsSync, mkdirSync, openSync, writeSync } from "node:fs";
import { randomUUID } from "node:crypto";
import { delimiter, resolve } from "node:path";
import { defineTool } from "@earendil-works/pi-coding-agent";
import { Type } from "typebox";

const PREVIEW_BYTES = 32 * 1024;

function tail(value: Buffer, limit = PREVIEW_BYTES): string {
  return value.subarray(Math.max(0, value.length - limit)).toString("utf8");
}

function shellPath(): string {
  const root = process.env.SystemRoot ?? process.env.WINDIR ?? "C:\\Windows";
  const pwsh = resolve(process.env.ProgramFiles ?? "C:\\Program Files", "PowerShell", "7", "pwsh.exe");
  const legacy = resolve(root, "System32", "WindowsPowerShell", "v1.0", "powershell.exe");
  const pathKey = Object.keys(process.env).find((key) => key.toLowerCase() === "path") ?? "Path";
  const entries = (process.env[pathKey] ?? "").split(delimiter).filter(Boolean);
  const detected = entries.flatMap((entry) => [resolve(entry, "pwsh.exe"), resolve(entry, "powershell.exe")])
    .find(existsSync);
  const selected = process.env.OCEAN_POWERSHELL_PATH || (existsSync(pwsh) ? pwsh : detected ?? legacy);
  if (!existsSync(selected)) throw new Error(`找不到 PowerShell 可执行文件：${selected}`);
  return selected;
}

function wrappedCommand(command: string): string {
  // Capture the native process exit status immediately after the user command.
  // A successful Select-String/Select-Object must not hide a failed Python process.
  return [
    "[Console]::OutputEncoding = [System.Text.Encoding]::UTF8",
    "$OutputEncoding = [System.Text.Encoding]::UTF8",
    "$global:LASTEXITCODE = $null",
    "try {",
    "& {",
    command,
    "}",
    "$oceanSucceeded = $?",
    "if ($null -ne $global:LASTEXITCODE) { exit $global:LASTEXITCODE }",
    "if (-not $oceanSucceeded) { exit 1 }",
    "exit 0",
    "} catch { [Console]::Error.WriteLine($_.ToString()); exit 1 }",
  ].join("\n");
}

export function createLocalPowerShellTool(cwd: string, logRoot: string, applicationRoot = cwd) {
  const workspaceVenv = resolve(cwd, ".venv");
  const applicationVenv = resolve(applicationRoot, ".venv");
  const requiredScientificModules = ["requests", "yaml", "netCDF4"];
  const scientificVenvReady = (directory: string) =>
    existsSync(resolve(directory, "Scripts", "python.exe"))
    && requiredScientificModules.every((name) => existsSync(resolve(directory, "Lib", "site-packages", name)));
  const venv = (process.env.OCEAN_PYTHON_VENV ? resolve(applicationRoot, process.env.OCEAN_PYTHON_VENV) : undefined)
    ?? (scientificVenvReady(workspaceVenv) ? workspaceVenv
      : scientificVenvReady(applicationVenv) ? applicationVenv : undefined);
  if (venv && !existsSync(resolve(venv, "Scripts", "python.exe"))) {
    throw new Error(`OCEAN_PYTHON_VENV 未指向可用的 Windows 虚拟环境：${venv}`);
  }
  return defineTool({
    name: "powershell",
    label: "powershell",
    description: `在当前工作目录运行 Windows PowerShell 命令${venv ? `，python 指向 ${resolve(venv, "Scripts", "python.exe")}` : "，python 从 PATH 解析（应用自带 .venv 缺少科研依赖时不自动启用）"}。分别记录 stdout、stderr、真实退出码和耗时；完整输出保存为本地日志。请使用 PowerShell 语法。Python 多行代码请先写入 .py 文件后运行；不要使用 Bash heredoc 或用 Select-Object -First 截断仍在运行的程序。`,
    promptSnippet: "Execute Windows PowerShell commands",
    parameters: Type.Object({
      command: Type.String(),
      timeout: Type.Optional(Type.Number({ description: "超时秒数，默认1800、最大7200；长任务应分批执行并保存检查点" })),
    }),
    async execute(_id, { command, timeout }, signal, onUpdate) {
      if (/\bpython(?:\.exe)?\s+-\s*<<\s*['"]?\w+/i.test(command)) {
        throw new Error("PowerShell 不支持 Bash heredoc。请先用 write 创建 .py 文件，再运行 python <脚本路径>。");
      }
      if (/\b(?:python|py)(?:\.exe)?\b[\s\S]*?2>\s*&1\s*\|\s*Select-(?:Object|String)/i.test(command)) {
        throw new Error("不要用 2>&1 | Select-* 包裹 Python：PowerShell 管道可能提前关闭或把警告变成错误记录。直接运行 python -u <脚本>，工具会分别保存 stdout/stderr 完整日志。");
      }
      const timeoutSeconds = timeout ?? 1800;
      if (!Number.isFinite(timeoutSeconds) || timeoutSeconds <= 0 || timeoutSeconds > 7200) {
        throw new Error("timeout 必须是 0 到 7200 之间的有效秒数；长任务请分批保存检查点");
      }
      mkdirSync(logRoot, { recursive: true });
      const id = randomUUID();
      const stdoutPath = resolve(logRoot, `${id}.stdout.log`);
      const stderrPath = resolve(logRoot, `${id}.stderr.log`);
      const stdoutFile = openSync(stdoutPath, "w");
      const stderrFile = openSync(stderrPath, "w");
      const started = Date.now();
      let stdoutTail = Buffer.alloc(0);
      let stderrTail = Buffer.alloc(0);
      let stdoutBytes = 0;
      let stderrBytes = 0;
      let timedOut = false;
      let cancelled = false;
      let timer: NodeJS.Timeout | undefined;
      let abort: (() => void) | undefined;
      let lastUpdateAt = 0;
      let child: ReturnType<typeof spawn> | undefined;
      try {
        const script = Buffer.from(wrappedCommand(command), "utf16le").toString("base64");
        const env: NodeJS.ProcessEnv = { ...process.env, PYTHONIOENCODING: "utf-8" };
        if (venv) {
          const pathKey = Object.keys(env).find((key) => key.toLowerCase() === "path") ?? "Path";
          env[pathKey] = `${resolve(venv, "Scripts")}${delimiter}${env[pathKey] ?? ""}`;
          env.VIRTUAL_ENV = venv;
        }
        child = spawn(shellPath(), ["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-EncodedCommand", script], {
          cwd, windowsHide: true, stdio: ["ignore", "pipe", "pipe"],
          env,
        });
        const stop = () => {
          if (!child?.pid || child.exitCode !== null) return;
          const killer = spawn("taskkill.exe", ["/PID", String(child.pid), "/T", "/F"], { windowsHide: true, stdio: "ignore" });
          killer.on("error", () => child?.kill());
        };
        abort = () => { cancelled = true; stop(); };
        if (signal?.aborted) abort();
        else signal?.addEventListener("abort", abort, { once: true });
        timer = setTimeout(() => { timedOut = true; stop(); }, timeoutSeconds * 1000);
        const append = (stream: "stdout" | "stderr", data: Buffer) => {
          writeSync(stream === "stdout" ? stdoutFile : stderrFile, data);
          const previous = stream === "stdout" ? stdoutTail : stderrTail;
          const next = Buffer.concat([previous, data]);
          if (stream === "stdout") { stdoutTail = next.subarray(Math.max(0, next.length - PREVIEW_BYTES)); stdoutBytes += data.length; }
          else { stderrTail = next.subarray(Math.max(0, next.length - PREVIEW_BYTES)); stderrBytes += data.length; }
          if (Date.now() - lastUpdateAt >= 2000) {
            lastUpdateAt = Date.now();
            onUpdate?.({
              content: [{ type: "text", text: `stdout:\n${tail(stdoutTail, 4096)}\n\nstderr:\n${tail(stderrTail, 4096)}` }],
              details: { reason: "running", stdoutBytes, stderrBytes },
            });
          }
        };
        child.stdout?.on("data", (data: Buffer) => append("stdout", data));
        child.stderr?.on("data", (data: Buffer) => append("stderr", data));
        const result = await new Promise<{ code: number | null; error?: Error }>((done) => {
          child!.once("error", (error) => done({ code: null, error }));
          child!.once("close", (code) => done({ code }));
        });
        const elapsedMs = Date.now() - started;
        const reason = cancelled ? "cancelled" : timedOut ? "timeout" : result.error ? "spawn_error" : result.code === 0 ? "completed" : "nonzero_exit";
        const summary = [
          `状态: ${reason}; exitCode: ${result.code ?? "null"}; 耗时: ${elapsedMs} ms`,
          `stdout (${stdoutBytes} bytes):\n${tail(stdoutTail) || "(empty)"}`,
          `stderr (${stderrBytes} bytes):\n${tail(stderrTail) || "(empty)"}`,
          `完整日志: ${stdoutPath} ; ${stderrPath}`,
          ...(result.error ? [result.error.message] : []),
        ].join("\n\n");
        if (reason !== "completed") throw new Error(summary);
        return {
          content: [{ type: "text" as const, text: summary }],
          details: { reason, exitCode: result.code, elapsedMs, stdoutBytes, stderrBytes, stdoutPath, stderrPath },
        };
      } finally {
        if (timer) clearTimeout(timer);
        if (abort) signal?.removeEventListener("abort", abort);
        closeSync(stdoutFile);
        closeSync(stderrFile);
      }
    },
  });
}
