import { resolve } from "node:path";
import { randomUUID } from "node:crypto";
import { defineTool } from "@earendil-works/pi-coding-agent";
import { Type, type Static } from "typebox";
import type { RagService } from "../../rag/rag-service.js";
import { acquireDatasets, DataAccessError, validateDatasetBbox, type DatasetRequest } from "../../data-access/acquire.js";
import { redactDataUrl } from "../../data-access/safe-http.js";
import { currentTelemetry } from "../../telemetry/run-telemetry.js";
import type { OceanToolContext } from "../tool-context.js";
import { resolveScientificPython } from "../python-environment.js";
import { contextAblationPolicy, projectKnowledgeDocument } from "../../experiments/ablation-policy.js";

/** Cards are evidence, never executable instructions or network policy. */
export function cardAccessUrls(value: unknown, depth = 0): string[] {
  if (depth > 8) return [];
  if (typeof value === "string") return [...value.matchAll(/https?:\/\/[^\s<>"'`]+/g)]
    .map(([url]) => url.replace(/[),;。]+$/, "").replace(/^http:/, "https:"));
  if (Array.isArray(value)) return value.slice(0, 80).flatMap((item) => cardAccessUrls(item, depth + 1));
  if (value && typeof value === "object") return Object.entries(value)
    .filter(([key]) => !/secret|password|token|credential|api.?key/i.test(key))
    .slice(0, 100).flatMap(([, item]) => cardAccessUrls(item, depth + 1));
  return [];
}

/** Runs before the SDK's primitive coercion and before any retrieval/download side effect. */
function validateArgumentBboxes(args: unknown): void {
  const datasets = args && typeof args === "object" ? (args as { datasets?: unknown }).datasets : undefined;
  if (!Array.isArray(datasets)) throw new DataAccessError("INVALID_REQUEST", "datasets 必须是数据集参数数组");
  for (const dataset of datasets) {
    validateDatasetBbox(dataset && typeof dataset === "object" ? (dataset as { bbox?: unknown }).bbox : undefined);
  }
}

export function createAcquireScientificDataTool(rag: RagService, context: OceanToolContext, applicationRoot = context.workspacePath) {
  const policy = contextAblationPolicy(context);
  const access = policy.knowledgeAccessEnabled && typeof rag.withAblationPolicy === "function" ? rag.withAblationPolicy(policy) : rag;
  const parameters = Type.Object({
      datasets: Type.Array(Type.Object({
        datasetId: Type.String({ minLength: 1, description: "与 Plan.datasets 一致的 DatasetCard ID 或明确的官方数据集ID" }),
        urls: Type.Optional(Type.Array(Type.String(), { maxItems: 8, description: "官方产品页、服务或文件地址；省略时从 DatasetCard 解析" })),
        variables: Type.Array(Type.String({ minLength: 1 }), { minItems: 1, maxItems: 8, description: "科学问题所需变量；工具会依据实际元数据核验，错误名称不能替代为相近变量" }),
        timeStart: Type.String({ description: "所需起始UTC时间，ISO8601" }),
        timeEnd: Type.String({ description: "所需结束UTC时间，ISO8601" }),
        bbox: Type.Tuple([Type.Number(), Type.Number(), Type.Number(), Type.Number()], { description: "[west,south,east,north]，经度用-180..180；自动转换源经度" }),
        stride: Type.Optional(Type.Integer({ minimum: 1, maximum: 100, description: "明确的空间抽样步长；默认1，不能静默降低分辨率" })),
      }), { minItems: 1, maxItems: 6 }),
    });
  return defineTool({
    name: "acquire_scientific_data", label: "自动获取并验证科学数据切片",
    description: "根据本轮科学问题和 DatasetCard 获取公开数据。传入实际所需变量、UTC时段与经纬范围；先官方元数据、极小非空切片，再有界下载与验证。支持 ERDDAP griddap/tabledap、OPeNDAP 和小型直接文件，自动尝试官方备用入口。组合数据必须在同一次调用中提交以检查兼容性。返回本地已验证路径供 Plan 和分析读取。无需用户预先下载；仅确实需要登录授权时请求协助。默认每文件16MiB、每轮总64MiB（含元数据和重试）；超限请缩小范围或分批，不得下载无界全球文件。",
    parameters,
    prepareArguments(args) {
      validateArgumentBboxes(args);
      return args as Static<typeof parameters>;
    },
    async execute(_id, params, signal) {
      if (context.dataDownloadAllowed === false) throw new Error("This recommendation-only experiment does not permit downloads or analysis");
      validateArgumentBboxes(params);
      const attempts = context.dataAcquisitionAttempts ??= new Set();
      const requests: DatasetRequest[] = params.datasets.map((item) => {
        const cards = policy.knowledgeAccessEnabled ? access.getDatasetCards([item.datasetId])
          .map(card => projectKnowledgeDocument(card, policy)) : [];
        const known = context.dataSourceChecks.get(item.datasetId);
        const urls = [...new Set([...(item.urls ?? []), ...cards.flatMap((card) => cardAccessUrls(card.payload)),
          ...(known ? [known.dataUrl, known.pageUrl].filter((url): url is string => Boolean(url)) : [])])];
        if (!urls.length) throw new Error(`${item.datasetId}: ${!policy.knowledgeAccessEnabled ? "缺少官方入口；知识库隔离模式请直接" : "DatasetCard 无入口；请"}用 search_official_web 查询官方产品/服务元数据后重试。`);
        attempts.add(item.datasetId);
        if (known) context.dataSourceChecks.set(item.datasetId, { ...known, validated: false,
          reason: "正在核验本次请求范围；已有缓存仅在重新验证后复用。" });
        currentTelemetry()?.trace.emit("dataset_recommendation", { status: "selected", dataset_id: item.datasetId,
          knowledge_evidence_ids: cards.map((card) => card.id), variables: item.variables,
          time_start: item.timeStart, time_end: item.timeEnd, bbox: item.bbox });
        return { ...item, bbox: item.bbox as [number, number, number, number], urls: urls.slice(0, 12) };
      });
      const budget = context.dataAcquisitionBudget ??= { used: context.dataAcquisitionBytes ?? 0, limit: 64 * 1024 * 1024 };
      const remaining = budget.limit - budget.used;
      if (remaining <= 0) throw new Error("本轮自动获取总字节预算已用完；保留已验证缓存并缩小后续数据需求。");
      let pythonPath: string | undefined = process.env.OCEAN_DATA_PYTHON;
      if (!pythonPath) try { pythonPath = resolveScientificPython(context.workspacePath, applicationRoot).pythonPath; } catch { /* JSON/OPeNDAP text need no Python. */ }
      try {
        const result = await acquireDatasets(requests, {
          cacheDir: context.scientificCachePath ?? resolve(context.workspacePath, "data", "scientific-cache"),
          maxFileBytes: 16 * 1024 * 1024, maxTotalBytes: remaining, budget, signal, pythonPath,
          onEvent(event, payload) {
            currentTelemetry()?.trace.emit(event, payload);
          },
        });
        context.webSearchAttempted = true; // Official metadata HTTP was actually read; no search API key is needed.
        const compatibilityGroup = randomUUID();
        for (const dataset of result.datasets) {
          const request = requests.find((item) => item.datasetId === dataset.datasetId)!;
          context.dataSourceChecks.set(dataset.datasetId, {
            dataset: dataset.datasetId, pageUrl: redactDataUrl(request.urls[0]!), dataUrl: dataset.sourceUrl,
            status: "available", reason: "已自动获取有界切片，完成实际数据验证及组合兼容性检查。",
            checkedAt: new Date().toISOString(), localPath: dataset.path, sha256: dataset.sha256,
            bytes: dataset.bytes, validated: true, protocol: dataset.protocol,
            compatibilityGroup,
            validation: { dataset: dataset.validation, compatibility: result.compatibility },
            transformations: [...dataset.transformations, ...result.compatibility.transformations],
          });
          context.addCitation({ sourceType: "web", sourceId: dataset.sourceUrl,
            title: `${dataset.datasetId} 官方数据切片`, url: dataset.sourceUrl,
            evidenceText: `已验证本地文件 SHA-256 ${dataset.sha256}`,
            metadata: { datasetId: dataset.datasetId, path: dataset.path, sha256: dataset.sha256 } });
        }
        return { content: [{ type: "text", text: JSON.stringify({ ...result,
          instruction: "使用已验证本地数据继续生成可执行 Plan；独立原生网格统计读 datasets.path，逐点联合分析优先读 compatibility.alignedPath（已配准的共同格点/时间，列名datasetId::variable）。执行时先复核哈希。必须将配准方法、offset、排除样本、覆盖缺口与 transformations/warnings 写入报告；不得声称已完成科学分析。" }) }], details: result as unknown };
      } catch (error) {
        if (signal?.aborted) throw error;
        const code = error instanceof DataAccessError ? error.code : "DATA_ACCESS_ERROR";
        const requiresAccess = error instanceof DataAccessError && error.requiresAuthentication;
        const failedId = error instanceof DataAccessError ? error.datasetId : undefined;
        for (const request of requests) {
          const partial = error instanceof DataAccessError ? error.partialDatasets?.find((value) =>
            value && typeof value === "object" && (value as { datasetId?: string }).datasetId === request.datasetId) as
            { path: string; sha256: string; bytes: number; sourceUrl: string } | undefined : undefined;
          const needsAuth = requiresAccess && (failedId === request.datasetId || requests.length === 1);
          context.dataSourceChecks.set(request.datasetId, {
            dataset: request.datasetId, pageUrl: redactDataUrl(request.urls[0]!),
            status: needsAuth ? "requires_access" : partial ? "available" : "unavailable", errorType: code,
            ...(partial ? { localPath: partial.path, sha256: partial.sha256, bytes: partial.bytes, dataUrl: partial.sourceUrl } : {}),
            validated: false,
            reason: `自动数据获取失败 (${code})；请查看原生访问事件并调整入口或切片。`, checkedAt: new Date().toISOString(),
          });
        }
        currentTelemetry()?.trace.emit("data_validation", { status: "failed", error_type: code,
          dataset_ids: requests.map((item) => item.datasetId), requires_authentication: requiresAccess });
        return { content: [{ type: "text", text: JSON.stringify({ status: "failed", errorType: code,
          reason: error instanceof Error ? error.message : "数据获取失败", requiresAuthentication: requiresAccess,
          nextAction: requiresAccess ? "官方服务确需认证，请用户在官方渠道授权，勿在聊天提交凭据。"
            : "继续查询官方备用服务或缩小请求后重试；网络或请求失败不等于需要认证，不要要求用户下载上传。" }) }],
          details: { datasets: [], compatibility: null, downloadedBytes: budget.used,
            errorType: code, requiresAuthentication: requiresAccess } };
      } finally {
        context.dataAcquisitionBytes = budget.used;
        currentTelemetry()?.trace.emit("data_validation", { status: "budget_accounted",
          downloaded_bytes_total: budget.used, byte_limit: budget.limit });
      }
    },
  });
}
