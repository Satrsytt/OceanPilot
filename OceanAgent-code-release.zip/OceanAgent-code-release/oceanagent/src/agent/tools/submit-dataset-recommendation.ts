import { createHash } from "node:crypto";
import { defineTool } from "@earendil-works/pi-coding-agent";
import { Type } from "typebox";
import type { OceanToolContext } from "../tool-context.js";
import { currentExperimentUnit, recordExperimentRecommendation } from "../../experiments/runtime-context.js";
import { RECOMMENDATION_CONTRACT, scientificProtocol, type DatasetRecommendation, type OrderedProductCandidate } from "../../experiments/scientific-protocol.js";
import { resolveCanonicalProduct } from "../../experiments/public-product-catalog.js";
import { currentTelemetry, redactTelemetry } from "../../telemetry/run-telemetry.js";
import { stage3CanonicalJson } from "../../experiments/paired-dev.js";

export function validateDatasetIdentifier(id: string): string {
  if (typeof id !== "string" || !/^[A-Za-z0-9][A-Za-z0-9._:/?&=+%#@~-]{0,299}$/.test(id)) {
    throw new Error("datasetId必须是单独的ASCII产品/目录ID或HTTPS URL；解释写入rationale，不能混入ID。");
  }
  if (/^https?:/i.test(id)) validatePublicEvidenceUrl(id);
  return id;
}
export function validatePublicEvidenceUrl(raw: string): string {
  const url = new URL(raw);
  if (url.protocol !== "https:" || url.username || url.password || url.port && url.port !== "443"
    || !url.hostname.includes(".") || /(?:^|\.)(localhost|local|internal)$/.test(url.hostname)
    || /^\d+(?:\.\d+){3}$/.test(url.hostname) || url.hostname.includes(":")
    || [...url.searchParams.keys()].some(key => /token|secret|pass|key|signature|credential|auth|session/i.test(key))) {
    throw new Error("证据URL必须是无凭据的公开HTTPS来源。");
  }
  return url.toString();
}

export function createSubmitDatasetRecommendationTool(context: OceanToolContext) {
  return defineTool({ name: "submit_dataset_recommendation", label: "提交有序数据推荐",
    description: "提交最终数据推荐并结束推荐阶段，不要求下载、入口可达或生成Plan。数组顺序是推荐优先级，应用生成rank；datasetId只放ID，说明放rationale。capabilities/roles是待专家验证的声明，不是科学正确标签。允许明确提交空数组，缺失输出与空数组会分别记录。",
    parameters: Type.Object({ candidates: Type.Array(Type.Object({
      datasetId: Type.String({ minLength: 1, maxLength: 300 }),
      sourceUrls: Type.Array(Type.String()), capabilities: Type.Array(Type.String()), roles: Type.Array(Type.String()),
      rationale: Type.String(), evidenceIds: Type.Array(Type.String()),
    }), { maxItems: 20 }) }),
    async execute(_id, params) {
      const unit = currentExperimentUnit();
      if (!unit || !scientificProtocol(unit.runtime_config) || !context.recommendationOnly) {
        throw new Error("独立推荐提交仅适用于stage3-scientific-v2推荐模式。");
      }
      if (!Array.isArray(params.candidates) || params.candidates.length > 20) throw new Error("候选上限20。");
      const ids = new Set<string>();
      // Hash exactly the credential-safe representation written to native logs and unit-result.
      const candidates = redactTelemetry(params.candidates.map((item, i) => {
        const id = validateDatasetIdentifier(item.datasetId);
        if (ids.has(id)) throw new Error("推荐ID不能重复；应用不会静默删改排序。"); ids.add(id);
        const urls = item.sourceUrls.map(validatePublicEvidenceUrl);
        const trace = currentTelemetry()?.trace;
        for (const evidence of item.evidenceIds) {
          if (!trace?.hasRetrievedCard(evidence)) throw new Error("evidenceIds只能引用本run实际检索的卡。");
        }
        const identity = resolveCanonicalProduct({ datasetId: id, sourceUrls: urls });
        return { rank: i + 1, dataset_id: id, canonical_product_id: identity.canonicalProductId,
          identity_status: identity.status === "matched" ? "verified" as const : identity.status,
          evidence_urls: [...new Set([...urls, ...identity.evidenceUrls])], capabilities: item.capabilities,
          roles: item.roles, rationale: item.rationale, evidence_ids: item.evidenceIds };
      })) as OrderedProductCandidate[];
      const recommendation: DatasetRecommendation = { schema_version: RECOMMENDATION_CONTRACT,
        ranking_semantics: "explicit_model_priority_not_retrieval_score", candidates,
        candidate_sha256: createHash("sha256").update(stage3CanonicalJson(candidates)).digest("hex"),
        candidate_hash_semantics: "redacted_canonical_json_v1",
        capability_semantics: "model_claims_require_independent_judgment", submitted_at: new Date().toISOString() };
      recordExperimentRecommendation(unit, recommendation);
      context.setTerminalAction({ type: "recommendation", recommendation });
      currentTelemetry()?.trace.recommendationSubmitted(recommendation);
      return { content: [{ type: "text" as const, text: "推荐已保存。推荐阶段完成，不再下载数据或提出Plan。" }],
        details: { recommendation }, terminate: true };
    },
  });
}
