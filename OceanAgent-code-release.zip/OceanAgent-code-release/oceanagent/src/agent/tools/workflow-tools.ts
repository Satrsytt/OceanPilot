import { defineTool } from "@earendil-works/pi-coding-agent";
import { Type } from "typebox";
import type { PlanStep } from "../../contracts.js";
import type { OceanToolContext } from "../tool-context.js";
import { fixedPlanStructureErrors } from "../../experiments/plan-structure.js";
import { currentExperimentUnit, experimentPlan, recordExperimentPlan } from "../../experiments/runtime-context.js";
import { currentTelemetry } from "../../telemetry/run-telemetry.js";

const StringList = Type.Optional(Type.Array(Type.String(), { default: [] }));

interface PlanStepInput {
  id: string;
  title: string;
  description: string;
  tool?: string;
  inputs?: Record<string, unknown>;
  dependsOn?: string[];
  expectedOutputs?: string[];
  risks?: string[];
  phase?: "data" | "analysis" | "validation" | "artifact";
}

const PlanStepSchema = Type.Object({
  id: Type.String({ description: "步骤稳定标识，例如 S1" }),
  title: Type.String(),
  description: Type.String(),
  tool: Type.Optional(Type.String()),
  inputs: Type.Optional(Type.Record(Type.String(), Type.Unknown(), {
    description: "步骤输入。固定组合实验用datasetIds数组引用给定产品ID，用fromSteps数组引用本步dependsOn内的步骤ID；可另列参数。evidenceRefs数组仅引用本轮真实检索Card ID或公开HTTPS URL，未知则空数组；不要预设或虚构。",
  })),
  dependsOn: StringList,
  expectedOutputs: StringList,
  risks: StringList,
  phase: Type.Optional(Type.Union([Type.Literal("data"), Type.Literal("analysis"), Type.Literal("validation"), Type.Literal("artifact")], {
    description: "固定数据组合实验必填；data包括预处理，analysis包括科学分析，validation包括结果检验，artifact为报告产物。阶段标签不代表科学正确。",
  })),
});

function firstJsonArray(value: string): unknown {
  const start = value.indexOf("[");
  if (start < 0) throw new Error("科研规划步骤必须是JSON数组");
  let depth = 0;
  let inString = false;
  let escaped = false;
  for (let index = start; index < value.length; index += 1) {
    const char = value[index];
    if (inString) {
      if (escaped) escaped = false;
      else if (char === "\\") escaped = true;
      else if (char === '"') inString = false;
      continue;
    }
    if (char === '"') inString = true;
    else if (char === "[") depth += 1;
    else if (char === "]") {
      depth -= 1;
      if (depth === 0) return JSON.parse(value.slice(start, index + 1));
    }
  }
  throw new Error("科研规划步骤JSON数组不完整");
}

export function normalizePlanSteps(value: unknown): PlanStepInput[] {
  let parsed: unknown = value;
  if (typeof value === "string") {
    try {
      parsed = JSON.parse(value.trim());
    } catch {
      parsed = firstJsonArray(value);
    }
  }
  if (!Array.isArray(parsed) || parsed.length === 0) throw new Error("科研规划至少需要一个步骤");
  for (const step of parsed) {
    if (!step || typeof step !== "object") throw new Error("科研规划步骤必须是对象");
    const item = step as Record<string, unknown>;
    if (![item.id, item.title, item.description].every((field) => typeof field === "string" && field.trim())) {
      throw new Error("科研规划步骤缺少id、title或description");
    }
  }
  return parsed as PlanStepInput[];
}

export function createRequestClarificationTool(context: OceanToolContext) {
  return defineTool({
    name: "request_clarification",
    label: "请求补充科研参数",
    description: "当缺少会实质改变结论或科研规划的关键信息时，生成最少量的结构化问题并结束当前轮。不要用于可通过合理假设解决的细节。",
    parameters: Type.Object({
      summary: Type.String({ description: "说明为什么需要补充信息" }),
      questions: Type.Array(Type.Object({
        id: Type.String({ description: "稳定的英文或拼音字段名，例如 spatial_range" }),
        label: Type.String({ description: "表单短标签" }),
        question: Type.String({ description: "面向用户的清晰问题" }),
        required: Type.Boolean({ default: true }),
        reason: Type.Optional(Type.String({ description: "该信息如何影响研究结果" })),
        options: Type.Array(Type.Object({
          value: Type.String({ description: "提交给智能体的稳定值" }),
          label: Type.String({ description: "用户可直接选择的短文本" }),
          description: Type.Optional(Type.String({ description: "该选项的简短说明" })),
        }), { minItems: 2, maxItems: 6, description: "优先覆盖最常见且互斥的答案" }),
        allowCustom: Type.Boolean({ default: true, description: "没有合适选项时是否允许用户填写其他答案" }),
      }), { minItems: 1, maxItems: 6 }),
    }),
    async execute(_toolCallId, params) {
      const action = { type: "clarification" as const, summary: params.summary, questions: params.questions };
      context.setTerminalAction(action);
      return {
        content: [{ type: "text", text: `需要用户补充：${params.questions.map((item) => item.question).join("；")}` }],
        details: action,
        terminate: true,
      };
    },
  });
}

export function createProposeResearchPlanTool(context: OceanToolContext) {
  return defineTool({
    name: "propose_research_plan",
    label: "提出科研规划",
    description: "为复杂海洋科研需求提出结构化、可审核的计划。调用后进入等待用户确认状态，不能继续执行计划。",
    parameters: Type.Object({
      objective: Type.String({ description: "可验证的研究目标" }),
      assumptions: StringList,
      requiredInputs: StringList,
      datasets: StringList,
      evidenceNeeds: StringList,
      datasetRoles: Type.Optional(Type.Record(Type.String(), Type.String(), { description: context.planningOnly
        ? "自由规划必填：每个实际选择的datasets ID对应其科学角色，ID与datasets逐项一致。"
        : "固定数据组合实验必填：每个固定dataset ID对应其科学角色；不得替换ID。" })),
      evidenceRefs: Type.Optional(Type.Array(Type.String(), { description: "仅填写本run实际检索的Card ID或无凭据公开HTTPS URL；证据未知时空数组并在evidenceNeeds注明。" })),
      steps: Type.Union([
        Type.Array(PlanStepSchema, { minItems: 1, maxItems: 20 }),
        Type.String({ description: "兼容模型偶发返回的JSON数组字符串；应优先传入真实数组" }),
      ]),
      deliverables: StringList,
      risks: StringList,
      estimatedCost: Type.Optional(Type.String({ description: "预计时间、Token、存储或计算量；未知时说明未知" })),
    }),
    async execute(_toolCallId, params) {
      if (context.recommendationOnly) throw new Error("推荐模式使用submit_dataset_recommendation，Plan单独评价。");
      const unit = currentExperimentUnit();
      if ((context.fixedPlanningDatasets || context.planningOnly) && unit && experimentPlan(unit)) throw new Error("STAGE3_PLAN_ALREADY_SUBMITTED");
      if (context.fixedPlanningDatasets && ((params.datasets ?? []).length !== context.fixedPlanningDatasets.length
        || context.fixedPlanningDatasets.some(id => !(params.datasets ?? []).includes(id)))) {
        throw new Error("固定组合规划必须使用本实验给定的同一数据集集合，不可替换或增加。");
      }
      const decision = context.retrievalDecision;
      const selectedBundle = decision?.bundles.find((bundle) =>
        bundle.datasetIds.length === (params.datasets ?? []).length
        && bundle.datasetIds.every((id) => (params.datasets ?? []).includes(id)));
      if (context.adaptiveRetrievalEnabled && decision) {
        if (!decision.bundles.length) {
          throw new Error(`当前知识库尚未确认完整数据路线：${decision.missingRequirements.join("、") || decision.reason}。请说明缺口或请求澄清。`);
        }
        if (!selectedBundle) {
          throw new Error("规划 datasets 必须恰好使用 assess_dataset_routes 已验证的某一完整 Bundle 的 datasetIds。");
        }
      }
      if (context.knowledgeGroundingRequired && !context.knowledgeGrounded) {
        throw new Error("涉及海洋科研的规划必须先完成至少一次 Ocean-RAG 知识库检索。");
      }
      if (context.requiresDataValidation) {
        const datasets = params.datasets ?? [];
        if (!datasets.length) throw new Error("数据任务的规划必须列出需要的数据集和官方来源核验结果。");
        const missing = datasets.filter((dataset) => !context.dataSourceChecks.has(dataset));
        if (missing.length) throw new Error(`以下数据集尚未核验官方来源：${missing.join("、")}。请逐项调用 check_official_data_source。`);
        const blocked = datasets.map((dataset) => context.dataSourceChecks.get(dataset)!)
          .filter((check) => check.status !== "available"
            && !(context.dataDiscoveryOnly && check.status === "metadata_only")
            || !context.dataDiscoveryOnly && (!check.validated || !check.localPath));
        if (blocked.length) {
          throw new Error(`数据尚未完成本地验证：${blocked.map((check) => `${check.dataset} ${check.status}（${check.reason}）`).join("；")}。请调用 acquire_scientific_data 获取当前问题所需的有界切片；先元数据、极小切片，再验证组合。入口失效应查询官方备用入口，不要直接要求上传。`);
        }
        if (!context.dataDiscoveryOnly && datasets.length > 1) {
          const groups = datasets.map((id) => context.dataSourceChecks.get(id)?.compatibilityGroup);
          if (groups.some((group) => !group) || new Set(groups).size !== 1) {
            throw new Error("多数据集尚未完成共同兼容性检查；请在一次 acquire_scientific_data 调用中提交完整组合。");
          }
        }
      }
      const rawSteps = normalizePlanSteps(params.steps);
      const steps: PlanStep[] = rawSteps.map((step) => ({
        id: step.id,
        title: step.title,
        description: step.description,
        tool: step.tool,
        inputs: step.inputs,
        dependsOn: step.dependsOn ?? [],
        expectedOutputs: step.expectedOutputs ?? [],
        risks: step.risks ?? [],
        ...(step.phase ? { phase: step.phase } : {}),
      }));
      const ids = new Set(steps.map((step) => step.id));
      if (ids.size !== steps.length) throw new Error("科研规划的步骤id不能重复");
      for (const step of steps) {
        if (!Array.isArray(step.dependsOn) || step.dependsOn.some(id => typeof id !== "string")) throw new Error(`步骤${step.id}的dependsOn必须是字符串数组`);
        const unknown = step.dependsOn.filter((dependency) => !ids.has(dependency));
        if (unknown.length) throw new Error(`步骤${step.id}引用了不存在的依赖：${unknown.join(", ")}`);
      }
      if (context.fixedPlanningDatasets || context.planningOnly) {
        const refs = [...(params.evidenceRefs ?? []), ...steps.flatMap(step => Array.isArray(step.inputs?.evidenceRefs) ? step.inputs!.evidenceRefs as string[] : [])];
        const trace = currentTelemetry()?.trace;
        const known = new Set(refs.filter(ref => trace?.hasRetrievedCard(ref)));
        const errors = fixedPlanStructureErrors({ ...params, steps }, context.fixedPlanningDatasets ?? params.datasets ?? [], { knownEvidenceIds: known });
        if (errors.length) throw new Error(`${context.planningOnly ? "自由规划" : "固定组合"}Plan结构无效：${errors.join("；")}`);
      }
      const plan = context.createPlan({
        objective: params.objective,
        assumptions: params.assumptions ?? [],
        requiredInputs: params.requiredInputs ?? [],
        datasets: params.datasets ?? [],
        ...(params.datasetRoles ? { datasetRoles: params.datasetRoles } : {}),
        ...(params.evidenceRefs ? { evidenceRefs: params.evidenceRefs } : {}),
        retrievalTrace: decision && selectedBundle ? {
          queryId: decision.queryId, decisionState: decision.state,
          datasetIds: selectedBundle.datasetIds, requirementIds: selectedBundle.requirementIds,
          evidenceRefs: selectedBundle.evidenceRefs,
        } : undefined,
        verifiedDataSources: (params.datasets ?? []).map((dataset) => context.dataSourceChecks.get(dataset))
          .filter((check) => check !== undefined),
        evidenceNeeds: params.evidenceNeeds ?? [],
        steps,
        deliverables: params.deliverables ?? [],
        risks: params.risks ?? [],
        estimatedCost: params.estimatedCost,
      });
      context.setTerminalAction({ type: "plan", plan });
      if ((context.fixedPlanningDatasets || context.planningOnly) && unit) recordExperimentPlan(unit, plan);
      return {
        content: [{ type: "text", text: `科研规划v${plan.version}已生成，正在等待用户确认。` }],
        details: { plan },
        terminate: true,
      };
    },
  });
}

export function createReportDataBlockedTool(context: OceanToolContext) {
  return defineTool({
    name: "report_data_blocked",
    label: "记录数据获取阻断",
    description: "自动获取并尝试官方备用入口后仍失败时，记录具体请求与恢复条件。只有真实认证或授权需求才能向用户请求协助；公开源超时、404、空切片或超限须先调整入口或范围，不能直接要求用户下载上传。",
    parameters: Type.Object({
      summary: Type.String({ description: "明确缺失或受限数据及暂不能执行的原因。逐数据集写明所需变量、时段、海域、分辨率、下载文件或子集；未经官方目录核验的具体文件名和下载步骤必须标为待确认，不能推测。" }),
    }),
    async execute(_id, params) {
      const sources = [...context.dataSourceChecks.values()];
      if (context.requiresDataValidation && !context.dataDiscoveryOnly
        && !context.dataAcquisitionAttempts?.size) {
        throw new Error("报告数据阻断前必须调用 acquire_scientific_data 尝试自动获取和官方备用入口。");
      }
      if (!sources.some((source) => source.status === "requires_access") && /上传|自行下载|手动下载/.test(params.summary)) {
        throw new Error("当前没有真实认证需求；不要将公开数据获取失败转交用户下载上传，请记录错误和可恢复的官方备用路径。");
      }
      const action = { type: "data_blocked" as const, summary: params.summary, sources };
      context.setTerminalAction(action);
      return {
        content: [{ type: "text", text: `已记录数据阻断：${params.summary}` }],
        details: action, terminate: true,
      };
    },
  });
}
