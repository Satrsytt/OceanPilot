import { safeProbe, redactDataUrl, DataAccessError } from "../../data-access/safe-http.js";
import { currentTelemetry } from "../../telemetry/run-telemetry.js";
import { defineTool } from "@earendil-works/pi-coding-agent";
import { Type } from "typebox";
import { realpath, stat } from "node:fs/promises";
import { isAbsolute, relative, resolve } from "node:path";
import type { DataSourceCheck, OceanToolContext } from "../tool-context.js";

interface ProbeResult { status: number; url: string; contentType: string; preview: string; errorType?: string }

async function probe(value: string, signal?: AbortSignal): Promise<ProbeResult> {
  try { return await safeProbe(value, signal); }
  catch (error) {
    if (signal?.aborted) throw error;
    const code = error instanceof DataAccessError ? error.code : "NETWORK_ERROR";
    return { status: error instanceof DataAccessError && error.requiresAuthentication ? 401 : 0,
      url: redactDataUrl(value), contentType: "", preview: code, errorType: code };
  }
}
const redactUrl = redactDataUrl;

function accessStatus(probeResult: ProbeResult, isData: boolean): DataSourceCheck["status"] {
  if (probeResult.status === 401
    || /urs\.earthdata\.nasa\.gov|oauth|login|sign.?in/i.test(probeResult.url)) return "requires_access";
  if (probeResult.status < 200 || probeResult.status >= 300) return "unavailable";
  if (isData && /(?:"error"\s*:|<error>|exception|dataset not found|no data found)/i.test(probeResult.preview)) {
    return "unavailable";
  }
  if (isData && /text\/html/i.test(probeResult.contentType)) {
    return /login|sign.?in|earthdata|password|authentication/i.test(probeResult.preview)
      ? "requires_access" : "metadata_only";
  }
  return isData ? "available" : "metadata_only";
}

export function createCheckOfficialDataSourceTool(context: OceanToolContext) {
  return defineTool({
    name: "check_official_data_source",
    label: "核验官方原始数据入口",
    description: "检查官方产品页与原始数据/API下载URL的实际HTTP响应、跳转、内容类型和权限状态。每个计划数据集分别调用；只有介绍页不能证明原始数据可获取。",
    parameters: Type.Object({
      dataset: Type.String({ description: "与规划 datasets 列表完全一致的标识；启用 P1/P2 时填写 DatasetCard ID" }),
      pageUrl: Type.String({ description: "官方产品介绍页 HTTPS URL" }),
      dataUrl: Type.Optional(Type.String({ description: "具体原始文件或数据API的 HTTPS URL；数据发现任务可暂不提供" })),
      uploadedPath: Type.Optional(Type.String({ description: "用户上传到当前项目 data/uploads 的原始文件绝对路径；需要先核对变量和时间覆盖" })),
    }),
    async execute(_id, params, signal) {
      const dataset = params.dataset.trim();
      if (!dataset) throw new Error("数据集名称不能为空");
      let check: DataSourceCheck;
      try {
        let uploaded: { path: string; bytes: number } | undefined;
        if (params.uploadedPath) {
          const root = resolve(context.workspacePath, "data", "uploads");
          const path = resolve(params.uploadedPath);
          const rel = relative(root, path);
          if (!isAbsolute(params.uploadedPath) || rel.startsWith("..") || isAbsolute(rel) || !rel) {
            throw new Error("上传文件必须位于当前项目 data/uploads 目录内");
          }
          const physicalRoot = await realpath(root);
          const physicalPath = await realpath(path);
          const physicalRelative = relative(physicalRoot, physicalPath);
          if (physicalRelative.startsWith("..") || isAbsolute(physicalRelative)) {
            throw new Error("上传文件不能通过符号链接指向项目目录外部");
          }
          const file = await stat(path);
          if (!file.isFile() || file.size === 0) throw new Error("上传的原始数据文件不存在或为空");
          uploaded = { path, bytes: file.size };
        }
        const page = await probe(params.pageUrl, signal);
        const pageStatus = accessStatus(page, false);
        const data = params.dataUrl ? await probe(params.dataUrl, signal) : undefined;
        const dataStatus = data ? accessStatus(data, true) : undefined;
        // A discovery-only Plan needs verified product metadata, not permission
        // to download its files. Keep the actual data-endpoint failure in reason
        // and errorType; acquisition/execution still require validated local data.
        const status = uploaded ? "available" : context.dataDiscoveryOnly && pageStatus === "metadata_only"
          && dataStatus !== "available" ? "metadata_only" : dataStatus ?? pageStatus;
        check = {
          dataset, pageUrl: redactUrl(params.pageUrl), ...(params.dataUrl ? { dataUrl: redactUrl(params.dataUrl) } : {}), status,
          reason: `产品页 HTTP ${page.status} (${page.contentType || "未知类型"}${page.errorType ? `；${page.errorType}` : ""})；${data ? `数据入口 HTTP ${data.status} (${data.contentType || "未知类型"}${data.errorType ? `；${data.errorType}` : ""}，最终域名 ${new URL(data.url).hostname})` : "尚无具体原始数据入口"}${uploaded ? `；当前项目已收到原始文件 ${uploaded.path} (${uploaded.bytes} 字节，变量及时间覆盖仍需读取文件核对)` : ""}`,
          ...((data?.errorType ?? page.errorType) ? { errorType: data?.errorType ?? page.errorType } : {}),
          checkedAt: new Date().toISOString(),
        };
      } catch (error) {
        check = {
          dataset, pageUrl: redactUrl(params.pageUrl), ...(params.dataUrl ? { dataUrl: redactUrl(params.dataUrl) } : {}),
          status: error instanceof DataAccessError && error.requiresAuthentication ? "requires_access" : "unavailable", reason: error instanceof Error ? error.message : String(error),
          errorType: error instanceof DataAccessError ? error.code : error instanceof Error ? error.name : "UNKNOWN_ERROR",
          checkedAt: new Date().toISOString(),
        };
      }
      // A later page probe must not downgrade already downloaded and validated data.
      const verified = context.dataSourceChecks.get(dataset);
      if (verified?.validated && verified.localPath) check = verified;
      context.dataSourceChecks.set(dataset, check);
      currentTelemetry()?.trace.emit("access_resolution", { status: check.status, dataset_id: dataset,
        page_url: check.pageUrl, data_url: check.dataUrl, reason: check.reason, error_type: check.errorType ?? null,
        validated: check.validated ?? false });
      if (check.status !== "unavailable") context.addCitation({
        sourceType: "web", sourceId: check.pageUrl, title: `${dataset} 官方入口`,
        url: check.pageUrl, evidenceText: check.reason,
        metadata: { accessStatus: check.status, dataUrl: check.dataUrl ?? null },
      });
      return { content: [{ type: "text", text: JSON.stringify(check) }], details: check };
    },
  });
}
