import { accessSync, constants, existsSync, mkdirSync } from "node:fs";
import { delimiter, dirname, isAbsolute, join, resolve } from "node:path";

export interface ScientificPython {
  pythonPath: string;
  venvPath?: string;
  source: "explicit_python" | "explicit_venv" | "workspace_venv" | "application_venv" | "path";
}

function executable(path: string): boolean {
  try { accessSync(path, process.platform === "win32" ? constants.F_OK : constants.X_OK); return true; }
  catch { return false; }
}

function pathCommand(command: string, env: NodeJS.ProcessEnv): string | undefined {
  const key = Object.keys(env).find(key => key.toLowerCase() === "path") ?? "PATH";
  return (env[key] ?? "").split(delimiter).filter(Boolean)
    .map(directory => join(directory, command)).find(executable);
}

/** Detect only the current platform's executable; copied Windows Scripts are not a Unix environment. */
export function resolveScientificPython(workspacePath: string, applicationRoot = workspacePath,
  env: NodeJS.ProcessEnv = process.env): ScientificPython {
  const fromVenv = (directory: string, source: ScientificPython["source"]): ScientificPython | undefined => {
    const path = join(directory, process.platform === "win32" ? "Scripts" : "bin", process.platform === "win32" ? "python.exe" : "python");
    return executable(path) ? { pythonPath: path, venvPath: directory, source } : undefined;
  };
  const explicit = env.OCEAN_PYTHON_PATH?.trim();
  if (explicit) {
    if (process.platform !== "win32" && /^[A-Za-z]:[\\/]/.test(explicit)) {
      throw new Error("OCEAN_PYTHON_PATH 仍是 Windows 路径，请配置当前平台可执行的 Python。");
    }
    const candidate = isAbsolute(explicit) ? explicit : /[\\/]/.test(explicit)
      ? resolve(applicationRoot, explicit) : pathCommand(explicit, env);
    if (!candidate || !executable(candidate)) throw new Error("OCEAN_PYTHON_PATH 未指向可执行的当前平台 Python。");
    const parent = dirname(candidate);
    const venvPath = /^(bin|Scripts)$/i.test(parent.split(/[\\/]/).at(-1) ?? "")
      && existsSync(join(dirname(parent), "pyvenv.cfg")) ? dirname(parent) : undefined;
    return { pythonPath: candidate, venvPath, source: "explicit_python" };
  }
  if (env.OCEAN_PYTHON_VENV?.trim()) {
    const directory = resolve(applicationRoot, env.OCEAN_PYTHON_VENV.trim());
    const result = fromVenv(directory, "explicit_venv");
    if (!result) throw new Error("OCEAN_PYTHON_VENV 未指向当前平台可执行的虚拟环境。");
    return result;
  }
  const local = fromVenv(resolve(workspacePath, ".venv"), "workspace_venv")
    ?? fromVenv(resolve(applicationRoot, ".venv"), "application_venv");
  if (local) return local;
  for (const command of process.platform === "win32" ? ["python.exe", "python3.exe"] : ["python3", "python"]) {
    const path = pathCommand(command, env);
    if (path) return { pythonPath: path, source: "path" };
  }
  throw new Error("找不到当前平台的 Python；请配置 OCEAN_PYTHON_PATH 或安装项目 .venv。");
}

/** Per-command environment avoids changing PATH across concurrent project sessions. */
export function pythonExecutionEnvironment(workspacePath: string, applicationRoot = workspacePath,
  env: NodeJS.ProcessEnv = process.env): NodeJS.ProcessEnv {
  const python = resolveScientificPython(workspacePath, applicationRoot, env);
  const key = Object.keys(env).find(key => key.toLowerCase() === "path") ?? "PATH";
  const mplConfig = env.MPLCONFIGDIR ?? resolve(workspacePath, ".cache", "matplotlib");
  mkdirSync(mplConfig, { recursive: true });
  return { ...env,
    [key]: [...new Set([dirname(python.pythonPath), dirname(process.execPath), ...(env[key] ?? "").split(delimiter).filter(Boolean)])].join(delimiter),
    ...(python.venvPath ? { VIRTUAL_ENV: python.venvPath } : {}),
    OCEAN_PYTHON_PATH: python.pythonPath,
    OCEAN_DATA_PYTHON: env.OCEAN_DATA_PYTHON ?? python.pythonPath,
    MPLCONFIGDIR: mplConfig, MPLBACKEND: env.MPLBACKEND ?? "Agg", PYTHONIOENCODING: "utf-8",
  };
}
