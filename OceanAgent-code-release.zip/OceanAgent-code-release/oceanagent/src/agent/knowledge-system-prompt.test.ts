import { readFile } from "node:fs/promises";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";
import { prepareKnowledgeSystemPrompt } from "./session-factory.js";

describe("knowledge ablation system prompt", () => {
  it("preserves the original on-mode instructions byte for byte", async () => {
    const prompt = await readFile(resolve(import.meta.dirname, "../../.pi/SYSTEM.md"), "utf8");
    expect(prepareKnowledgeSystemPrompt(prompt, "on")).toBe(prompt);
  });
  it("removes forced card retrieval while preserving real scientific-data and execution requirements", async () => {
    const prompt = await readFile(resolve(import.meta.dirname, "../../.pi/SYSTEM.md"), "utf8");
    const off = prepareKnowledgeSystemPrompt(prompt, "off");
    for (const tool of ["search_research_cases", "expand_research_case", "search_ocean_datasets", "get_dataset_facts", "trace_global_knowledge_graph"]) {
      expect(off).not.toContain(tool);
    }
    expect(off).not.toContain("必须先实际调用 Ocean-RAG");
    expect(off).not.toContain("读取 DatasetCard");
    expect(off).not.toContain("知识库使用记录”");
    for (const requirement of ["acquire_scientific_data", "内容类型、权限和覆盖", "检查兼容性", "不得提前运行研究分析计算", "真实退出码和异常", "用户明确确认"]) {
      expect(off).toContain(requirement);
    }
    expect(off).toContain("本轮知识库隔离"); expect(off).toContain("直接查找官方元数据");
  });
});
