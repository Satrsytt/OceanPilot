import type { ResearchPlan } from "../contracts.js";
import type { ConversationRepository } from "../db/conversation-repository.js";
import type { PlanRepository } from "../db/plan-repository.js";
import type { RunRepository } from "../db/run-repository.js";

/** The selected ResearchPlan is passed unchanged to the existing runner. */
export function selectPlanForExecution(
  plan: ResearchPlan,
  dependencies: { plans: PlanRepository; conversations: ConversationRepository; runs: RunRepository },
  model: string,
) {
  if (plan.status !== "awaiting_approval" || !plan.nodeId) throw new Error("科研规划尚未就绪或已被选择");
  if (plan.candidateGroupId && plan.feasibilityStatus !== "executable") {
    throw new Error("候选规划未通过全部执行前检查");
  }
  if (dependencies.runs.findActive(plan.conversationId)) throw new Error("当前会话已有正在运行的任务");
  const userNode = dependencies.conversations.addNode({
    conversationId: plan.conversationId, parentId: plan.nodeId, role: "user",
    content: `已选择科研规划 ${plan.title ?? `v${plan.version}`}（${plan.id}），请开始执行。`,
    metadata: { approvedPlanId: plan.id, selected_plan_id: plan.id },
  });
  const run = dependencies.runs.create(plan.conversationId, userNode.id, model);
  dependencies.runs.saveCheckpoint(run.id, { selected_plan_id: plan.id, progress: "已选择候选规划" });
  if (plan.candidateGroupId) {
    for (const other of dependencies.plans.list(plan.conversationId)) {
      if (other.id !== plan.id && other.candidateGroupId === plan.candidateGroupId
        && other.status === "awaiting_approval") dependencies.plans.updateStatus(other.id, "rejected");
    }
  }
  dependencies.plans.updateStatus(plan.id, "approved");
  const executingPlan = dependencies.plans.updateStatus(plan.id, "executing");
  return { plan: executingPlan, run: dependencies.runs.get(run.id)!, userNode };
}
