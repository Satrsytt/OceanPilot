import type { ModelRuntime } from "@earendil-works/pi-coding-agent";

type Node = Record<string, unknown>;
type Model = Parameters<ModelRuntime["streamSimple"]>[0];
type Options = NonNullable<Parameters<ModelRuntime["streamSimple"]>[2]>;
type PayloadHook = NonNullable<Options["onPayload"]>;
const object = (value: unknown): value is Node => !!value && typeof value === "object" && !Array.isArray(value);
const maps = new Set(["properties", "patternProperties", "$defs", "$def", "definitions", "dependentSchemas"]);
const children = new Set(["items", "additionalItems", "additionalProperties", "contains", "propertyNames", "not", "if", "then", "else"]);
const unions = new Set(["anyOf", "oneOf", "allOf", "prefixItems"]);

/** Clone schema nodes, not arbitrary enum/default data or property names. Execution schemas stay intact. */
function mapSchema(schema: unknown, visit: (node: Node) => Node): unknown {
  if (!object(schema)) return schema;
  const node: Node = { ...schema };
  for (const [key, value] of Object.entries(node)) {
    if (maps.has(key) && object(value)) node[key] = Object.fromEntries(Object.entries(value)
      .map(([name, child]) => [name, mapSchema(child, visit)]));
    else if (children.has(key) && object(value)) node[key] = mapSchema(value, visit);
    else if ((unions.has(key) || key === "items") && Array.isArray(value)) {
      node[key] = value.map(child => mapSchema(child, visit));
    }
  }
  return visit(node);
}

export function normalizeDeepSeekSchema(schema: unknown, strict = false): unknown {
  return mapSchema(schema, node => {
    const tuple = Array.isArray(node.items) ? node.items : Array.isArray(node.prefixItems) ? node.prefixItems : undefined;
    const tupleClosed = node.additionalItems === false || Array.isArray(node.prefixItems) && node.items === false;
    if (tuple) {
      const variants = [...tuple];
      if (Array.isArray(node.prefixItems) && object(node.items)) variants.push(node.items);
      const unique = [...new Map(variants.map(item => [JSON.stringify(item), item])).values()];
      node.items = unique.length === 1 ? unique[0] : unique.length ? { anyOf: unique } : {};
      delete node.prefixItems; delete node.additionalItems;
    }
    if (node.type === "array" || tuple) {
      const minimum = node.minItems, maximum = node.maxItems ?? (tuple && tupleClosed ? tuple.length : undefined);
      if (minimum !== undefined || maximum !== undefined) {
        const length = minimum === maximum ? `exactly ${minimum}` : `${minimum ?? 0}..${maximum ?? "unbounded"}`;
        node.description = `${typeof node.description === "string" ? node.description + " " : ""}Array length ${length}; enforced by the application.`;
      }
      // DeepSeek strict rejects these; retaining them is never our execution-side length guarantee.
      delete node.minItems; delete node.maxItems;
    }
    if (strict) { delete node.minLength; delete node.maxLength; }
    return node;
  });
}

export interface ToolSchemaIssue { tool: string; path: string; keyword: string }
const strictUnsupported = ["minItems", "maxItems", "minLength", "maxLength", "patternProperties", "oneOf", "allOf", "not", "contains", "prefixItems"];

/** A small outgoing-schema scan. Optional strict=true also exposes latent strict-only incompatibilities. */
export function scanDeepSeekToolSchemas(payload: unknown, forceStrict = false): ToolSchemaIssue[] {
  if (!object(payload) || !Array.isArray(payload.tools)) return [];
  const issues: ToolSchemaIssue[] = [];
  for (const tool of payload.tools) {
    if (!object(tool) || tool.type !== "function") continue;
    const fn = object(tool.function) ? tool.function : tool;
    const strict = forceStrict || fn.strict === true;
    const name = typeof fn.name === "string" ? fn.name : "unknown";
    const walk = (schema: unknown, path: string) => {
      if (!object(schema)) return;
      if (schema.items !== undefined && typeof schema.items !== "boolean" && !object(schema.items)) {
        issues.push({ tool: name, path: `${path}.items`, keyword: "items" });
      }
      if (strict) {
        for (const key of strictUnsupported) if (schema[key] !== undefined) issues.push({ tool: name, path: `${path}.${key}`, keyword: key });
        if (schema.type === "object") {
          if (schema.additionalProperties !== false) issues.push({ tool: name, path: `${path}.additionalProperties`, keyword: "additionalProperties" });
          const required = Array.isArray(schema.required) ? schema.required : [];
          if (object(schema.properties) && Object.keys(schema.properties).some(key => !required.includes(key))) {
            issues.push({ tool: name, path: `${path}.required`, keyword: "required" });
          }
        }
      }
      for (const [key, value] of Object.entries(schema)) {
        if (maps.has(key) && object(value)) for (const [name, child] of Object.entries(value)) walk(child, `${path}.${key}.${name}`);
        else if (children.has(key) && object(value)) walk(value, `${path}.${key}`);
        else if ((unions.has(key) || key === "items") && Array.isArray(value)) value.forEach((child, i) => walk(child, `${path}.${key}[${i}]`));
      }
    };
    walk(fn.parameters, "parameters");
  }
  return issues;
}

/** Runs after the SDK serializer and existing callbacks, just before HTTP. Never changes strict mode. */
export function normalizeDeepSeekToolPayload(payload: unknown): unknown {
  if (!object(payload) || !Array.isArray(payload.tools)) return payload;
  const result = { ...payload, tools: payload.tools.map(tool => {
    if (!object(tool) || tool.type !== "function") return tool;
    const fn = object(tool.function) ? tool.function : tool;
    const normalized = { ...fn, parameters: normalizeDeepSeekSchema(fn.parameters, fn.strict === true) };
    return object(tool.function) ? { ...tool, function: normalized } : normalized;
  }) };
  const issues = scanDeepSeekToolSchemas(result);
  if (issues.length) {
    // Arbitrary dictionary inputs cannot be silently closed or dropped to claim strict compatibility.
    throw new Error(`DeepSeek tool schema is incompatible: ${issues.map(issue => `${issue.tool}.${issue.path}`).join(", ")}`);
  }
  return result;
}

function isDeepSeek(model: Model): boolean {
  if (model.provider === "deepseek") return true;
  try { return new URL(model.baseUrl).hostname === "api.deepseek.com"; } catch { return false; }
}
function payloadHook(previous?: PayloadHook): PayloadHook {
  return async (payload, model) => {
    const next = await previous?.(payload, model);
    return normalizeDeepSeekToolPayload(next === undefined ? payload : next);
  };
}
const installed = new WeakSet<ModelRuntime>();
export function installToolSchemaCompatibility(runtime: ModelRuntime): void {
  if (installed.has(runtime)) return;
  installed.add(runtime);
  const stream = runtime.stream.bind(runtime), streamSimple = runtime.streamSimple.bind(runtime);
  runtime.stream = ((model, context, options) => stream(model, context, (isDeepSeek(model)
    ? { ...options, onPayload: payloadHook(options?.onPayload) } : options) as typeof options)) as ModelRuntime["stream"];
  runtime.streamSimple = ((model, context, options) => streamSimple(model, context, isDeepSeek(model)
    ? { ...options, onPayload: payloadHook(options?.onPayload) } : options)) as ModelRuntime["streamSimple"];
}
