import type { ResearchPlan } from "../contracts.js";
import type { TerminalAction } from "./tool-context.js";

export function renderPlan(plan: ResearchPlan): string {
  const lines = [
    `## 科研规划 v${plan.version}`,
    "",
    `**研究目标：** ${plan.objective}`,
  ];
  if (plan.datasets.length) lines.push("", `**建议数据：** ${plan.datasets.join("、")}`);
  if (plan.verifiedDataSources?.length) {
    lines.push("", "### 已核验数据入口");
    for (const source of plan.verifiedDataSources) {
      lines.push(`- **${source.dataset}**：${source.status}；[官方产品页](${source.pageUrl})${source.dataUrl ? `；[原始数据入口](${source.dataUrl})` : ""}。${source.reason}`);
    }
  }
  if (plan.assumptions.length) lines.push("", "**当前假设：**", ...plan.assumptions.map((item) => `- ${item}`));
  lines.push("", "### 执行步骤");
  plan.steps.forEach((step, index) => {
    const dependency = step.dependsOn.length ? `（依赖：${step.dependsOn.join("、")}）` : "";
    lines.push("", `${index + 1}. **${step.title}** ${dependency}`, `   ${step.description}`);
    if (step.expectedOutputs.length) lines.push(`   产物：${step.expectedOutputs.join("、")}`);
  });
  if (plan.deliverables.length) lines.push("", "### 预期产物", ...plan.deliverables.map((item) => `- ${item}`));
  if (plan.risks.length) lines.push("", "### 风险与限制", ...plan.risks.map((item) => `- ${item}`));
  if (plan.estimatedCost) lines.push("", `**预计成本/时间：** ${plan.estimatedCost}`);
  lines.push("", "请确认是否按此规划执行，或指出需要修改的步骤。当前尚未开始执行。 ");
  return lines.join("\n");
}

export function renderTerminalAction(action: TerminalAction): string {
  if (action.type === "recommendation") return ["数据集推荐（尚未执行科学分析）", "",
    ...action.recommendation.candidates.map(item => `${item.rank}. ${item.dataset_id}：${item.rationale}`),
    "", "排序表示本次推荐优先级；能力与角色为待独立验证的声明。"].join("\n");
  if (action.type === "plan") return renderPlan(action.plan);
  if (action.type === "plan_candidates") return [
    action.plans.length ? "## 可选科研规划" : "## 当前没有完整可执行规划",
    "", action.comparisonSummary,
    ...(action.plans.length ? ["", "请在右侧选择一条规划执行；其余方案保留为备选。"] : []),
    ...(action.gaps.length ? ["", "### 未通过检查的候选与下一步", ...action.gaps.map((gap) => `- ${gap}`)] : []),
  ].join("\n");
  if (action.type === "data_blocked") return [
    "## 数据获取受阻",
    "",
    action.summary,
    "",
    "下列链接仅供查找官方数据。产品页不等于原始文件；数据入口的 HTTP 响应也不能单独证明变量、时段和海域符合本次研究。点击后会在新标签页打开，当前对话会保留。",
    "",
    ...action.sources.flatMap((source) => [
      `- **${source.dataset}**：${source.status}；${source.reason}`,
      `  [打开官方产品页](${source.pageUrl})${source.dataUrl ? `；[打开候选数据入口](${source.dataUrl})` : ""}`,
    ]),
    "",
    action.sources.some((source) => source.status === "requires_access")
      ? "官方入口确实需要认证或授权。请在官方渠道完成授权后继续；不要在聊天或日志中提交密码、API密钥或令牌。"
      : "自动获取的访问记录和有效缓存已保留。公开服务的临时故障、无效入口或空切片可通过官方备用入口、请求范围调整继续处理。",
  ].join("\n");
  return [
    action.summary,
    "",
    ...action.questions.map((question, index) => `${index + 1}. **${question.label}**：${question.question}`),
  ].join("\n");
}
