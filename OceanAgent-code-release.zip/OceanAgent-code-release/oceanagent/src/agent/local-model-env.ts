import { existsSync, readFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { parseEnv } from "node:util";

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), "../..");
const KEYS = ["DASHSCOPE_API_KEY", "QWEN_BASE_URL", "QWEN_JUDGE_MODEL"] as const;
/** Installation-relative, whitelist-only and no interpolation. Never log values or overwrite shell env. */
export function loadLocalModelEnvironment(root = ROOT, env: NodeJS.ProcessEnv = process.env) {
  const loaded: string[] = [], files: string[] = [];
  for (const name of [".env.local", ".env.loacl", ".env"]) {
    const path = resolve(root, name); if (!existsSync(path)) continue;
    const values = parseEnv(readFileSync(path, "utf8")); files.push(name);
    for (const key of KEYS) if (!env[key] && values[key]?.trim()) { env[key] = values[key]; loaded.push(key); }
  }
  return { files, loaded_names: loaded, key_present: Boolean(env.DASHSCOPE_API_KEY) };
}
