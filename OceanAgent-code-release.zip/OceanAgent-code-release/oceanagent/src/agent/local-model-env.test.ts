import { afterEach, expect, it } from "vitest";
import { mkdtemp, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { loadLocalModelEnvironment } from "./local-model-env.js";
const dirs:string[]=[];
afterEach(async()=>{for(const d of dirs.splice(0))await rm(d,{recursive:true,force:true});});
it("loads local aliases without overwriting shell values or importing unrelated settings",async()=>{
 const d=await mkdtemp(join(tmpdir(),"ocean-env-"));dirs.push(d);
 await writeFile(join(d,".env.local"),'DASHSCOPE_API_KEY="local-test-only"\nPORT=9999\nQWEN_BASE_URL=https://example.org/v1');
 await writeFile(join(d,".env.loacl"),'DASHSCOPE_API_KEY=legacy-test-only\nQWEN_JUDGE_MODEL=qwen-plus');
 const env:NodeJS.ProcessEnv={DASHSCOPE_API_KEY:"shell-test-only"};const r=loadLocalModelEnvironment(d,env);
 expect(env).toEqual({DASHSCOPE_API_KEY:"shell-test-only",QWEN_BASE_URL:"https://example.org/v1",QWEN_JUDGE_MODEL:"qwen-plus"});
 expect(r).not.toHaveProperty("apiKey");expect(JSON.stringify(r)).not.toContain("test-only");
});
it("works with the existing misspelled filename and fresh process environment",async()=>{
 const d=await mkdtemp(join(tmpdir(),"ocean-env-"));dirs.push(d);
 await writeFile(join(d,".env.loacl"),'DASHSCOPE_API_KEY=legacy-test-only');
 const env:NodeJS.ProcessEnv={};expect(loadLocalModelEnvironment(d,env).key_present).toBe(true);expect(env.DASHSCOPE_API_KEY).toBe("legacy-test-only");
 expect(loadLocalModelEnvironment(d,env).loaded_names).toEqual([]);
});
