import { chmod, mkdir, mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { dirname, join, resolve } from "node:path";
import { afterEach, describe, expect, it } from "vitest";
import { pythonExecutionEnvironment, resolveScientificPython } from "./python-environment.js";
import { createLocalScientificBashTool } from "./session-factory.js";

const temporary: string[] = [];
afterEach(async () => { for (const path of temporary.splice(0)) await rm(path, { recursive: true, force: true }); });
async function workspace() { const path = await mkdtemp(join(tmpdir(), "ocean-python-")); temporary.push(path); return path; }
const quote = (value: string) => `'${value.replaceAll("'", "'\\''")}'`;

describe.skipIf(process.platform === "win32")("native Python environment", () => {
  it("ignores copied Windows executables and rejects explicit Windows configuration", async () => {
    const path = await workspace(); await mkdir(join(path, ".venv", "Scripts"), { recursive: true });
    await writeFile(join(path, ".venv", "Scripts", "python.exe"), "Windows binary placeholder");
    const env = { PATH: "/usr/bin:/bin" };
    expect(resolveScientificPython(path, path, env)).toMatchObject({ pythonPath: "/usr/bin/python3", source: "path" });
    expect(() => resolveScientificPython(path, path, { ...env, OCEAN_PYTHON_PATH: "D:\\old\\python.exe" })).toThrow("Windows 路径");
  });

  it("selects the workspace native venv without mutating the process environment", async () => {
    const path = await workspace(); const bin = join(path, ".venv", "bin"); await mkdir(bin, { recursive: true });
    const python = join(bin, "python"); await writeFile(python, "#!/bin/sh\nexit 0\n"); await chmod(python, 0o755);
    const original = { PATH: "/usr/bin:/bin" };
    const env = pythonExecutionEnvironment(path, path, original);
    expect(env.PATH?.split(":")[0]).toBe(bin);
    expect(env.OCEAN_DATA_PYTHON).toBe(python); expect(env.VIRTUAL_ENV).toBe(dirname(bin));
    expect(env.MPLCONFIGDIR).toBe(join(path, ".cache", "matplotlib")); expect(original.PATH).toBe("/usr/bin:/bin");
  });

  it("runs real scientific Python through the Agent Bash override and retains explicit step identity", async () => {
    const path = await workspace(); const application = resolve(import.meta.dirname, "../..");
    const script = join(path, "smoke.py");
    await writeFile(script, `import json, sys\nimport numpy as np, pandas as pd, xarray as xr, netCDF4, yaml, jsonschema\nfrom scipy.stats import linregress\nimport matplotlib.pyplot as plt\ny=np.array([1.,3.,5.]); slope=float(linregress(np.arange(3),y).slope)\nds=xr.Dataset({'value':('time',y)},coords={'time':pd.date_range('2022-05-01',periods=3)})\nds['value'].attrs['units']='degree_C'; ds.to_netcdf('smoke.nc')\nwith xr.open_dataset('smoke.nc') as opened:\n assert float(opened.value.mean())==3.0 and opened.value.attrs['units']=='degree_C'\nplt.plot(y);plt.savefig('smoke.png');plt.close()\nresult={'slope':slope,'mean':float(y.mean()),'python':sys.executable}\njsonschema.validate(result,{'type':'object','required':['slope','mean']})\nopen('result.json','w').write(json.dumps(result));print(json.dumps(result))\n`);
    const result = await createLocalScientificBashTool(path, application).execute("science-smoke", {
      command: `python -u ${quote(script)}`, timeout: 30, planStepId: "S_ANALYSIS",
    }, undefined, undefined, undefined as never);
    expect(JSON.parse(await readFile(join(path, "result.json"), "utf8"))).toMatchObject({ slope: 2, mean: 3 });
    expect(result.details).toMatchObject({ planStepId: "S_ANALYSIS" }); expect(result.details.elapsedMs).toBeGreaterThan(0);
    expect((await readFile(join(path, "smoke.png"))).length).toBeGreaterThan(0);
  }, 30000);
});
