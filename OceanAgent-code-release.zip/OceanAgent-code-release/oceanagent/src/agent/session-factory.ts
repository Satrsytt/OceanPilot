import { existsSync } from "node:fs";
import { mkdir, readFile } from "node:fs/promises";
import { delimiter, resolve } from "node:path";
import {
  createAgentSession,
  createBashToolDefinition,
  createReadToolDefinition,
  createEditToolDefinition,
  createWriteToolDefinition,
  defineTool,
  DefaultResourceLoader,
  type SessionManager,
  type ToolDefinition,
} from "@earendil-works/pi-coding-agent";
import type { AppConfig } from "../config.js";
import { OceanModelService } from "./model-service.js";
import { ACTIVE_TOOL_NAMES } from "./tools/index.js";
import { createLocalPowerShellTool } from "./tools/local-powershell.js";
import { Type } from "typebox";
import { pythonExecutionEnvironment, resolveScientificPython } from "./python-environment.js";
import { prepareNoBundleSystemPrompt, resolveAblationPolicy } from "../experiments/ablation-policy.js";
import { KB_PLANNING_INSTRUCTION, kbFreePlanningProtocol, kbPlanningToolNames, kbPlanningRepairProtocol, kbPlanningSystemPrompt } from "../experiments/kb-ablation-protocol.js";
import { createKbPlanningToolCoordinator, shouldFinalizeKbPlanning, kbPlanIsFinalizing } from "../experiments/kb-planning-control.js";
import { sandboxBashSpawnHook, wrapExperimentTool, type ExperimentToolIsolationOptions } from "../experiments/tool-isolation.js";
import { consumeExperimentTool, experimentPlan, experimentRecommendation, remainingExperimentMs } from "../experiments/runtime-context.js";
import { scientificProtocol } from "../experiments/scientific-protocol.js";
import { createRecommendationToolCoordinator } from "../experiments/recommendation-efficiency.js";

/** The off condition disables knowledge instructions as well as tool registration. */
export function prepareKnowledgeSystemPrompt(prompt: string, mode: "on" | "off", publicCatalog = false): string {
  if (mode === "on") return prompt;
  const knowledgeOnly = /必须先实际调用 Ocean-RAG|Ocean-RAG 检索过程|当前知识库以|publication_quality\.status|需要知识库时|NSFC-D06|D06受控领域|问题卡检索|ProblemSolutionCard|UsageBundleCard|DatasetCard 只保存|search_research_cases|expand_research_case|search_ocean_datasets|get_dataset_facts|trace_global_knowledge_graph|ID精确展开只读取已经选择的卡片/;
  const lines = prompt.split(/\r?\n/).filter(line => !knowledgeOnly.test(line)).map(line => {
    // Preserve the actual acquisition and scientific validation rule without its card dependency.
    if (line.includes("acquire_scientific_data")) return line
      .replace(/读取 DatasetCard 和官方元数据/g, "读取官方元数据")
      .replace(/、官方介绍页或本地 DatasetCard/g, "或官方介绍页");
    if (line.includes("引用已经展开或精确读取的结果时保留 card_id")) {
      return "- 引用已核实的官方来源、原始数据、论文或文献页码；候选搜索结果不视为最终引用。";
    }
    return line;
  });
  const prefix = publicCatalog ? "【A0私有过程知识隔离】不使用PSC、UBC、历史DAG及私有共用关系。公共DatasetCard目录与官方事实和其他条件相同，可使用search_ocean_datasets/get_dataset_facts。"
    : "【本轮知识库隔离】不使用 Ocean-RAG、Three-Card 或历史卡片，也不要求知识库使用记录。直接查找官方元数据与可核验来源；数据获取、内容验证、规划审批和执行要求保持有效。";
  return prefix + "\n\n" + lines.join("\n");
}

export function createPlatformCoreToolOverrides(rootDir: string, applicationRoot = rootDir): ToolDefinition<any, any, any>[] {
  if (process.platform !== "win32") return [createLocalScientificBashTool(rootDir, applicationRoot)];
  ensureWindowsPowerShellOnPath();
  return [createLocalPowerShellTool(rootDir, resolve(applicationRoot, "data", "tool-logs"), applicationRoot)];
}

export function createLocalScientificBashTool(cwd: string, applicationRoot = cwd, isolation?: ExperimentToolIsolationOptions) {
  const python = resolveScientificPython(cwd, applicationRoot);
  const sandboxHook = isolation ? sandboxBashSpawnHook(isolation) : undefined;
  const bash = createBashToolDefinition(cwd, {
    ...(isolation ? { shellPath: "/bin/bash", exposeSessionEnvironment: false } : {}),
    spawnHook: context => sandboxHook ? sandboxHook(context) : ({ ...context,
      env: pythonExecutionEnvironment(context.cwd, applicationRoot, context.env) }),
  });
  return defineTool({ ...bash,
    description: `${bash.description}\n当前平台使用 Bash，科学 Python：${python.pythonPath}；默认超时1800秒、最大7200秒。已批准 Plan 的真实分析调用应携带 planStepId；它用于运行日志关联，不代表审批。`,
    parameters: Type.Object({ command: Type.String(),
      timeout: Type.Optional(Type.Number({ minimum: 0, maximum: 7200, description: "超时秒数，默认1800，最大7200" })),
      planStepId: Type.Optional(Type.String({ minLength: 1, maxLength: 80, description: "仅填写已批准 Plan 中本次命令实际执行的步骤 ID；不填写时不宣称步骤级执行。" })),
    }),
    async execute(id, params, signal, onUpdate, context) {
      const timeout = params.timeout ?? 1800;
      if (!Number.isFinite(timeout) || timeout <= 0 || timeout > 7200) throw new Error("timeout 必须是0到7200之间的有效秒数。");
      const started = performance.now();
      const boundedTimeout = isolation && isolation.beforeExecute
        ? Math.min(timeout, Math.max(0.001, remainingExperimentMsForIsolation(isolation) / 1000)) : timeout;
      const result = await bash.execute(id, { command: params.command, timeout: boundedTimeout }, signal, onUpdate, context);
      return { ...result, details: { ...result.details, elapsedMs: performance.now() - started, exitCode: 0,
        ...(result.details?.fullOutputPath ? { outputPath: result.details.fullOutputPath } : {}),
        ...(params.planStepId ? { planStepId: params.planStepId } : {}) } };
    },
  });
}

// The shared unit deadline is also enforced by the worker's abort timer. Bash must
// not continue for its normal 30 minute default after an experiment is cancelled.
function remainingExperimentMsForIsolation(options: ExperimentToolIsolationOptions): number {
  return (options as ExperimentToolIsolationOptions & { remainingMs?: () => number }).remainingMs?.() ?? 7_200_000;
}

function ensureWindowsPowerShellOnPath(): void {
  const pathKey = Object.keys(process.env).find((key) => key.toLowerCase() === "path") ?? "PATH";
  const currentEntries = (process.env[pathKey] ?? "").split(delimiter).filter(Boolean);
  const normalized = new Set(currentEntries.map((entry) => entry.toLowerCase()));
  const windowsRoot = process.env.SystemRoot ?? process.env.WINDIR ?? "C:\\Windows";
  const candidates = [
    resolve(process.env.ProgramFiles ?? "C:\\Program Files", "PowerShell", "7"),
    resolve(windowsRoot, "System32", "WindowsPowerShell", "v1.0"),
  ].filter((entry) => existsSync(entry) && !normalized.has(entry.toLowerCase()));

  if (candidates.length > 0) {
    process.env[pathKey] = [...candidates, ...currentEntries].join(delimiter);
  }
}

export class OceanSessionFactory {
  private constructor(
    private readonly config: AppConfig,
    private readonly systemPrompt: string,
    private readonly models: OceanModelService,
  ) {}

  static async create(config: AppConfig, models: OceanModelService): Promise<OceanSessionFactory> {
    const systemPrompt = await readFile(resolve(config.rootDir, ".pi/SYSTEM.md"), "utf8");
    return new OceanSessionFactory(config, systemPrompt, models);
  }

  async createSession(
    sessionManager: SessionManager,
    customTools: ToolDefinition[],
    cwd = this.config.rootDir,
    activeToolNames: readonly string[] = ACTIVE_TOOL_NAMES,
    modelValue?: string,
    additionalSystemPrompt?: string,
  ) {
    const experiment = this.config.experiment;
    const agentDir = experiment ? resolve(experiment.paths.runtime_home, "pi-runtime") : resolve(this.config.rootDir, "data/pi-runtime");
    await mkdir(agentDir, { recursive: true });
    const loader = new DefaultResourceLoader({
      cwd,
      agentDir,
      systemPromptOverride: () => {
        const experiment = this.config.experiment;
        // V2 uses one planning-only contract in both arms. Do not inherit general
        // acquisition, file execution, mandatory successful access or retry rules.
        if (kbPlanningRepairProtocol(experiment?.runtime_config)) return kbPlanningSystemPrompt(experiment!.condition);
        const policy = resolveAblationPolicy(experiment?.condition
          ?? (process.env.OCEANAGENT_KNOWLEDGE_MODE === "off" ? "A0" : "A1"), scientificProtocol(experiment?.runtime_config));
        const prompt = prepareKnowledgeSystemPrompt(
          [this.systemPrompt, additionalSystemPrompt].filter(Boolean).join("\n\n"), policy.knowledgeMode, Boolean(policy.publicDatasetAccessEnabled));
        const sharedCatalog = policy.publicDatasetAccessEnabled
          ? "\n【共同公开目录】三条件共有相同官方产品目录。search_ocean_datasets/get_dataset_facts允许访问公共产品事实；这不授予私有PSC、UBC或历史关系访问。"
            + (experiment?.runtime_config.mode === "plan"
              ? "本轮只用固定组合提出Plan，使用propose_research_plan，不要求下载或实际执行；未知版本与作者生成数据应写入假设。\n"
              : "推荐使用submit_dataset_recommendation，不以下载或Plan成功为提交前提。\n") : "";
        return (policy.bundleAccessEnabled || !policy.knowledgeAccessEnabled ? prompt : prepareNoBundleSystemPrompt(prompt)) + sharedCatalog
          + (kbFreePlanningProtocol(experiment?.runtime_config) ? `\n【规划生成工具范围】${KB_PLANNING_INSTRUCTION}` : "");
      },
      appendSystemPromptOverride: () => [],
      noContextFiles: true,
      noSkills: true,
      noExtensions: true,
      noPromptTemplates: true,
      noThemes: true,
    });
    await loader.reload();
    const model = this.models.resolveRunModel(modelValue);
    const scopedModels = this.models.enabledModels().map((item) => ({
      model: this.models.runtime.getModel(item.providerId, item.modelId)!,
      thinkingLevel: "medium" as const,
    }));
    const isolation = experiment ? {
      workspace: cwd, unitDir: experiment.paths.unit_dir, runtimeHome: experiment.paths.runtime_home,
      applicationRoot: this.config.rootDir, pythonExecutable: resolveScientificPython(cwd, this.config.rootDir).pythonPath,
      nodeExecutable: process.execPath, beforeExecute: () => consumeExperimentTool(experiment),
      remainingMs: () => remainingExperimentMs(experiment),
    } : undefined;
    const coreTools: ToolDefinition<any, any, any>[] = isolation
      ? [createReadToolDefinition(cwd), createLocalScientificBashTool(cwd, this.config.rootDir, isolation),
        createEditToolDefinition(cwd), createWriteToolDefinition(cwd)] : [];
    const recommendationCoordinator = experiment && kbPlanningRepairProtocol(experiment.runtime_config)
      ? createKbPlanningToolCoordinator(experiment)
      : experiment && (scientificProtocol(experiment.runtime_config) || kbFreePlanningProtocol(experiment.runtime_config))
      && ["recommendation", "plan"].includes(String(experiment.runtime_config.mode))
      ? createRecommendationToolCoordinator(experiment.runtime_config.mode as "recommendation" | "plan") : undefined;
    const localTools = isolation
      ? [...coreTools, ...customTools].filter(tool => !kbFreePlanningProtocol(experiment?.runtime_config)
        || activeToolNames.includes(tool.name) && kbPlanningToolNames(experiment!.condition).includes(tool.name))
          // The outer isolation wrapper still charges cached calls against the same tool budget.
          .map(tool => recommendationCoordinator ? recommendationCoordinator(tool) : tool)
          .map(tool => wrapExperimentTool(tool, isolation))
      : [...createPlatformCoreToolOverrides(cwd, this.config.rootDir), ...customTools];
    const created = await createAgentSession({
      cwd,
      agentDir,
      modelRuntime: this.models.runtime,
      model,
      scopedModels,
      thinkingLevel: "medium",
      tools: kbFreePlanningProtocol(experiment?.runtime_config)
        ? activeToolNames.filter(name => kbPlanningToolNames(experiment!.condition).includes(name)) : [...activeToolNames],
      customTools: localTools,
      resourceLoader: loader,
      sessionManager,
    });
    if (recommendationCoordinator && experiment) {
      // SDK terminate:true stops only when every tool in the assistant batch opts in.
      // A reasoning/report tool beside submission must not trigger another model turn.
      const agent = created.session.agent;
      const previousStop = agent.shouldStopAfterTurn;
      agent.shouldStopAfterTurn = async (context, signal) => Boolean(experiment.runtime_config.mode === "plan" ? experimentPlan(experiment) : experimentRecommendation(experiment))
        || shouldFinalizeKbPlanning(experiment)
        || kbPlanningRepairProtocol(experiment.runtime_config) && kbPlanIsFinalizing(experiment)
        || Boolean(await previousStop?.call(agent, context, signal));
    }
    return created;
  }
}
