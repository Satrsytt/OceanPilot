import type { PlanStep } from "../contracts.js";
import type { RetrievalDecision } from "../rag/retrieval-decision.js";
import type { DataSourceCheck } from "./tool-context.js";

export type MethodFamily = "statistical" | "event_detection" | "mechanistic"
  | "machine_learning" | "data_assimilation" | "comparative";
export type ScientificFocus = "trend" | "event" | "attribution" | "prediction" | "mapping" | "validation";
export type ExecutionMode = "lightweight" | "full_resolution" | "ensemble";

export interface CandidateDraft {
  draftId: string;
  title: string;
  objective: string;
  methodFamily: MethodFamily;
  scientificFocus: ScientificFocus;
  executionMode: ExecutionMode;
  datasets: string[];
  datasetRoles: Record<string, string>;
  steps: PlanStep[];
  requiredInputs: string[];
  assumptions: string[];
  evidenceNeeds: string[];
  evidenceRefs: string[];
  deliverables: string[];
  risks: string[];
  tradeoffs: { advantages: string[]; risks: string[] };
  estimatedResources: { dataGb?: number; computeHours?: number; note?: string };
}

export interface CandidateValidationContext {
  retrievalDecision?: RetrievalDecision;
  allowedTools: ReadonlySet<string>;
  dataSourceChecks: ReadonlyMap<string, DataSourceCheck>;
  requireDownloadedData?: boolean;
}

export interface ValidCandidate {
  draft: CandidateDraft;
  bundle: NonNullable<RetrievalDecision["bundles"][number]>;
  feasibilityStatus: "executable";
  estimatedToolCalls: number;
  evidenceRefs: string[];
}

function distinct(values: string[]): boolean {
  return values.length === new Set(values).size;
}

/** Shared graph check; tool availability and scientific adequacy are separate concerns. */
export function hasPlanDependencyCycle(steps: Array<Pick<PlanStep, "id" | "dependsOn">>): boolean {
  const byId = new Map(steps.map(step => [step.id, step]));
  const color = new Map<string, number>();
  const visit = (id: string): boolean => {
    if (color.get(id) === 1) return true;
    if (color.get(id) === 2) return false;
    color.set(id, 1);
    for (const dependency of byId.get(id)?.dependsOn ?? []) if (byId.has(dependency) && visit(dependency)) return true;
    color.set(id, 2); return false;
  };
  return steps.some(step => visit(step.id));
}

function dagErrors(steps: PlanStep[], allowedTools: ReadonlySet<string>, hasDatasets: boolean): string[] {
  const errors: string[] = [];
  if (steps.length < 3 || steps.length > 20) errors.push("DAG 必须有 3–20 个步骤");
  const ids = steps.map((step) => step.id);
  if (!distinct(ids) || ids.some((id) => !id.trim())) errors.push("步骤 ID 为空或重复");
  const byId = new Map(steps.map((step) => [step.id, step]));
  for (const step of steps) {
    if (!step.title.trim() || !step.description.trim()) errors.push(`${step.id}: 缺少步骤描述`);
    if (!step.tool || !allowedTools.has(step.tool)) errors.push(`${step.id}: 工具 ${step.tool || "未指定"} 不可用`);
    if (!step.phase) errors.push(`${step.id}: 未声明科学阶段`);
    if (step.phase !== "data" && ["search_official_web", "check_official_data_source", "acquire_scientific_data"].includes(step.tool ?? "")) {
      errors.push(`${step.id}: 来源检索工具不能充当分析、验证或产物步骤`);
    }
    if (step.tool === "complete_research_plan" && step.phase !== "artifact") {
      errors.push(`${step.id}: 产物交付工具只能用于产物阶段`);
    }
    if (step.dependsOn.some((id) => !byId.has(id))) errors.push(`${step.id}: 引用了不存在的依赖`);
    if (step.dependsOn.includes(step.id)) errors.push(`${step.id}: 不能依赖自身`);
    if ((step.phase === "validation" || step.phase === "artifact") && !step.expectedOutputs.length) {
      errors.push(`${step.id}: 验证/产物步骤缺少预期输出`);
    }
  }
  const phases = new Set(steps.map((step) => step.phase));
  for (const required of ["analysis", "validation", "artifact", ...(hasDatasets ? ["data"] : [])]) {
    if (!phases.has(required as PlanStep["phase"])) errors.push(`缺少 ${required} 阶段`);
  }
  if (hasPlanDependencyCycle(steps)) errors.push("DAG 存在环");
  const hasAncestorPhase = (id: string, phase: PlanStep["phase"], seen = new Set<string>()): boolean => {
    if (seen.has(id)) return false;
    seen.add(id);
    return (byId.get(id)?.dependsOn ?? []).some((dependency) =>
      byId.get(dependency)?.phase === phase || hasAncestorPhase(dependency, phase, seen));
  };
  if (hasDatasets && !steps.some((step) => step.phase === "analysis" && hasAncestorPhase(step.id, "data"))) {
    errors.push("分析步骤未依赖数据准备步骤");
  }
  if (!steps.some((step) => step.phase === "validation" && hasAncestorPhase(step.id, "analysis"))) {
    errors.push("科学验证未依赖分析结果");
  }
  if (!steps.some((step) => step.phase === "artifact" && hasAncestorPhase(step.id, "validation"))) {
    errors.push("预期产物未依赖科学验证");
  }
  return errors;
}

export function validateCandidate(draft: CandidateDraft, context: CandidateValidationContext): {
  candidate?: ValidCandidate; errors: string[];
} {
  const errors: string[] = [];
  if (!draft.title.trim() || !draft.objective.trim()) errors.push("方案缺少标题或目标");
  if (!draft.deliverables.length) errors.push("方案缺少预期产物");
  if (!draft.tradeoffs.advantages.length || !draft.tradeoffs.risks.length) errors.push("方案缺少优势或风险说明");
  if (!distinct(draft.datasets)) errors.push("数据集 ID 重复");
  const bundle = context.retrievalDecision?.bundles.find((item) =>
    item.datasetIds.length === draft.datasets.length
    && item.datasetIds.every((id) => draft.datasets.includes(id)));
  if (!bundle) errors.push("数据路线未通过 Requirement/Bundle 能力检查");
  if (draft.datasets.some((id) => !draft.datasetRoles[id]?.trim())) errors.push("数据角色未逐项标明");
  if (Object.keys(draft.datasetRoles).some((id) => !draft.datasets.includes(id))) errors.push("数据角色包含未选数据集");
  errors.push(...dagErrors(draft.steps, context.allowedTools, draft.datasets.length > 0));
  if (draft.estimatedResources.dataGb !== undefined &&
      (!Number.isFinite(draft.estimatedResources.dataGb) || draft.estimatedResources.dataGb < 0)) {
    errors.push("数据量估计无效");
  }
  if (draft.estimatedResources.computeHours !== undefined &&
      (!Number.isFinite(draft.estimatedResources.computeHours) || draft.estimatedResources.computeHours < 0)) {
    errors.push("计算时间估计无效");
  }
  if (draft.estimatedResources.dataGb === undefined && draft.estimatedResources.computeHours === undefined
    && !draft.estimatedResources.note?.trim()) errors.push("资源需求未估计，也未说明未知原因");
  const feasibilityStatus = "executable" as const;
  if (draft.datasets.length > 0) {
    for (const dataset of draft.datasets) {
      const check = context.dataSourceChecks.get(dataset);
      if (!check) errors.push(`${dataset}: 缺少官方来源核验`);
      else if (check.status !== "available") errors.push(`${dataset}: 当前不可直接获取 (${check.status})`);
      else if (context.requireDownloadedData && (!check.validated || !check.localPath)) errors.push(`${dataset}: 请先 acquire_scientific_data 获取并验证本地切片`);
    }
    if (context.requireDownloadedData && draft.datasets.length > 1) {
      const groups = draft.datasets.map((id) => context.dataSourceChecks.get(id)?.compatibilityGroup);
      if (groups.some((group) => !group) || new Set(groups).size !== 1) errors.push("完整数据组合尚未共同验证兼容性，请调用 acquire_scientific_data");
    }
  }
  if (bundle) {
    const knownRefs = new Set([...bundle.evidenceRefs, ...draft.datasets.flatMap((id) => {
      const check = context.dataSourceChecks.get(id);
      return check ? [check.pageUrl, check.dataUrl].filter((value): value is string => Boolean(value)) : [];
    })]);
    for (const ref of draft.evidenceRefs) if (!knownRefs.has(ref)) errors.push(`未经检索或核验的证据引用：${ref}`);
  }
  if (errors.length || !bundle) return { errors };
  return { errors: [], candidate: {
    draft, bundle, feasibilityStatus, estimatedToolCalls: draft.steps.length,
    evidenceRefs: [...new Set([...bundle.evidenceRefs, ...draft.evidenceRefs])],
  } };
}

export function candidateSignature(candidate: ValidCandidate): string {
  const draft = candidate.draft;
  const byId = new Map(draft.steps.map((step) => [step.id, step]));
  const structureById = new Map<string, string>();
  const describe = (id: string): string => {
    const cached = structureById.get(id);
    if (cached) return cached;
    const step = byId.get(id)!;
    const structure = JSON.stringify([step.phase, step.tool, step.dependsOn.map(describe).sort()]);
    structureById.set(id, structure);
    return structure;
  };
  const structure = draft.steps.map((step) => describe(step.id)).sort();
  return JSON.stringify([draft.methodFamily, draft.scientificFocus, draft.executionMode,
    [...draft.datasets].sort(), structure]);
}

function numericCost(value: number | undefined): number {
  return value === undefined ? Number.POSITIVE_INFINITY : value;
}

export function selectCandidates(candidates: ValidCandidate[], maximum = 3): ValidCandidate[] {
  const ranked = [...candidates].sort((left, right) =>
    right.bundle.requirementIds.length - left.bundle.requirementIds.length
    || left.draft.tradeoffs.risks.length - right.draft.tradeoffs.risks.length
    || numericCost(left.draft.estimatedResources.computeHours) - numericCost(right.draft.estimatedResources.computeHours)
    || numericCost(left.draft.estimatedResources.dataGb) - numericCost(right.draft.estimatedResources.dataGb)
    || left.estimatedToolCalls - right.estimatedToolCalls
    || left.draft.draftId.localeCompare(right.draft.draftId));
  const signatures = new Set<string>();
  return ranked.filter((candidate) => {
    const signature = candidateSignature(candidate);
    if (signatures.has(signature)) return false;
    signatures.add(signature);
    return true;
  }).slice(0, Math.min(Math.max(maximum, 1), 5));
}
