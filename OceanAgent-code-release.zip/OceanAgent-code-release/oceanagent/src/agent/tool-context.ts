import type { Citation, ResearchPlan } from "../contracts.js";
import type { RetrievalDecision, RuntimeTaskSpec } from "../rag/retrieval-decision.js";
import type { AblationPolicy } from "../experiments/ablation-policy.js";
import type { DatasetRecommendation } from "../experiments/scientific-protocol.js";

export type CitationDraft = Omit<Citation, "id" | "runId" | "nodeId">;

export interface ClarificationQuestion {
  id: string;
  label: string;
  question: string;
  required: boolean;
  reason?: string;
  options: Array<{
    value: string;
    label: string;
    description?: string;
  }>;
  allowCustom: boolean;
}

export type TerminalAction =
  | { type: "recommendation"; recommendation: DatasetRecommendation }
  | { type: "clarification"; questions: ClarificationQuestion[]; summary: string }
  | { type: "plan"; plan: ResearchPlan }
  | { type: "plan_candidates"; plans: ResearchPlan[]; comparisonSummary: string; gaps: string[] }
  | { type: "data_blocked"; summary: string; sources: DataSourceCheck[] };

export interface DataSourceCheck {
  dataset: string;
  pageUrl: string;
  dataUrl?: string;
  status: "available" | "metadata_only" | "requires_access" | "unavailable";
  reason: string;
  checkedAt: string;
  localPath?: string;
  sha256?: string;
  bytes?: number;
  validated?: boolean;
  protocol?: string;
  validation?: unknown;
  transformations?: string[];
  errorType?: string;
  compatibilityGroup?: string;
}

export interface OceanToolContext {
  recommendationOnly?: boolean;
  planningOnly?: boolean;
  fixedPlanningDatasets?: string[];
  workspacePath: string;
  requiresDataValidation: boolean;
  dataDiscoveryOnly: boolean;
  dataDownloadAllowed?: boolean;
  scientificCachePath?: string;
  knowledgeGroundingRequired: boolean;
  knowledgeGrounded: boolean;
  knowledgeAccessEnabled?: boolean;
  ablationPolicy?: AblationPolicy;
  bundleAccessEnabled?: boolean;
  adaptiveRetrievalEnabled?: boolean;
  multiplePlansEnabled?: boolean;
  maxCandidatePlans?: number;
  taskId?: string;
  runId?: string;
  dataAcquisitionBytes?: number;
  dataAcquisitionBudget?: { used: number; limit: number };
  dataAcquisitionAttempts?: Set<string>;
  executableToolNames?: Set<string>;
  retrievalDecision?: RetrievalDecision;
  ideaTaskSpec?: RuntimeTaskSpec;
  webSearchAttempted: boolean;
  dataSourceChecks: Map<string, DataSourceCheck>;
  addCitation(citation: CitationDraft): void;
  setTerminalAction(action: TerminalAction): void;
  createPlan(input: Omit<ResearchPlan, "id" | "conversationId" | "version" | "status" | "createdAt">): ResearchPlan;
}
