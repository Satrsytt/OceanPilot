import { describe, expect, it } from "vitest";
import type { ResearchPlan } from "../contracts.js";
import type { ConversationRepository } from "../db/conversation-repository.js";
import type { PlanRepository } from "../db/plan-repository.js";
import type { RunRepository } from "../db/run-repository.js";
import { selectPlanForExecution } from "./plan-selection.js";

function plan(id: string, rank: number): ResearchPlan {
  return { id, conversationId: "conversation", nodeId: "choice-node", version: rank,
    status: "awaiting_approval", title: `Route ${rank}`, taskId: "task",
    candidateGroupId: "group", candidateRank: rank, methodFamily: rank === 1 ? "statistical" : "mechanistic",
    feasibilityStatus: "executable", objective: "ocean study", assumptions: [], requiredInputs: [],
    datasets: ["sst"], evidenceNeeds: [], steps: [], deliverables: [], risks: [],
    createdAt: "2026-10-26T00:00:00Z" };
}

describe("selected plan adapter", () => {
  it("passes the second Plan ID into the existing run and records selection lineage", () => {
    const plans = [plan("plan-1", 1), plan("plan-2", 2)];
    let userMetadata: Record<string, unknown> = {};
    let checkpoint: Record<string, unknown> = {};
    const planRepo = {
      list: () => plans,
      updateStatus: (id: string, status: ResearchPlan["status"]) => {
        const item = plans.find((candidate) => candidate.id === id)!;
        item.status = status;
        return item;
      },
    } as unknown as PlanRepository;
    const conversations = {
      addNode: (input: { metadata: Record<string, unknown> }) => {
        userMetadata = input.metadata;
        return { id: "execution-user-node", ...input };
      },
    } as unknown as ConversationRepository;
    const runs = {
      findActive: () => null,
      create: () => ({ id: "execution-run" }),
      saveCheckpoint: (_id: string, value: Record<string, unknown>) => { checkpoint = value; },
      get: () => ({ id: "execution-run", checkpoint }),
    } as unknown as RunRepository;

    const selected = selectPlanForExecution(plans[1]!, { plans: planRepo, conversations, runs }, "mock-model");
    expect(selected.plan.id).toBe("plan-2");
    expect(selected.run.id).toBe("execution-run");
    expect(userMetadata.approvedPlanId).toBe("plan-2");
    expect(userMetadata.selected_plan_id).toBe("plan-2");
    expect(checkpoint.selected_plan_id).toBe("plan-2");
    expect(plans[0]?.status).toBe("rejected");
    expect(plans[1]?.status).toBe("executing");
  });
});
