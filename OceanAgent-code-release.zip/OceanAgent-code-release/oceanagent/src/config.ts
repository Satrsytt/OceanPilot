import { fileURLToPath } from "node:url";
import { existsSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import type { Stage3UnitSpec } from "./experiments/paired-dev.js";

// Keep persistent application data anchored to the installation directory.
// process.cwd() changes when OceanAgent is launched from a shortcut, another
// terminal directory, or an absolute `node .../dist/server.js` command.
const APPLICATION_ROOT = resolve(dirname(fileURLToPath(import.meta.url)), "..");

function intFromEnv(name: string, fallback: number): number {
  const value = Number.parseInt(process.env[name] ?? "", 10);
  return Number.isFinite(value) && value > 0 ? value : fallback;
}

function resolveFromRoot(root: string, value: string): string {
  if (process.platform !== "win32" && /^(?:[A-Za-z]:[\\/]|\\\\)/.test(value)) {
    throw new Error("配置中仍包含 Windows 绝对路径；请改为当前机器可访问的绝对路径。");
  }
  return resolve(root, value);
}

function resolveKnowledgeGraphRoot(root: string): string {
  if (process.env.OCEAN_RAG_ROOT) return resolveFromRoot(root, process.env.OCEAN_RAG_ROOT);

  // Code release keeps one shared frozen snapshot.
  const supplemental = resolveFromRoot(root, "../benchmark/knowledge_snapshot");
  if (existsSync(join(supplemental, "cards", "problem_solution_cards.jsonl"))) return supplemental;

  const bundled = resolveFromRoot(root, "Ocean-RAG");
  if (existsSync(join(bundled, "cards", "problem_solution_cards.jsonl"))) return bundled;

  // Migrated layout: Ocean-RAG sits beside OceanAgent-main2.0.
  const sibling = resolveFromRoot(root, "../../Ocean-RAG");
  if (["dataset_cards.jsonl", "problem_solution_cards.jsonl", "usage_bundle_cards.jsonl"]
    .every((file) => existsSync(join(sibling, "cards", file)))) return sibling;

  // Development layout: OceanAgent-main2.0 and OceanKnowledgeBase are sibling projects.
  const siblingKnowledgeBase = resolveFromRoot(root, "../../OceanKnowledgeBase/Ocean-RAG");
  if (existsSync(join(siblingKnowledgeBase, "cards", "problem_solution_cards.jsonl"))) {
    return siblingKnowledgeBase;
  }
  return bundled;
}

export interface AppConfig {
  rootDir: string;
  host: string;
  port: number;
  databasePath: string;
  experiment?: Stage3UnitSpec;
  ragRoot: string;
  adaptiveRetrievalEnabled: boolean;
  multiplePlansEnabled: boolean;
  maxCandidatePlans: number;
  knowledgeGraphRoot: string;
  ragAutoSync?: boolean;
  frontendDist: string;
  timeouts: {
    idleMs: number;
    hardMs: number;
  };
  remoteSsh: {
    pythonPath: string;
    connectTimeoutMs: number;
    commandTimeoutMs: number;
    strictHostKey: boolean;
  };
}

export function loadConfig(rootDir = APPLICATION_ROOT): AppConfig {
  const knowledgeGraphRoot = resolveKnowledgeGraphRoot(rootDir);
  return {
    rootDir,
    host: process.env.HOST ?? "127.0.0.1",
    port: intFromEnv("PORT", 3210),
    databasePath: resolveFromRoot(rootDir, process.env.OCEAN_DB_PATH ?? "data/ocean-agent.sqlite"),
    // Retrieval and graph browsing must read the same card snapshots.  The old
    // split default made the UI show the sibling Ocean-RAG while the agent
    // indexed the empty bundled directory.
    ragRoot: knowledgeGraphRoot,
    adaptiveRetrievalEnabled: process.env.OCEAN_ADAPTIVE_RETRIEVAL === "true"
      || process.env.OCEAN_MULTIPLE_PLANS === "true",
    multiplePlansEnabled: process.env.OCEAN_MULTIPLE_PLANS === "true",
    maxCandidatePlans: Math.min(intFromEnv("OCEAN_MAX_CANDIDATE_PLANS", 3), 5),
    knowledgeGraphRoot,
    ragAutoSync: process.env.OCEAN_RAG_AUTO_SYNC !== "false",
    frontendDist: resolveFromRoot(rootDir, "frontend/dist"),
    timeouts: {
      idleMs: intFromEnv("CHAT_IDLE_TIMEOUT_MS", 600_000),
      hardMs: intFromEnv("CHAT_HARD_TIMEOUT_MS", 7_200_000),
    },
    remoteSsh: {
      pythonPath: process.env.OCEAN_PYTHON_PATH ?? "python",
      connectTimeoutMs: intFromEnv("OCEAN_SSH_CONNECT_TIMEOUT_MS", 20_000),
      commandTimeoutMs: intFromEnv("OCEAN_SSH_COMMAND_TIMEOUT_MS", 900_000),
      strictHostKey: process.env.OCEAN_SSH_STRICT_HOST_KEY === "true",
    },
  };
}
