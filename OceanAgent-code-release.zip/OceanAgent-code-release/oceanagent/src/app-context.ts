import { loadConfig, type AppConfig } from "./config.js";
import { OceanAgentRunner } from "./agent/agent-runner.js";
import { OceanSessionFactory } from "./agent/session-factory.js";
import { ConversationRepository } from "./db/conversation-repository.js";
import { OceanDatabase } from "./db/database.js";
import { PlanRepository } from "./db/plan-repository.js";
import { ProjectRepository } from "./db/project-repository.js";
import { RunRepository } from "./db/run-repository.js";
import { RunEventBus } from "./events/run-event-bus.js";
import { RagService } from "./rag/rag-service.js";
import { RagStore } from "./rag/rag-store.js";
import { OfficialWebSearch } from "./web-search.js";
import { ProjectCredentialVault } from "./projects/project-credential-vault.js";
import { RemoteConnectionRepository } from "./db/remote-connection-repository.js";
import { createSecretProtector } from "./security/platform-secret-protector.js";
import { ModelSettingsRepository } from "./db/model-settings-repository.js";
import { OceanModelService } from "./agent/model-service.js";
import { OCEAN_DASHSCOPE_PROVIDER_ID } from "./agent/model-defaults.js";
import { KnowledgeGraphService } from "./knowledge-graph/knowledge-graph-service.js";
import { syncOceanRagLexical } from "./rag/indexer.js";
import { resolve } from "node:path";
import { UserLiteratureWorkspace } from "./ideation/user-literature-workspace.js";
import { ProvenanceService } from "./provenance/provenance-service.js";
import { recoverInterruptedTelemetry } from "./telemetry/run-telemetry.js";
import { resolveScientificPython } from "./agent/python-environment.js";
import { resolveAblationPolicy } from "./experiments/ablation-policy.js";
import { scientificProtocol } from "./experiments/scientific-protocol.js";
import { kbFreePlanningProtocol } from "./experiments/kb-ablation-protocol.js";

export interface AppContext {
  config: AppConfig;
  database: OceanDatabase;
  conversations: ConversationRepository;
  projects: ProjectRepository;
  runs: RunRepository;
  plans: PlanRepository;
  events: RunEventBus;
  rag: RagService;
  knowledgeGraph: KnowledgeGraphService;
  userLiterature: UserLiteratureWorkspace;
  provenance: ProvenanceService;
  webSearch: OfficialWebSearch;
  projectCredentials: ProjectCredentialVault;
  remoteConnections: RemoteConnectionRepository;
  models: OceanModelService;
  runner: OceanAgentRunner;
  close(): void;
}

export async function createAppContext(config = loadConfig(), options: {
  models?: OceanModelService;
  initializeRag?: (store: RagStore) => Promise<void>;
} = {}): Promise<AppContext> {
  const storageRoot = config.experiment?.paths.unit_dir ?? config.rootDir;
  const telemetryRoot = config.experiment?.paths.logs ?? resolve(config.rootDir, "eval_logs");
  const artifactRoot = config.experiment?.paths.artifacts ?? resolve(config.rootDir, "data/artifacts");
  const database = new OceanDatabase(config.databasePath, config.experiment?.paths.workspace ?? config.rootDir);
  const projects = new ProjectRepository(database);
  projects.ensureDefault();
  const conversations = new ConversationRepository(database);
  const runs = new RunRepository(database);
  runs.redactStoredSecrets();
  const plans = new PlanRepository(database);
  const events = new RunEventBus(runs);
  for (const stranded of runs.listUnfinished()) {
    const reason = "服务器进程在任务运行期间结束；已保留工具记录和工作区检查点，可在原会话发送“继续”恢复。";
    const userNode = conversations.getNode(stranded.userNodeId);
    const planId = typeof userNode?.metadata.approvedPlanId === "string"
      ? userNode.metadata.approvedPlanId : undefined;
    const plan = planId ? plans.get(planId) : null;
    const planNode = plan?.nodeId ? conversations.getNode(plan.nodeId) : null;
    const originalInput = planNode?.parentId ? conversations.getNode(planNode.parentId) : null;
    const taskId = originalInput?.role === "user" ? originalInput.id : stranded.userNodeId;
    try { recoverInterruptedTelemetry(telemetryRoot, taskId, stranded.id); }
    catch (error) { console.error("恢复任务级评价日志失败：", error); }
    const node = conversations.addNode({
      conversationId: stranded.conversationId,
      parentId: stranded.userNodeId,
      role: "assistant",
      content: reason,
      metadata: { runId: stranded.id, error: "server_restart" },
    });
    runs.interruptToolCalls(stranded.id);
    runs.update(stranded.id, {
      status: "failed", outcome: "interrupted", assistantNodeId: node.id, error: "server_restart",
    });
    if (planId && plans.get(planId)?.status === "executing") plans.updateStatus(planId, "interrupted");
    events.publish(stranded.id, "run.error", {
      outcome: "interrupted", reason: "server_restart", checkpoint: stranded.checkpoint, assistantNode: node,
    });
  }
  const projectCredentials = new ProjectCredentialVault();
  const protector = createSecretProtector(storageRoot);
  const remoteConnections = new RemoteConnectionRepository(database, protector);
  const modelSettings = new ModelSettingsRepository(database, protector);
  const ragStore = new RagStore(database);
  if (options.initializeRag) await options.initializeRag(ragStore);
  const syncRagSnapshot = async () => config.experiment || config.ragAutoSync === false ? undefined : syncOceanRagLexical(config, ragStore);
  try {
    // Always make the latest reviewed Ocean-RAG snapshot available locally.
    // This performs no network calls; semantic embeddings remain an optional
    // enhancement built by `npm run index:rag`.
    await syncRagSnapshot();
  } catch (error) {
    console.warn("Ocean-RAG 本地索引同步失败，应用将继续启动：", error);
  }
  const rawRag = new RagService(
    ragStore,
    modelSettings.getEmbeddingSettings(),
    () => modelSettings.getApiKey(OCEAN_DASHSCOPE_PROVIDER_ID),
    () => Boolean(modelSettings.getProvider(OCEAN_DASHSCOPE_PROVIDER_ID)?.hasSavedCredential),
    syncRagSnapshot,
  );
  let rag = config.experiment ? rawRag.withAblationPolicy(resolveAblationPolicy(config.experiment.condition,
    scientificProtocol(config.experiment.runtime_config))) : rawRag;
  if (scientificProtocol(config.experiment?.runtime_config) || kbFreePlanningProtocol(config.experiment?.runtime_config)) rag = rag.withRetrievalMode("lexical");
  const knowledgeGraph = new KnowledgeGraphService(config.knowledgeGraphRoot);
  const userLiterature = new UserLiteratureWorkspace(
    resolve(storageRoot, "data", "user-literature"),
    resolve(config.knowledgeGraphRoot, "code"),
    resolve(config.rootDir, "src", "ideation", "extract_user_pdf.py"),
    resolveScientificPython(config.rootDir, config.rootDir).pythonPath,
  );
  const provenance = new ProvenanceService(database, plans, userLiterature,
    config.knowledgeGraphRoot, artifactRoot);
  const webSearch = new OfficialWebSearch();
  const models = options.models ?? await OceanModelService.create(modelSettings);
  const sessions = await OceanSessionFactory.create(config, models);
  const runner = new OceanAgentRunner(
    config,
    sessions,
    conversations,
    runs,
    plans,
    events,
    rag,
    webSearch,
    projects,
    projectCredentials,
    remoteConnections,
    provenance,
  );
  return {
    config,
    database,
    projects,
    conversations,
    runs,
    plans,
    events,
    rag,
    knowledgeGraph,
    userLiterature,
    provenance,
    webSearch,
    projectCredentials,
    remoteConnections,
    models,
    runner,
    close: () => {
      projectCredentials.clear();
      database.close();
    },
  };
}
