import { existsSync, readFileSync, statSync } from "node:fs";
import { join } from "node:path";
import type { KnowledgeCatalogItem, KnowledgeGraphEdge, KnowledgeGraphNode, KnowledgeGraphResponse, KnowledgeGraphStats, KnowledgePerspective } from "../contracts.js";

type JsonObject = Record<string, unknown>;

interface KnowledgeCache {
  stamp: string;
  problems: JsonObject[];
  bundles: JsonObject[];
  datasets: JsonObject[];
  papers: JsonObject[];
  problemByPaper: Map<string, JsonObject>;
  problemByBundle: Map<string, JsonObject>;
  bundleById: Map<string, JsonObject>;
  datasetById: Map<string, JsonObject>;
  paperById: Map<string, JsonObject>;
  bundleIdsByDataset: Map<string, string[]>;
  publishBlockersByPaper: Map<string, string[]>;
  unresolvedDatasetCards: number;
  qualitySummary: JsonObject;
  lastUpdated: string | null;
}

const TEMPORARY_MARKER = /(unresolved|pending_web_search)/i;
const TERMINAL_STATUSES = new Set([
  "not_applicable", "not_available", "not_found", "not_reported",
  "not_versioned", "restricted_or_by_request", "conflicted",
]);

function text(value: unknown, fallback = ""): string {
  if (typeof value === "number" && Number.isFinite(value)) return String(value);
  return typeof value === "string" && value.trim() ? value.trim() : fallback;
}

function record(value: unknown): JsonObject {
  return value && typeof value === "object" && !Array.isArray(value) ? value as JsonObject : {};
}

function records(value: unknown): JsonObject[] {
  return Array.isArray(value) ? value.map(record).filter((item) => Object.keys(item).length > 0) : [];
}

function strings(value: unknown): string[] {
  return Array.isArray(value) ? value.map((item) => text(item)).filter(Boolean) : [];
}

function valueStrings(value: unknown): string[] {
  if (Array.isArray(value)) return value.flatMap(valueStrings);
  if (value && typeof value === "object") return Object.values(value as JsonObject).flatMap(valueStrings);
  const result = text(value);
  return result && !TEMPORARY_MARKER.test(result) && result !== "not_applicable" ? [result] : [];
}

function temporaryMarkerPaths(value: unknown, path = "$"): string[] {
  if (typeof value === "string") return TEMPORARY_MARKER.test(value) ? [path] : [];
  if (Array.isArray(value)) return value.flatMap((item, index) => temporaryMarkerPaths(item, `${path}[${index}]`));
  if (value && typeof value === "object") {
    return Object.entries(value as JsonObject).flatMap(([key, child]) => temporaryMarkerPaths(child, `${path}.${key}`));
  }
  return [];
}

function ambiguous(value: unknown): boolean {
  if (value == null) return true;
  if (typeof value !== "string") return false;
  const normalized = value.trim().toLocaleLowerCase();
  return !normalized || TEMPORARY_MARKER.test(normalized)
    || ["not reported", "not specified", "not provided", "not verified", "no web access"].some((marker) => normalized.includes(marker))
    || ["unknown", "none", "null"].includes(normalized);
}

function httpUrl(value: unknown): boolean {
  if (typeof value !== "string") return false;
  try { return ["http:", "https:"].includes(new URL(value).protocol); } catch { return false; }
}

function explicitTerminal(value: unknown): boolean {
  if (typeof value !== "string") return false;
  return TERMINAL_STATUSES.has(value.trim().toLocaleLowerCase().replace(/[\s-]+/g, "_"));
}

function missingStructuredValue(value: unknown): boolean {
  return value == null || value === "" || (Array.isArray(value) && value.length === 0) || ambiguous(value);
}

function datasetPublicationBlockers(dataset: JsonObject, prefix: string): string[] {
  const blockers = temporaryMarkerPaths(dataset, prefix);
  for (const key of ["dataset_id", "product_id", "name", "provider", "version", "description", "ownership", "public_availability", "license"]) {
    if (ambiguous(dataset[key])) blockers.push(`${prefix}.${key}`);
  }
  for (const key of ["coverage", "resolution"]) {
    const value = record(dataset[key]);
    if (Object.keys(value).length === 0) blockers.push(`${prefix}.${key}`);
    for (const component of ["spatial", "temporal", "vertical"]) {
      if (ambiguous(value[component])) blockers.push(`${prefix}.${key}.${component}`);
    }
  }
  const fields = records(dataset.fields);
  if (fields.length === 0) blockers.push(`${prefix}.fields`);
  fields.forEach((field, index) => {
    for (const key of ["raw_name", "description", "unit", "dimensions", "valid_range", "quality_field", "quality_rule"]) {
      if (ambiguous(field[key])) blockers.push(`${prefix}.fields[${index}].${key}`);
    }
    if (!httpUrl(field.source_url) && !explicitTerminal(field.source_url)) blockers.push(`${prefix}.fields[${index}].source_url`);
  });
  const sources = records(dataset.sources);
  if (!sources.some((source) => httpUrl(source.url))) blockers.push(`${prefix}.sources[].url`);
  sources.forEach((source, index) => {
    if (!httpUrl(source.url)) return;
    for (const key of ["authority", "supports", "accessed_at"]) {
      if (missingStructuredValue(source[key])) blockers.push(`${prefix}.sources[${index}].${key}`);
    }
  });
  const availability = text(dataset.public_availability).toLocaleLowerCase();
  const access = records(dataset.access);
  if (!["not_found", "not_available"].includes(availability)
    && !access.some((entry) => httpUrl(entry.url))) blockers.push(`${prefix}.access[].url`);
  access.forEach((entry, index) => {
    if (!httpUrl(entry.url)) blockers.push(`${prefix}.access[${index}].url`);
    for (const key of ["type", "authentication", "status", "accessed_at"]) {
      if (ambiguous(entry[key])) blockers.push(`${prefix}.access[${index}].${key}`);
    }
  });
  return blockers;
}

function publicationBlockers(
  problem: JsonObject,
  bundle: JsonObject | undefined,
  datasetById: Map<string, JsonObject>,
): string[] {
  const blockers = temporaryMarkerPaths(problem, "problem_solution_card");
  if (!bundle) return [...blockers, "missing_usage_bundle"];
  blockers.push(...temporaryMarkerPaths(bundle, "usage_bundle_card"));
  if (records(bundle.steps).length === 0) blockers.push("usage_bundle_card.steps_empty");
  for (const usage of records(bundle.data_usages)) {
    const datasetId = text(usage.dataset_id);
    if (!datasetId) {
      blockers.push("usage_bundle_card.data_usages[].dataset_id_missing");
      continue;
    }
    const dataset = datasetById.get(datasetId);
    if (!dataset) blockers.push(`missing_dataset_card:${datasetId}`);
    else blockers.push(...datasetPublicationBlockers(dataset, `dataset_card:${datasetId}`));
  }
  return [...new Set(blockers)];
}

function shorten(value: string, length = 110): string {
  return value.length > length ? `${value.slice(0, length - 1)}…` : value;
}

function paperTitle(paper: JsonObject | undefined, paperId: string): string {
  const verifiedTitle = text(paper?.title, text(paper?.display_title));
  if (verifiedTitle) return verifiedTitle;
  const filename = text(paper?.filename);
  return filename
    ? filename.replace(/\.pdf$/i, "").replace(/^\d{4}__\d+__/, "").replaceAll("_", " ")
    : paperId;
}

function readJsonLines(filePath: string): JsonObject[] {
  if (!existsSync(filePath)) return [];
  return readFileSync(filePath, "utf8").split(/\r?\n/).flatMap((line) => {
    if (!line.trim()) return [];
    try { return [record(JSON.parse(line))]; } catch { return []; }
  }).filter((item) => Object.keys(item).length > 0);
}

function readJsonObject(filePath: string): JsonObject {
  if (!existsSync(filePath)) return {};
  try { return record(JSON.parse(readFileSync(filePath, "utf8"))); } catch { return {}; }
}

function nodeId(type: KnowledgeGraphNode["type"], entityId: string): string {
  return `${type}:${entityId}`;
}

function edge(
  edges: KnowledgeGraphEdge[],
  source: string,
  target: string,
  label: string,
  kind: KnowledgeGraphEdge["kind"],
  metadata: Pick<KnowledgeGraphEdge, "weight" | "evidenceIds"> = {},
): void {
  edges.push({ id: `${kind}:${source}:${target}:${edges.length}`, source, target, label, kind, ...metadata });
}

function uniquePush(nodes: KnowledgeGraphNode[], seen: Set<string>, node: KnowledgeGraphNode): void {
  if (seen.has(node.id)) return;
  seen.add(node.id);
  nodes.push(node);
}

function indexBy(items: JsonObject[], key: string): Map<string, JsonObject> {
  const result = new Map<string, JsonObject>();
  for (const item of items) {
    const id = text(item[key]);
    if (id) result.set(id, item);
  }
  return result;
}

export class KnowledgeGraphService {
  private cache: KnowledgeCache | null = null;

  constructor(private readonly ragRoot: string) {}

  getStats(): KnowledgeGraphStats {
    const cache = this.load();
    const calculatedReady = [...cache.publishBlockersByPaper.values()].filter((items) => items.length === 0).length;
    const qualityReady = Number(cache.qualitySummary.publish_ready_papers);
    const qualityQuarantined = Number(cache.qualitySummary.quarantined_papers);
    const publishReadyPapers = Number.isFinite(qualityReady) ? qualityReady : calculatedReady;
    const quarantinedPapers = Number.isFinite(qualityQuarantined)
      ? qualityQuarantined
      : cache.problemByPaper.size - calculatedReady;
    const publishedPapers = publishReadyPapers + quarantinedPapers;
    const planSteps = cache.bundles.reduce((total, bundle) => total + records(bundle.steps).length, 0);
    const dataUsages = cache.bundles.reduce((total, bundle) => total + records(bundle.data_usages).length, 0);
    const dataRelations = cache.bundles.reduce((total, bundle) => total + records(bundle.data_relations).length, 0);
    const validationRules = cache.bundles.reduce((total, bundle) => total + records(bundle.validation).length, 0);
    return {
      knowledgeBases: cache.problems.length + cache.bundles.length + cache.datasets.length > 0 ? 1 : 0,
      papers: cache.papers.length,
      publishedPapers,
      // User-facing knowledge volume is derived from the cards currently
      // available, independently of extraction workflow counters.
      papersWithKnowledge: cache.problemByPaper.size,
      publishReadyPapers,
      quarantinedPapers,
      knowledgeCards: cache.problems.length + cache.bundles.length + cache.datasets.length,
      problemCards: cache.problems.length,
      usageBundles: cache.bundles.length,
      datasetCards: cache.datasets.length,
      planSteps,
      dataUsages,
      dataRelations,
      validationRules,
      unresolvedDatasetCards: cache.unresolvedDatasetCards,
      lastUpdated: cache.lastUpdated,
      sourceName: "Ocean-RAG 海洋科研知识库",
      sourcePath: this.ragRoot,
    };
  }

  getCatalog(perspective: KnowledgePerspective, query = "", limit = 5000): KnowledgeCatalogItem[] {
    const cache = this.load();
    const normalized = query.trim().toLocaleLowerCase();
    const items = perspective === "global"
      ? [{ id: "ocean_global", title: "Ocean-RAG 全局知识图谱", subtitle: "跨论文数据集共用关系与全局证据路径" }]
      : perspective === "paper"
      ? [...cache.problemByPaper.entries()].map(([paperId, problem]) => {
        const paper = cache.paperById.get(paperId);
        return {
          id: paperId,
          title: paperTitle(paper, paperId),
          subtitle: [
            text(paper?.collection), text(paper?.year),
            shorten(text(problem.problem), 80),
          ].filter(Boolean).join(" · "),
        };
      })
      : cache.datasets.map((dataset) => ({
        id: text(dataset.dataset_id),
        title: text(dataset.name, text(dataset.dataset_id, "未命名数据集")),
        subtitle: [text(dataset.provider), text(dataset.version)].filter((value) => value && value !== "unresolved").join(" · ") || "数据集卡",
      }));
    return items
      .filter((item) => item.id && (!normalized || `${item.id} ${item.title} ${item.subtitle}`.toLocaleLowerCase().includes(normalized)))
      .sort((left, right) => left.id.localeCompare(right.id, undefined, { numeric: true }))
      .slice(0, Math.min(Math.max(limit, 1), 5000));
  }

  getGraph(perspective: KnowledgePerspective, focusId: string): KnowledgeGraphResponse | null {
    return perspective === "global" ? this.globalGraph() : perspective === "paper" ? this.paperGraph(focusId) : this.datasetGraph(focusId);
  }

  private globalGraph(): KnowledgeGraphResponse | null {
    const cache = this.load();
    if (cache.bundles.length === 0) return null;
    const nodes: KnowledgeGraphNode[] = [];
    const edges: KnowledgeGraphEdge[] = [];
    const seen = new Set<string>();
    const focusNode = nodeId("concept", "ocean_global");
    // The global view represents the complete reviewed extraction snapshot.
    // Publication quality remains visible as metadata instead of silently
    // removing the majority of reviewed papers from the graph.
    const includedBundleIds = new Set([...cache.problemByPaper.values()]
      .map((problem) => text(problem.bundle_id))
      .filter((bundleId) => Boolean(bundleId) && cache.bundleById.has(bundleId)));
    const includedBundleIdsByDataset = new Map<string, string[]>();
    for (const [datasetId, bundleIds] of cache.bundleIdsByDataset) {
      const included = bundleIds.filter((bundleId) => includedBundleIds.has(bundleId));
      if (included.length > 0) includedBundleIdsByDataset.set(datasetId, included);
    }
    const rankedDatasets = [...includedBundleIdsByDataset.entries()]
      .sort((left, right) => right[1].length - left[1].length || left[0].localeCompare(right[0]))
      .slice(0, 28);
    const selectedIds = new Set(rankedDatasets.map(([datasetId]) => datasetId));
    const publishReadyPapers = [...cache.publishBlockersByPaper.values()].filter((blockers) => blockers.length === 0).length;
    const needsCompletionPapers = Math.max(0, cache.problemByPaper.size - publishReadyPapers);
    uniquePush(nodes, seen, {
      id: focusNode,
      entityId: "ocean_global",
      type: "concept",
      title: "Ocean-RAG 全局知识图谱",
      subtitle: `${cache.problemByPaper.size} 篇论文知识 · ${includedBundleIdsByDataset.size} 个数据实体`,
      payload: {
        category: "全局知识图谱",
        value: "跨论文 Dataset 共用关系",
        reviewed_paper_count: cache.problemByPaper.size,
        publish_ready_paper_count: publishReadyPapers,
        needs_completion_paper_count: needsCompletionPapers,
        dataset_count: includedBundleIdsByDataset.size,
        construction: "ProblemSolutionCard → UsageBundleCard → DatasetCard；CO_USED_WITH 由同一论文中的 USES 边确定性派生",
        quality_note: "图谱包含全部已复核抽取卡；待补全卡参与关系展示，但不能作为已通过发布门禁的事实使用。",
      },
    });
    for (const [datasetId, bundleIds] of rankedDatasets) {
      const dataset = cache.datasetById.get(datasetId);
      const datasetNode = nodeId("dataset", datasetId);
      uniquePush(nodes, seen, {
        id: datasetNode,
        entityId: datasetId,
        type: "dataset",
        title: text(dataset?.name, datasetId),
        subtitle: `${bundleIds.length} 篇论文使用`,
        payload: { ...(dataset ?? { dataset_id: datasetId, missing_card: true }), connected_bundle_count: bundleIds.length },
      });
      edge(edges, focusNode, datasetNode, `${bundleIds.length} 篇论文`, "global_contains", { weight: bundleIds.length, evidenceIds: bundleIds });
    }

    const pairs = new Map<string, { left: string; right: string; bundleIds: string[] }>();
    for (const bundle of cache.bundles) {
      const bundleId = text(bundle.bundle_id);
      if (!includedBundleIds.has(bundleId)) continue;
      const datasetIds = [...new Set(records(bundle.data_usages).map((usage) => text(usage.dataset_id)).filter((id) => selectedIds.has(id)))].sort();
      for (let leftIndex = 0; leftIndex < datasetIds.length; leftIndex += 1) {
        for (let rightIndex = leftIndex + 1; rightIndex < datasetIds.length; rightIndex += 1) {
          const left = datasetIds[leftIndex]!;
          const right = datasetIds[rightIndex]!;
          const key = `${left}\u0000${right}`;
          const current = pairs.get(key) ?? { left, right, bundleIds: [] };
          if (bundleId) current.bundleIds.push(bundleId);
          pairs.set(key, current);
        }
      }
    }
    [...pairs.values()]
      .sort((left, right) => right.bundleIds.length - left.bundleIds.length || `${left.left}:${left.right}`.localeCompare(`${right.left}:${right.right}`))
      .slice(0, 48)
      .forEach((pair) => edge(
        edges,
        nodeId("dataset", pair.left),
        nodeId("dataset", pair.right),
        `共同使用 ${pair.bundleIds.length} 次`,
        "dataset_co_usage",
        { weight: pair.bundleIds.length, evidenceIds: pair.bundleIds },
      ));
    return this.response("global", "ocean_global", focusNode, nodes, edges, includedBundleIdsByDataset.size > rankedDatasets.length);
  }

  private paperGraph(paperId: string): KnowledgeGraphResponse | null {
    const cache = this.load();
    const problem = cache.problemByPaper.get(paperId);
    if (!problem) return null;
    const paper = cache.paperById.get(paperId) ?? {};
    const bundleId = text(problem.bundle_id);
    const bundle = cache.bundleById.get(bundleId) ?? {};
    const steps = records(bundle.steps);
    const usages = records(bundle.data_usages);
    const nodes: KnowledgeGraphNode[] = [];
    const edges: KnowledgeGraphEdge[] = [];
    const seen = new Set<string>();
    const paperNode = nodeId("paper", paperId);
    const problemId = text(problem.card_id, `${paperId}_problem`);
    const problemNode = nodeId("problem_solution", problemId);
    const bundleNode = nodeId("usage_bundle", bundleId || `${paperId}_bundle`);

    uniquePush(nodes, seen, {
      id: paperNode, entityId: paperId, type: "paper", title: paperTitle(paper, paperId),
      subtitle: [text(paper.collection), text(paper.year)].filter(Boolean).join(" · "),
      payload: {
        ...paper,
        structured_problem_count: 1,
        publication_quality: {
          status: (cache.publishBlockersByPaper.get(paperId)?.length ?? 0) === 0 ? "publish_ready" : "legacy_needs_completion",
          blockers: cache.publishBlockersByPaper.get(paperId) ?? [],
        },
        problem_card: problem,
        usage_bundle: bundle,
      },
    });
    uniquePush(nodes, seen, {
      id: problemNode, entityId: problemId, type: "problem_solution",
      title: shorten(text(problem.problem, "未记录研究问题"), 84),
      subtitle: shorten(text(problem.solution_summary, "未记录解决方案摘要"), 96), payload: problem,
    });
    edge(edges, paperNode, problemNode, "研究问题", "paper_problem");
    uniquePush(nodes, seen, {
      id: bundleNode, entityId: bundleId || `${paperId}_bundle`, type: "usage_bundle",
      title: "实验用法包（UsageBundleCard）", subtitle: `${steps.length} 个 Plan 步骤 · ${usages.length} 个数据用法`, payload: bundle,
    });
    edge(edges, problemNode, bundleNode, "bundle_id", "problem_bundle");

    const usageDataset = new Map<string, string>();
    const usageContexts = new Map<string, JsonObject[]>();
    for (const usage of usages) {
      const datasetId = text(usage.dataset_id);
      const usageId = text(usage.usage_id);
      if (!datasetId) continue;
      if (usageId) usageDataset.set(usageId, datasetId);
      usageContexts.set(datasetId, [...(usageContexts.get(datasetId) ?? []), usage]);
    }
    for (const [datasetId, contexts] of usageContexts) {
      const dataset = cache.datasetById.get(datasetId);
      const roles = [...new Set(contexts.map((usage) => text(usage.role)).filter(Boolean))];
      const datasetNode = nodeId("dataset", datasetId);
      uniquePush(nodes, seen, {
        id: datasetNode, entityId: datasetId, type: "dataset", title: text(dataset?.name, datasetId),
        subtitle: roles.join(" / ") || "实验数据集",
        payload: { ...(dataset ?? { dataset_id: datasetId, missing_card: true }), usage_contexts: contexts },
      });
      edge(edges, bundleNode, datasetNode, roles[0] ?? "dataset_id", "bundle_dataset");
      edge(edges, paperNode, datasetNode, roles[0] ?? "使用数据", "paper_entity");
    }

    for (const step of steps) {
      const stepId = text(step.step_id, `step_${nodes.length}`);
      const stepNode = nodeId("step", `${bundleId}:${stepId}`);
      uniquePush(nodes, seen, {
        id: stepNode, entityId: stepId, type: "step",
        title: `${stepId} · ${shorten(text(step.action, "实验步骤"), 76)}`,
        subtitle: `输出：${shorten(text(step.output, "未记录"), 76)}`, payload: step,
      });
      edge(edges, bundleNode, stepNode, "实验步骤", "bundle_step");
      edge(edges, paperNode, stepNode, "实验流程", "paper_entity");
    }
    for (const step of steps) {
      const stepId = text(step.step_id);
      if (!stepId) continue;
      const stepNode = nodeId("step", `${bundleId}:${stepId}`);
      for (const dependency of strings(step.depends_on_step_ids)) edge(edges, nodeId("step", `${bundleId}:${dependency}`), stepNode, "依赖", "step_dependency");
      for (const usageId of strings(step.input_usage_ids)) {
        const datasetId = usageDataset.get(usageId);
        if (datasetId) edge(edges, nodeId("dataset", datasetId), stepNode, "输入", "dataset_input");
      }
    }
    for (const relation of records(bundle.data_relations)) {
      const fromDataset = usageDataset.get(text(relation.from_usage_id));
      const toDataset = usageDataset.get(text(relation.to_usage_id));
      if (fromDataset && toDataset && fromDataset !== toDataset) edge(edges, nodeId("dataset", fromDataset), nodeId("dataset", toDataset), text(relation.relation, "关联"), "data_relation");
    }

    const variables = new Map<string, { datasets: Set<string>; usages: Set<string> }>();
    for (const usage of usages) {
      const datasetId = text(usage.dataset_id);
      const usageId = text(usage.usage_id);
      const datasetFields = records(cache.datasetById.get(datasetId)?.fields).slice(0, 8).map((field) => text(field.raw_name)).filter(Boolean);
      const candidateNames = [...new Set([...strings(usage.fields), ...datasetFields])].filter((item) => item !== "unresolved");
      for (const name of candidateNames) {
        const current = variables.get(name) ?? { datasets: new Set<string>(), usages: new Set<string>() };
        if (datasetId) current.datasets.add(datasetId);
        if (usageId) current.usages.add(usageId);
        variables.set(name, current);
      }
    }
    [...variables.entries()].slice(0, 16).forEach(([name, context], index) => {
      const entityId = `${paperId}:variable:${index + 1}`;
      const variableNode = nodeId("scientific_variable", entityId);
      uniquePush(nodes, seen, {
        id: variableNode, entityId, type: "scientific_variable", title: name,
        subtitle: [...context.datasets].map((id) => text(cache.datasetById.get(id)?.name, id)).join(" / "),
        payload: { name, dataset_ids: [...context.datasets], usage_ids: [...context.usages] },
      });
      edge(edges, paperNode, variableNode, "科学变量", "paper_entity");
      for (const datasetId of context.datasets) edge(edges, nodeId("dataset", datasetId), variableNode, "包含变量", "dataset_variable");
    });

    const settings: { category: string; value: string; usageId: string }[] = [];
    const settingSeen = new Set<string>();
    const pushSetting = (category: string, value: string, usageId: string) => {
      const normalized = value.trim();
      const key = `${category}:${normalized}`;
      if (normalized && !settingSeen.has(key)) {
        settingSeen.add(key);
        settings.push({ category, value: normalized, usageId });
      }
    };
    for (const usage of usages) {
      const usageId = text(usage.usage_id);
      const subset = record(usage.subset);
      for (const value of valueStrings(subset.spatial)) pushSetting("空间范围", value, usageId);
      for (const value of valueStrings(subset.temporal)) pushSetting("时间范围", value, usageId);
      for (const value of valueStrings(subset.frequency)) pushSetting("时间分辨率", value, usageId);
      for (const value of valueStrings(subset.filters)) pushSetting("筛选条件", value, usageId);
      for (const value of valueStrings(usage.preprocessing)) pushSetting("预处理", value, usageId);
      const quality = record(usage.quality_control);
      for (const value of valueStrings(quality.rules)) pushSetting("质量控制", value, usageId);
      for (const value of valueStrings(quality.thresholds)) pushSetting("质量阈值", value, usageId);
    }
    settings.slice(0, 12).forEach((setting, index) => {
      const entityId = `${paperId}:setting:${index + 1}`;
      const settingNode = nodeId("experiment_setting", entityId);
      uniquePush(nodes, seen, {
        id: settingNode, entityId, type: "experiment_setting", title: shorten(setting.value, 78),
        subtitle: setting.category, payload: setting,
      });
      edge(edges, paperNode, settingNode, setting.category, "paper_entity");
    });

    records(bundle.validation).slice(0, 10).forEach((validation, index) => {
      const entityId = `${paperId}:metric:${index + 1}`;
      const metricNode = nodeId("evaluation_metric", entityId);
      uniquePush(nodes, seen, {
        id: metricNode, entityId, type: "evaluation_metric",
        title: text(validation.metric, text(validation.target, "验证指标")),
        subtitle: shorten(text(validation.criterion, text(validation.target, "实验验证")), 86), payload: validation,
      });
      edge(edges, paperNode, metricNode, "评估指标", "paper_entity");
    });

    const concepts: { category: string; value: string }[] = [];
    const researchField = record(problem.research_field);
    const primary = text(researchField.primary);
    if (primary) concepts.push({ category: "研究领域", value: primary });
    for (const value of strings(researchField.secondary)) concepts.push({ category: "研究领域", value });
    for (const value of [...new Set(usages.map((usage) => text(usage.role)).filter(Boolean))]) concepts.push({ category: "数据用途", value });
    concepts.slice(0, 10).forEach((concept, index) => {
      const entityId = `${paperId}:concept:${index + 1}`;
      const conceptNode = nodeId("concept", entityId);
      uniquePush(nodes, seen, { id: conceptNode, entityId, type: "concept", title: concept.value, subtitle: concept.category, payload: concept });
      edge(edges, paperNode, conceptNode, concept.category, "paper_entity");
    });
    return this.response("paper", paperId, paperNode, nodes, edges, false);
  }

  private datasetGraph(datasetId: string): KnowledgeGraphResponse | null {
    const cache = this.load();
    const dataset = cache.datasetById.get(datasetId);
    if (!dataset) return null;
    const allBundleIds = cache.bundleIdsByDataset.get(datasetId) ?? [];
    const bundleIds = allBundleIds.slice(0, 12);
    const usageContexts = bundleIds.flatMap((bundleId) => {
      const bundle = cache.bundleById.get(bundleId);
      const problem = cache.problemByBundle.get(bundleId);
      return records(bundle?.data_usages).filter((usage) => text(usage.dataset_id) === datasetId)
        .map((usage) => ({ ...usage, bundle_id: bundleId, paper_id: text(problem?.paper_id) }));
    });
    const nodes: KnowledgeGraphNode[] = [];
    const edges: KnowledgeGraphEdge[] = [];
    const seen = new Set<string>();
    const focusNode = nodeId("dataset", datasetId);
    uniquePush(nodes, seen, {
      id: focusNode, entityId: datasetId, type: "dataset", title: text(dataset.name, datasetId),
      subtitle: [text(dataset.provider), text(dataset.version)].filter((value) => value && value !== "unresolved").join(" · ") || "数据集卡（DatasetCard）",
      payload: { ...dataset, connected_bundle_count: allBundleIds.length, usage_contexts: usageContexts },
    });

    const rolePapers = new Map<string, Set<string>>();
    const variablePapers = new Map<string, Set<string>>();
    const connectedPaperNodes = new Set<string>();
    for (const bundleId of bundleIds) {
      const bundle = cache.bundleById.get(bundleId);
      const problem = cache.problemByBundle.get(bundleId);
      if (!bundle || !problem) continue;
      const problemId = text(problem.card_id, `${bundleId}_problem`);
      const paperId = text(problem.paper_id);
      const paper = cache.paperById.get(paperId) ?? {};
      const bundleNode = nodeId("usage_bundle", bundleId);
      const problemNode = nodeId("problem_solution", problemId);
      const paperNode = nodeId("paper", paperId);
      const matchingUsages = records(bundle.data_usages).filter((usage) => text(usage.dataset_id) === datasetId);
      const roles = [...new Set(matchingUsages.map((usage) => text(usage.role)).filter(Boolean))];

      uniquePush(nodes, seen, { id: bundleNode, entityId: bundleId, type: "usage_bundle", title: "实验用法包", subtitle: roles.join(" / ") || `${records(bundle.steps).length} 个 Plan 步骤`, payload: { ...bundle, selected_dataset_usages: matchingUsages } });
      uniquePush(nodes, seen, { id: problemNode, entityId: problemId, type: "problem_solution", title: shorten(text(problem.problem, "未记录研究问题"), 84), subtitle: shorten(text(problem.solution_summary, "未记录解决方案摘要"), 96), payload: problem });
      uniquePush(nodes, seen, { id: paperNode, entityId: paperId, type: "paper", title: paperTitle(paper, paperId), subtitle: [text(paper.collection), text(paper.year)].filter(Boolean).join(" · "), payload: {
        ...paper,
        publication_quality: {
          status: (cache.publishBlockersByPaper.get(paperId)?.length ?? 0) === 0 ? "publish_ready" : "legacy_needs_completion",
          blockers: cache.publishBlockersByPaper.get(paperId) ?? [],
        },
        problem_card: problem,
        usage_bundle: bundle,
      } });
      edge(edges, paperNode, problemNode, "研究问题", "paper_problem");
      edge(edges, problemNode, bundleNode, "bundle_id", "problem_bundle");
      edge(edges, bundleNode, focusNode, roles[0] ?? "dataset_id", "bundle_dataset");
      edge(edges, focusNode, paperNode, roles[0] ?? "使用该数据集", "paper_entity");
      connectedPaperNodes.add(paperNode);

      for (const role of roles) {
        const papers = rolePapers.get(role) ?? new Set<string>();
        papers.add(paperNode);
        rolePapers.set(role, papers);
      }
      for (const field of matchingUsages.flatMap((usage) => strings(usage.fields)).filter((item) => item !== "unresolved")) {
        const papers = variablePapers.get(field) ?? new Set<string>();
        papers.add(paperNode);
        variablePapers.set(field, papers);
      }

      const usageDataset = new Map<string, string>();
      for (const usage of records(bundle.data_usages)) {
        const usageId = text(usage.usage_id);
        const usageDatasetId = text(usage.dataset_id);
        if (usageId && usageDatasetId) usageDataset.set(usageId, usageDatasetId);
      }
      const selectedUsageIds = new Set(matchingUsages.map((usage) => text(usage.usage_id)));
      for (const relation of records(bundle.data_relations)) {
        const fromUsage = text(relation.from_usage_id);
        const toUsage = text(relation.to_usage_id);
        if (!selectedUsageIds.has(fromUsage) && !selectedUsageIds.has(toUsage)) continue;
        const otherDatasetId = selectedUsageIds.has(fromUsage) ? usageDataset.get(toUsage) : usageDataset.get(fromUsage);
        if (!otherDatasetId || otherDatasetId === datasetId) continue;
        const otherDataset = cache.datasetById.get(otherDatasetId);
        const otherNode = nodeId("dataset", otherDatasetId);
        uniquePush(nodes, seen, { id: otherNode, entityId: otherDatasetId, type: "dataset", title: text(otherDataset?.name, otherDatasetId), subtitle: "关联数据集", payload: otherDataset ?? { dataset_id: otherDatasetId, missing_card: true } });
        edge(edges, selectedUsageIds.has(fromUsage) ? focusNode : otherNode, selectedUsageIds.has(fromUsage) ? otherNode : focusNode, text(relation.relation, "数据关系"), "data_relation");
      }
    }

    for (const field of records(dataset.fields).slice(0, 16)) {
      const name = text(field.raw_name);
      if (name && name !== "unresolved" && !variablePapers.has(name)) variablePapers.set(name, new Set(connectedPaperNodes));
    }

    [...rolePapers.entries()].slice(0, 10).forEach(([role, papers], index) => {
      const entityId = `${datasetId}:role:${index + 1}`;
      const roleNode = nodeId("concept", entityId);
      uniquePush(nodes, seen, { id: roleNode, entityId, type: "concept", title: role, subtitle: `数据用途 · ${papers.size} 篇论文`, payload: { category: "数据用途", value: role, paper_count: papers.size } });
      edge(edges, focusNode, roleNode, "使用方式", "paper_entity");
      for (const paperNode of papers) edge(edges, roleNode, paperNode, "用于论文", "paper_entity");
    });
    [...variablePapers.entries()].slice(0, 16).forEach(([name, papers], index) => {
      const entityId = `${datasetId}:variable:${index + 1}`;
      const variableNode = nodeId("scientific_variable", entityId);
      uniquePush(nodes, seen, { id: variableNode, entityId, type: "scientific_variable", title: name, subtitle: `${papers.size} 篇论文使用`, payload: { name, paper_count: papers.size } });
      edge(edges, focusNode, variableNode, "包含变量", "dataset_variable");
    });
    return this.response("dataset", datasetId, focusNode, nodes, edges, allBundleIds.length > bundleIds.length);
  }

  private response(perspective: KnowledgePerspective, focusId: string, focusNodeId: string, nodes: KnowledgeGraphNode[], edges: KnowledgeGraphEdge[], truncated: boolean): KnowledgeGraphResponse {
    const visibleNodes = nodes.filter((node) => node.type !== "usage_bundle");
    const visibleNodeIds = new Set(visibleNodes.map((node) => node.id));
    return {
      perspective, focusId, focusNodeId, nodes, edges,
      counts: {
        nodes: visibleNodes.length,
        edges: edges.filter((item) => visibleNodeIds.has(item.source) && visibleNodeIds.has(item.target)).length,
        datasets: visibleNodes.filter((node) => node.type === "dataset").length,
        steps: visibleNodes.filter((node) => node.type === "step").length,
        papers: visibleNodes.filter((node) => node.type === "paper").length,
      },
      truncated,
    };
  }

  private load(): KnowledgeCache {
    const paths = {
      problems: join(this.ragRoot, "cards", "problem_solution_cards.jsonl"),
      bundles: join(this.ragRoot, "cards", "usage_bundle_cards.jsonl"),
      datasets: join(this.ragRoot, "cards", "dataset_cards.jsonl"),
      papers: join(this.ragRoot, "manifest", "papers.jsonl"),
      titles: join(this.ragRoot, "manifest", "paper_titles.jsonl"),
      quality: join(this.ragRoot, "state", "knowledge_quality.json"),
    };
    const existing = Object.values(paths).filter((path) => existsSync(path));
    const stamp = existing.map((path) => {
      const stat = statSync(path);
      return `${path}:${stat.size}:${stat.mtimeMs}`;
    }).join("|");
    if (this.cache?.stamp === stamp) return this.cache;

    const problems = readJsonLines(paths.problems);
    const bundles = readJsonLines(paths.bundles);
    const datasets = readJsonLines(paths.datasets);
    const papers = readJsonLines(paths.papers);
    const titles = readJsonLines(paths.titles);
    const qualitySummary = readJsonObject(paths.quality);
    const problemByPaper = indexBy(problems, "paper_id");
    const problemByBundle = indexBy(problems, "bundle_id");
    const bundleById = indexBy(bundles, "bundle_id");
    const datasetById = indexBy(datasets, "dataset_id");
    const paperById = indexBy(papers, "paper_id");
    for (const titleRow of titles) {
      const paperId = text(titleRow.paper_id);
      if (paperId) paperById.set(paperId, { ...(paperById.get(paperId) ?? { paper_id: paperId }), ...titleRow });
    }
    const bundleIdsByDataset = new Map<string, string[]>();
    for (const bundle of bundles) {
      const bundleId = text(bundle.bundle_id);
      const datasetIds = new Set(records(bundle.data_usages).map((usage) => text(usage.dataset_id)).filter(Boolean));
      for (const datasetId of datasetIds) bundleIdsByDataset.set(datasetId, [...(bundleIdsByDataset.get(datasetId) ?? []), bundleId]);
    }
    const publishBlockersByPaper = new Map<string, string[]>();
    for (const [paperId, problem] of problemByPaper) {
      publishBlockersByPaper.set(paperId, publicationBlockers(problem, bundleById.get(text(problem.bundle_id)), datasetById));
    }
    const unresolvedDatasetCards = datasets.filter((dataset) => temporaryMarkerPaths(dataset).length > 0).length;
    const latest = existing.reduce((value, path) => Math.max(value, statSync(path).mtimeMs), 0);
    this.cache = {
      stamp, problems, bundles, datasets, papers, problemByPaper, problemByBundle, bundleById, datasetById, paperById,
      bundleIdsByDataset, publishBlockersByPaper, unresolvedDatasetCards, qualitySummary,
      lastUpdated: latest ? new Date(latest).toISOString() : null,
    };
    return this.cache;
  }
}
