import { createWriteStream } from "node:fs";
import { mkdir, rename, rm } from "node:fs/promises";
import { randomUUID } from "node:crypto";
import { basename, resolve } from "node:path";
import { Readable, Transform } from "node:stream";
import { pipeline } from "node:stream/promises";
import type { FastifyInstance } from "fastify";
import type { AppContext } from "../app-context.js";

const MAX_UPLOAD_BYTES = 2 * 1024 * 1024 * 1024;

export function registerUploadRoutes(server: FastifyInstance, context: AppContext): void {
  server.post<{ Params: { id: string }; Querystring: { name?: string } }>(
    "/api/conversations/:id/uploads",
    { bodyLimit: MAX_UPLOAD_BYTES },
    async (request, reply) => {
      const conversation = context.conversations.get(request.params.id);
      if (!conversation) return reply.code(404).send({ error: "会话不存在" });
      const project = context.projects.get(conversation.projectId);
      if (!project) return reply.code(404).send({ error: "项目不存在" });
      if (project.executionTarget !== "local") {
        return reply.code(400).send({ error: "远程项目请先将原始数据上传到远程项目目录，再发送文件路径以重新规划" });
      }
      const name = request.query.name?.trim() ?? "";
      if (!name || name !== basename(name) || name === "." || name === ".."
        || /[\\/\x00-\x1f:*?"<>|]/.test(name) || name.length > 180) {
        return reply.code(400).send({ error: "文件名无效" });
      }
      const source = request.body;
      if (!(source instanceof Readable)) return reply.code(415).send({ error: "请以 application/octet-stream 上传原始文件" });
      const directory = resolve(project.workspacePath, "data", "uploads");
      await mkdir(directory, { recursive: true });
      const id = randomUUID();
      const target = resolve(directory, `${id}-${name}`);
      const temporary = `${target}.partial`;
      let bytes = 0;
      try {
        const limit = new Transform({
          transform(chunk: Buffer, _encoding, callback) {
            bytes += chunk.length;
            callback(bytes > MAX_UPLOAD_BYTES ? new Error("文件超过 2 GiB 上传上限") : null, chunk);
          },
        });
        await pipeline(source, limit, createWriteStream(temporary, { flags: "wx" }));
        if (bytes === 0) throw new Error("上传文件为空");
        await rename(temporary, target);
        return reply.code(201).send({ name, path: target, bytes });
      } catch (error) {
        await rm(temporary, { force: true });
        return reply.code(400).send({ error: error instanceof Error ? error.message : String(error) });
      }
    },
  );
}
