import { createReadStream } from "node:fs";
import { stat } from "node:fs/promises";
import { extname, resolve } from "node:path";
import type { FastifyInstance } from "fastify";

function attachmentHeader(name: string): string {
  const fallback = name.replace(/[^\x20-\x7e]|["\\]/g, "_");
  const encoded = encodeURIComponent(name).replace(/[!'()*]/g, (char) => `%${char.charCodeAt(0).toString(16).toUpperCase()}`);
  return `attachment; filename="${fallback}"; filename*=UTF-8''${encoded}`;
}

export function registerArtifactRoutes(server: FastifyInstance, root: string) {
  const types: Record<string, string> = { ".html": "text/html; charset=utf-8", ".md": "text/plain; charset=utf-8",
    ".json": "application/json", ".csv": "text/csv; charset=utf-8", ".png": "image/png", ".pdf": "application/pdf", ".nc": "application/octet-stream" };
  server.get<{ Params: { runId: string; name: string } }>("/api/artifacts/:runId/:name", async (request, reply) => {
    const { runId, name } = request.params;
    if (!/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/.test(runId)
      || !name || name === "." || name === ".." || /[\x00-\x1f\x7f<>:"/\\|?*]/.test(name)) return reply.code(404).send();
    const type = types[extname(name).toLowerCase()];
    if (!type) return reply.code(404).send();
    const file = resolve(root, runId, name);
    let size: number;
    try {
      const info = await stat(file);
      if (!info.isFile()) return reply.code(404).send();
      size = info.size;
    }
    catch { return reply.code(404).send(); }
    reply.header("X-Content-Type-Options", "nosniff");
    reply.header("Content-Security-Policy", "sandbox; default-src 'none'; img-src data: 'self'; style-src 'unsafe-inline'");
    reply.header("Content-Disposition", attachmentHeader(name));
    reply.header("Content-Length", size);
    return reply.type(type).send(createReadStream(file));
  });
}
