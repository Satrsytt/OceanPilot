import type { FastifyInstance } from "fastify";
import type { AppContext } from "../app-context.js";

export function registerProvenanceRoutes(server: FastifyInstance, context: AppContext): void {
  server.get<{ Params: { id: string }; Querystring: { planId?: string; download?: string } }>(
    "/api/conversations/:id/provenance", async (request, reply) => {
      if (!context.conversations.get(request.params.id)) {
        return reply.code(404).send({ error: "会话不存在" });
      }
      if (request.query.planId && !context.plans.list(request.params.id)
        .some((plan) => plan.id === request.query.planId)) {
        return reply.code(404).send({ error: "Plan 不属于当前会话" });
      }
      const graph = await context.provenance.graph(request.params.id, request.query.planId);
      reply.header("Cache-Control", "no-store");
      if (request.query.download === "1") {
        reply.header("Content-Disposition", "attachment; filename=provenance-graph.json");
      }
      return graph;
    });
}
