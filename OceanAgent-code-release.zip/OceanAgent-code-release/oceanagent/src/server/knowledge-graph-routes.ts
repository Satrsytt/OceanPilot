import type { FastifyInstance } from "fastify";
import type { KnowledgePerspective } from "../contracts.js";
import type { KnowledgeGraphService } from "../knowledge-graph/knowledge-graph-service.js";

function perspective(value: unknown): KnowledgePerspective {
  return value === "global" ? "global" : value === "dataset" ? "dataset" : "paper";
}

export function registerKnowledgeGraphRoutes(server: FastifyInstance, graph: KnowledgeGraphService): void {
  server.get("/api/knowledge-graph/stats", async () => graph.getStats());

  server.get("/api/knowledge-graph/catalog", async (request) => {
    const query = request.query as { perspective?: string; q?: string; limit?: string };
    const limit = Number.parseInt(query.limit ?? "5000", 10);
    return graph.getCatalog(perspective(query.perspective), query.q ?? "", Number.isFinite(limit) ? limit : 5000);
  });

  server.get("/api/knowledge-graph/subgraph", async (request, reply) => {
    const query = request.query as { perspective?: string; focusId?: string };
    const focusId = query.focusId?.trim();
    if (!focusId) return reply.code(400).send({ error: "请选择全局图谱、论文或数据集" });
    const result = graph.getGraph(perspective(query.perspective), focusId);
    if (!result) return reply.code(404).send({ error: `知识图谱中未找到实体：${focusId}` });
    return result;
  });
}
