import type { FastifyInstance } from "fastify";
import type { AppContext } from "../app-context.js";
import { selectPlanForExecution } from "../agent/plan-selection.js";

interface IdParams {
  id: string;
}

export function registerPlanRoutes(server: FastifyInstance, context: AppContext): void {
  server.post<{ Params: IdParams }>("/api/plans/:id/approve", async (request, reply) => {
    const plan = context.plans.get(request.params.id);
    if (!plan) return reply.code(404).send({ error: "科研规划不存在" });
    if (plan.status !== "awaiting_approval") {
      return reply.code(409).send({ error: `当前规划状态为 ${plan.status}，不能重复确认` });
    }
    if (!plan.nodeId) return reply.code(409).send({ error: "科研规划尚未关联会话节点" });
    if (plan.candidateGroupId && plan.feasibilityStatus !== "executable") {
      return reply.code(409).send({ error: "候选规划未通过全部执行前检查" });
    }
    const active = context.runs.findActive(plan.conversationId);
    if (active) return reply.code(409).send({ error: "当前会话已有正在运行的任务", runId: active.id });
    const caseModel = context.conversations.getNode(plan.nodeId)?.metadata.caseModel;
    const previousModel = context.runs.latestForConversation(plan.conversationId)?.model
      ?? (typeof caseModel === "string" ? caseModel : undefined);
    const { plan: executingPlan, run, userNode } = selectPlanForExecution(plan,
      { plans: context.plans, conversations: context.conversations, runs: context.runs },
      previousModel ?? context.models.runModelValue());
    setImmediate(() => void context.runner.execute(run.id));
    return reply.code(202).send({
      plan: executingPlan,
      run,
      userNode,
      executionQueued: true,
      eventsUrl: `/api/runs/${run.id}/events`,
      message: "规划已确认，OceanAgent已开始执行当前工具能力范围内的步骤。",
    });
  });

  server.post<{ Params: IdParams }>("/api/plans/:id/reject", async (request, reply) => {
    const plan = context.plans.get(request.params.id);
    if (!plan) return reply.code(404).send({ error: "科研规划不存在" });
    if (plan.status !== "awaiting_approval") {
      return reply.code(409).send({ error: `当前规划状态为 ${plan.status}，不能拒绝` });
    }
    return { plan: context.plans.updateStatus(plan.id, "rejected") };
  });
}
