import { createWriteStream } from "node:fs";
import { mkdir, rm } from "node:fs/promises";
import { randomUUID } from "node:crypto";
import { basename, resolve } from "node:path";
import { Readable, Transform } from "node:stream";
import { pipeline } from "node:stream/promises";
import type { FastifyInstance } from "fastify";
import type { AppContext } from "../app-context.js";
import type { ModelReference } from "../contracts.js";
import { generateIdeas } from "../ideation/research-ideas.js";
import { searchVerifiedLiterature } from "../ideation/literature-search.js";
import type { IdeationMode } from "../ideation/types.js";

const MAX_PDF_BYTES = 40 * 1024 * 1024;
const VALID_MODES = new Set<IdeationMode>(["L1", "L2", "L3"]);

export function registerIdeationRoutes(server: FastifyInstance, context: AppContext): void {
  server.get<{ Params: { id: string } }>("/api/conversations/:id/literature", async (request, reply) => {
    if (!context.conversations.get(request.params.id)) return reply.code(404).send({ error: "会话不存在" });
    return { papers: await context.userLiterature.list(request.params.id),
      latest: await context.userLiterature.latestIdeas(request.params.id) };
  });

  server.post<{ Params: { id: string }; Querystring: { name?: string } }>(
    "/api/conversations/:id/literature",
    { bodyLimit: MAX_PDF_BYTES },
    async (request, reply) => {
      if (!context.conversations.get(request.params.id)) return reply.code(404).send({ error: "会话不存在" });
      const name = request.query.name?.trim() ?? "";
      if (!name || name !== basename(name) || !/\.pdf$/i.test(name)
        || /[\\/\x00-\x1f:*?"<>|]/.test(name) || name.length > 180) {
        return reply.code(400).send({ error: "请选择文件名有效的 PDF" });
      }
      if (!(request.body instanceof Readable)) return reply.code(415).send({ error: "请以 application/octet-stream 上传 PDF" });
      const directory = context.userLiterature.directory(request.params.id);
      await mkdir(directory, { recursive: true });
      const temporary = resolve(directory, `${randomUUID()}.partial`);
      let bytes = 0;
      try {
        const limit = new Transform({ transform(chunk: Buffer, _encoding, callback) {
          bytes += chunk.length;
          callback(bytes > MAX_PDF_BYTES ? new Error("PDF 超过 40 MiB 上限") : null, chunk);
        } });
        await pipeline(request.body, limit, createWriteStream(temporary, { flags: "wx" }));
        if (bytes === 0) throw new Error("PDF 文件为空");
        const result = await context.userLiterature.ingest(request.params.id, temporary, name);
        return reply.code(result.duplicate ? 200 : 201).send(result);
      } catch (error) {
        await rm(temporary, { force: true });
        return reply.code(400).send({ error: error instanceof Error ? error.message : String(error) });
      }
    },
  );

  server.post<{ Params: { id: string }; Body: { mode: IdeationMode; objective?: string } }>(
    "/api/conversations/:id/ideas",
    async (request, reply) => {
      if (!context.conversations.get(request.params.id)) return reply.code(404).send({ error: "会话不存在" });
      const mode = request.body?.mode;
      const objective = request.body?.objective?.trim() ?? "";
      if (!VALID_MODES.has(mode)) return reply.code(400).send({ error: "模式必须是 L1、L2 或 L3" });
      if (objective.length > 2000) return reply.code(400).send({ error: "研究目标最多 2000 字" });
      if ((mode === "L1" || mode === "L3") && !objective) {
        return reply.code(400).send({ error: `${mode} 需要研究目标或 Prompt` });
      }
      const papers = await context.userLiterature.list(request.params.id);
      if (!papers.some((paper) => paper.status === "parsed")) {
        return reply.code(400).send({ error: "请先上传至少一篇可解析 PDF" });
      }
      const found = mode === "L3" ? await searchVerifiedLiterature(context.webSearch, objective)
        : { items: [], status: "not_requested" as const, reason: undefined };
      const uploadedDoi = new Set(papers.map((paper) => paper.doi).filter(Boolean));
      const external = found.items.filter((item) => !uploadedDoi.has(item.doi));
      const searchStatus = found.status === "verified" && !external.length ? "no_verified_results" : found.status;
      const searchReason = found.status === "verified" && !external.length
        ? "核验结果均与已上传论文重复，未加入新的外部引用。" : found.reason;
      const result = generateIdeas(request.params.id, mode, objective, papers, external,
        searchStatus, searchReason);
      await context.userLiterature.saveIdeas(request.params.id, result);
      return result;
    },
  );

  server.post<{ Params: { id: string; ideaId: string }; Body: { model?: ModelReference } }>(
    "/api/conversations/:id/ideas/:ideaId/plan",
    async (request, reply) => {
      const conversation = context.conversations.get(request.params.id);
      if (!conversation) return reply.code(404).send({ error: "会话不存在" });
      const result = await context.userLiterature.latestIdeas(conversation.id);
      const idea = result?.ideas.find((item) => item.ideaId === request.params.ideaId);
      if (!idea) return reply.code(404).send({ error: "Idea 不存在或已被新的探索结果替换" });
      if (idea.planStatus !== "ready_for_planning") {
        return reply.code(409).send({ error: "Idea 缺少必要数据变量；请补充数据需求后再规划" });
      }
      const active = context.runs.findActive(conversation.id);
      if (active) return reply.code(409).send({ error: "当前会话已有正在运行的任务", runId: active.id });
      let model: string;
      try { model = context.models.runModelValue(request.body?.model); }
      catch (error) { return reply.code(400).send({ error: error instanceof Error ? error.message : String(error) }); }
      const evidence = result!.papers.filter((paper) => idea.supportingLiterature.some((source) => source.paperId === paper.id))
        .map((paper) => ({ paperId: paper.id, title: paper.title, doi: paper.doi,
          excerpts: paper.evidence.filter((item) => idea.evidenceRefs.includes(item.id)).slice(0, 4) }));
      const userNode = context.conversations.addNode({
        conversationId: conversation.id, parentId: conversation.activeNodeId, role: "user",
        content: `请把已选海洋科研 Idea「${idea.title}」转换为可执行科研规划；必要数据变量：${idea.essentialDataRequirements.map((item) => item.variable).join("、")}。`,
        metadata: { ideaId: idea.ideaId, ideationMode: idea.mode,
          ideaContext: { idea, evidence, externalLiterature: result!.externalLiterature }, model },
      });
      const run = context.runs.create(conversation.id, userNode.id, model);
      setImmediate(() => void context.runner.execute(run.id));
      return reply.code(202).send({ run, userNode, eventsUrl: `/api/runs/${run.id}/events` });
    },
  );
}
