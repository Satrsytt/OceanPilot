import { createHash, randomUUID } from "node:crypto";
import { closeSync, openSync, readSync, realpathSync, statSync } from "node:fs";
import { mkdir, writeFile } from "node:fs/promises";
import { resolve } from "node:path";
import type { OceanDatabase } from "../db/database.js";
import type { PlanRepository } from "../db/plan-repository.js";
import type { UserLiteratureWorkspace } from "../ideation/user-literature-workspace.js";
import type { Citation, ResearchPlan } from "../contracts.js";
import type { IdeationResult, ResearchIdea } from "../ideation/types.js";
import { buildProvenanceGraph } from "./build-graph.js";
import { loadGlobalPaperMetadata } from "./paper-metadata.js";
import type { ArtifactRecord, CardRecord, ProvenanceEvent, ProvenanceGraph,
  ProvenanceSnapshot, ToolCallRecord } from "./types.js";
import { datasetReadIdentity } from "../agent/tools/record-dataset-read.js";

type Row = Record<string, unknown>;
const object = (value: unknown): Record<string, unknown> => value && typeof value === "object"
  && !Array.isArray(value) ? value as Record<string, unknown> : {};
const parsed = (value: unknown): Record<string, unknown> => {
  try { return object(JSON.parse(String(value ?? "{}"))); } catch { return {}; }
};
const list = (value: unknown): Record<string, unknown>[] => Array.isArray(value) ? value.map(object) : [];
const id = (value: unknown): string => typeof value === "string" ? value : "";

export class ProvenanceService {
  constructor(private readonly db: OceanDatabase, private readonly plans: PlanRepository,
    private readonly literature: UserLiteratureWorkspace, private readonly ragRoot: string,
    private readonly artifactRoot: string) {}

  isDatasetCard(datasetId: string): boolean {
    const row = this.db.raw.prepare("SELECT card_type FROM rag_documents WHERE id=?")
      .get(datasetId) as { card_type: string } | undefined;
    return row?.card_type === "dataset";
  }

  recordDatasetRead(input: { conversationId: string; runId: string; planId: string;
    toolCallId: string; datasetId: string; path: string; sha256: string; sizeBytes: number }): void {
    const plan = this.plans.get(input.planId);
    const call = this.db.raw.prepare("SELECT run_id, tool_name, status FROM tool_calls WHERE id=?")
      .get(input.toolCallId) as { run_id: string; tool_name: string; status: string } | undefined;
    if (!plan || plan.conversationId !== input.conversationId || !plan.datasets.includes(input.datasetId)
      || !call || call.run_id !== input.runId
      || call.tool_name !== "record_dataset_read" || call.status !== "completed"
      || !/^[a-f0-9]{64}$/.test(input.sha256) || input.sizeBytes <= 0) {
      throw new Error("数据读取事件缺少真实 Plan、有效数据身份或成功工具调用");
    }
    const path = realpathSync(input.path), info = statSync(path);
    if (!info.isFile() || info.size !== input.sizeBytes) throw new Error("数据读取事件的文件大小与真实文件不一致");
    const hash = createHash("sha256"), descriptor = openSync(path, "r"), buffer = Buffer.allocUnsafe(64 * 1024);
    let actualBytes = 0;
    try { for (let bytes = readSync(descriptor, buffer); bytes > 0; bytes = readSync(descriptor, buffer)) {
      hash.update(buffer.subarray(0, bytes)); actualBytes += bytes;
    } } finally { closeSync(descriptor); }
    if (actualBytes !== input.sizeBytes || hash.digest("hex") !== input.sha256) {
      throw new Error("数据读取事件的 SHA-256 与真实文件不一致");
    }
    const identity_source = datasetReadIdentity(plan, input.datasetId, path, input.sha256, input.sizeBytes,
      datasetId => this.isDatasetCard(datasetId));
    this.db.raw.prepare(`INSERT INTO provenance_events
      (id, conversation_id, run_id, plan_id, tool_call_id, event_type, payload_json, created_at)
      VALUES (?, ?, ?, ?, ?, 'dataset_read', ?, ?)`).run(
      randomUUID(), input.conversationId, input.runId, input.planId, input.toolCallId,
      JSON.stringify({ datasetId: input.datasetId, path,
        sha256: input.sha256, sizeBytes: input.sizeBytes, identity_source }), new Date().toISOString());
  }

  async graph(conversationId: string, planId?: string): Promise<ProvenanceGraph> {
    const plans = this.plans.list(conversationId);
    if (planId && !plans.some((plan) => plan.id === planId)) throw new Error("Plan 不属于当前会话");
    const runRows = this.db.raw.prepare("SELECT * FROM runs WHERE conversation_id = ? ORDER BY created_at")
      .all(conversationId) as Row[];
    const runs = runRows.map((row) => ({
      id: String(row.id), conversationId, userNodeId: String(row.user_node_id),
      assistantNodeId: row.assistant_node_id ? String(row.assistant_node_id) : null,
      status: String(row.status), outcome: String(row.outcome), checkpoint: parsed(row.checkpoint_json),
      model: String(row.model), error: row.error ? String(row.error) : null,
      startedAt: row.started_at ? String(row.started_at) : null,
      settledAt: row.settled_at ? String(row.settled_at) : null, createdAt: String(row.created_at),
    })) as ProvenanceSnapshot["runs"];
    const userIds = runRows.map((row) => String(row.user_node_id));
    const nodeRows = userIds.length ? this.db.raw.prepare(`SELECT id, metadata_json FROM nodes WHERE id IN
      (${userIds.map(() => "?").join(",")})`).all(...userIds) as Row[] : [];
    const byNode = new Map(nodeRows.map((row) => [String(row.id), parsed(row.metadata_json)]));
    const runMetadata = Object.fromEntries(runRows.map((row) => [String(row.id),
      byNode.get(String(row.user_node_id)) ?? {}]));
    const callRows = this.db.raw.prepare(`SELECT tool_calls.* FROM tool_calls JOIN runs ON runs.id=tool_calls.run_id
      WHERE runs.conversation_id=? ORDER BY tool_calls.started_at`).all(conversationId) as Row[];
    const calls: ToolCallRecord[] = callRows.map((row) => {
      const result = parsed(row.result_json);
      const error = String(row.status) === "failed"
        ? list(result.content).map((item) => id(item.text)).filter(Boolean).join(" ").slice(0, 800)
        : undefined;
      return { id: String(row.id), runId: String(row.run_id), name: String(row.tool_name),
        status: String(row.status), args: parsed(row.args_json), details: object(result.details),
        detailsRecorded: result.details !== undefined && typeof result.details === "object",
        startedAt: String(row.started_at), finishedAt: row.finished_at ? String(row.finished_at) : undefined,
        error };
    });
    const citationRows = this.db.raw.prepare(`SELECT citations.* FROM citations JOIN runs ON runs.id=citations.run_id
      WHERE runs.conversation_id=?`).all(conversationId) as Row[];
    const citations: Citation[] = citationRows.map((row) => ({ id: String(row.id), runId: String(row.run_id),
      sourceType: String(row.source_type) as Citation["sourceType"], sourceId: String(row.source_id),
      title: String(row.title), locator: row.locator ? String(row.locator) : undefined,
      url: row.url ? String(row.url) : undefined,
      evidenceText: row.evidence_text ? String(row.evidence_text) : undefined,
      metadata: parsed(row.metadata_json) }));
    const relevantIds = new Set<string>([
      ...plans.flatMap((plan) => [...plan.datasets, ...(plan.evidenceRefs ?? []),
        ...(plan.retrievalTrace?.evidenceRefs ?? [])]),
      ...citations.filter((citation) => citation.sourceType === "ocean_rag").map((citation) => citation.sourceId),
    ]);
    for (const call of calls) {
      const details = call.details;
      for (const path of list(details.paths)) {
        for (const bundleId of Array.isArray(path.bundleIds) ? path.bundleIds : []) {
          if (id(bundleId)) relevantIds.add(id(bundleId));
        }
        if (id(path.fromDatasetId)) relevantIds.add(id(path.fromDatasetId));
        if (id(path.toDatasetId)) relevantIds.add(id(path.toDatasetId));
      }
      for (const value of [...list(details.results), ...list(details.documents), ...list(details.matches),
        ...list(details.assessments),
        object(details.problem), object(details.bundle)]) {
        for (const key of ["id", "cardId", "datasetId", "candidate_id", "card_id", "dataset_id", "bundle_id"]) {
          if (id(value[key])) relevantIds.add(id(value[key]));
        }
      }
    }
    const cardRows = relevantIds.size ? this.db.raw.prepare(`SELECT * FROM rag_documents WHERE id IN
      (${[...relevantIds].map(() => "?").join(",")})`).all(...relevantIds) as Row[] : [];
    const cards: CardRecord[] = cardRows.map((row) => ({ id: String(row.id),
      cardType: String(row.card_type) as CardRecord["cardType"], title: String(row.title),
      sourceIds: JSON.parse(String(row.source_ids_json)) as string[], payload: parsed(row.payload_json) }));
    const eventRows = this.db.raw.prepare("SELECT * FROM provenance_events WHERE conversation_id=? ORDER BY created_at")
      .all(conversationId) as Row[];
    const events: ProvenanceEvent[] = eventRows.filter((row) => row.event_type === "dataset_read")
      .map((row) => ({ id: String(row.id), runId: String(row.run_id),
        planId: row.plan_id ? String(row.plan_id) : undefined,
        toolCallId: row.tool_call_id ? String(row.tool_call_id) : undefined,
        eventType: "dataset_read", payload: parsed(row.payload_json) as unknown as ProvenanceEvent["payload"],
        createdAt: String(row.created_at) }));
    const artifactRows = this.db.raw.prepare("SELECT * FROM artifacts WHERE conversation_id=? ORDER BY created_at")
      .all(conversationId) as Row[];
    const artifacts: ArtifactRecord[] = artifactRows.map((row) => {
      const metadata = parsed(row.metadata_json);
      return { id: String(row.id), runId: id(metadata.runId),
        planId: row.plan_id ? String(row.plan_id) : undefined,
        name: id(metadata.name) || String(row.path).split(/[\\/]/).at(-1) || "产物",
        url: id(metadata.url), sha256: String(row.sha256 ?? ""), sizeBytes: Number(row.size_bytes ?? 0),
        createdAt: String(row.created_at), toolCallId: id(metadata.toolCallId) || undefined };
    });
    const papers = await this.literature.list(conversationId);
    const latest = await this.literature.latestIdeas(conversationId);
    const historicalIdeas = Object.values(runMetadata).map((metadata) => object(metadata.ideaContext).idea)
      .filter((value): value is ResearchIdea => Boolean(value && typeof value === "object" && id(object(value).ideaId)));
    const ideaMap = new Map((latest?.ideas ?? []).map((idea) => [idea.ideaId, idea]));
    for (const idea of historicalIdeas) ideaMap.set(idea.ideaId, idea);
    const ideas: IdeationResult | null = latest || historicalIdeas.length ? {
      mode: latest?.mode ?? historicalIdeas[0]!.mode, objective: latest?.objective,
      papers, externalLiterature: latest?.externalLiterature ?? [],
      externalSearchStatus: latest?.externalSearchStatus ?? "not_requested",
      themeSummary: latest?.themeSummary ?? "历史 Idea", ideas: [...ideaMap.values()],
      gaps: latest?.gaps ?? [], createdAt: latest?.createdAt ?? historicalIdeas[0]!.createdAt,
    } : null;
    return buildProvenanceGraph({ conversationId, planId, plans, runs, runMetadata,
      calls, citations, cards, papers, ideas, events, artifacts,
      globalPaperMetadata: await loadGlobalPaperMetadata(this.ragRoot) });
  }

  async saveArtifactManifest(input: { runId: string; conversationId: string; plan: ResearchPlan;
    toolCallId: string;
    artifacts: Array<{ name: string; url: string; sha256: string; sizeBytes: number }> }): Promise<void> {
    const run = this.db.raw.prepare("SELECT * FROM runs WHERE id=? AND conversation_id=?")
      .get(input.runId, input.conversationId) as Row | undefined;
    if (!run) throw new Error("运行记录不存在");
    const directory = resolve(this.artifactRoot, input.runId);
    await mkdir(directory, { recursive: true });
    const callRows = this.db.raw.prepare("SELECT * FROM tool_calls WHERE run_id=? ORDER BY started_at")
      .all(input.runId) as Row[];
    const toolCalls = callRows.map((row) => {
      const status = String(row.status);
      const result = parsed(row.result_json);
      const errorSummary = status === "failed"
        ? list(result.content).map((item) => id(item.text)).filter(Boolean).join(" ").slice(0, 800)
        : null;
      return { id: String(row.id), name: String(row.tool_name),
        args: parsed(row.args_json), status, startedAt: String(row.started_at),
        finishedAt: row.finished_at ? String(row.finished_at) : null, errorSummary };
    });
    const readRows = this.db.raw.prepare("SELECT payload_json FROM provenance_events WHERE run_id=? AND event_type='dataset_read'")
      .all(input.runId) as Row[];
    const dataReads = readRows.map((row) => parsed(row.payload_json));
    const graph = await this.graph(input.conversationId, input.plan.id);
    const usedCards = new Set(graph.edges.filter((edge) => edge.relation === "supports"
      && (edge.to.startsWith("plan:") || edge.to.startsWith("step:")))
      .map((edge) => edge.from));
    const selectedCards = new Set(graph.edges.filter((edge) => edge.relation === "selected_for_plan"
      && edge.to === `plan:${input.plan.id}`).map((edge) => edge.from));
    const supportedIdeas = new Set(graph.edges.filter((edge) => edge.relation === "derived_from"
      && edge.to === `plan:${input.plan.id}` && edge.from.startsWith("idea:"))
      .map((edge) => edge.from));
    const paperIds = new Set(graph.edges.filter((edge) =>
      edge.from.startsWith("paper:") && (usedCards.has(edge.to) || selectedCards.has(edge.to))
      || edge.from.startsWith("userpaper:") && supportedIdeas.has(edge.to)
        && edge.relation === "supports").map((edge) => edge.from));
    const paperEvidence = graph.nodes.filter((node) => paperIds.has(node.id))
      .map((node) => ({ paperId: node.sourceId, title: node.label,
        sourceType: node.metadata.sourceType ?? "unknown",
        role: graph.edges.some((edge) => edge.from === node.id && usedCards.has(edge.to))
          ? "supports_decision" : graph.edges.some((edge) => edge.from === node.id
            && selectedCards.has(edge.to)) ? "selected_data_source" : "supports_idea",
        evidenceRefs: graph.edges.filter((edge) => edge.from === node.id)
          .flatMap((edge) => edge.evidenceRefs) }));
    const manifest = {
      schemaVersion: 1, runId: input.runId, planId: input.plan.id,
      deliveryToolCallId: input.toolCallId,
      planVersion: input.plan.version, plannedDatasetIds: input.plan.datasets,
      actualDatasetReads: dataReads, paperEvidence,
      planEvidenceRefs: input.plan.evidenceRefs ?? [],
      retrievalEvidenceRefs: input.plan.retrievalTrace?.evidenceRefs ?? [],
      workflowSteps: input.plan.steps.map((step) => ({ id: step.id, title: step.title,
        tool: step.tool ?? null, dependsOn: step.dependsOn })),
      observedStepIds: [...new Set(toolCalls.filter((call) => call.status === "completed")
        .map((call) => id(call.args.planStepId)).filter(Boolean))],
      toolCalls, failures: toolCalls.filter((call) => call.status === "failed"),
      repairedFromPlanId: input.plan.repairedFromPlanId ?? null,
      subsequentAttempts: toolCalls.filter((call, index) => toolCalls.slice(0, index)
        .some((earlier) => earlier.name === call.name && earlier.status === "failed")),
      outputFiles: input.artifacts, startedAt: run.started_at ?? run.created_at,
      manifestCreatedAt: new Date().toISOString(),
      unknown: input.plan.datasets.length && !dataReads.length
        ? ["没有可核验的数据集实际读取记录"] : [],
    };
    const manifestText = JSON.stringify(manifest, null, 2);
    const manifestPath = resolve(directory, "provenance-manifest.json");
    await writeFile(manifestPath, manifestText, "utf8");
    const insert = this.db.raw.prepare(`INSERT OR REPLACE INTO artifacts
      (id, conversation_id, plan_id, step_id, path, mime_type, size_bytes, sha256, metadata_json, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`);
    for (const artifact of [...input.artifacts, { name: "provenance-manifest.json",
      url: `/api/artifacts/${input.runId}/provenance-manifest.json`,
      sha256: createHash("sha256").update(manifestText).digest("hex"),
      sizeBytes: Buffer.byteLength(manifestText) }]) {
      insert.run(`${input.runId}:${artifact.name}`, input.conversationId, input.plan.id,
        null, resolve(directory, artifact.name), "application/octet-stream", artifact.sizeBytes,
        artifact.sha256, JSON.stringify({ runId: input.runId, name: artifact.name, url: artifact.url,
          toolCallId: input.toolCallId }),
        new Date().toISOString());
    }
  }
}
