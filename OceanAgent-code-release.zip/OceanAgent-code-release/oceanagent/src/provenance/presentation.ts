import type { ProvenanceEdge, ProvenanceGraph, ProvenanceNode } from "./types.js";

export interface ProvenanceView {
  nodes: ProvenanceNode[];
  edges: ProvenanceEdge[];
  retrievedCards: ProvenanceNode[];
  referencePapers: ProvenanceNode[];
  ideaLiterature: ProvenanceNode[];
  plans: ProvenanceNode[];
  planEvidence: ProvenanceEdge[];
  plannedDatasets: ProvenanceEdge[];
  toolCalls: ProvenanceNode[];
  observedDatasetReads: ProvenanceEdge[];
  artifacts: ProvenanceNode[];
}

export function selectProvenanceView(graph: ProvenanceGraph, focusId = ""): ProvenanceView {
  const byId = new Map(graph.nodes.map((node) => [node.id, node]));
  const visible = new Set<string>(focusId && byId.has(focusId) ? [focusId] : graph.nodes.map((node) => node.id));
  if (focusId && byId.has(focusId)) {
    let changed = true;
    while (changed) {
      changed = false;
      for (const edge of graph.edges) {
        if (visible.has(edge.from) && !visible.has(edge.to)) { visible.add(edge.to); changed = true; }
      }
    }
    for (const edge of graph.edges) {
      if (visible.has(edge.to) && edge.relation === "supports" && edge.from.startsWith("card:")) {
        visible.add(edge.from);
      }
    }
    for (const edge of graph.edges) {
      if (visible.has(edge.to) && edge.relation === "derived_from"
        && ["Paper", "UserPaper"].includes(byId.get(edge.from)?.type ?? "")) visible.add(edge.from);
    }
  }
  const nodes = graph.nodes.filter((node) => visible.has(node.id));
  const edges = graph.edges.filter((edge) => visible.has(edge.from) && visible.has(edge.to));
  const retrievedIds = new Set(graph.edges.filter((edge) => edge.relation === "retrieved"
    && edge.status === "observed").map((edge) => edge.to));
  const retrievedCards = nodes.filter((node) => ["PSC", "UBC", "DatasetCard"].includes(node.type)
    && retrievedIds.has(node.id));
  const referenceCardIds = new Set(retrievedCards.map((node) => node.id));
  const referencePapers = nodes.filter((node) => ["Paper", "UserPaper"].includes(node.type)
    && graph.edges.some((edge) => edge.from === node.id && edge.relation === "derived_from"
      && referenceCardIds.has(edge.to)));
  const ideaLiterature = nodes.filter((node) => ["Paper", "UserPaper"].includes(node.type)
    && edges.some((edge) => edge.from === node.id && byId.get(edge.to)?.type === "ResearchIdea"
      && ["supports", "considered"].includes(edge.relation)));
  const plans = nodes.filter((node) => node.type === "WorkflowPlan");
  const planEvidence = edges.filter((edge) => edge.relation === "supports" && edge.from.startsWith("card:")
    && (edge.to.startsWith("plan:") || edge.to.startsWith("step:")));
  const plannedDatasets = edges.filter((edge) => edge.relation === "selected_for_plan");
  const toolCalls = nodes.filter((node) => node.type === "ToolCall"
    && edges.some((edge) => edge.to === node.id && edge.relation === "executed_with"
      && (edge.from.startsWith("plan:") || edge.from.startsWith("step:"))));
  const observedDatasetReads = edges.filter((edge) => edge.relation === "executed_with"
    && edge.status === "observed" && byId.get(edge.from)?.type === "DatasetCard"
    && byId.get(edge.to)?.type === "ToolCall");
  const artifacts = nodes.filter((node) => node.type === "Artifact"
    && edges.some((edge) => edge.to === node.id && edge.relation === "produced"));
  return { nodes, edges, retrievedCards, referencePapers, ideaLiterature, plans, planEvidence,
    plannedDatasets, toolCalls, observedDatasetReads, artifacts };
}
