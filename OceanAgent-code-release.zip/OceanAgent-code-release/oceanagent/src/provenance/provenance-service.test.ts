import { createHash } from "node:crypto";
import { mkdtemp, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { afterEach, describe, expect, it, vi } from "vitest";
import { OceanDatabase } from "../db/database.js";
import { ConversationRepository } from "../db/conversation-repository.js";
import { PlanRepository } from "../db/plan-repository.js";
import { RunRepository } from "../db/run-repository.js";
import type { ResearchPlan } from "../contracts.js";
import type { UserLiteratureWorkspace } from "../ideation/user-literature-workspace.js";
import { ProvenanceService } from "./provenance-service.js";

const temporary: string[] = [];
const databases: OceanDatabase[] = [];
afterEach(async () => { databases.splice(0).forEach(db => db.close()); for (const path of temporary.splice(0)) await rm(path, { recursive: true, force: true }); });
async function fixture(official = true) {
  const workspace = await mkdtemp(join(tmpdir(), "ocean-read-provenance-")); temporary.push(workspace);
  const db = new OceanDatabase(":memory:", workspace); databases.push(db);
  const conversations = new ConversationRepository(db), plans = new PlanRepository(db), runs = new RunRepository(db);
  const conversation = conversations.create("fixture");
  const node = conversations.addNode({ conversationId: conversation.id, role: "user", content: "fixture" });
  const run = runs.create(conversation.id, node.id, "no-model");
  const path = join(workspace, "data.csv"), body = "time,value\n2020,1\n"; await writeFile(path, body);
  const sha256 = createHash("sha256").update(body).digest("hex"), sizeBytes = Buffer.byteLength(body);
  const plan = plans.save({ id: "plan", conversationId: conversation.id, version: 1, status: "executing",
    objective: "fixture", knowledgeMode: official ? "off" : "on", datasets: ["data"], steps: [], assumptions: [],
    requiredInputs: [], evidenceNeeds: [], deliverables: [], risks: [], createdAt: new Date().toISOString(),
    ...(official ? { verifiedDataSources: [{ dataset: "data", status: "available", validated: true, localPath: path,
      sha256, bytes: sizeBytes, pageUrl: "https://example.noaa.gov", checkedAt: new Date().toISOString(), reason: "fixture" }] } : {}) } as ResearchPlan);
  const input = { conversationId: conversation.id, runId: run.id, planId: plan.id, toolCallId: "read-call",
    datasetId: "data", path, sha256, sizeBytes };
  runs.startToolCall(run.id, input.toolCallId, "record_dataset_read", { datasetId: "data", file: path });
  runs.finishToolCall(input.toolCallId, { details: input }, false);
  const service = new ProvenanceService(db, plans, {} as UserLiteratureWorkspace, "unused", workspace);
  return { db, service, input, plan };
}

describe("official data read provenance", () => {
  it("persists an actual public read without inventing a DatasetCard lookup", async () => {
    const { db, service, input } = await fixture();
    const lookup = vi.spyOn(service, "isDatasetCard"); service.recordDatasetRead(input);
    const row = db.raw.prepare("SELECT payload_json FROM provenance_events WHERE event_type='dataset_read'").get() as { payload_json: string };
    expect(JSON.parse(row.payload_json)).toMatchObject({ datasetId: "data", sha256: input.sha256, identity_source: "validated_public_data" });
    expect(lookup).not.toHaveBeenCalled();
    expect(db.raw.prepare("SELECT COUNT(*) n FROM rag_documents").get()).toMatchObject({ n: 0 });
  });

  it("rejects a forged file hash and an unvalidated official source", async () => {
    const { db, service, input } = await fixture();
    expect(() => service.recordDatasetRead({ ...input, sha256: "0".repeat(64) })).toThrow("SHA-256");
    const planRow = db.raw.prepare("SELECT plan_json FROM plans WHERE id='plan'").get() as { plan_json: string };
    const value = JSON.parse(planRow.plan_json); value.verifiedDataSources[0].validated = false;
    db.raw.prepare("UPDATE plans SET plan_json=? WHERE id='plan'").run(JSON.stringify(value));
    expect(() => service.recordDatasetRead(input)).toThrow("完全匹配");
    expect(db.raw.prepare("SELECT COUNT(*) n FROM provenance_events").get()).toMatchObject({ n: 0 });
  });

  it("keeps the existing A1 DatasetCard path", async () => {
    const { db, service, input } = await fixture(false);
    db.raw.prepare(`INSERT INTO rag_documents (id,card_type,title,content,source_ids_json,payload_json,source_path,source_hash,indexed_at)
      VALUES ('data','dataset','fixture','fixture','[]','{}','fixture','fixture',?)`).run(new Date().toISOString());
    service.recordDatasetRead(input);
    const row = db.raw.prepare("SELECT payload_json FROM provenance_events").get() as { payload_json: string };
    expect(JSON.parse(row.payload_json).identity_source).toBe("dataset_card");
  });
});
