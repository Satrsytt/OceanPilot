import { readFile } from "node:fs/promises";
import { resolve } from "node:path";
import type { CardRecord, GlobalPaperMetadata } from "./types.js";

const paperIdPattern = /^paper_\d+$/i;
const missingTitle = /^(?:unknown|unresolved|not[_ -]?(?:reported|available)|none|null)$/i;
const record = (value: unknown): Record<string, unknown> =>
  value && typeof value === "object" && !Array.isArray(value) ? value as Record<string, unknown> : {};
const string = (value: unknown): string => typeof value === "string" ? value.trim() : "";

export function normalizeDoi(value: unknown): string | null {
  let raw = string(value).replace(/^doi:\s*/i, "");
  raw = raw.replace(/^https?:\/\/(?:dx\.)?doi\.org\//i, "");
  try { raw = decodeURIComponent(raw); } catch { return null; }
  raw = raw.trim().toLowerCase();
  return /^10\.\d{4,9}\/\S+$/.test(raw) ? raw : null;
}

function validTitle(value: unknown): string | null {
  const title = string(value);
  return title && !missingTitle.test(title) ? title : null;
}

export async function loadGlobalPaperMetadata(root: string): Promise<Record<string, GlobalPaperMetadata>> {
  const metadata: Record<string, GlobalPaperMetadata> = {};
  for (const name of ["paper_titles.jsonl", "papers.jsonl"]) {
    try {
      const content = await readFile(resolve(root, "manifest", name), "utf8");
      for (const line of content.split(/\r?\n/)) {
        if (!line.trim()) continue;
        let item: Record<string, unknown>;
        try { item = record(JSON.parse(line)); } catch { continue; }
        const paperId = string(item.paper_id);
        if (!paperId) continue;
        const current = metadata[paperId] ?? { paperId };
        if (name === "paper_titles.jsonl") {
          const title = validTitle(item.title);
          if (title) current.title = title;
          if (string(item.title_source)) current.titleSource = string(item.title_source);
          if (string(item.title_confidence)) current.titleConfidence = string(item.title_confidence);
          if (string(item.original_filename)) current.filename = string(item.original_filename);
        } else {
          const year = Number(item.year);
          if (Number.isInteger(year) && year >= 1500 && year <= 2200) current.year = year;
          if (string(item.filename) && !current.filename) current.filename = string(item.filename);
          if (string(item.source_path)) current.sourcePath = string(item.source_path);
        }
        const doi = normalizeDoi(item.doi);
        if (doi) current.doi = doi;
        const url = string(item.url);
        if (/^https?:\/\//i.test(url)) current.url = url;
        if (Array.isArray(item.authors)) current.authors = item.authors.filter((author): author is string =>
          typeof author === "string" && Boolean(author.trim()));
        metadata[paperId] = current;
      }
    } catch { /* Missing local index leaves identifiers unresolved. */ }
  }
  return metadata;
}

export interface PaperSourceReference {
  sourceId: string;
  sourceField: string;
  locator?: string;
  quote?: string;
  directTitle?: string;
  sourceGroupId?: string;
}

export function cardPaperReferences(card: CardRecord): PaperSourceReference[] {
  const refs: PaperSourceReference[] = [];
  const payload = card.payload;
  const directId = string(payload.paper_id);
  if (directId) refs.push({ sourceId: directId, sourceField: "paper_id",
    directTitle: string(payload.paper_title) || undefined,
    sourceGroupId: string(payload.source_group_id) || undefined });
  const sources = Array.isArray(payload.sources) ? payload.sources : [];
  for (const source of sources) {
    const item = record(source);
    const sourceId = string(item.source_id);
    if (sourceId) refs.push({ sourceId, sourceField: "sources.source_id" });
    const doi = normalizeDoi(item.doi) ?? normalizeDoi(item.url);
    if (doi) refs.push({ sourceId: doi, sourceField: "sources.doi" });
  }
  const visit = (value: unknown, depth: number): void => {
    if (depth > 9 || !value || typeof value !== "object") return;
    if (Array.isArray(value)) { for (const item of value) visit(item, depth + 1); return; }
    for (const [key, child] of Object.entries(record(value))) {
      if (key === "evidence" && Array.isArray(child)) {
        for (const evidence of child) {
          const item = record(evidence);
          const sourceId = string(item.source_id);
          if (sourceId) refs.push({ sourceId, sourceField: "evidence.source_id",
            locator: string(item.page_or_section) || undefined, quote: string(item.quote) || undefined });
        }
      } else if (child && typeof child === "object") visit(child, depth + 1);
    }
  };
  visit(payload, 0);
  return refs;
}

export interface ResolvedPaper {
  id: string;
  rawSourceId: string;
  label: string;
  titleStatus: "confirmed" | "unverified" | "missing";
  metadata: GlobalPaperMetadata;
  unresolvedReason?: string;
}

export function resolvePaperReference(reference: PaperSourceReference,
  index: Record<string, GlobalPaperMetadata>): ResolvedPaper | null {
  const raw = reference.sourceId;
  const doi = normalizeDoi(raw);
  const direct = index[raw];
  const doiMatches = doi ? Object.entries(index).filter(([, item]) => normalizeDoi(item.doi) === doi) : [];
  if (!direct && !doi && !paperIdPattern.test(raw)) return null;
  if (!direct && doi && doiMatches.length > 1) return null;
  const paperId = direct ? raw : doiMatches[0]?.[0] ?? (paperIdPattern.test(raw) ? raw : `doi:${doi}`);
  const indexed = index[paperId] ?? {};
  const directTitle = reference.sourceField === "paper_id" ? validTitle(reference.directTitle) : null;
  const title = directTitle ?? validTitle(indexed.title);
  const metadata: GlobalPaperMetadata = { ...indexed, paperId,
    ...(doi && !indexed.doi ? { doi } : {}),
    ...(title ? { title, titleSource: directTitle ? "card.paper_title" : indexed.titleSource } : {}) };
  if (metadata.doi && !metadata.url) metadata.url = `https://doi.org/${metadata.doi}`;
  const titleStatus = !title ? "missing"
    : !directTitle && metadata.titleConfidence?.toLowerCase() === "low" ? "unverified" : "confirmed";
  return { id: paperId, rawSourceId: raw,
    label: titleStatus === "unverified" ? `${title}（索引候选题名，待核验）`
      : title ?? (paperId.startsWith("doi:") ? `论文记录 DOI ${doi}（题名未收录）`
      : `论文记录 ${paperId}（题名未收录）`),
    titleStatus, metadata,
    ...(!title ? { unresolvedReason: index[paperId]
      ? "论文索引存在该记录，但未收录可靠题名" : "论文索引中没有对应记录" } : {}) };
}
