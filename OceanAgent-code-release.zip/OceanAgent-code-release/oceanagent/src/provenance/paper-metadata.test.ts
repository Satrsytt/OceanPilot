import { existsSync, readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";
import { loadConfig } from "../config.js";
import { buildProvenanceGraph } from "./build-graph.js";
import { cardPaperReferences, loadGlobalPaperMetadata, resolvePaperReference } from "./paper-metadata.js";
import type { CardRecord, ProvenanceSnapshot } from "./types.js";

const ragRoot = loadConfig().knowledgeGraphRoot;
const titlePath = resolve(ragRoot, "manifest", "paper_titles.jsonl");
const pscPath = resolve(ragRoot, "cards", "problem_solution_cards.jsonl");

describe("exact local paper identity", () => {
  it.skipIf(!existsSync(titlePath) || !existsSync(pscPath))(
    "resolves a real PSC paper_id through the existing title index without guessing", async () => {
      const indexed = readFileSync(titlePath, "utf8").split(/\r?\n/).filter(Boolean)
        .map((line) => JSON.parse(line) as { paper_id: string; title: string });
      const first = indexed.find((item) => Boolean(item.paper_id && item.title));
      expect(first).toBeDefined();
      const payload = readFileSync(pscPath, "utf8").split(/\r?\n/).filter(Boolean)
        .map((line) => JSON.parse(line) as Record<string, unknown>)
        .find((item) => item.paper_id === first!.paper_id);
      expect(payload).toBeDefined();
      const index = await loadGlobalPaperMetadata(ragRoot);
      const card: CardRecord = { id: String(payload!.card_id), cardType: "problem_solution",
        title: "Research case", sourceIds: [String(payload!.source_group_id), String(payload!.bundle_id)],
        payload: payload! };
      const graph = buildProvenanceGraph({ conversationId: "real-index", plans: [], runs: [{
        id: "run", conversationId: "real-index", userNodeId: "user", assistantNodeId: null,
        status: "settled", outcome: "completed", checkpoint: null, model: "mock", error: null,
        startedAt: null, settledAt: null, createdAt: "2026-10-26T00:00:00Z" }],
      runMetadata: {}, calls: [{ id: "search", runId: "run", name: "search_research_cases",
        status: "completed", args: {}, details: { results: [{ id: card.id }] },
        detailsRecorded: true, startedAt: "2026-10-26T00:00:00Z" }], citations: [],
      cards: [card], papers: [], ideas: null, events: [], artifacts: [],
      globalPaperMetadata: index } satisfies ProvenanceSnapshot);
      expect(graph.nodes.find((node) => node.id === `paper:${first!.paper_id}`)?.label).toBe(first!.title);
      expect(graph.nodes.some((node) => node.id === `paper:${payload!.source_group_id}`)).toBe(false);
      expect(graph.metrics.retrievedPsc).toMatchObject({ status: "confirmed", count: 1 });
    });

  it("resolves by a normalized DOI only when the local metadata relationship is unique", () => {
    const index = { paper_a: { title: "Local metadata title", doi: "10.1234/ABC.2026" } };
    const card: CardRecord = { id: "dataset", cardType: "dataset", title: "Dataset", sourceIds: [],
      payload: { sources: [{ doi: "https://doi.org/10.1234/abc.2026" }] } };
    const ref = cardPaperReferences(card)[0]!;
    const resolved = resolvePaperReference(ref, index);
    expect(resolved).toMatchObject({ id: "paper_a", label: "Local metadata title", titleStatus: "confirmed" });
    expect(resolvePaperReference(ref, { ...index,
      paper_b: { title: "Different record", doi: "10.1234/abc.2026" } })).toBeNull();
  });

  it("marks a low-confidence indexed title as a candidate rather than a confirmed title", () => {
    const resolved = resolvePaperReference({ sourceId: "paper_42", sourceField: "paper_id" },
      { paper_42: { title: "Extracted heading", titleSource: "first_page", titleConfidence: "low" } });
    expect(resolved).toMatchObject({ id: "paper_42", titleStatus: "unverified" });
    expect(resolved?.label).toContain("待核验");
  });

  it("keeps a stable missing paper ID and ignores unrelated source IDs", () => {
    const card: CardRecord = { id: "psc", cardType: "problem_solution", title: "Case",
      sourceIds: ["source_group_1", "dataset_1"],
      payload: { paper_id: "paper_9999", source_group_id: "source_group_1",
        evidence: [{ source_id: "repository_1" }] } };
    const refs = cardPaperReferences(card);
    expect(resolvePaperReference(refs[0]!, {})).toMatchObject({ id: "paper_9999", titleStatus: "missing" });
    expect(resolvePaperReference(refs[1]!, {})).toBeNull();
  });
});
