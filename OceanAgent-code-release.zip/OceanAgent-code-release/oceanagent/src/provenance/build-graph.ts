import type { CardRecord, ProvenanceEdge, ProvenanceGraph, ProvenanceNode, ProvenanceSnapshot,
  ProvenanceRelation, ToolCallRecord } from "./types.js";
import { cardPaperReferences, normalizeDoi, resolvePaperReference } from "./paper-metadata.js";

function record(value: unknown): Record<string, unknown> {
  return value && typeof value === "object" && !Array.isArray(value) ? value as Record<string, unknown> : {};
}
function entries(value: unknown): Record<string, unknown>[] {
  return Array.isArray(value) ? value.map(record) : [];
}
function identity(value: unknown): string {
  return typeof value === "string" ? value : "";
}
function cardId(value: Record<string, unknown>): string {
  return identity(value.id) || identity(value.cardId) || identity(value.datasetId)
    || identity(value.card_id) || identity(value.dataset_id) || identity(value.bundle_id);
}

export function buildProvenanceGraph(snapshot: ProvenanceSnapshot): ProvenanceGraph {
  const nodes = new Map<string, ProvenanceNode>();
  const edges = new Map<string, ProvenanceEdge>();
  const unknown = new Set<string>();
  const unresolvedPaperSources = new Map<string, ProvenanceGraph["unresolvedPaperSources"][number]>();
  const cards = new Map(snapshot.cards.map((card) => [card.id, card]));
  const scopedPlans = snapshot.planId ? snapshot.plans.filter((plan) => plan.id === snapshot.planId) : snapshot.plans;
  const scopedRunIds = new Set(snapshot.planId
    ? snapshot.runs.filter((run) => scopedPlans.some((plan) => plan.taskId === run.id
        || snapshot.runMetadata[run.id]?.approvedPlanId === plan.id)).map((run) => run.id)
    : snapshot.runs.map((run) => run.id));
  const calls = snapshot.calls.filter((call) => scopedRunIds.has(call.runId));
  const citations = snapshot.citations.filter((citation) => scopedRunIds.has(citation.runId));
  const events = snapshot.events.filter((event) => scopedRunIds.has(event.runId)
    && (!snapshot.planId || event.planId === snapshot.planId));
  const artifacts = snapshot.artifacts.filter((artifact) => scopedRunIds.has(artifact.runId)
    && (!snapshot.planId || artifact.planId === snapshot.planId));
  for (const artifact of snapshot.artifacts) {
    if (!artifact.runId && (!snapshot.planId || artifact.planId === snapshot.planId)) {
      unknown.add(`历史产物 ${artifact.name} 缺少 run_id，无法确认执行来源`);
    }
  }
  const knownEvidence = new Set<string>([
    ...snapshot.cards.map((card) => card.id),
    ...snapshot.cards.flatMap((card) => card.sourceIds),
    ...Object.keys(snapshot.globalPaperMetadata),
    ...snapshot.papers.flatMap((paper) => paper.evidence.map((item) => item.id)),
    ...(snapshot.ideas?.externalLiterature.map((item) => item.url) ?? []),
    ...citations.flatMap((citation) => [citation.id, citation.sourceId]),
  ]);
  const put = (node: ProvenanceNode) => {
    const current = nodes.get(node.id);
    if (!current) nodes.set(node.id, node);
    else if (current.type === "Requirement" && current.label === current.sourceId) {
      nodes.set(node.id, { ...current, label: node.label, metadata: { ...current.metadata, ...node.metadata } });
    }
  };
  const link = (from: string, to: string, relation: ProvenanceRelation, refs: string[] = [],
    status?: ProvenanceEdge["status"], eventId?: string, metadata?: Record<string, unknown>) => {
    if (!nodes.has(from) || !nodes.has(to)) { unknown.add(`缺失节点：${from} → ${to}`); return; }
    const validRefs = refs.filter((ref) => knownEvidence.has(ref));
    if (relation === "supports" && !validRefs.length) {
      unknown.add(`缺少可核验支持证据：${from} → ${to}`); return;
    }
    const id = `${from}|${relation}|${to}|${eventId ?? ""}`;
    if (!edges.has(id)) edges.set(id, { id, from, to, relation, evidenceRefs: validRefs,
      ...(status ? { status } : {}), ...(eventId ? { eventId } : {}),
      ...(metadata ? { metadata } : {}) });
  };
  const cardNode = (id: string): string | null => {
    const card = cards.get(id);
    if (!card) { unknown.add(`卡片 ${id} 不在当前知识快照中`); return null; }
    const type = card.cardType === "problem_solution" ? "PSC"
      : card.cardType === "usage_bundle" ? "UBC" : "DatasetCard";
    const key = `card:${id}`;
    const sourceCitations = citations.filter((citation) => citation.sourceId === id).map((citation) => ({
      id: citation.id, locator: citation.locator ?? null, evidenceText: citation.evidenceText ?? null,
      url: citation.url ?? null }));
    const summary = card.cardType === "problem_solution" ? identity(card.payload.solution_summary)
      : card.cardType === "dataset" ? identity(card.payload.description)
        : entries(card.payload.steps).slice(0, 2).map((step) => identity(step.action)).filter(Boolean).join("；");
    put({ id: key, type, sourceId: id, label: card.title || id,
      metadata: { sourceIds: card.sourceIds, citations: sourceCitations,
        summary: summary.slice(0, 500), cardType: card.cardType } });
    const grouped = new Map<string, { source: ReturnType<typeof resolvePaperReference>;
      fields: Set<string>; locators: Set<string>; quotes: Set<string>; groups: Set<string> }>();
    for (const reference of cardPaperReferences(card)) {
      const source = resolvePaperReference(reference, snapshot.globalPaperMetadata);
      if (!source) {
        if (reference.sourceField === "paper_id" || normalizeDoi(reference.sourceId)) {
          const key = `${id}:${reference.sourceField}:${reference.sourceId}`;
          unresolvedPaperSources.set(key, { sourceId: reference.sourceId, cardId: id,
            sourceField: reference.sourceField, reason: "来源标识无法唯一关联本地论文索引" });
        }
        continue;
      }
      if (source.titleStatus === "missing") {
        const unresolvedKey = `${id}:${reference.sourceField}:${source.id}`;
        unresolvedPaperSources.set(unresolvedKey, { sourceId: source.id, cardId: id,
          sourceField: reference.sourceField,
          reason: source.unresolvedReason ?? "题名未收录" });
      }
      const current = grouped.get(source.id) ?? { source, fields: new Set<string>(),
        locators: new Set<string>(), quotes: new Set<string>(), groups: new Set<string>() };
      current.fields.add(reference.sourceField);
      if (reference.locator) current.locators.add(reference.locator);
      if (reference.quote) current.quotes.add(reference.quote.slice(0, 500));
      if (reference.sourceGroupId) current.groups.add(reference.sourceGroupId);
      grouped.set(source.id, current);
    }
    for (const [paperId, value] of grouped) {
      const paperKey = `paper:${paperId}`;
      put({ id: paperKey, type: "Paper", sourceId: paperId, label: value.source!.label,
        metadata: { ...value.source!.metadata, sourceType: "global_knowledge_base", paperId,
          rawSourceId: value.source!.rawSourceId, titleStatus: value.source!.titleStatus,
          unresolvedReason: value.source!.unresolvedReason ?? null } });
      link(paperKey, key, "derived_from", [paperId], undefined, undefined, {
        sourceFields: [...value.fields], sourceGroupIds: [...value.groups],
        locators: [...value.locators].slice(0, 12), quotes: [...value.quotes].slice(0, 4),
      });
    }
    return key;
  };
  const scopedIdeaIds = new Set(scopedPlans.map((plan) =>
    snapshot.runMetadata[plan.taskId ?? ""]?.ideaId).filter((value): value is string => typeof value === "string"));
  const visibleIdeas = snapshot.planId ? (snapshot.ideas?.ideas ?? []).filter((idea) => scopedIdeaIds.has(idea.ideaId))
    : snapshot.ideas?.ideas ?? [];
  const visiblePaperIds = new Set(visibleIdeas.flatMap((idea) => idea.supportingLiterature.map((source) => source.paperId)));
  for (const paper of snapshot.papers.filter((item) => !snapshot.planId || visiblePaperIds.has(item.id))) {
    put({ id: `userpaper:${paper.id}`, type: "UserPaper", sourceId: paper.id,
      label: paper.title || `论文记录 ${paper.id}（题名未收录）`, status: paper.status,
      metadata: { authors: paper.authors, year: paper.year ?? null, doi: paper.doi ?? null,
        filename: paper.filename, titleStatus: paper.title ? "confirmed" : "missing",
        sourceType: "user_upload", evidence: paper.evidence.map((item) => ({ id: item.id, page: item.page,
          text: item.text, section: item.section })) } });
  }
  for (const item of (snapshot.ideas?.externalLiterature ?? []).filter((external) =>
    !snapshot.planId || visibleIdeas.some((idea) => idea.evidenceRefs.includes(external.url)))) {
    put({ id: `externalpaper:${item.id}`, type: "Paper", sourceId: item.id, label: item.title,
      metadata: { authors: item.authors, year: item.year ?? null, doi: item.doi,
        url: item.url, sourceType: "external_search", metadataOnly: true } });
  }
  for (const idea of visibleIdeas) {
    const ideaKey = `idea:${idea.ideaId}`;
    put({ id: ideaKey, type: "ResearchIdea", sourceId: idea.ideaId, label: idea.title,
      metadata: { mode: idea.mode, researchQuestion: idea.researchQuestion } });
    for (const requirement of idea.essentialDataRequirements) {
      const reqKey = `requirement:idea:${idea.ideaId}:${requirement.id}`;
      put({ id: reqKey, type: "Requirement", sourceId: requirement.id,
        label: `${requirement.variable} · ${requirement.role}`,
        metadata: { variable: requirement.variable, role: requirement.role,
          essential: requirement.essential !== false, ideaId: idea.ideaId } });
      link(ideaKey, reqKey, "derived_from");
    }
    for (const source of idea.supportingLiterature) {
      const evidenceIds = new Set(snapshot.papers.find((paper) => paper.id === source.paperId)?.evidence
        .map((item) => item.id) ?? []);
      link(`userpaper:${source.paperId}`, ideaKey, "supports",
        source.evidenceRefs.filter((ref) => evidenceIds.has(ref)));
    }
    for (const external of snapshot.ideas?.externalLiterature ?? []) {
      if (idea.evidenceRefs.includes(external.url)) link(`externalpaper:${external.id}`, ideaKey, "considered", [external.url]);
    }
  }
  for (const plan of scopedPlans) {
    const planKey = `plan:${plan.id}`;
    put({ id: planKey, type: "WorkflowPlan", sourceId: plan.id,
      label: plan.title || plan.objective, status: plan.status,
      metadata: { version: plan.version, candidateGroupId: plan.candidateGroupId ?? null,
        taskId: plan.taskId ?? null, feasibilityStatus: plan.feasibilityStatus ?? "unknown",
        verifiedDataSources: plan.verifiedDataSources ?? [] } });
    const ideaId = plan.taskId && snapshot.runMetadata[plan.taskId]?.ideaId;
    if (typeof ideaId === "string") link(`idea:${ideaId}`, planKey, "derived_from");
    for (const step of plan.steps) {
      const stepKey = `step:${plan.id}:${step.id}`;
      put({ id: stepKey, type: "WorkflowStep", sourceId: step.id, label: step.title,
        metadata: { tool: step.tool ?? null, phase: step.phase ?? null, dependsOn: step.dependsOn,
          planId: plan.id } });
      link(planKey, stepKey, "derived_from");
      const rawRefs = step.inputs?.evidenceRefs;
      const stepRefs = Array.isArray(rawRefs)
        ? rawRefs.filter((ref): ref is string => typeof ref === "string") : [];
      for (const ref of stepRefs) {
        const source = cardNode(ref);
        if (source) link(source, stepKey, "supports", [ref]);
      }
    }
    for (const datasetId of plan.datasets) {
      const key = cardNode(datasetId);
      if (key && cards.get(datasetId)?.cardType === "dataset") link(key, planKey, "selected_for_plan", [], "planned");
    }
    for (const requirementId of plan.retrievalTrace?.requirementIds ?? []) {
      const reqKey = `requirement:${plan.taskId ?? plan.id}:${requirementId}`;
      put({ id: reqKey, type: "Requirement", sourceId: requirementId, label: requirementId,
        metadata: { taskId: plan.taskId ?? null } });
      link(reqKey, planKey, "considered", plan.retrievalTrace?.evidenceRefs ?? []);
    }
    for (const ref of plan.evidenceRefs ?? []) {
      const key = cardNode(ref);
      if (key && ["problem_solution", "usage_bundle"].includes(cards.get(ref)?.cardType ?? "")) {
        link(key, planKey, "supports", [ref]);
      }
    }
  }
  for (const plan of scopedPlans) {
    const parent = snapshot.plans.find((source) => source.id === plan.repairedFromPlanId);
    if (parent) {
      put({ id: `plan:${parent.id}`, type: "WorkflowPlan", sourceId: parent.id,
        label: parent.title || parent.objective, status: parent.status,
        metadata: { version: parent.version, repairAncestor: true } });
      link(`plan:${plan.repairedFromPlanId}`, `plan:${plan.id}`, "derived_from");
    }
  }
  const callNode = (call: ToolCallRecord): string => {
    const key = `tool:${call.id}`;
    put({ id: key, type: "ToolCall", sourceId: call.id, label: call.name, status: call.status,
      metadata: { runId: call.runId, args: call.args, startedAt: call.startedAt,
        finishedAt: call.finishedAt ?? null, error: call.error ?? null } });
    return key;
  };
  for (const call of calls) {
    const toolKey = callNode(call);
    if (call.name === "record_dataset_read" && call.status === "failed") {
      const failedId = identity(call.args.datasetId);
      const failedCard = failedId ? cardNode(failedId) : null;
      if (failedCard) link(failedCard, toolKey, "executed_with", [], "failed", call.id);
      unknown.add(`数据产品 ${failedId || "未知"} 的读取失败；实际使用未确认`);
    }
    for (const plan of scopedPlans) {
      if (snapshot.runMetadata[call.runId]?.approvedPlanId === plan.id) {
        link(`plan:${plan.id}`, toolKey, "executed_with", [], call.status === "completed" ? "observed" : "failed");
        const stepId = identity(call.args.planStepId);
        if (stepId && plan.steps.some((step) => step.id === stepId)) {
          link(`step:${plan.id}:${stepId}`, toolKey, "executed_with", [],
            call.status === "completed" ? "observed" : "failed");
        }
      }
    }
    const result = call.details;
    if (call.status === "completed" && ["propose_research_plan", "propose_candidate_plans"].includes(call.name)) {
      const producedIds = [identity(record(result.plan).id), ...entries(result.plans).map((item) => identity(item.id))];
      for (const producedId of producedIds.filter(Boolean)) {
        if (scopedPlans.some((plan) => plan.id === producedId && plan.taskId === call.runId)) {
          link(toolKey, `plan:${producedId}`, "produced", [], "observed", call.id);
        }
      }
    }
    const returned: Array<{ id: string; type: CardRecord["cardType"]; method: string }> = [];
    const addReturned = (id: string, type: CardRecord["cardType"], method: string) => {
      if (id) returned.push({ id, type, method });
    };
    if (call.status === "completed") {
      if (call.name === "search_research_cases" || call.name === "search_ocean_datasets") {
        const type = call.name === "search_research_cases" ? "problem_solution" : "dataset";
        for (const item of entries(result.results)) addReturned(cardId(item), type,
          identity(item.retrievalMethod) || call.name);
      } else if (call.name === "expand_research_case") {
        addReturned(cardId(record(result.problem)), "problem_solution", "exact_expand");
        addReturned(cardId(record(result.bundle)), "usage_bundle", "exact_expand");
      } else if (call.name === "get_dataset_facts") {
        for (const item of entries(result.documents)) addReturned(cardId(item), "dataset", "exact_facts");
      } else if (call.name === "trace_global_knowledge_graph") {
        for (const path of entries(result.paths)) {
          for (const id of Array.isArray(path.bundleIds) ? path.bundleIds : []) {
            if (typeof id === "string") addReturned(id, "usage_bundle", "exact_graph_trace");
          }
          addReturned(identity(path.fromDatasetId), "dataset", "exact_graph_trace");
          addReturned(identity(path.toDatasetId), "dataset", "exact_graph_trace");
        }
      } else if (call.name === "assess_dataset_routes") {
        for (const assessment of entries(result.assessments)) {
          const type = identity(assessment.card_type) as CardRecord["cardType"];
          if (["dataset", "problem_solution", "usage_bundle"].includes(type)) {
            addReturned(identity(assessment.candidate_id), type,
              identity(assessment.retrieval_method) || "assessment");
          }
        }
      }
    }
    for (const item of returned) {
      if (cards.get(item.id)?.cardType !== item.type) continue;
      const key = cardNode(item.id);
      if (key) link(toolKey, key, "retrieved", [], "observed", undefined,
        { method: item.method, toolCallId: call.id });
    }
    if (call.name === "assess_dataset_routes" && call.status === "completed") {
      for (const requirement of entries(record(call.args.taskSpec).requirements)) {
        const requirementId = identity(requirement.id);
        if (!requirementId) continue;
        const reqKey = `requirement:${call.runId}:${requirementId}`;
        put({ id: reqKey, type: "Requirement", sourceId: requirementId,
          label: `${identity(requirement.variable) || requirementId} · ${identity(requirement.role) || "角色未知"}`,
          metadata: { taskId: call.runId, ...requirement } });
        link(toolKey, reqKey, "considered");
      }
      for (const match of entries(result.matches)) {
        const id = identity(match.datasetId);
        const requirementId = identity(match.requirementId);
        if (!id || !requirementId) continue;
        const cardKey = cardNode(id);
        const reqKey = `requirement:${call.runId}:${requirementId}`;
        put({ id: reqKey, type: "Requirement", sourceId: requirementId, label: requirementId,
          metadata: { taskId: call.runId, matchStatus: match.status ?? "unknown" } });
        const card = cards.get(id);
        const validCardRefs = new Set([id, ...(card?.sourceIds ?? [])]);
        if (cardKey) link(cardKey, reqKey, match.status === "satisfied" ? "supports" : "considered",
          Array.isArray(match.evidenceRefs)
            ? match.evidenceRefs.filter((ref): ref is string => typeof ref === "string" && validCardRefs.has(ref)) : []);
      }
    }
  }
  for (const event of events) {
    if (event.eventType !== "dataset_read") continue;
    const key = cardNode(event.payload.datasetId);
    const call = calls.find((item) => item.id === event.toolCallId);
    const plan = scopedPlans.find((item) => item.id === event.planId);
    if (key && call?.name === "record_dataset_read" && call.status === "completed"
      && plan?.datasets.includes(event.payload.datasetId)
      && snapshot.runMetadata[event.runId]?.approvedPlanId === plan.id) {
      link(key, `tool:${event.toolCallId}`, "executed_with", [event.payload.datasetId], "observed", event.id,
        { path: event.payload.path, sha256: event.payload.sha256,
          sizeBytes: event.payload.sizeBytes, recordedAt: event.createdAt });
    }
  }
  for (const artifact of artifacts) {
    const key = `artifact:${artifact.id}`;
    put({ id: key, type: "Artifact", sourceId: artifact.id, label: artifact.name,
      metadata: { url: artifact.url, sha256: artifact.sha256, sizeBytes: artifact.sizeBytes,
        runId: artifact.runId, planId: artifact.planId ?? null } });
    const producer = calls.find((call) => call.id === artifact.toolCallId && call.runId === artifact.runId
      && call.name === "complete_research_plan" && call.status === "completed");
    if (producer) link(`tool:${producer.id}`, key, "produced", [], "observed");
    else unknown.add(`产物 ${artifact.name} 缺少可核验的交付工具调用`);
  }
  for (const plan of scopedPlans) {
    if (plan.status === "completed" && plan.datasets.length
      && !events.some((event) => event.planId === plan.id)) {
      unknown.add(`Plan ${plan.id} 未记录可确认的数据集实际读取事件`);
    }
    if (plan.steps.length && !["awaiting_approval", "rejected"].includes(plan.status)
      && !calls.some((call) => snapshot.runMetadata[call.runId]?.approvedPlanId === plan.id
      && typeof call.args.planStepId === "string")) {
      unknown.add(`Plan ${plan.id} 的历史工具调用未记录精确 WorkflowStep ID`);
    }
  }
  const graphEdges = [...edges.values()];
  const metric = (ids: string[], status: "confirmed" | "not_recorded" | "unknown",
    reason?: string): ProvenanceGraph["metrics"]["retrievedPsc"] => ({
    status, count: status === "confirmed" ? new Set(ids).size : null,
    evidenceIds: [...new Set(ids)], ...(reason ? { reason } : {}),
  });
  const retrievedCards = graphEdges.filter((edge) => edge.relation === "retrieved"
    && edge.status === "observed" && nodes.get(edge.to)?.id.startsWith("card:"));
  const hasCompleteRetrievalDetails = (call: ToolCallRecord): boolean => {
    if (call.detailsRecorded === false) return false;
    const details = call.details;
    const indexed = (value: unknown, type: CardRecord["cardType"]): boolean => {
      const id = cardId(record(value));
      return Boolean(id) && cards.get(id)?.cardType === type;
    };
    switch (call.name) {
      case "search_research_cases":
        return Array.isArray(details.results) && details.results.every((item) => indexed(item, "problem_solution"));
      case "search_ocean_datasets":
        return Array.isArray(details.results) && details.results.every((item) => indexed(item, "dataset"));
      case "expand_research_case":
        return indexed(details.problem, "problem_solution") && indexed(details.bundle, "usage_bundle");
      case "get_dataset_facts":
        return Array.isArray(details.documents) && details.documents.every((item) => indexed(item, "dataset"));
      case "trace_global_knowledge_graph":
        return Array.isArray(details.paths) && details.paths.every((value) => {
          const path = record(value);
          return Array.isArray(path.bundleIds) && path.bundleIds.every((id) =>
            typeof id === "string" && cards.get(id)?.cardType === "usage_bundle")
            && identity(path.fromDatasetId) !== "" && cards.get(identity(path.fromDatasetId))?.cardType === "dataset"
            && identity(path.toDatasetId) !== "" && cards.get(identity(path.toDatasetId))?.cardType === "dataset";
        });
      case "assess_dataset_routes":
        return Array.isArray(details.assessments) && details.assessments.every((value) => {
          const assessment = record(value);
          const type = identity(assessment.card_type);
          return ["dataset", "problem_solution", "usage_bundle"].includes(type)
            && cards.get(identity(assessment.candidate_id))?.cardType === type;
        });
      default: return false;
    }
  };
  const retrievalMetric = (type: "PSC" | "UBC" | "DatasetCard", toolNames: string[]) => {
    const relevantCalls = calls.filter((call) => call.status === "completed" && toolNames.includes(call.name));
    const ids = retrievedCards.filter((edge) => nodes.get(edge.to)?.type === type).map((edge) => edge.to);
    if (!relevantCalls.length) return metric(ids, "not_recorded", "没有对应的成功检索工具记录");
    if (relevantCalls.some((call) => !hasCompleteRetrievalDetails(call))) {
      return metric(ids, "unknown", "工具候选清单不完整，或知识快照缺少返回的卡片");
    }
    return metric(ids, "confirmed");
  };
  const explicitSupports = graphEdges.filter((edge) => edge.relation === "supports"
    && edge.from.startsWith("card:")
    && (edge.to.startsWith("plan:") || edge.to.startsWith("step:")));
  const citedCardIds = explicitSupports.map((edge) => edge.from);
  const supportedStepIds = explicitSupports.filter((edge) => edge.to.startsWith("step:"))
    .map((edge) => edge.to);
  const selectedPlans = scopedPlans.filter((plan) => !["awaiting_approval", "rejected"].includes(plan.status));
  const selectedIds = graphEdges.filter((edge) => edge.relation === "selected_for_plan"
    && selectedPlans.some((plan) => edge.to === `plan:${plan.id}`)).map((edge) => edge.from);
  const missingSelectedCards = selectedPlans.some((plan) => plan.datasets.some((id) => !cards.has(id)));
  const executionCalls = calls.filter((call) => selectedPlans.some((plan) =>
    snapshot.runMetadata[call.runId]?.approvedPlanId === plan.id));
  const actualReadIds = graphEdges.filter((edge) => edge.relation === "executed_with"
    && edge.from.startsWith("card:") && nodes.get(edge.from)?.type === "DatasetCard"
    && edge.status === "observed").map((edge) => edge.from);
  const citationMetric = citedCardIds.length ? metric(citedCardIds, "confirmed")
    : metric([], "not_recorded", "当前 Plan 未记录可核实的知识引用关系");
  const stepMetric = supportedStepIds.length ? metric(supportedStepIds, "confirmed")
    : metric([], "not_recorded", "Plan 步骤没有有效的显式证据 ID 关联");
  return { conversationId: snapshot.conversationId, planId: snapshot.planId,
    nodes: [...nodes.values()], edges: graphEdges,
    metrics: {
      retrievedPsc: retrievalMetric("PSC", ["search_research_cases", "expand_research_case", "assess_dataset_routes"]),
      retrievedUbc: retrievalMetric("UBC", ["expand_research_case", "trace_global_knowledge_graph", "assess_dataset_routes"]),
      retrievedDatasetCards: retrievalMetric("DatasetCard", ["search_ocean_datasets", "get_dataset_facts",
        "trace_global_knowledge_graph", "assess_dataset_routes"]),
      recordedKnowledgeCitations: citationMetric,
      selectedDatasetProducts: !selectedPlans.length ? metric([], "not_recorded", "尚无已选并执行的 Plan")
        : missingSelectedCards ? metric(selectedIds, "unknown", "已选 Plan 的部分 DatasetCard 不在当前知识快照")
          : metric(selectedIds, "confirmed"),
      actualReadDatasetProducts: actualReadIds.length ? metric(actualReadIds, "confirmed")
        : executionCalls.length ? metric([], "unknown", "执行日志不足以排除其他工具读取数据")
          : metric([], "not_recorded", "暂无可核实的执行记录"),
      knowledgeSupportedPlanSteps: stepMetric,
    }, unknownRelations: [...unknown], unresolvedPaperSources: [...unresolvedPaperSources.values()],
    generatedAt: new Date().toISOString() };
}
