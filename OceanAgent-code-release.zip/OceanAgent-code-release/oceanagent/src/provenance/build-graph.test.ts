import { describe, expect, it } from "vitest";
import type { AgentRun, ResearchPlan } from "../contracts.js";
import { buildProvenanceGraph } from "./build-graph.js";
import { selectProvenanceView } from "./presentation.js";
import type { CardRecord, ProvenanceSnapshot, ToolCallRecord } from "./types.js";

const at = "2026-10-26T00:00:00.000Z";
function plan(id: string, extra: Partial<ResearchPlan> = {}): ResearchPlan {
  return { id, conversationId: "c", version: 1, status: "awaiting_approval", objective: id,
    taskId: `planning-${id}`, assumptions: [], requiredInputs: [], datasets: [], evidenceNeeds: [],
    steps: [{ id: "s1", title: "分析步骤", description: "", dependsOn: [],
      expectedOutputs: [], risks: [], inputs: {} }], deliverables: [], risks: [], createdAt: at, ...extra };
}
function run(id: string): AgentRun {
  return { id, conversationId: "c", userNodeId: id, assistantNodeId: null,
    status: "settled", outcome: "completed", checkpoint: null, model: "mock", error: null,
    startedAt: at, settledAt: at, createdAt: at };
}
function card(id: string, cardType: CardRecord["cardType"], payload: Record<string, unknown> = {}): CardRecord {
  return { id, cardType, title: id, sourceIds: [id, "sg_not_a_paper", "dataset_not_a_paper"], payload };
}
function call(id: string, runId: string, name: string, details: Record<string, unknown>,
  status = "completed", args: Record<string, unknown> = {}): ToolCallRecord {
  return { id, runId, name, status, args, details, detailsRecorded: true, startedAt: at };
}
function snapshot(extra: Partial<ProvenanceSnapshot> = {}): ProvenanceSnapshot {
  return { conversationId: "c", plans: [], runs: [], runMetadata: {}, calls: [], citations: [],
    cards: [], papers: [], ideas: null, events: [], artifacts: [], globalPaperMetadata: {}, ...extra };
}
const paperEvidence = (id: string) => [{ source_id: id, page_or_section: "PDF p. 2",
  quote: "A measured observation from the paper." }];

describe("record-backed provenance", () => {
  it("shows a retrieved PSC without claiming it was cited", () => {
    const graph = buildProvenanceGraph(snapshot({ plans: [plan("p")], runs: [run("planning-p")],
      cards: [card("psc", "problem_solution", { paper_id: "paper_1", evidence: paperEvidence("paper_1") })],
      globalPaperMetadata: { paper_1: { title: "Recorded title" } },
      calls: [call("search", "planning-p", "search_research_cases", { results: [{ id: "psc" }] })] }));
    expect(graph.metrics.retrievedPsc).toMatchObject({ status: "confirmed", count: 1 });
    expect(graph.metrics.recordedKnowledgeCitations).toMatchObject({ status: "not_recorded", count: null });
    expect(graph.nodes.find((node) => node.id === "paper:paper_1")?.label).toBe("Recorded title");
    expect(graph.nodes.some((node) => node.id === "paper:sg_not_a_paper")).toBe(false);
    expect(graph.edges.some((edge) => edge.relation === "supports" && edge.to === "plan:p")).toBe(false);
  });

  it("counts a PSC-to-step link only when the Plan has a valid explicit evidence ID", () => {
    const p = plan("p", { steps: [{ id: "s1", title: "验证", description: "", dependsOn: [],
      expectedOutputs: [], risks: [], inputs: { evidenceRefs: ["psc"] } }] });
    const graph = buildProvenanceGraph(snapshot({ plans: [p], cards: [card("psc", "problem_solution")] }));
    expect(graph.edges.some((edge) => edge.from === "card:psc" && edge.to === "step:p:s1"
      && edge.relation === "supports")).toBe(true);
    expect(graph.metrics.knowledgeSupportedPlanSteps).toMatchObject({ status: "confirmed", count: 1 });
    const invalid = buildProvenanceGraph(snapshot({ plans: [plan("p", { steps: [{ ...p.steps[0]!,
      inputs: { evidenceRefs: ["invented"] } }] })], cards: [card("psc", "problem_solution")] }));
    expect(invalid.metrics.knowledgeSupportedPlanSteps.status).toBe("not_recorded");
  });

  it("records a returned UBC as retrieval without inferring method adoption", () => {
    const graph = buildProvenanceGraph(snapshot({ plans: [plan("p")], runs: [run("planning-p")],
      cards: [card("psc", "problem_solution"), card("ub", "usage_bundle",
        { steps: [{ evidence: paperEvidence("paper_1") }] })],
      globalPaperMetadata: { paper_1: { title: "Recorded paper" } },
      calls: [call("expand", "planning-p", "expand_research_case",
        { problem: { id: "psc" }, bundle: { id: "ub" } })] }));
    expect(graph.metrics.retrievedUbc).toMatchObject({ status: "confirmed", count: 1 });
    expect(graph.metrics.recordedKnowledgeCitations.status).toBe("not_recorded");
  });

  it("separates a selected DatasetCard from an unrecorded execution", () => {
    const graph = buildProvenanceGraph(snapshot({ plans: [plan("p", { status: "approved", datasets: ["d"] })],
      cards: [card("d", "dataset")] }));
    expect(graph.metrics.selectedDatasetProducts).toMatchObject({ status: "confirmed", count: 1 });
    expect(graph.metrics.actualReadDatasetProducts).toMatchObject({ status: "not_recorded", count: null });
  });

  it("counts a successful read only from the bound tool call and event", () => {
    const graph = buildProvenanceGraph(snapshot({ plans: [plan("p", { status: "completed", datasets: ["d"] })],
      runs: [run("exec")], runMetadata: { exec: { approvedPlanId: "p" } }, cards: [card("d", "dataset")],
      calls: [call("read", "exec", "record_dataset_read", {}, "completed", { datasetId: "d", planStepId: "s1" }),
        call("delivery", "exec", "complete_research_plan", {})],
      events: [{ id: "event", runId: "exec", planId: "p", toolCallId: "read", eventType: "dataset_read",
        payload: { datasetId: "d", path: "data.csv", sha256: "a".repeat(64), sizeBytes: 10 }, createdAt: at }],
      artifacts: [{ id: "file", runId: "exec", planId: "p", toolCallId: "delivery",
        name: "result.csv", url: "/result.csv", sha256: "b".repeat(64), sizeBytes: 2, createdAt: at }] }));
    expect(graph.metrics.actualReadDatasetProducts).toMatchObject({ status: "confirmed", count: 1 });
    expect(graph.edges.find((edge) => edge.eventId === "event")?.metadata?.sha256).toBe("a".repeat(64));
    expect(graph.edges.some((edge) => edge.from === "tool:delivery" && edge.to === "artifact:file"
      && edge.relation === "produced")).toBe(true);
  });

  it("reports unknown data usage when execution logs exist without a read event", () => {
    const graph = buildProvenanceGraph(snapshot({ plans: [plan("p", { status: "completed", datasets: ["d"] })],
      runs: [run("exec")], runMetadata: { exec: { approvedPlanId: "p" } },
      cards: [card("d", "dataset")], calls: [call("shell", "exec", "bash", {})] }));
    expect(graph.metrics.actualReadDatasetProducts).toMatchObject({ status: "unknown", count: null });
  });

  it("keeps one paper node for multiple cards and preserves the source group as a field", () => {
    const cards = [card("psc", "problem_solution", { paper_id: "paper_3", source_group_id: "sg_alpha" }),
      card("ub", "usage_bundle", { steps: [{ evidence: paperEvidence("paper_3") }] })];
    const graph = buildProvenanceGraph(snapshot({ plans: [plan("p", { evidenceRefs: ["psc", "ub"] })],
      cards, globalPaperMetadata: { paper_3: { title: "Indexed paper" } } }));
    expect(graph.nodes.filter((node) => node.id === "paper:paper_3")).toHaveLength(1);
    expect(graph.edges.filter((edge) => edge.from === "paper:paper_3" && edge.relation === "derived_from")).toHaveLength(2);
    expect(graph.edges.find((edge) => edge.to === "card:psc")?.metadata?.sourceGroupIds).toEqual(["sg_alpha"]);
  });

  it("retains an unresolved stable paper ID without creating fake paper nodes for other IDs", () => {
    const graph = buildProvenanceGraph(snapshot({ plans: [plan("p", { datasets: ["d"] })],
      cards: [card("d", "dataset", { sources: [{ evidence: paperEvidence("paper_9999") }] })] }));
    expect(graph.nodes.find((node) => node.id === "paper:paper_9999")?.label).toContain("paper_9999");
    expect(graph.unresolvedPaperSources.some((item) => item.sourceId === "paper_9999")).toBe(true);
    expect(graph.nodes.some((node) => node.id === "paper:dataset_not_a_paper")).toBe(false);
  });

  it("isolates the selected Plan's evidence and execution from another Plan", () => {
    const graph = buildProvenanceGraph(snapshot({ planId: "a", plans: [
      plan("a", { status: "completed", datasets: ["d-a"], evidenceRefs: ["psc-a"] }),
      plan("b", { status: "completed", datasets: ["d-b"], evidenceRefs: ["psc-b"] })],
    runs: [run("exec-a"), run("exec-b")], runMetadata: {
      "exec-a": { approvedPlanId: "a" }, "exec-b": { approvedPlanId: "b" } },
    cards: [card("d-a", "dataset"), card("d-b", "dataset"),
      card("psc-a", "problem_solution"), card("psc-b", "problem_solution")],
    calls: [call("tool-a", "exec-a", "bash", {}), call("tool-b", "exec-b", "bash", {})] }));
    expect(graph.edges.some((edge) => edge.to === "plan:b" && edge.relation === "supports")).toBe(false);
    expect(graph.nodes.some((node) => node.id === "card:d-b")).toBe(false);
    expect(graph.metrics.recordedKnowledgeCitations).toMatchObject({ status: "confirmed", count: 1 });
  });

  it("distinguishes a confirmed zero-result search from missing search records", () => {
    const empty = buildProvenanceGraph(snapshot({ runs: [run("r")],
      calls: [call("search", "r", "search_research_cases", { results: [] })] }));
    const missing = buildProvenanceGraph(snapshot());
    const incomplete = buildProvenanceGraph(snapshot({ runs: [run("r")],
      calls: [call("search", "r", "search_research_cases", {})] }));
    const staleIndex = buildProvenanceGraph(snapshot({ runs: [run("r")],
      calls: [call("search", "r", "search_research_cases", { results: [{ id: "missing-psc" }] })] }));
    expect(empty.metrics.retrievedPsc).toMatchObject({ status: "confirmed", count: 0 });
    expect(missing.metrics.retrievedPsc).toMatchObject({ status: "not_recorded", count: null });
    expect(incomplete.metrics.retrievedPsc).toMatchObject({ status: "unknown", count: null });
    expect(staleIndex.metrics.retrievedPsc).toMatchObject({ status: "unknown", count: null });
  });

  it("uses the exported JSON graph for the same visible sections", () => {
    const graph = buildProvenanceGraph(snapshot({ plans: [plan("p")], runs: [run("planning-p")],
      cards: [card("psc", "problem_solution")],
      calls: [call("search", "planning-p", "search_research_cases", { results: [{ id: "psc" }] })] }));
    const exported = JSON.parse(JSON.stringify(graph)) as typeof graph;
    expect(selectProvenanceView(exported).retrievedCards.map((node) => node.id))
      .toEqual(selectProvenanceView(graph).retrievedCards.map((node) => node.id));
    expect(selectProvenanceView(exported).planEvidence).toEqual(selectProvenanceView(graph).planEvidence);
  });
});
