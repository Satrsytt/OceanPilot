import type { AgentRun, Citation, ResearchPlan } from "../contracts.js";
import type { IdeationResult, UserPaper } from "../ideation/types.js";

export type ProvenanceNodeType = "Paper" | "UserPaper" | "PSC" | "UBC" | "DatasetCard"
  | "Requirement" | "ResearchIdea" | "WorkflowPlan" | "WorkflowStep" | "ToolCall" | "Artifact";
export type ProvenanceRelation = "retrieved" | "considered" | "supports" | "derived_from"
  | "selected_for_plan" | "executed_with" | "produced";

export interface ProvenanceNode {
  id: string;
  type: ProvenanceNodeType;
  label: string;
  sourceId: string;
  status?: string;
  metadata: Record<string, unknown>;
}

export interface ProvenanceEdge {
  id: string;
  from: string;
  to: string;
  relation: ProvenanceRelation;
  eventId?: string;
  evidenceRefs: string[];
  status?: "planned" | "observed" | "failed";
  metadata?: Record<string, unknown>;
}

export type RecordStatus = "confirmed" | "not_recorded" | "unknown";
export interface ProvenanceMetric {
  status: RecordStatus;
  count: number | null;
  evidenceIds: string[];
  reason?: string;
}

export interface KnowledgeUsageMetrics {
  retrievedPsc: ProvenanceMetric;
  retrievedUbc: ProvenanceMetric;
  retrievedDatasetCards: ProvenanceMetric;
  recordedKnowledgeCitations: ProvenanceMetric;
  selectedDatasetProducts: ProvenanceMetric;
  actualReadDatasetProducts: ProvenanceMetric;
  knowledgeSupportedPlanSteps: ProvenanceMetric;
}

export interface UnresolvedPaperSource {
  sourceId: string;
  cardId: string;
  sourceField: string;
  reason: string;
}

export interface ProvenanceGraph {
  conversationId: string;
  planId?: string;
  nodes: ProvenanceNode[];
  edges: ProvenanceEdge[];
  metrics: KnowledgeUsageMetrics;
  unknownRelations: string[];
  unresolvedPaperSources: UnresolvedPaperSource[];
  generatedAt: string;
}

export interface ToolCallRecord {
  id: string;
  runId: string;
  name: string;
  status: string;
  args: Record<string, unknown>;
  details: Record<string, unknown>;
  detailsRecorded?: boolean;
  startedAt: string;
  finishedAt?: string;
  error?: string;
}

export interface CardRecord {
  id: string;
  cardType: "problem_solution" | "usage_bundle" | "dataset";
  title: string;
  sourceIds: string[];
  payload: Record<string, unknown>;
}

export interface ProvenanceEvent {
  id: string;
  runId: string;
  planId?: string;
  toolCallId?: string;
  eventType: "dataset_read";
  payload: { datasetId: string; path: string; sha256: string; sizeBytes: number };
  createdAt: string;
}

export interface ArtifactRecord {
  id: string;
  runId: string;
  planId?: string;
  name: string;
  url: string;
  sha256: string;
  sizeBytes: number;
  createdAt: string;
  toolCallId?: string;
}

export interface ProvenanceSnapshot {
  conversationId: string;
  planId?: string;
  plans: ResearchPlan[];
  runs: AgentRun[];
  runMetadata: Record<string, Record<string, unknown>>;
  calls: ToolCallRecord[];
  citations: Citation[];
  cards: CardRecord[];
  papers: UserPaper[];
  ideas: IdeationResult | null;
  events: ProvenanceEvent[];
  artifacts: ArtifactRecord[];
  globalPaperMetadata: Record<string, GlobalPaperMetadata>;
}

export interface GlobalPaperMetadata {
  paperId?: string;
  title?: string;
  titleSource?: string;
  titleConfidence?: string;
  year?: number;
  authors?: string[];
  doi?: string;
  url?: string;
  filename?: string;
  sourcePath?: string;
}
