# OceanAgent

This directory contains the OceanAgent application: the TypeScript agent and tool loop, card retrieval and graph expansion, research planning, plan approval and execution, the web interface, PDF ingestion, data access, and runtime regression tests. The package retains dataset retrieval and recommendation code, experiment isolation, and plan generation contracts. Historical workflow scoring, judge packets, review annotations, and their report generators are omitted from this code release.

Requirements: Node.js >=22.19.0, npm, and Python 3.11+. Installing `better-sqlite3` may require a C/C++ toolchain. Model execution requires a supported provider and your own credentials.

## Install and start

From this directory:

```bash
npm ci
python3 -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements-science.txt
npm run build
OCEAN_RAG_ROOT="$(cd ../benchmark/knowledge_snapshot && pwd)" npm start
```

Open http://127.0.0.1:3210 and configure a model provider in Settings. The application creates local settings and sessions in `data/`. Model runs may incur provider charges. The shared knowledge snapshot defaults to `../benchmark/knowledge_snapshot`; `OCEAN_RAG_ROOT` overrides it. Startup builds a derived retrieval index from the released cards when needed.

Environment options are listed in `.env.example`. The app autoloads only its whitelisted DashScope settings from `.env.local`; export other options in the shell. No credentials, session databases, dependencies, downloaded scientific datasets, or historical run outputs are supplied.

PDF ingestion uses the self-contained section-aware extractor in `src/ideation/extract_user_pdf.py` and the PyMuPDF dependency. The optional SST demo in `demos/sst-analysis/` retains analysis and validation scripts; see its README for public-data acquisition and execution commands.

## Validate locally

After installing the dependencies and activating the scientific Python environment:

```bash
npm run typecheck
npm test
npm run build
```

These checks do not require model calls. The scientific Python regression test needs the packages in `requirements-science.txt`. `OCEAN_PYTHON_PATH` can select another existing scientific Python environment.

## Retained experiment code

`experiments/agent_e1_taskcompiler/` and `experiments/agent_e2_structured_knowledge/` retain TaskCompiler and dataset recommendation adapters. The release-level `../experiments/` directory documents dataset retrieval evaluation. Runtime helpers in `src/experiments/` retain bounded tool/model budgets, isolated workspaces, knowledge access policies, retrieval diagnostics, recommendation submission, and plan generation. Plan contracts validate submitted fields and dependencies; they do not compare plans against reference steps or assign scientific scores.

To prepare an isolated DEV task without model execution:

```bash
node dist/experiments/paired-dev.js \
  --experiment dev-smoke --model example-provider::example-model \
  --knowledge-root ../benchmark/knowledge_snapshot --limit 1 --dry-run
```

Preparation creates `outputs/stage3/dev-smoke`. Execution is enabled separately with `--execute` and requires configured model credentials.

## License

The original PolyForm Noncommercial 1.0.0 license is retained in `LICENSE`, with the original author notice in `NOTICE`. Third-party dependencies retain their own licenses and notices.
