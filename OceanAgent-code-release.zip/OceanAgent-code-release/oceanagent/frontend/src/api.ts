import type {
  AgentRun,
  Citation,
  Conversation,
  ConversationNode,
  CreateResearchProjectInput,
  ProjectExecutionTarget,
  ConfiguredModel,
  ModelDiscoveryResult,
  ModelReference,
  ModelSettingsState,
  ResearchProject,
  RemoteConnectionProfile,
  ResearchPlan,
  StreamEvent,
  ToolTrace,
  KnowledgeCatalogItem,
  KnowledgeGraphResponse,
  KnowledgeGraphStats,
  KnowledgePerspective,
} from "../../src/contracts";
import type { IdeationMode, IdeationResult, UserPaper } from "../../src/ideation/types";
import type { ProvenanceGraph } from "../../src/provenance/types";

export type { AgentRun, Citation, Conversation, ConversationNode, ResearchPlan, ResearchProject, RemoteConnectionProfile, StreamEvent, ToolTrace };
export type { CreateResearchProjectInput, ProjectExecutionTarget };
export type { ConfiguredModel, ModelDiscoveryResult, ModelReference, ModelSettingsState };
export type { KnowledgeCatalogItem, KnowledgeGraphResponse, KnowledgeGraphStats, KnowledgePerspective };
export type { IdeationMode, IdeationResult, UserPaper };
export type { ProvenanceGraph };

export interface ConversationDetail {
  conversation: Conversation;
  latestRun?: AgentRun | null;
  nodes: ConversationNode[];
  plans: ResearchPlan[];
  citations: Record<string, Citation[]>;
  traces: Record<string, ToolTrace[]>;
  activities?: Record<string, import("../../src/run-timeline").RunActivity[]>;
}

export interface HealthStatus {
  ok: boolean;
  name: string;
  model: ModelReference | null;
  rag: {
    documents: number;
    version: string | null;
    graphVersion?: string | null;
    indexedAt: string | null;
    embeddingModel: string | null;
    embeddingDimensions: number | null;
    credentialConfigured: boolean;
    qualityQuarantined?: number;
  };
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const headers = new Headers(init?.headers);
  if (init?.body !== undefined && !headers.has("Content-Type")) {
    headers.set("Content-Type", "application/json");
  }
  const response = await fetch(path, {
    ...init,
    headers,
  });
  const payload = await response.json().catch(() => ({})) as T & { error?: string };
  if (!response.ok) throw new Error(payload.error ?? `请求失败：HTTP ${response.status}`);
  return payload;
}

export const api = {
  getProvenance: (conversationId: string, planId?: string) => request<ProvenanceGraph>(
    `/api/conversations/${encodeURIComponent(conversationId)}/provenance${planId ? `?planId=${encodeURIComponent(planId)}` : ""}`,
  ),
  getLiterature: (conversationId: string) => request<{ papers: UserPaper[]; latest: IdeationResult | null }>(
    `/api/conversations/${encodeURIComponent(conversationId)}/literature`,
  ),
  uploadLiterature: async (conversationId: string, file: File) => {
    const response = await fetch(`/api/conversations/${encodeURIComponent(conversationId)}/literature?name=${encodeURIComponent(file.name)}`, {
      method: "POST", headers: { "Content-Type": "application/octet-stream" }, body: file,
    });
    const payload = await response.json() as { paper?: UserPaper; duplicate?: boolean; error?: string };
    if (!response.ok || !payload.paper) throw new Error(payload.error ?? `PDF 上传失败：HTTP ${response.status}`);
    return { paper: payload.paper, duplicate: Boolean(payload.duplicate) };
  },
  generateIdeas: (conversationId: string, mode: IdeationMode, objective: string) => request<IdeationResult>(
    `/api/conversations/${encodeURIComponent(conversationId)}/ideas`,
    { method: "POST", body: JSON.stringify({ mode, objective }) },
  ),
  planIdea: (conversationId: string, ideaId: string, model: ModelReference) => request<{
    run: AgentRun; userNode: ConversationNode; eventsUrl: string;
  }>(`/api/conversations/${encodeURIComponent(conversationId)}/ideas/${encodeURIComponent(ideaId)}/plan`, {
    method: "POST", body: JSON.stringify({ model }),
  }),
  uploadRawData: async (conversationId: string, file: File) => {
    const response = await fetch(`/api/conversations/${encodeURIComponent(conversationId)}/uploads?name=${encodeURIComponent(file.name)}`, {
      method: "POST", headers: { "Content-Type": "application/octet-stream" }, body: file,
    });
    const result = await response.json() as { name?: string; path?: string; bytes?: number; error?: string };
    if (!response.ok || !result.path) throw new Error(result.error ?? `上传失败：HTTP ${response.status}`);
    return result as { name: string; path: string; bytes: number };
  },
  activateSstCase: (model: ModelReference | null) => request<{ conversationId: string; run: AgentRun; eventsUrl: string }>(
    "/api/research-cases/south-china-sea-sst/activate", {
      method: "POST", body: JSON.stringify({ model: model ?? undefined }),
    },
  ),
  health: () => request<HealthStatus>("/api/health"),
  getKnowledgeGraphStats: () => request<KnowledgeGraphStats>("/api/knowledge-graph/stats"),
  listKnowledgeCatalog: (perspective: KnowledgePerspective, query = "") => request<KnowledgeCatalogItem[]>(
    `/api/knowledge-graph/catalog?perspective=${encodeURIComponent(perspective)}&q=${encodeURIComponent(query)}&limit=5000`,
  ),
  getKnowledgeSubgraph: (perspective: KnowledgePerspective, focusId: string) => request<KnowledgeGraphResponse>(
    `/api/knowledge-graph/subgraph?perspective=${encodeURIComponent(perspective)}&focusId=${encodeURIComponent(focusId)}`,
  ),
  getModelSettings: () => request<ModelSettingsState>("/api/model-settings"),
  discoverProviderModels: (providerId: string, apiKey?: string) => request<ModelDiscoveryResult>(
    `/api/model-settings/providers/${encodeURIComponent(providerId)}/discover`,
    { method: "POST", body: JSON.stringify({ apiKey }) },
  ),
  saveProviderModels: (providerId: string, apiKey: string | undefined, modelIds: string[]) => request<ModelSettingsState>(
    `/api/model-settings/providers/${encodeURIComponent(providerId)}`,
    { method: "PUT", body: JSON.stringify({ apiKey, modelIds }) },
  ),
  setDefaultModel: (model: ModelReference) => request<ModelSettingsState>("/api/model-settings/default", {
    method: "PATCH", body: JSON.stringify({ model }),
  }),
  listProjects: () => request<ResearchProject[]>("/api/projects"),
  listRemoteConnections: () => request<RemoteConnectionProfile[]>("/api/remote-connections"),
  selectLocalDirectory: () => request<{ path: string | null }>("/api/system/select-directory", {
    method: "POST",
  }),
  createProject: (input: CreateResearchProjectInput) => request<ResearchProject>("/api/projects", {
    method: "POST",
    body: JSON.stringify(input),
  }),
  renameProject: (id: string, title: string) => request<ResearchProject>(`/api/projects/${id}`, {
    method: "PATCH",
    body: JSON.stringify({ title }),
  }),
  connectProject: (id: string, password: string) => request<ResearchProject>(`/api/projects/${id}/connect`, {
    method: "POST",
    body: JSON.stringify({ password }),
  }),
  deleteProject: (id: string) => request<void>(`/api/projects/${id}`, { method: "DELETE" }),
  listConversations: () => request<Conversation[]>("/api/conversations"),
  createConversation: (projectId: string, title?: string) => request<Conversation>("/api/conversations", {
    method: "POST",
    body: JSON.stringify({ projectId, title }),
  }),
  startConversation: (projectId: string, content: string, model: ModelReference) => request<{
    conversation: Conversation;
    run: AgentRun;
    userNode: ConversationNode;
    eventsUrl: string;
  }>(`/api/projects/${projectId}/messages`, {
    method: "POST",
    body: JSON.stringify({ content, model }),
  }),
  renameConversation: (id: string, title: string) => request<Conversation>(`/api/conversations/${id}`, {
    method: "PATCH",
    body: JSON.stringify({ title }),
  }),
  deleteConversation: (id: string) => request<void>(`/api/conversations/${id}`, { method: "DELETE" }),
  getConversation: (id: string) => request<ConversationDetail>(`/api/conversations/${id}`),
  setActiveNode: (conversationId: string, nodeId: string | null) => request<{ ok: boolean }>(
    `/api/conversations/${conversationId}/active-node`,
    { method: "POST", body: JSON.stringify({ nodeId }) },
  ),
  sendMessage: (conversationId: string, content: string, parentId: string | null, model: ModelReference) => request<{
    run: AgentRun;
    userNode: ConversationNode;
    plan?: ResearchPlan;
    executionQueued?: boolean;
    eventsUrl: string;
  }>(`/api/conversations/${conversationId}/messages`, {
    method: "POST",
    body: JSON.stringify({ content, parentId, model }),
  }),
  submitClarification: (
    conversationId: string,
    clarificationForNodeId: string,
    content: string,
    model: ModelReference,
  ) => request<{
    run: AgentRun;
    userNode: ConversationNode;
    plan?: ResearchPlan;
    executionQueued?: boolean;
    eventsUrl: string;
  }>(`/api/conversations/${conversationId}/messages`, {
    method: "POST",
    body: JSON.stringify({ content, parentId: clarificationForNodeId, clarificationForNodeId, model }),
  }),
  abortRun: (runId: string) => request<{ stopped: boolean }>(`/api/runs/${runId}/abort`, { method: "POST" }),
  approvePlan: (planId: string) => request<{
    plan: ResearchPlan;
    run: AgentRun;
    userNode: ConversationNode;
    eventsUrl: string;
    executionQueued: true;
    message: string;
  }>(
    `/api/plans/${planId}/approve`, { method: "POST" },
  ),
  rejectPlan: (planId: string) => request<{ plan: ResearchPlan }>(
    `/api/plans/${planId}/reject`, { method: "POST" },
  ),
};

const EVENT_TYPES: StreamEvent["type"][] = [
  "run.started",
  "run.progress",
  "message.delta",
  "message.completed",
  "tool.started",
  "tool.progress",
  "tool.completed",
  "citation.added",
  "clarification.requested",
  "plan.proposed",
  "plan.candidates",
  "plan.awaiting_approval",
  "run.settled",
  "run.error",
];

export function streamRun(
  url: string,
  onEvent: (event: StreamEvent) => void,
  onConnectionError: () => void,
): () => void {
  const source = new EventSource(url);
  let terminal = false;
  for (const type of EVENT_TYPES) {
    source.addEventListener(type, (raw) => {
      const message = raw as MessageEvent<string>;
      const event: StreamEvent = {
        id: Number(message.lastEventId) || undefined,
        runId: url.split("/").at(-2) ?? "",
        type,
        data: JSON.parse(message.data) as unknown,
        createdAt: new Date().toISOString(),
      };
      onEvent(event);
      if (type === "run.settled" || type === "run.error") {
        terminal = true;
        source.close();
      }
    });
  }
  source.onerror = () => {
    if (!terminal) onConnectionError();
  };
  return () => source.close();
}
