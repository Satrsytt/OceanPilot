import { useEffect, useMemo, useState } from "react";
import { api, type ProvenanceGraph } from "../api";
import type { ProvenanceMetric, ProvenanceNode } from "../../../src/provenance/types";
import { selectProvenanceView } from "../../../src/provenance/presentation";

const relationLabel: Record<string, string> = {
  retrieved: "检索返回", considered: "评估时考虑", supports: "显式证据关联",
  derived_from: "来源关联", selected_for_plan: "Plan 数据路线",
  executed_with: "执行记录", produced: "工具产物",
};
const sourceLabel: Record<string, string> = {
  global_knowledge_base: "Ocean-RAG 知识库", user_upload: "用户上传",
  external_search: "外部核验文献",
};
const statusLabel: Record<string, string> = {
  awaiting_approval: "待选择", approved: "已批准", executing: "执行中",
  completed: "已完成", partial: "部分完成", failed: "失败", rejected: "未选择",
  cancelled: "已取消", interrupted: "已中断", running: "运行中",
  parsed: "已解析", observed: "已观察", planned: "计划中",
};
const text = (value: unknown): string => typeof value === "string" && value.trim() ? value : "未知";
const titleSourceLabel: Record<string, string> = {
  pdf_metadata: "PDF 元数据", first_page: "首页抽取", extractor: "文档抽取",
  dual_extractor_agreement: "两种抽取结果一致",
  direct_full_text_and_official_record: "全文与官方记录一致",
  extractor_pdf_pdf_metadata_agreement: "文档抽取与 PDF 元数据一致",
  "card.paper_title": "知识卡明确记录",
};
const confidenceLabel: Record<string, string> = { high: "较高", medium: "中等", low: "较低，待核验" };
const metricText = (label: string, metric: ProvenanceMetric): string => metric.status === "confirmed"
  ? `${label} ${metric.count}` : `${label}：${metric.status === "not_recorded" ? "未记录" : "记录不足"}`;

function PaperDetail({ node, graph }: { node: ProvenanceNode; graph: ProvenanceGraph }) {
  const linked = graph.edges.filter((edge) => edge.from === node.id
    && ["derived_from", "supports", "considered"].includes(edge.relation));
  const byId = new Map(graph.nodes.map((item) => [item.id, item]));
  const authors = Array.isArray(node.metadata.authors) ? node.metadata.authors.join("、") : "";
  return <details className="provenance-node" key={node.id}>
    <summary>{node.label} <small>{sourceLabel[String(node.metadata.sourceType)] ?? "来源待核对"}</small></summary>
    <p>来源 ID：{node.sourceId} · 作者：{authors || "未收录"} · 年份：{String(node.metadata.year ?? "未收录")}</p>
    <p>DOI：{text(node.metadata.doi)} · 题名依据：
      {titleSourceLabel[String(node.metadata.titleSource)] ?? text(node.metadata.titleSource)}
      {Boolean(node.metadata.titleConfidence) && ` · 索引置信度：${confidenceLabel[String(node.metadata.titleConfidence)] ?? text(node.metadata.titleConfidence)}`}
    </p>
    {Boolean(node.metadata.filename) && <p>原始文件名：{String(node.metadata.filename)}</p>}
    {Boolean(node.metadata.unresolvedReason) && <p>未解析原因：{String(node.metadata.unresolvedReason)}</p>}
    {Boolean(node.metadata.url) && <a href={String(node.metadata.url)} target="_blank" rel="noreferrer">打开可靠来源</a>}
    {linked.length > 0 && <ul>{linked.map((edge) => <li key={edge.id}>
      {byId.get(edge.to)?.type === "ResearchIdea" ? "关联研究 Idea" : "关联知识卡"}：
      {byId.get(edge.to)?.label ?? edge.to} · {relationLabel[edge.relation]}
      {Array.isArray(edge.metadata?.sourceFields) && <small>来源字段：{edge.metadata.sourceFields.join("、")}</small>}
      {Array.isArray(edge.metadata?.sourceGroupIds) && edge.metadata.sourceGroupIds.length > 0
        && <small>来源组：{edge.metadata.sourceGroupIds.join("、")}</small>}
      {Array.isArray(edge.metadata?.locators) && edge.metadata.locators.length > 0
        && <small>原文定位：{edge.metadata.locators.join("；")}</small>}
    </li>)}</ul>}
    {Array.isArray(node.metadata.evidence) && (node.metadata.evidence as Array<{ id: string; page: number; text: string }>).slice(0, 6).map((item) =>
      <p key={item.id}>p.{item.page} · {item.text}</p>)}
  </details>;
}

export function ProvenancePanel({ conversationId, planIds, preferredPlanId, refreshKey }: {
  conversationId: string; planIds: string[]; preferredPlanId?: string; refreshKey?: string;
}) {
  const [open, setOpen] = useState(false);
  const [planId, setPlanId] = useState(preferredPlanId ?? "");
  const [focusId, setFocusId] = useState("");
  const [query, setQuery] = useState("");
  const [graph, setGraph] = useState<ProvenanceGraph | null>(null);
  const [error, setError] = useState("");
  useEffect(() => { setPlanId(preferredPlanId ?? ""); setFocusId(""); }, [conversationId, preferredPlanId]);
  useEffect(() => {
    if (!open) return;
    let active = true;
    api.getProvenance(conversationId, planId || undefined).then((value) => {
      if (active) { setGraph(value); setError(""); }
    }).catch((reason: unknown) => {
      if (active) { setGraph(null); setError(reason instanceof Error ? reason.message : String(reason)); }
    });
    return () => { active = false; };
  }, [conversationId, open, planId, refreshKey]);
  const view = useMemo(() => graph ? selectProvenanceView(graph, focusId) : null, [graph, focusId]);
  const byId = useMemo(() => new Map(view?.nodes.map((node) => [node.id, node]) ?? []), [view]);
  const searchChoices = graph?.nodes.filter((node) =>
    ["Paper", "UserPaper", "DatasetCard", "WorkflowStep"].includes(node.type)
      && node.metadata.titleStatus !== "missing"
      && `${node.label} ${node.sourceId}`.toLowerCase().includes(query.toLowerCase())).slice(0, 12) ?? [];
  const download = `/api/conversations/${encodeURIComponent(conversationId)}/provenance?download=1${planId ? `&planId=${encodeURIComponent(planId)}` : ""}`;
  const unresolved = graph?.unresolvedPaperSources.filter((item) => !focusId
    || view?.nodes.some((node) => node.id === `card:${item.cardId}`)) ?? [];
  const unresolvedIds = new Set(unresolved.map((item) => item.sourceId));

  return <section className="research-widget provenance-widget">
    <details open={open} onToggle={(event) => setOpen(event.currentTarget.open)}>
      <summary>科研依据与执行记录 <small>检索资料 · 方案依据 · 可核实执行</small></summary>
      <div className="provenance-content">
        <p className="provenance-note">展示已检索的科研资料、计划依据及可核实的执行记录。未记录的关系不代表未发生。</p>
        <div className="provenance-controls">
          <label>Plan <select value={planId} onChange={(event) => { setPlanId(event.target.value); setFocusId(""); }}>
            <option value="">所有 Plan</option>{planIds.map((id) => <option key={id} value={id}>{id.slice(0, 12)}</option>)}
          </select></label>
          <label>查找证据 <input type="search" value={query} onChange={(event) => setQuery(event.target.value)}
            placeholder="论文、数据集或步骤" /></label>
          <a href={download}>导出 JSON</a>
        </div>
        {query && <div className="provenance-search-results">{searchChoices.map((node) =>
          <button type="button" key={node.id} onClick={() => { setFocusId(node.id); setQuery(""); }}>
            {node.type} · {node.label}</button>)}
          {!searchChoices.length && <small>没有匹配的可识别记录</small>}
        </div>}
        {focusId && <button type="button" className="provenance-clear" onClick={() => setFocusId("")}>清除筛选</button>}
        {error && <p role="alert">记录读取失败：{error}</p>}
        {!graph && !error && <p>正在读取记录…</p>}
        {graph && view && <>
          <section className="provenance-stage">
            <h3>A. 检索参考资料</h3>
            <p>{metricText("PSC", graph.metrics.retrievedPsc)} · {metricText("UBC", graph.metrics.retrievedUbc)}</p>
            <p>{metricText("DatasetCard", graph.metrics.retrievedDatasetCards)}</p>
            {view.retrievedCards.length ? view.retrievedCards.map((node) =>
              <details className="provenance-node" key={node.id}><summary>{node.type} · {node.label}</summary>
                <p>卡片 ID：{node.sourceId}</p>
                {Boolean(node.metadata.summary) && <p>内容：{String(node.metadata.summary)}</p>}
                {Array.isArray(node.metadata.citations) && (node.metadata.citations as Array<{ id: string; locator: string | null; evidenceText: string | null }>).map((item) =>
                  <p key={item.id}>来源定位：{item.locator || "未收录"} · {item.evidenceText || "摘录未收录"}</p>)}
              </details>) : <p>当前范围没有可核实的卡片检索返回记录。</p>}
            {view.referencePapers.filter((node) => node.metadata.titleStatus !== "missing").map((node) =>
              <PaperDetail key={node.id} node={node} graph={graph} />)}
            {unresolvedIds.size > 0 && <details className="provenance-node"><summary>另有 {unresolvedIds.size} 条论文来源题名未收录</summary>
              <ul>{unresolved.map((item) => <li key={`${item.cardId}:${item.sourceField}:${item.sourceId}`}>
                {item.sourceId} · 卡片 {item.cardId} · {item.sourceField} · {item.reason}
              </li>)}</ul></details>}
          </section>
          <section className="provenance-stage">
            <h3>B. 方案依据</h3>
            {view.plans.length ? view.plans.map((node) => <p key={node.id}>
              Plan v{String(node.metadata.version ?? "?")} · {node.label} · {statusLabel[node.status ?? ""] ?? "状态未记录"}
            </p>) : <p>当前范围没有已生成的 Plan。</p>}
            {view.plannedDatasets.map((edge) => <p key={edge.id}>
              {byId.get(edge.to)?.status === "awaiting_approval" || byId.get(edge.to)?.status === "rejected"
                ? "候选数据路线" : "Plan 记录的数据产品"}：{byId.get(edge.from)?.label ?? edge.from}
            </p>)}
            {view.ideaLiterature.length > 0 && <>
              <p>Idea 关联文献（关联状态见各论文详情）：</p>
              {view.ideaLiterature.map((node) => <PaperDetail key={node.id} node={node} graph={graph} />)}
            </>}
            {graph.metrics.recordedKnowledgeCitations.status === "confirmed" ? <>
              <p>{metricText("已记录的知识引用", graph.metrics.recordedKnowledgeCitations)}</p>
              {view.planEvidence.map((edge) => <p key={edge.id}>
                {byId.get(edge.from)?.label ?? edge.from} → {byId.get(edge.to)?.label ?? edge.to}
                <small>证据 ID：{edge.evidenceRefs.join("、")}</small>
              </p>)}
            </> : <p>当前 Plan 未记录可核实的知识引用关系。</p>}
            {graph.metrics.knowledgeSupportedPlanSteps.status === "confirmed"
              && <p>{metricText("有显式证据关联的步骤", graph.metrics.knowledgeSupportedPlanSteps)}</p>}
          </section>
          <section className="provenance-stage">
            <h3>C. 执行与科研产物</h3>
            {view.toolCalls.length || view.observedDatasetReads.length || view.artifacts.length ? <>
              {view.toolCalls.map((node) => <details className="provenance-node" key={node.id}>
                <summary>{node.label} · {node.status === "completed" ? "成功" : node.status === "failed" ? "失败" : "状态未确认"}</summary>
                <p>工具调用 ID：{node.sourceId}</p><p>时间：{text(node.metadata.startedAt)} → {text(node.metadata.finishedAt)}</p>
                {Boolean(node.metadata.error) && <p>失败原因：{String(node.metadata.error)}</p>}
                <pre>参数：{JSON.stringify(node.metadata.args ?? {})}</pre>
              </details>)}
              {view.observedDatasetReads.map((edge) => <p key={edge.id}>已核实文件读取：{byId.get(edge.from)?.label ?? edge.from}
                {Boolean(edge.metadata?.sha256) && <small>SHA-256：{String(edge.metadata?.sha256)}</small>}
              </p>)}
              {view.artifacts.map((node) => <p key={node.id}>产物：{node.label}
                {Boolean(node.metadata.url) && <> · <a href={String(node.metadata.url)}>下载</a></>}
                <small>SHA-256：{text(node.metadata.sha256)}</small>
              </p>)}
            </> : <p>暂无可核实的执行记录。</p>}
            {graph.metrics.actualReadDatasetProducts.status === "confirmed"
              ? <p>{metricText("已核实成功读取的数据产品", graph.metrics.actualReadDatasetProducts)}</p>
              : <p>数据实际读取：{graph.metrics.actualReadDatasetProducts.status === "unknown"
                ? "现有日志不足以判断" : "未记录"}。计划列出数据集不代表已读取。</p>}
          </section>
          <details className="provenance-relations"><summary>查看原始关系（{view.edges.length}）</summary>
            <ul>{view.edges.map((edge) => <li key={edge.id}>
              {byId.get(edge.from)?.label ?? edge.from} → {relationLabel[edge.relation]} → {byId.get(edge.to)?.label ?? edge.to}
              <small>状态：{statusLabel[edge.status ?? ""] ?? "未标注"} · 证据 ID：{edge.evidenceRefs.join("、") || "未记录"}</small>
              {Array.isArray(edge.metadata?.locators) && edge.metadata.locators.length > 0
                && <small>定位：{edge.metadata.locators.join("；")}</small>}
            </li>)}</ul>
          </details>
          {graph.unknownRelations.length > 0 && <details><summary>无法确认的历史关系（{graph.unknownRelations.length}）</summary>
            <ul>{graph.unknownRelations.map((item) => <li key={item}>{item}</li>)}</ul></details>}
        </>}
      </div>
    </details>
  </section>;
}
