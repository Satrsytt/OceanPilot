import { useEffect, useMemo, useRef } from "react";
import { CheckCircle, CircleNotch, Database, ListChecks, WarningCircle, Robot } from "@phosphor-icons/react";
import type { ConversationDetail, HealthStatus, ResearchPlan } from "../api";
import { toolLabel, type ResearchActivity } from "../useOceanAgent";
import { shortText } from "../tree";
import { savedExecutionActivities } from "./execution-history";
import { runningSubagents } from "./subagent-activity";
import { ProvenancePanel } from "./ProvenancePanel";

interface EvidencePanelProps {
  detail: ConversationDetail | null;
  livePlan: ResearchPlan | null;
  activities: ResearchActivity[];
  busy: boolean;
  status: string;
  ragStatus: HealthStatus["rag"] | null;
  onPlanAction: (id: string, action: "approve" | "reject") => void;
}

const STATUS_LABEL: Record<ResearchPlan["status"], string> = {
  awaiting_approval: "规划待确认",
  approved: "执行准备中",
  rejected: "规划已暂停",
  executing: "执行中",
  completed: "已完成",
  partial: "部分完成，可继续",
  failed: "执行失败",
  cancelled: "已取消，可继续",
  interrupted: "运行中断，可继续",
};

function ProgressIcon({ status }: { status: ResearchActivity["status"] }) {
  if (status === "running") return <CircleNotch className="spin" />;
  if (status === "failed") return <WarningCircle weight="fill" />;
  return <CheckCircle weight="fill" />;
}

export function EvidencePanel({ detail, livePlan, activities: liveActivities, busy, status, ragStatus, onPlanAction }: EvidencePanelProps) {
  const endRef = useRef<HTMLDivElement>(null);
  const savedActivities = useMemo(() => savedExecutionActivities(detail), [detail]);
  const activities = busy ? liveActivities : savedActivities;
  const activeChildren = useMemo(() => runningSubagents(liveActivities, busy), [liveActivities, busy]);
  const latestRun = detail?.latestRun;
  const { plan, candidatePlans } = useMemo(() => {
    const stored = detail?.plans ?? [];
    const plans = livePlan ? [livePlan, ...stored.filter((item) => item.id !== livePlan.id)] : [...stored];
    plans.sort((a, b) => b.version - a.version);
    const group = plans[0]?.candidateGroupId;
    const candidatePlans = group ? plans.filter((item) => item.candidateGroupId === group)
      .sort((a, b) => (a.candidateRank ?? 99) - (b.candidateRank ?? 99)) : [];
    const plan = candidatePlans.find((item) => ["executing", "approved", "completed", "partial", "failed", "cancelled", "interrupted"].includes(item.status))
      ?? candidatePlans[0] ?? plans[0];
    return { plan, candidatePlans };
  }, [detail?.plans, livePlan]);
  const executionObserved = !!plan
    && plan.status === "awaiting_approval"
    && busy
    && activities.some((item) => ["bash", "powershell", "run_remote_command", "edit", "write"].includes(item.toolName ?? ""));
  const planning = !executionObserved && (candidatePlans.some((item) => item.status === "awaiting_approval")
    || plan?.status === "awaiting_approval" || plan?.status === "rejected");
  const phase = planning ? "规划阶段" : plan || busy || activities.length ? "执行阶段" : "科研状态";

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }, [activities]);

  return (
    <aside className="research-rail">
      <section className="research-assets">
        <header><div><span className="eyebrow">ASSETS</span><h2>科研资产</h2></div><i>{ragStatus ? (ragStatus.credentialConfigured ? "在线" : "待配置") : "连接中"}</i></header>
        <div className="asset-row"><span><Database weight="duotone" /></span><div><b>Ocean-RAG</b><small>{ragStatus?.documents ?? "—"} 条合格索引卡{ragStatus?.qualityQuarantined ? ` · 隔离 ${ragStatus.qualityQuarantined} 条` : ""}{ragStatus?.graphVersion ? ` · 图版本 ${ragStatus.graphVersion}` : ""} · {ragStatus?.credentialConfigured ? (ragStatus.embeddingModel ?? "向量索引") : "请配置阿里云模型"}</small></div></div>
        {activeChildren.length > 0 && <div className="active-subagents" aria-live="polite">
          <div className="active-subagents-title">正在运行的子智能体 <span>{activeChildren.length}</span></div>
          {activeChildren.map((child, index) => <details className="active-subagent" key={child.id}>
            <summary><Robot className={`subagent-color-${index % 3}`} weight="duotone" /><b>{child.name}</b><CircleNotch className="spin" /></summary>
            <p>{child.task}</p>
          </details>)}
        </div>}
      </section>
      <section className="research-widget">
        <header>
          <div><span className="eyebrow">RESEARCH</span><h2>{phase}</h2></div>
          <i className={busy ? "working" : ""}>{executionObserved ? "执行中" : plan ? STATUS_LABEL[plan.status] : status}</i>
        </header>

        {planning && candidatePlans.length ? (
          <div className="widget-plan candidate-plan-list">
            <p className="widget-note">{candidatePlans.some((candidate) => candidate.status === "awaiting_approval")
              ? `${candidatePlans.length} 条通过检查的科研路线，请选择一条执行。`
              : "这组科研路线已暂停，可在对话中说明修改要求。"}</p>
            {candidatePlans.map((candidate) => <section className="plan-candidate" key={candidate.id}>
              <div className="widget-plan-title"><ListChecks /><div><small>PLAN {candidate.candidateRank} · V{candidate.version} · {candidate.id.slice(0, 8)}</small><b>{candidate.title ?? candidate.objective}</b></div></div>
              <p>{candidate.objective}</p>
              <small>数据：{candidate.datasets.map((id) => `${id}${candidate.datasetRoles?.[id] ? `（${candidate.datasetRoles[id]}）` : ""}`).join("、") || "无"} · 方法：{candidate.methodFamily} · 侧重点：{candidate.scientificFocus}</small>
              <ol>{candidate.steps.map((step) => <li key={step.id}><span>{step.id}</span><div><b>{step.title}</b><small>{shortText(step.description, 68)}</small></div></li>)}</ol>
              <p className="widget-note">资源：{candidate.estimatedCost ?? "待估计"}</p>
              <p className="widget-note">优势：{candidate.tradeoffs?.advantages.join("；") || "—"}</p>
              <p className="widget-note">风险：{candidate.tradeoffs?.risks.join("；") || "—"}</p>
              {candidate.status === "awaiting_approval" && <div className="widget-actions">
                <button type="button" onClick={() => onPlanAction(candidate.id, "reject")}>暂不选择</button>
                <button className="primary" type="button" onClick={() => onPlanAction(candidate.id, "approve")}>选择并执行</button>
              </div>}
            </section>)}
          </div>
        ) : planning && plan ? (
          <div className="widget-plan">
            <div className="widget-plan-title"><ListChecks /><div><small>PLAN · V{plan.version}</small><b>{plan.objective}</b></div></div>
            <ol>
              {plan.steps.map((step) => (
                <li key={step.id}><span>{step.id}</span><div><b>{step.title}</b><small>{shortText(step.description, 68)}</small></div></li>
              ))}
            </ol>
            {plan.status === "awaiting_approval" && (
              <div className="widget-actions">
                <button type="button" onClick={() => onPlanAction(plan.id, "reject")}>暂不执行</button>
                <button className="primary" type="button" onClick={() => onPlanAction(plan.id, "approve")}>确认并执行</button>
              </div>
            )}
            {plan.status === "rejected" && <p className="widget-note">规划已暂停，你可以在对话中提出修改意见。</p>}
          </div>
        ) : (
          <div className="widget-progress">
            {!busy && plan && ["partial", "failed", "interrupted", "cancelled"].includes(plan.status) && (
              <div className="widget-plan">
                <p className="widget-note">{STATUS_LABEL[plan.status]}。在本会话发送“继续”可检查缓存和现有产物后恢复。</p>
                {typeof latestRun?.checkpoint?.progress === "string" && (
                  <p className="widget-note">最后检查点：{String(latestRun?.checkpoint?.progress)}</p>
                )}
                {latestRun?.error && <p className="widget-note">终止原因：{latestRun.error}</p>}
                <details><summary>尚未通过最终核验的规划步骤</summary>
                  <ol>{plan.steps.map((step) => <li key={step.id}>{step.title}</li>)}</ol>
                </details>
              </div>
            )}
            {activities.length ? activities.map((item) => (
              <div className={`widget-progress-item ${item.status}`} key={item.id}>
                <ProgressIcon status={item.status} />
                <div><b>{item.kind !== "tool" ? shortText(item.text ?? "阶段说明", 52) : toolLabel(item.toolName ?? "工具")}</b>{item.detail && <small>{shortText(item.detail, 52)}</small>}</div>
              </div>
            )) : (
              <div className="widget-empty"><ListChecks /><p>{plan ? STATUS_LABEL[plan.status] : "发送问题后，这里会显示规划或执行进度。"}</p></div>
            )}
            <div ref={endRef} />
          </div>
        )}
      </section>
      {detail && <ProvenancePanel conversationId={detail.conversation.id}
        planIds={detail.plans.map((item) => item.id)}
        preferredPlanId={plan && !["awaiting_approval", "rejected"].includes(plan.status) ? plan.id : undefined}
        refreshKey={`${detail.latestRun?.id ?? ""}:${detail.latestRun?.status ?? ""}:${detail.plans.map((item) => item.status).join(",")}`} />}
    </aside>
  );
}
