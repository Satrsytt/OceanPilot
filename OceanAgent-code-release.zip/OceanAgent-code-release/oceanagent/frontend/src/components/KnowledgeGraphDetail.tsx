import { ArrowRight, GitBranch, LinkSimple, WarningCircle } from "@phosphor-icons/react";
import type { KnowledgeGraphNode } from "../../../src/contracts";
import type { KnowledgeGraphResponse, KnowledgePerspective } from "../api";

type JsonObject = Record<string, unknown>;

function object(value: unknown): JsonObject {
  return value && typeof value === "object" && !Array.isArray(value) ? value as JsonObject : {};
}

function objects(value: unknown): JsonObject[] {
  return Array.isArray(value) ? value.map(object).filter((item) => Object.keys(item).length > 0) : [];
}

function values(value: unknown): string[] {
  if (!Array.isArray(value)) return [];
  return value.map((item) => typeof item === "string" ? item : JSON.stringify(item) ?? "").filter((item) => item.length > 0);
}

function display(value: unknown, fallback = "未记录"): string {
  if (typeof value === "string" || typeof value === "number") {
    const result = String(value).trim();
    return result && !/(unresolved|pending_web_search)/i.test(result) ? result : fallback;
  }
  if (Array.isArray(value)) return values(value).join("、") || fallback;
  if (value && typeof value === "object") {
    const result = Object.entries(value as JsonObject)
      .map(([key, nested]) => `${key}: ${display(nested, "—")}`)
      .join("；");
    return result || fallback;
  }
  return fallback;
}

function EvidenceList({ evidence }: { evidence: unknown }) {
  const items = objects(evidence);
  if (items.length === 0) return null;
  return (
    <div className="knowledge-evidence-list">
      {items.slice(0, 5).map((item, index) => (
        <blockquote key={`${display(item.source_id)}-${index}`}>
          <span>{display(item.page_or_section, display(item.source_id))}</span>
          <p>{display(item.quote)}</p>
        </blockquote>
      ))}
      {items.length > 5 && <small>另有 {items.length - 5} 条原文证据</small>}
    </div>
  );
}

function ProblemDetail({ value }: { value: JsonObject }) {
  const field = object(value.research_field);
  return (
    <>
      <section className="knowledge-detail-section">
        <h3>研究问题</h3>
        <p className="detail-lead">{display(value.problem)}</p>
      </section>
      <section className="knowledge-detail-section">
        <h3>解决方案摘要</h3>
        <p>{display(value.solution_summary)}</p>
      </section>
      <section className="knowledge-detail-section compact">
        <h3>规范字段</h3>
        <dl>
          <div><dt>卡片 ID</dt><dd>{display(value.card_id)}</dd></div>
          <div><dt>论文 ID</dt><dd>{display(value.paper_id)}</dd></div>
          <div><dt>研究领域</dt><dd>{[display(field.primary, ""), ...values(field.secondary)].filter(Boolean).join(" / ") || "未记录"}</dd></div>
          <div><dt>Bundle ID</dt><dd>{display(value.bundle_id)}</dd></div>
        </dl>
      </section>
      <section className="knowledge-detail-section">
        <h3>原文证据</h3>
        <EvidenceList evidence={value.evidence} />
      </section>
    </>
  );
}

function PlanDetail({ value }: { value: JsonObject }) {
  const steps = objects(value.steps);
  const usages = objects(value.data_usages);
  const relations = objects(value.data_relations);
  const validations = objects(value.validation);
  return (
    <>
      <section className="knowledge-detail-section compact">
        <h3>实验用法包</h3>
        <dl>
          <div><dt>Bundle ID</dt><dd>{display(value.bundle_id)}</dd></div>
          <div><dt>步骤</dt><dd>{steps.length}</dd></div>
          <div><dt>数据用法</dt><dd>{usages.length}</dd></div>
          <div><dt>数据关系</dt><dd>{relations.length}</dd></div>
        </dl>
      </section>
      <section className="knowledge-detail-section">
        <h3>实验 Plan（DAG）</h3>
        <ol className="detail-plan-list">
          {steps.map((step, index) => (
            <li key={display(step.step_id, String(index))}>
              <span>{index + 1}</span>
              <div>
                <b>{display(step.action)}</b>
                <p>输出：{display(step.output)}</p>
                {values(step.depends_on_step_ids).length > 0 && <small>依赖：{values(step.depends_on_step_ids).join("、")}</small>}
                <EvidenceList evidence={step.evidence} />
              </div>
            </li>
          ))}
          {steps.length === 0 && <p className="knowledge-empty-copy">未记录实验步骤</p>}
        </ol>
      </section>
      <section className="knowledge-detail-section">
        <h3>数据用法</h3>
        <div className="detail-usage-list">
          {usages.map((usage, index) => (
            <article key={display(usage.usage_id, String(index))}>
              <b>{display(usage.dataset_id)}</b>
              <span>{display(usage.role, "实验数据")}</span>
              <p>{display(usage.fields, "未记录字段")}</p>
              <small>{display(object(usage.subset).temporal, "未记录时间范围")}</small>
            </article>
          ))}
        </div>
      </section>
      {validations.length > 0 && (
        <section className="knowledge-detail-section">
          <h3>验证方式</h3>
          {validations.map((item, index) => (
            <div className="detail-validation" key={`${display(item.target)}-${index}`}>
              <b>{display(item.target)}</b>
              <p>{display(item.metric)} · {display(item.criterion, "未设置判据")}</p>
            </div>
          ))}
        </section>
      )}
      {relations.length > 0 && (
        <section className="knowledge-detail-section">
          <h3>数据关系</h3>
          {relations.map((item, index) => (
            <div className="detail-relation" key={`${display(item.from_usage_id)}-${index}`}>
              <b>{display(item.from_usage_id)} <ArrowRight /> {display(item.to_usage_id)}</b>
              <p>{display(item.relation)}：{display(item.reason)}</p>
            </div>
          ))}
        </section>
      )}
    </>
  );
}

function DatasetDetail({ value }: { value: JsonObject }) {
  const fields = objects(value.fields);
  const access = objects(value.access);
  const contexts = objects(value.usage_contexts ?? value.selected_dataset_usages);
  return (
    <>
      <section className="knowledge-detail-section">
        <h3>数据集说明</h3>
        <p className="detail-lead">{display(value.description)}</p>
      </section>
      <section className="knowledge-detail-section compact">
        <h3>实体档案</h3>
        <dl>
          <div><dt>Dataset ID</dt><dd>{display(value.dataset_id)}</dd></div>
          <div><dt>产品 ID</dt><dd>{display(value.product_id)}</dd></div>
          <div><dt>提供方</dt><dd>{display(value.provider)}</dd></div>
          <div><dt>版本</dt><dd>{display(value.version)}</dd></div>
          <div><dt>覆盖范围</dt><dd>{display(value.coverage)}</dd></div>
          <div><dt>分辨率</dt><dd>{display(value.resolution)}</dd></div>
          <div><dt>公开状态</dt><dd>{display(value.public_availability)}</dd></div>
        </dl>
      </section>
      {contexts.length > 0 && (
        <section className="knowledge-detail-section">
          <h3>在本论文中的用法</h3>
          {contexts.map((usage, index) => (
            <div className="detail-validation" key={`${display(usage.usage_id)}-${index}`}>
              <b>{display(usage.role, "实验数据")}</b>
              <p>{display(usage.fields, "未记录字段")}</p>
            </div>
          ))}
        </section>
      )}
      <section className="knowledge-detail-section">
        <h3>变量 / 字段</h3>
        <div className="detail-field-list">
          {fields.slice(0, 20).map((field, index) => (
            <div key={`${display(field.raw_name)}-${index}`}><b>{display(field.raw_name)}</b><span>{display(field.description)}</span><small>{display(field.unit, "单位未记录")}</small></div>
          ))}
          {fields.length === 0 && <p className="knowledge-empty-copy">未记录字段</p>}
        </div>
      </section>
      {access.length > 0 && (
        <section className="knowledge-detail-section">
          <h3>访问方式</h3>
          {access.map((item, index) => {
            const url = display(item.url, "");
            return url.startsWith("http") ? <a className="detail-access-link" key={`${url}-${index}`} href={url} target="_blank" rel="noreferrer"><LinkSimple />{display(item.type, "数据入口")}</a> : null;
          })}
        </section>
      )}
      {values(value.warnings).length > 0 && (
        <section className="knowledge-detail-section detail-warnings">
          <h3><WarningCircle /> 数据提示</h3>
          {values(value.warnings).map((item) => <p key={item}>{item}</p>)}
        </section>
      )}
    </>
  );
}

export function KnowledgeGraphDetail(props: {
  node: KnowledgeGraphNode | null;
  graph: KnowledgeGraphResponse;
  perspective: KnowledgePerspective;
  onOpenPaper: (paperId: string) => void;
  onOpenPlan: (paperId: string) => void;
  onOpenNormative: (paperId: string) => void;
}) {
  const node = props.node;
  if (!node) return <aside className="knowledge-detail"><div className="knowledge-detail-empty"><GitBranch /><p>点击图谱节点查看详细知识</p></div></aside>;
  const problem = object(node.payload.problem_card);
  const publicationQuality = object(node.payload.publication_quality);
  const typeLabel = node.type === "paper" ? "论文" : node.type === "problem_solution" ? "论文方案" : node.type === "usage_bundle" ? "实验用法包" : node.type === "dataset" ? "数据集" : node.type === "step" ? "流程步骤" : node.type === "scientific_variable" ? "科学变量" : node.type === "experiment_setting" ? "实验设置" : node.type === "evaluation_metric" ? "评估指标" : "概念与用途";
  return (
    <aside className="knowledge-detail">
      <header>
        <span className={`detail-type type-${node.type}`}>{typeLabel}</span>
        <h2>{node.title}</h2>
        <p>{node.subtitle}</p>
        <code>{node.entityId}</code>
        {props.perspective !== "paper" && node.type === "paper" && <button className="open-paper-button" type="button" onClick={() => props.onOpenPaper(node.entityId)}>以这篇论文为中心展开图谱 <ArrowRight /></button>}
      </header>
      <div className="knowledge-detail-scroll">
        {node.type === "paper" && (
          <>
            <section className="knowledge-detail-section compact paper-archive">
              <h3>论文档案</h3>
              <dl>
                <div><dt>论文编号</dt><dd>{display(node.payload.paper_id)}</dd></div>
                <div><dt>收录集合</dt><dd>{display(node.payload.collection)}</dd></div>
                <div><dt>年份</dt><dd>{display(node.payload.year)}</dd></div>
                <div><dt>源文件</dt><dd>{display(node.payload.relative_path, display(node.payload.filename))}</dd></div>
                <div><dt>发布质量</dt><dd>{publicationQuality.status === "publish_ready" ? "已通过发布门禁" : "历史卡待补全"}</dd></div>
              </dl>
            </section>
            {values(publicationQuality.blockers).length > 0 && <section className="knowledge-detail-section detail-warnings"><h3><WarningCircle /> 门禁阻塞项</h3>{values(publicationQuality.blockers).slice(0, 12).map((item) => <p key={item}>{item}</p>)}</section>}
            <section className="knowledge-detail-section">
              <h3>内容摘要</h3>
              <p className="detail-lead">{display(problem.problem)}</p>
              <p>{display(problem.solution_summary)}</p>
            </section>
            <section className="paper-detail-actions">
              <button type="button" onClick={() => props.onOpenPlan(node.entityId)}>查看问题与实验 Plan <ArrowRight /></button>
              <button type="button" onClick={() => props.onOpenNormative(node.entityId)}>检查三层规范知识卡 <ArrowRight /></button>
            </section>
          </>
        )}
        {node.type === "problem_solution" && <ProblemDetail value={node.payload} />}
        {node.type === "usage_bundle" && <PlanDetail value={node.payload} />}
        {node.type === "dataset" && <DatasetDetail value={node.payload} />}
        {node.type === "step" && (
          <section className="knowledge-detail-section">
            <h3>Plan 步骤详情</h3>
            <p className="detail-lead">{display(node.payload.action)}</p>
            <dl>
              <div><dt>输出</dt><dd>{display(node.payload.output)}</dd></div>
              <div><dt>依赖</dt><dd>{display(node.payload.depends_on_step_ids, "无前置依赖")}</dd></div>
              <div><dt>输入用法</dt><dd>{display(node.payload.input_usage_ids)}</dd></div>
              <div><dt>推断状态</dt><dd>{display(node.payload.inference_status)}</dd></div>
            </dl>
            <EvidenceList evidence={node.payload.evidence} />
          </section>
        )}
        {node.type === "scientific_variable" && (
          <section className="knowledge-detail-section compact"><h3>科学变量</h3><dl><div><dt>变量名</dt><dd>{display(node.payload.name, node.title)}</dd></div><div><dt>关联数据集</dt><dd>{display(node.payload.dataset_ids)}</dd></div><div><dt>数据用法 ID</dt><dd>{display(node.payload.usage_ids)}</dd></div><div><dt>使用论文数</dt><dd>{display(node.payload.paper_count)}</dd></div></dl></section>
        )}
        {node.type === "experiment_setting" && (
          <section className="knowledge-detail-section compact"><h3>实验设置</h3><dl><div><dt>类别</dt><dd>{display(node.payload.category)}</dd></div><div><dt>设置值</dt><dd>{display(node.payload.value)}</dd></div><div><dt>来源用法</dt><dd>{display(node.payload.usageId)}</dd></div></dl></section>
        )}
        {node.type === "evaluation_metric" && (
          <section className="knowledge-detail-section"><h3>评估指标</h3><dl><div><dt>目标</dt><dd>{display(node.payload.target)}</dd></div><div><dt>指标</dt><dd>{display(node.payload.metric)}</dd></div><div><dt>判据</dt><dd>{display(node.payload.criterion)}</dd></div></dl><EvidenceList evidence={node.payload.evidence} /></section>
        )}
        {node.type === "concept" && (
          <section className="knowledge-detail-section compact"><h3>概念与用途</h3><dl><div><dt>类别</dt><dd>{display(node.payload.category)}</dd></div><div><dt>值</dt><dd>{display(node.payload.value, node.title)}</dd></div><div><dt>关联论文数</dt><dd>{display(node.payload.paper_count)}</dd></div></dl></section>
        )}
      </div>
    </aside>
  );
}
