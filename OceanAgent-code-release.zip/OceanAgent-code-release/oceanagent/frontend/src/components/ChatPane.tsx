import { useEffect, useMemo, useRef, useState } from "react";
import { api } from "../api";
import type { Citation, ConfiguredModel, ConversationDetail, IdeationMode, IdeationResult, ModelReference, UserPaper } from "../api";
import type { ResearchActivity } from "../useOceanAgent";
import { activeBranch } from "../tree";
import { ClarificationDock, clarificationAction } from "./ClarificationDock";
import { MessageCard } from "./MessageCard";
import { ResearchTrace } from "./ResearchTrace";

interface ChatPaneProps {
  detail: ConversationDetail | null;
  draftProjectTitle?: string;
  streamingText: string;
  activities: ResearchActivity[];
  liveCitations: Citation[];
  status: string;
  busy: boolean;
  error: string | null;
  models: ConfiguredModel[];
  selectedModel: ModelReference | null;
  onModelChange: (model: ModelReference) => void;
  onSend: (content: string) => void;
  onSstCase: () => Promise<void>;
  onClarify: (nodeId: string, content: string) => void;
  onAbort: () => void;
  onCreateLiteratureConversation: () => Promise<void>;
  onIdeaPlan: (ideaId: string) => Promise<void>;
}

const SUGGESTIONS = [
  "评估西北太平洋热带气旋路径预报所需的数据与方法",
  "为南海叶绿素浓度反演设计一套可执行的研究方案",
  "南海海表温度与异常分析 · 查看方案并执行",
];

export function ChatPane(props: ChatPaneProps) {
  const [draft, setDraft] = useState("");
  const [caseLoading, setCaseLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [papers, setPapers] = useState<UserPaper[]>([]);
  const [ideation, setIdeation] = useState<IdeationResult | null>(null);
  const [ideationMode, setIdeationMode] = useState<IdeationMode>("L1");
  const [ideaObjective, setIdeaObjective] = useState("");
  const [literatureBusy, setLiteratureBusy] = useState(false);
  const [literatureError, setLiteratureError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const literatureInputRef = useRef<HTMLInputElement>(null);
  const endRef = useRef<HTMLDivElement>(null);
  const canCompose = Boolean(props.detail || props.draftProjectTitle);
  // Paper experiments retain their original backend; engineering Idea UX lives in main.
  const showEngineeringIdeation = import.meta.env.VITE_OCEAN_PROJECT_ROLE === "engineering";
  useEffect(() => {
    const conversationId = props.detail?.conversation.id;
    setPapers([]);
    setIdeation(null);
    setLiteratureError(null);
    if (!conversationId) return;
    void api.getLiterature(conversationId).then((result) => {
      setPapers(result.papers);
      setIdeation(result.latest);
    }).catch((error) => setLiteratureError(error instanceof Error ? error.message : String(error)));
  }, [props.detail?.conversation.id]);
  const branch = useMemo(
    () => activeBranch(props.detail?.nodes ?? [], props.detail?.conversation.activeNodeId ?? null),
    [props.detail],
  );
  const answeredClarifications = useMemo(() => {
    const byId = new Map(branch.map((node) => [node.id, node]));
    const answered = new Set<string>();
    for (const node of branch) {
      if (node.metadata.uiHidden === true && typeof node.metadata.clarificationForNodeId === "string") {
        answered.add(String(node.metadata.clarificationForNodeId));
      }
      if (node.role === "user" && node.parentId && byId.get(node.parentId)?.kind === "clarification") {
        answered.add(node.parentId);
      }
    }
    return answered;
  }, [branch]);
  const visibleBranch = useMemo(() => branch.filter((node) => node.metadata.uiHidden !== true), [branch]);
  const pendingClarification = useMemo(() => [...branch].reverse().find((node) => (
    node.kind === "clarification"
    && !answeredClarifications.has(node.id)
    && Boolean(clarificationAction(node))
  )) ?? null, [answeredClarifications, branch]);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [visibleBranch.length, props.streamingText, props.activities.length, props.liveCitations.length]);

  const send = (value = draft) => {
    const content = value.trim();
    if (!content || props.busy || !canCompose || pendingClarification) return;
    props.onSend(content);
    setDraft("");
  };

  const upload = async (file: File) => {
    if (!props.detail || props.busy) return;
    setUploading(true);
    setUploadError(null);
    try {
      const result = await api.uploadRawData(props.detail.conversation.id, file);
      props.onSend(`已上传原始数据 ${result.name}（${result.bytes} 字节），项目文件路径：${result.path}。请先核对文件内容、时间覆盖、变量和质量，再根据真实数据与官方来源重新提出 Plan。`);
    } catch (error) {
      setUploadError(error instanceof Error ? error.message : String(error));
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };

  const uploadPapers = async (files: FileList | null) => {
    if (!props.detail || !files?.length || props.busy) return;
    setLiteratureBusy(true);
    setLiteratureError(null);
    try {
      const errors: string[] = [];
      for (const file of Array.from(files)) {
        try {
          const result = await api.uploadLiterature(props.detail.conversation.id, file);
          setPapers((items) => items.some((item) => item.id === result.paper.id)
            ? items.map((item) => item.id === result.paper.id ? result.paper : item)
            : [...items, result.paper]);
        } catch (error) {
          errors.push(`${file.name}: ${error instanceof Error ? error.message : String(error)}`);
        }
      }
      if (errors.length) setLiteratureError(errors.join("；"));
      setIdeation(null);
    } finally {
      setLiteratureBusy(false);
      if (literatureInputRef.current) literatureInputRef.current.value = "";
    }
  };

  const exploreIdeas = async () => {
    if (!props.detail || literatureBusy || props.busy) return;
    setLiteratureBusy(true);
    setLiteratureError(null);
    try {
      setIdeation(await api.generateIdeas(props.detail.conversation.id, ideationMode, ideaObjective));
    } catch (error) {
      setLiteratureError(error instanceof Error ? error.message : String(error));
    } finally {
      setLiteratureBusy(false);
    }
  };

  return (
    <main className="chat-pane">
      <header className="chat-header">
        <div>
          <span className="eyebrow">ACTIVE RESEARCH</span>
          <h1>{props.detail?.conversation.title ?? (props.draftProjectTitle ? `新会话 · ${props.draftProjectTitle}` : "从项目的 ··· 菜单中新建会话")}</h1>
        </div>
        <div className={`run-pill ${props.busy ? "working" : ""}`}>
          <span />{props.status}
        </div>
      </header>

      <section className="message-scroll">
        {showEngineeringIdeation && <details className="literature-workbench">
          <summary>用户论文库与 L1/L2/L3 Idea 探索 {papers.length ? `· ${papers.length} 篇` : ""}</summary>
          {!props.detail && props.draftProjectTitle && <button type="button" onClick={() => void props.onCreateLiteratureConversation()}>创建论文工作空间</button>}
          {props.detail && <>
            <div className="literature-controls">
              <input ref={literatureInputRef} type="file" accept="application/pdf,.pdf" multiple aria-label="批量上传论文 PDF"
                onChange={(event) => void uploadPapers(event.target.files)} />
              <select value={ideationMode} onChange={(event) => setIdeationMode(event.target.value as IdeationMode)} aria-label="Idea 模式">
                <option value="L1">L1 目标引导</option><option value="L2">L2 论文自主探索</option><option value="L3">L3 联网扩展</option>
              </select>
              <input value={ideaObjective} onChange={(event) => setIdeaObjective(event.target.value)}
                placeholder={ideationMode === "L2" ? "可选研究目标" : "研究目标或研究 Prompt"} aria-label="研究目标" />
              <button type="button" disabled={literatureBusy || props.busy || !papers.some((paper) => paper.status === "parsed")}
                onClick={() => void exploreIdeas()}>{literatureBusy ? "处理中…" : "探索 Idea"}</button>
            </div>
            {ideationMode === "L3" && <p>选择 L3 即授权本次联网检索相关文献，并仅保留可核验 DOI 元数据。</p>}
            {literatureError && <p className="literature-error">{literatureError}</p>}
            {papers.map((paper) => <details key={paper.id} className="literature-paper">
              <summary>{paper.title ?? paper.filename} · {paper.status === "parsed" ? "已解析" : "解析失败"}</summary>
              {paper.failureReason && <p>{paper.failureReason}</p>}
              <p>{paper.authors.join("、") || "作者未核实"} · {paper.year ?? "年份未核实"} · {paper.doi ?? "DOI 未核实"}</p>
              <p>摘要：{paper.abstract ?? "未能可靠定位"}</p>
              <p>研究目标：{paper.understanding?.researchGoals.map((item) => item.text).join("；") || "未可靠定位"}</p>
              <p>方法：{paper.understanding?.methods.map((item) => item.text).join("；") || "未可靠定位"}</p>
              <p>明确命名的数据产品：{paper.understanding?.dataProducts.map((item) => item.name).join("、") || "未可靠识别"}</p>
              <p>作者限制：{paper.understanding?.limitations.map((item) => item.text).join("；") || "未可靠定位"}</p>
              <p>待探索问题：{paper.understanding?.openQuestions.map((item) => item.text).join("；") || "未可靠定位"}</p>
              {paper.uncertainties.map((item) => <p key={item}>不确定：{item}</p>)}
              {paper.evidence.slice(0, 8).map((item) => <p key={item.id}>第 {item.page} 页 · {item.section} · 原文片段：{item.text}</p>)}
            </details>)}
            {ideation && <div className="literature-ideas">
              <p>主题：{ideation.themeSummary} · 外部检索：{ideation.externalSearchStatus}</p>
              {ideation.externalLiterature.map((item) => <p key={item.id}>核验外部文献：<a href={item.url} target="_blank" rel="noreferrer">{item.title}</a>
                {item.year ? `（${item.year}）` : ""} · DOI {item.doi} · 仅核验元数据</p>)}
              {ideation.gaps.map((gap) => <p key={gap}>缺口：{gap}</p>)}
              {ideation.ideas.map((idea) => <details key={idea.ideaId} className="literature-idea">
                <summary>{idea.title} · {idea.planStatus === "ready_for_planning" ? "可继续规划" : "需补充数据"}</summary>
                <p>标注：原文片段为论文明确文本；科学假设、比较和空白判断为系统推断。研究问题来源：{idea.claimProvenance?.researchQuestion === "user_goal" ? "用户目标" : "系统推断"}。</p>
                <p>问题：{idea.researchQuestion}</p><p>待检验假设：{idea.scientificHypothesis}</p>
                <p>相关工作：{idea.relatedWorkComparison}</p><p>研究空白假设：{idea.researchGapHypothesis}</p>
                <p>预期贡献：{idea.expectedContribution}</p>
                <p>必要数据：{idea.essentialDataRequirements.map((item) => item.variable).join("、") || "尚未明确"}</p>
                <p>方法：{idea.proposedMethod}</p><p>预期产物：{idea.expectedArtifacts.join("、")}</p>
                {Object.entries(idea.feasibilityAssessment).map(([name, item]) =>
                  <p key={name}>{name} · {item.status}：{item.reason} 不确定性：{item.uncertainty}</p>)}
                <div>证据：{idea.evidenceRefs.map((ref) => {
                  const citation = papers.flatMap((paper) => paper.evidence).find((item) => item.id === ref);
                  return citation ? <p key={ref}>{citation.paperId} · 第 {citation.page} 页 · 原文：{citation.text}</p>
                    : <p key={ref}><a href={ref} target="_blank" rel="noreferrer">{ref}</a> · DOI 元数据已核验，全文论点未核验</p>;
                })}</div>
                {idea.limitations.map((item) => <p key={item}>{item}</p>)}
                <button type="button" disabled={props.busy || !props.selectedModel || idea.planStatus !== "ready_for_planning"}
                  onClick={() => void props.onIdeaPlan(idea.ideaId)}>生成候选 Plan</button>
              </details>)}
            </div>}
          </>}
        </details>}
        {visibleBranch.length === 0 ? (
          <div className="welcome-state">
            <div className="welcome-orbit"><span>O</span></div>
            <p className="eyebrow">OCEAN INTELLIGENCE</p>
            <h2>从一个海洋科学问题开始</h2>
            <p>我会判断任务复杂度，按需检索 Ocean-RAG 与联网资料；复杂科研任务会先生成计划，等你确认后再执行。</p>
            <div className="suggestion-grid">
              {SUGGESTIONS.map((item, index) => (
                <button key={item} type="button" disabled={props.busy || caseLoading || (index !== 2 && !canCompose)} onClick={() => {
                  if (index !== 2) { send(item); return; }
                  setCaseLoading(true);
                  void props.onSstCase().finally(() => setCaseLoading(false));
                }}>
                  <i>{index === 2 ? "案例" : `0${index + 1}`}</i><span>{index === 2 && caseLoading ? "正在检查案例数据…" : item}</span><b>↗</b>
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="message-stack">
            {visibleBranch.map((node) => (
              <MessageCard
                key={node.id}
                node={node}
                citations={props.detail?.citations[node.id]}
                traces={props.detail?.traces[node.id]}
                activities={props.detail?.activities?.[node.id]}
              />
            ))}
            {props.busy && (
              <article className="message-row assistant-row streaming-row">
                <div className="avatar ocean-avatar">O</div>
                <div className="assistant-message">
                  <div className="message-author"><b>OceanAgent</b><span className="thinking">正在研究</span></div>
                  <ResearchTrace activities={props.activities} citations={props.liveCitations} live />
                </div>
              </article>
            )}
          </div>
        )}
        <div ref={endRef} />
      </section>

      <footer className="composer-wrap">
        {props.error && <div className="error-banner">{props.error}</div>}
        {uploadError && <div className="error-banner">{uploadError}</div>}
        {pendingClarification && (
          <ClarificationDock
            key={pendingClarification.id}
            node={pendingClarification}
            onSubmit={props.onClarify}
          />
        )}
        <div className="composer">
          <textarea
            value={draft}
            disabled={props.busy || !canCompose || Boolean(pendingClarification)}
            onChange={(event) => setDraft(event.target.value)}
            onKeyDown={(event) => {
              if (event.key === "Enter" && !event.shiftKey) {
                event.preventDefault();
                send();
              }
            }}
            placeholder={pendingClarification
              ? "请先完成上方的确认需求"
              : canCompose
                ? "描述你的海洋科研问题，可包含时空范围、变量和目标…"
                : "请先从研究项目右侧的 ··· 菜单中新建会话"}
            rows={2}
          />
          <div className="composer-controls">
            <input ref={fileInputRef} type="file" aria-label="选择原始数据文件" style={{ display: "none" }}
              onChange={(event) => { const file = event.target.files?.[0]; if (file) void upload(file); }} />
            <button type="button" disabled={!props.detail || props.busy || uploading}
              onClick={() => fileInputRef.current?.click()}>{uploading ? "上传中…" : "上传原始数据"}</button>
            <label className="composer-model-select" title="选择本次对话使用的模型">
              <select
                disabled={props.busy || !props.models.length}
                value={props.selectedModel ? `${props.selectedModel.providerId}::${props.selectedModel.modelId}` : ""}
                onChange={(event) => {
                  const model = props.models.find((item) => item.key === event.target.value);
                  if (model) props.onModelChange({ providerId: model.providerId, modelId: model.modelId });
                }}
              >
                {props.models.map((model) => <option key={model.key} value={model.key}>{model.name} · {model.providerName}</option>)}
              </select>
            </label>
            {props.busy ? (
              <button className="stop-button" type="button" onClick={props.onAbort} aria-label="停止运行">■</button>
            ) : (
              <button className="send-button" type="button" disabled={!draft.trim() || !canCompose || Boolean(pendingClarification) || !props.selectedModel} onClick={() => send()} aria-label="发送">↑</button>
            )}
          </div>
        </div>
        <small className="composer-note">OceanAgent 可能犯错，重要科研结论请核验来源。</small>
      </footer>
    </main>
  );
}
