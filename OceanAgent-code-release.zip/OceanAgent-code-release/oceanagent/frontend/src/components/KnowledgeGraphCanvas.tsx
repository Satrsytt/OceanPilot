import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { PointerEvent as ReactPointerEvent } from "react";
import { ArrowsOut, Minus, Plus, SlidersHorizontal } from "@phosphor-icons/react";
import type { KnowledgeGraphEdge, KnowledgeGraphNode, KnowledgeNodeType } from "../../../src/contracts";
import type { KnowledgeGraphResponse } from "../api";

interface Point { x: number; y: number }
interface Viewport extends Point { scale: number }

interface LayoutDirection {
  angle: number;
  itemsPerBand?: number;
  tangentGap?: number;
  radialGap?: number;
}

const TYPE_LABELS: Record<KnowledgeNodeType, string> = {
  paper: "论文",
  problem_solution: "论文方案",
  usage_bundle: "实验用法包",
  dataset: "数据集",
  step: "流程步骤",
  scientific_variable: "科学变量",
  experiment_setting: "实验设置",
  evaluation_metric: "评估指标",
  concept: "概念与用途",
};

const PAPER_LAYOUT_DIRECTIONS: Record<KnowledgeNodeType, LayoutDirection> = {
  paper: { angle: Math.PI },
  problem_solution: { angle: Math.PI * 1.18, itemsPerBand: 4 },
  usage_bundle: { angle: Math.PI * .98 },
  dataset: { angle: 0, itemsPerBand: 5 },
  step: { angle: Math.PI * .72 },
  scientific_variable: { angle: -Math.PI * .25 },
  experiment_setting: { angle: Math.PI * .24 },
  evaluation_metric: { angle: Math.PI * .5 },
  concept: { angle: -Math.PI * .5 },
};

const DATASET_LAYOUT_DIRECTIONS: Record<KnowledgeNodeType, LayoutDirection> = {
  paper: { angle: Math.PI * .75 },
  problem_solution: { angle: -Math.PI * .75 },
  usage_bundle: { angle: Math.PI },
  dataset: { angle: 0, itemsPerBand: 5 },
  step: { angle: Math.PI * .5 },
  scientific_variable: { angle: Math.PI * .28 },
  experiment_setting: { angle: Math.PI * .5 },
  evaluation_metric: { angle: Math.PI * .5 },
  concept: { angle: -Math.PI * .28 },
};

const LAYOUT_CENTER: Point = { x: 650, y: 440 };
const INNER_RADIUS = 315;
const DEFAULT_ITEMS_PER_BAND = 6;
const DEFAULT_TANGENT_GAP = 145;
const DEFAULT_RADIAL_GAP = 180;

function radiusFor(node: KnowledgeGraphNode, focusNodeId: string): number {
  if (node.id === focusNodeId) return 43;
  if (node.type === "paper" || node.type === "dataset") return 30;
  if (node.type === "problem_solution") return 29;
  return 25;
}

function estimatedTextWidth(value: string, maxCharacters: number, fontSize: number): number {
  const visibleText = value.length > maxCharacters ? `${value.slice(0, maxCharacters - 1)}…` : value;
  return [...visibleText].reduce((width, character) => width + (character.charCodeAt(0) > 255 ? fontSize : fontSize * .58), 0);
}

function nodeBounds(point: Point, node: KnowledgeGraphNode, focusNodeId: string) {
  const focused = node.id === focusNodeId;
  const radius = radiusFor(node, focusNodeId);
  const subtitle = node.subtitle || TYPE_LABELS[node.type];
  const titleWidth = estimatedTextWidth(node.title, focused ? 38 : 25, 14);
  const subtitleWidth = estimatedTextWidth(subtitle, focused ? 42 : 30, 11);
  const width = Math.max(radius * 2 + 20, titleWidth + 24, subtitleWidth + 24);
  return {
    left: point.x - width / 2,
    right: point.x + width / 2,
    top: point.y - radius - 12,
    bottom: point.y + radius + 52,
  };
}

function separateOverlaps(
  positions: Record<string, Point>,
  nodes: KnowledgeGraphNode[],
  focusNodeId: string,
): Record<string, Point> {
  const next = Object.fromEntries(Object.entries(positions).map(([id, point]) => [id, { ...point }]));
  const visibleNodes = nodes.filter((node) => next[node.id]);

  // The directional bands already provide the main structure. This small,
  // deterministic collision pass only moves boxes that still touch at sector edges.
  for (let iteration = 0; iteration < 24; iteration += 1) {
    let moved = false;
    for (let leftIndex = 0; leftIndex < visibleNodes.length; leftIndex += 1) {
      for (let rightIndex = leftIndex + 1; rightIndex < visibleNodes.length; rightIndex += 1) {
        const leftNode = visibleNodes[leftIndex];
        const rightNode = visibleNodes[rightIndex];
        const leftPoint = next[leftNode.id];
        const rightPoint = next[rightNode.id];
        const leftBounds = nodeBounds(leftPoint, leftNode, focusNodeId);
        const rightBounds = nodeBounds(rightPoint, rightNode, focusNodeId);
        const overlapX = Math.min(leftBounds.right, rightBounds.right) - Math.max(leftBounds.left, rightBounds.left);
        const overlapY = Math.min(leftBounds.bottom, rightBounds.bottom) - Math.max(leftBounds.top, rightBounds.top);
        if (overlapX <= 0 || overlapY <= 0) continue;

        const leftFixed = leftNode.id === focusNodeId;
        const rightFixed = rightNode.id === focusNodeId;
        const directionX = rightPoint.x === leftPoint.x ? (rightNode.id > leftNode.id ? 1 : -1) : Math.sign(rightPoint.x - leftPoint.x);
        const directionY = rightPoint.y === leftPoint.y ? (rightNode.id > leftNode.id ? 1 : -1) : Math.sign(rightPoint.y - leftPoint.y);
        const moveLeft = leftFixed ? 0 : (rightFixed ? 1 : .5);
        const moveRight = rightFixed ? 0 : (leftFixed ? 1 : .5);

        if (overlapX < overlapY) {
          const shift = overlapX + 10;
          leftPoint.x -= directionX * shift * moveLeft;
          rightPoint.x += directionX * shift * moveRight;
        } else {
          const shift = overlapY + 10;
          leftPoint.y -= directionY * shift * moveLeft;
          rightPoint.y += directionY * shift * moveRight;
        }
        moved = true;
      }
    }
    if (!moved) break;
  }
  return next;
}

function initialLayout(nodes: KnowledgeGraphNode[], graph: KnowledgeGraphResponse): Record<string, Point> {
  const positions: Record<string, Point> = { [graph.focusNodeId]: LAYOUT_CENTER };
  const groups = new Map<KnowledgeNodeType, KnowledgeGraphNode[]>();
  const directions = graph.perspective === "dataset" ? DATASET_LAYOUT_DIRECTIONS : PAPER_LAYOUT_DIRECTIONS;
  for (const node of nodes) {
    if (node.id === graph.focusNodeId) continue;
    groups.set(node.type, [...(groups.get(node.type) ?? []), node]);
  }
  for (const [type, items] of groups) {
    const sorted = [...items].sort((left, right) => left.entityId.localeCompare(right.entityId, undefined, { numeric: true }));
    const direction = directions[type];
    const itemsPerBand = direction.itemsPerBand ?? DEFAULT_ITEMS_PER_BAND;
    const tangentGap = direction.tangentGap ?? DEFAULT_TANGENT_GAP;
    const radialGap = direction.radialGap ?? DEFAULT_RADIAL_GAP;
    const radial = { x: Math.cos(direction.angle), y: Math.sin(direction.angle) };
    const tangent = { x: -radial.y, y: radial.x };
    sorted.forEach((node, index) => {
      const band = Math.floor(index / itemsPerBand);
      const firstItem = band * itemsPerBand;
      const itemsInBand = Math.min(itemsPerBand, sorted.length - firstItem);
      const slot = index - firstItem;
      const tangentOffset = (slot - (itemsInBand - 1) / 2) * tangentGap;
      const radius = INNER_RADIUS + band * radialGap;
      positions[node.id] = {
        x: LAYOUT_CENTER.x + radial.x * radius + tangent.x * tangentOffset,
        y: LAYOUT_CENTER.y + radial.y * radius + tangent.y * tangentOffset,
      };
    });
  }
  return separateOverlaps(positions, nodes, graph.focusNodeId);
}

function ellipsis(value: string, max: number): string {
  return value.length > max ? `${value.slice(0, max - 1)}…` : value;
}

function boundsFor(
  positions: Record<string, Point>,
  nodes: KnowledgeGraphNode[],
  focusNodeId: string,
): { minX: number; minY: number; maxX: number; maxY: number } {
  const values = nodes.flatMap((node) => positions[node.id] ? [nodeBounds(positions[node.id], node, focusNodeId)] : []);
  if (values.length === 0) return { minX: 0, minY: 0, maxX: 1300, maxY: 880 };
  return {
    minX: Math.min(...values.map((item) => item.left)),
    minY: Math.min(...values.map((item) => item.top)),
    maxX: Math.max(...values.map((item) => item.right)),
    maxY: Math.max(...values.map((item) => item.bottom)),
  };
}

function edgePath(source: Point, target: Point, sourceRadius: number, targetRadius: number, index: number) {
  const dx = target.x - source.x;
  const dy = target.y - source.y;
  const distance = Math.max(1, Math.hypot(dx, dy));
  const ux = dx / distance;
  const uy = dy / distance;
  const start = { x: source.x + ux * (sourceRadius + 3), y: source.y + uy * (sourceRadius + 3) };
  const end = { x: target.x - ux * (targetRadius + 7), y: target.y - uy * (targetRadius + 7) };
  const bend = ((index % 3) - 1) * Math.min(28, distance * .08);
  const control = { x: (start.x + end.x) / 2 - uy * bend, y: (start.y + end.y) / 2 + ux * bend };
  return {
    d: `M ${start.x} ${start.y} Q ${control.x} ${control.y} ${end.x} ${end.y}`,
    label: control,
  };
}

export function KnowledgeGraphCanvas(props: {
  graph: KnowledgeGraphResponse;
  selectedNodeId: string;
  onSelectNode: (nodeId: string) => void;
}) {
  const svgRef = useRef<SVGSVGElement>(null);
  const hostRef = useRef<HTMLDivElement>(null);
  const [positions, setPositions] = useState<Record<string, Point>>({});
  const positionsRef = useRef<Record<string, Point>>({});
  const [viewport, setViewport] = useState<Viewport>({ x: 20, y: 20, scale: .82 });
  const nodes = useMemo(() => props.graph.nodes.filter((node) => node.type !== "usage_bundle"), [props.graph.nodes]);
  const nodeById = useMemo(() => new Map(nodes.map((node) => [node.id, node])), [nodes]);
  const edges = useMemo(() => props.graph.edges.filter((item) => nodeById.has(item.source) && nodeById.has(item.target)), [props.graph.edges, nodeById]);
  const dragRef = useRef<{ id: string; pointerId: number; offset: Point; start: Point; moved: boolean } | null>(null);
  const panRef = useRef<{ pointerId: number; start: Point; origin: Point } | null>(null);

  const fitToView = useCallback((nextPositions?: Record<string, Point>) => {
    const rect = svgRef.current?.getBoundingClientRect();
    if (!rect || rect.width === 0 || rect.height === 0) return;
    const bounds = boundsFor(nextPositions ?? positionsRef.current, nodes, props.graph.focusNodeId);
    const contentWidth = bounds.maxX - bounds.minX + 80;
    const contentHeight = bounds.maxY - bounds.minY + 80;
    const scale = Math.min(1.15, Math.max(.24, Math.min(rect.width / contentWidth, rect.height / contentHeight)));
    setViewport({
      scale,
      x: (rect.width - (bounds.minX + bounds.maxX) * scale) / 2,
      y: (rect.height - (bounds.minY + bounds.maxY) * scale) / 2,
    });
  }, [nodes, props.graph.focusNodeId]);

  useEffect(() => {
    const next = initialLayout(nodes, props.graph);
    positionsRef.current = next;
    setPositions(next);
    const frame = requestAnimationFrame(() => fitToView(next));
    return () => cancelAnimationFrame(frame);
  }, [nodes, props.graph, fitToView]);

  const graphPoint = (clientX: number, clientY: number): Point => {
    const rect = svgRef.current?.getBoundingClientRect();
    return {
      x: (clientX - (rect?.left ?? 0) - viewport.x) / viewport.scale,
      y: (clientY - (rect?.top ?? 0) - viewport.y) / viewport.scale,
    };
  };

  const endPointer = (event: ReactPointerEvent<SVGSVGElement>) => {
    const dragging = dragRef.current;
    if (dragging?.pointerId === event.pointerId) {
      if (!dragging.moved) props.onSelectNode(dragging.id);
      dragRef.current = null;
    }
    if (panRef.current?.pointerId === event.pointerId) panRef.current = null;
    if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId);
  };

  return (
    <div className="knowledge-canvas-host" ref={hostRef}>
      <svg
        ref={svgRef}
        className="knowledge-canvas"
        aria-label="可拖拽的海洋科研知识图谱"
        onPointerMove={(event) => {
          const dragging = dragRef.current;
          if (dragging?.pointerId === event.pointerId) {
            const point = graphPoint(event.clientX, event.clientY);
            if (Math.hypot(point.x - dragging.start.x, point.y - dragging.start.y) > 3) dragging.moved = true;
            setPositions((current) => {
              const next = { ...current, [dragging.id]: { x: point.x - dragging.offset.x, y: point.y - dragging.offset.y } };
              positionsRef.current = next;
              return next;
            });
            return;
          }
          const panning = panRef.current;
          if (panning?.pointerId === event.pointerId) {
            setViewport((current) => ({ ...current, x: panning.origin.x + event.clientX - panning.start.x, y: panning.origin.y + event.clientY - panning.start.y }));
          }
        }}
        onPointerUp={endPointer}
        onPointerCancel={endPointer}
        onWheel={(event) => {
          event.preventDefault();
          const rect = event.currentTarget.getBoundingClientRect();
          const pointerX = event.clientX - rect.left;
          const pointerY = event.clientY - rect.top;
          const scale = Math.min(2, Math.max(.22, viewport.scale * (event.deltaY > 0 ? .9 : 1.1)));
          setViewport({ scale, x: pointerX - (pointerX - viewport.x) * scale / viewport.scale, y: pointerY - (pointerY - viewport.y) * scale / viewport.scale });
        }}
      >
        <defs>
          <pattern id="knowledge-grid" width="38" height="38" patternUnits="userSpaceOnUse">
            <path d="M 38 0 L 0 0 0 38" fill="none" stroke="#dcebea" strokeWidth="1" opacity=".5" />
          </pattern>
          <filter id="knowledge-shadow" x="-70%" y="-70%" width="240%" height="240%">
            <feDropShadow dx="0" dy="4" stdDeviation="5" floodColor="#44676b" floodOpacity=".2" />
          </filter>
          <marker id="knowledge-arrow" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 Z" fill="#96b7b9" /></marker>
          <marker id="knowledge-arrow-relation" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 Z" fill="#d29b45" /></marker>
        </defs>
        <rect
          width="100%" height="100%" fill="url(#knowledge-grid)"
          onPointerDown={(event) => {
            panRef.current = { pointerId: event.pointerId, start: { x: event.clientX, y: event.clientY }, origin: { x: viewport.x, y: viewport.y } };
            event.currentTarget.ownerSVGElement?.setPointerCapture(event.pointerId);
          }}
        />
        <g transform={`translate(${viewport.x} ${viewport.y}) scale(${viewport.scale})`}>
          {edges.map((item, index) => {
            const source = positions[item.source];
            const target = positions[item.target];
            const sourceNode = nodeById.get(item.source);
            const targetNode = nodeById.get(item.target);
            if (!source || !target || !sourceNode || !targetNode) return null;
            const geometry = edgePath(source, target, radiusFor(sourceNode, props.graph.focusNodeId), radiusFor(targetNode, props.graph.focusNodeId), index);
            const relation = item.kind === "data_relation";
            return (
              <g key={item.id} className={`knowledge-edge ${relation ? "relation" : ""}`}>
                <path d={geometry.d} markerEnd={`url(#${relation ? "knowledge-arrow-relation" : "knowledge-arrow"})`} />
                <text x={geometry.label.x} y={geometry.label.y - 7} textAnchor="middle">{ellipsis(item.label, 18)}</text>
              </g>
            );
          })}
          {nodes.map((node) => {
            const point = positions[node.id];
            if (!point) return null;
            const selected = props.selectedNodeId === node.id;
            const focused = props.graph.focusNodeId === node.id;
            const radius = radiusFor(node, props.graph.focusNodeId);
            return (
              <g
                key={node.id}
                className={`knowledge-node type-${node.type} ${selected ? "selected" : ""} ${focused ? "focused" : ""}`}
                transform={`translate(${point.x} ${point.y})`}
                role="button" tabIndex={0} aria-label={`${TYPE_LABELS[node.type]}：${node.title}`}
                onKeyDown={(event) => { if (event.key === "Enter" || event.key === " ") props.onSelectNode(node.id); }}
                onPointerDown={(event) => {
                  event.stopPropagation();
                  const pointer = graphPoint(event.clientX, event.clientY);
                  dragRef.current = { id: node.id, pointerId: event.pointerId, offset: { x: pointer.x - point.x, y: pointer.y - point.y }, start: pointer, moved: false };
                  svgRef.current?.setPointerCapture(event.pointerId);
                }}
              >
                {focused && <circle className="node-focus-ring" r={radius + 10} />}
                <circle className="node-body" r={radius} filter="url(#knowledge-shadow)" />
                <text className="node-kind" y={4} textAnchor="middle">{TYPE_LABELS[node.type].slice(0, 2)}</text>
                <text className="node-title" y={radius + 22} textAnchor="middle">{ellipsis(node.title, focused ? 38 : 25)}</text>
                <text className="node-subtitle" y={radius + 39} textAnchor="middle">{ellipsis(node.subtitle || TYPE_LABELS[node.type], focused ? 42 : 30)}</text>
              </g>
            );
          })}
        </g>
      </svg>
      <div className="knowledge-canvas-actions" aria-label="图谱视图控制">
        <button type="button" title="放大" onClick={() => setViewport((value) => ({ ...value, scale: Math.min(2, value.scale * 1.18) }))}><Plus /></button>
        <button type="button" title="缩小" onClick={() => setViewport((value) => ({ ...value, scale: Math.max(.22, value.scale / 1.18) }))}><Minus /></button>
        <button type="button" title="适应画布" onClick={() => fitToView()}><SlidersHorizontal /></button>
        <button type="button" title="全屏" onClick={() => { if (document.fullscreenElement) void document.exitFullscreen(); else void hostRef.current?.requestFullscreen(); }}><ArrowsOut /></button>
      </div>
      <div className="knowledge-drag-tip">拖动节点调整位置 · 拖动空白处平移 · 滚轮缩放</div>
    </div>
  );
}
