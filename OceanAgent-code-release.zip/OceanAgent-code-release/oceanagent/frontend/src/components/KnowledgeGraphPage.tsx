import { useEffect, useMemo, useRef, useState } from "react";
import { ArrowClockwise, BookOpenText, Database, FileText, GitBranch, MagnifyingGlass, ShareNetwork, SpinnerGap } from "@phosphor-icons/react";
import { api, type KnowledgeCatalogItem, type KnowledgeGraphResponse, type KnowledgeGraphStats, type KnowledgePerspective } from "../api";
import { KnowledgeGraphCanvas } from "./KnowledgeGraphCanvas";
import { KnowledgeGraphDetail } from "./KnowledgeGraphDetail";
import { NormativeKnowledgeView, PaperPlanView } from "./KnowledgeGraphViews";

type KnowledgeModule = "graph" | "global" | "plan" | "normative";

const MODULES: { id: KnowledgeModule; label: string; icon: typeof ShareNetwork }[] = [
  { id: "graph", label: "局部知识图谱", icon: ShareNetwork },
  { id: "global", label: "全局知识图谱", icon: ShareNetwork },
  { id: "plan", label: "论文问题与 Plan", icon: GitBranch },
  { id: "normative", label: "三层规范知识层", icon: FileText },
];

function formatNumber(value: number | undefined): string {
  return typeof value === "number" ? value.toLocaleString("zh-CN") : "—";
}

function updatedLabel(value: string | null | undefined): string {
  if (!value) return "等待知识库数据";
  return `数据更新于 ${new Intl.DateTimeFormat("zh-CN", { dateStyle: "short", timeStyle: "short" }).format(new Date(value))}`;
}

export function KnowledgeGraphPage() {
  const [module, setModule] = useState<KnowledgeModule>("graph");
  const [perspective, setPerspective] = useState<KnowledgePerspective>("paper");
  const [stats, setStats] = useState<KnowledgeGraphStats | null>(null);
  const [catalog, setCatalog] = useState<KnowledgeCatalogItem[]>([]);
  const [focusId, setFocusId] = useState("");
  const [graph, setGraph] = useState<KnowledgeGraphResponse | null>(null);
  const [selectedNodeId, setSelectedNodeId] = useState("");
  const [query, setQuery] = useState("");
  const [catalogLoading, setCatalogLoading] = useState(true);
  const [graphLoading, setGraphLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [refreshKey, setRefreshKey] = useState(0);
  const requestedFocusRef = useRef<string | null>(null);

  useEffect(() => {
    let active = true;
    void api.getKnowledgeGraphStats()
      .then((value) => { if (active) setStats(value); })
      .catch((reason: unknown) => { if (active) setError(reason instanceof Error ? reason.message : "知识库统计加载失败"); });
    return () => { active = false; };
  }, [refreshKey]);

  useEffect(() => {
    let active = true;
    setCatalogLoading(true);
    setError(null);
    setGraph(null);
    setFocusId("");
    void api.listKnowledgeCatalog(perspective)
      .then((items) => {
        if (!active) return;
        setCatalog(items);
        const requested = requestedFocusRef.current;
        const nextFocus = requested && items.some((item) => item.id === requested) ? requested : items[0]?.id ?? "";
        requestedFocusRef.current = null;
        setFocusId(nextFocus);
        if (items.length === 0) setError("Ocean-RAG 中没有可视化的结构化知识卡");
      })
      .catch((reason: unknown) => { if (active) setError(reason instanceof Error ? reason.message : "知识目录加载失败"); })
      .finally(() => { if (active) setCatalogLoading(false); });
    return () => { active = false; };
  }, [perspective, refreshKey]);

  useEffect(() => {
    if (!focusId) return undefined;
    let active = true;
    setGraphLoading(true);
    setError(null);
    void api.getKnowledgeSubgraph(perspective, focusId)
      .then((value) => {
        if (!active) return;
        setGraph(value);
        setSelectedNodeId(value.focusNodeId);
      })
      .catch((reason: unknown) => { if (active) setError(reason instanceof Error ? reason.message : "图谱加载失败"); })
      .finally(() => { if (active) setGraphLoading(false); });
    return () => { active = false; };
  }, [perspective, focusId, refreshKey]);

  const selectedNode = graph?.nodes.find((node) => node.id === selectedNodeId) ?? null;
  const isGraphModule = module === "graph" || module === "global";
  const currentItem = catalog.find((item) => item.id === focusId);
  const matches = useMemo(() => {
    const normalized = query.trim().toLocaleLowerCase();
    if (!normalized) return [];
    return catalog.filter((item) => `${item.id} ${item.title} ${item.subtitle}`.toLocaleLowerCase().includes(normalized)).slice(0, 8);
  }, [catalog, query]);

  const openPaperModule = (paperId: string, targetModule: KnowledgeModule) => {
    setModule(targetModule);
    if (perspective === "paper") {
      if (paperId) setFocusId(paperId);
      return;
    }
    requestedFocusRef.current = paperId || null;
    setPerspective("paper");
  };

  const selectModule = (targetModule: KnowledgeModule) => {
    if (targetModule === "global") {
      setModule("global");
      setPerspective("global");
      return;
    }
    if (targetModule === "graph") {
      setModule("graph");
      if (perspective === "global") setPerspective("paper");
      return;
    }
    openPaperModule(selectedNode?.type === "paper" ? selectedNode.entityId : "", targetModule);
  };

  const setGraphPerspective = (value: KnowledgePerspective) => {
    setModule(value === "global" ? "global" : "graph");
    setPerspective(value);
  };

  return (
    <main className="knowledge-shell">
      <header className="knowledge-page-header">
        <div><span>OCEAN RESEARCH KNOWLEDGE GRAPH</span><h1>海洋科研知识图谱</h1><p>以论文与数据集为入口，追踪研究问题、实验 Plan、数据用法和规范知识实体</p></div>
        <div className="knowledge-source-badge"><i /><div><b>{stats?.sourceName ?? "Ocean-RAG 海洋科研知识库"}</b><small>{updatedLabel(stats?.lastUpdated)}</small></div></div>
      </header>

      <nav className="knowledge-page-tabs knowledge-module-tabs" aria-label="知识图谱功能模块">
        {MODULES.map((item) => {
          const Icon = item.icon;
          return <button key={item.id} className={module === item.id ? "active" : ""} type="button" onClick={() => selectModule(item.id)}><Icon />{item.label}</button>;
        })}
      </nav>

      <section className={`knowledge-toolbar ${!isGraphModule ? "paper-module-toolbar" : ""}`}>
        {isGraphModule && (
          <div className="perspective-switch" aria-label="查看视角">
            <button className={perspective === "global" ? "active" : ""} type="button" onClick={() => setGraphPerspective("global")}><ShareNetwork />全局图谱</button>
            <button className={perspective === "paper" ? "active" : ""} type="button" onClick={() => setGraphPerspective("paper")}><BookOpenText />按论文查看</button>
            <button className={perspective === "dataset" ? "active" : ""} type="button" onClick={() => setGraphPerspective("dataset")}><Database />按数据集查看</button>
          </div>
        )}
        <label className="knowledge-target-select">
          <span>{perspective === "global" ? "图谱范围" : perspective === "paper" ? "目标论文" : "目标数据集"}</span>
          <select value={focusId} disabled={catalogLoading || catalog.length === 0} onChange={(event) => setFocusId(event.target.value)}>
            {catalog.map((item) => <option value={item.id} key={item.id}>{item.id} · {item.title}</option>)}
          </select>
        </label>
        <div className="knowledge-search">
          <MagnifyingGlass />
          <input value={query} onChange={(event) => setQuery(event.target.value)} disabled={perspective === "global"} placeholder={perspective === "global" ? "全局视角显示跨论文关系" : `搜索${perspective === "paper" ? "论文、问题" : "数据集、产品或提供方"}`} />
          {matches.length > 0 && <div className="knowledge-search-results">{matches.map((item) => <button type="button" key={item.id} onClick={() => { setFocusId(item.id); setQuery(""); }}><b>{item.title}</b><small>{item.id} · {item.subtitle}</small></button>)}</div>}
        </div>
        <button className="knowledge-refresh" type="button" title="重新读取 Ocean-RAG" onClick={() => setRefreshKey((value) => value + 1)}><ArrowClockwise /></button>
      </section>

      <section className="knowledge-stat-strip">
        <div title="知识库中已经形成结构化研究知识的论文数量"><BookOpenText /><span><b>{formatNumber(stats?.papersWithKnowledge)}</b><small>论文知识</small></span></div>
        <div title="全部论文实验方案中记录的步骤总数"><GitBranch /><span><b>{formatNumber(stats?.planSteps)}</b><small>实验步骤</small></span></div>
        <div title="论文中记录的数据集使用方式总数"><Database /><span><b>{formatNumber(stats?.dataUsages)}</b><small>数据用法</small></span></div>
        <div title="论文实验包中记录的数据关联关系总数"><ShareNetwork /><span><b>{formatNumber(stats?.dataRelations)}</b><small>数据关系</small></span></div>
        <div title="论文实验包中记录的验证与评估规则总数"><FileText /><span><b>{formatNumber(stats?.validationRules)}</b><small>验证规则</small></span></div>
        <div title="知识库中可查看的数据集知识实体数量"><Database /><span><b>{formatNumber(stats?.datasetCards)}</b><small>数据集</small></span></div>
      </section>

      {isGraphModule ? (
        <section className="knowledge-workspace">
          <div className="knowledge-graph-column">
            <div className="knowledge-context-line"><span>{perspective === "global" ? "跨论文全局图谱" : perspective === "paper" ? "论文中心子图" : "数据集中心子图"}</span><b title={currentItem?.title}>{currentItem?.title ?? "正在读取知识实体"}</b>{graph?.truncated && <i>{perspective === "global" ? "全局实体较多，当前显示使用频率最高的 28 个数据集" : "关联实体较多，当前显示前 12 篇论文"}</i>}</div>
            {graph && <KnowledgeGraphCanvas graph={graph} selectedNodeId={selectedNodeId} onSelectNode={setSelectedNodeId} />}
            {(catalogLoading || graphLoading) && <div className="knowledge-loading"><SpinnerGap /><p>正在组织知识关系…</p></div>}
            {error && !graphLoading && <div className="knowledge-error"><p>{error}</p><small>请确认 Ocean-RAG 路径或设置 OCEAN_RAG_ROOT 环境变量。</small></div>}
            <div className="knowledge-legend">
              <span className="paper">论文</span><span className="problem">论文方案</span><span className="dataset">数据集</span><span className="variable">科学变量</span><span className="step">流程步骤</span><span className="setting">实验设置</span><span className="metric">评估指标</span><span className="concept">概念与用途</span>
            </div>
          </div>
          {graph && <KnowledgeGraphDetail node={selectedNode} graph={graph} perspective={perspective} onOpenPaper={(paperId) => openPaperModule(paperId, "graph")} onOpenPlan={(paperId) => openPaperModule(paperId, "plan")} onOpenNormative={(paperId) => openPaperModule(paperId, "normative")} />}
        </section>
      ) : (
        <section className="knowledge-module-workspace">
          {(catalogLoading || graphLoading) && <div className="knowledge-loading"><SpinnerGap /><p>正在读取论文规范知识…</p></div>}
          {error && !graphLoading && <div className="knowledge-error"><p>{error}</p></div>}
          {graph && perspective === "paper" && (module === "plan" ? <PaperPlanView graph={graph} /> : <NormativeKnowledgeView graph={graph} />)}
        </section>
      )}
    </main>
  );
}
