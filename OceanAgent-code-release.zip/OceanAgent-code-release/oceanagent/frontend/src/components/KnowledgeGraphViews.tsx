import { useEffect, useMemo, useState } from "react";
import { ArrowDown, CheckCircle, Database, FileText, Flask, GitBranch, LinkSimple } from "@phosphor-icons/react";
import type { KnowledgeGraphNode } from "../../../src/contracts";
import type { KnowledgeGraphResponse } from "../api";

type JsonObject = Record<string, unknown>;

function object(value: unknown): JsonObject {
  return value && typeof value === "object" && !Array.isArray(value) ? value as JsonObject : {};
}

function objects(value: unknown): JsonObject[] {
  return Array.isArray(value) ? value.map(object).filter((item) => Object.keys(item).length > 0) : [];
}

function values(value: unknown): string[] {
  return Array.isArray(value)
    ? value.map((item) => typeof item === "string" ? item : JSON.stringify(item) ?? "").filter(Boolean)
    : [];
}

function display(value: unknown, fallback = "未记录"): string {
  if (typeof value === "string" || typeof value === "number") {
    const result = String(value).trim();
    return result && !/(unresolved|pending_web_search)/i.test(result) ? result : fallback;
  }
  if (Array.isArray(value)) return values(value).join("、") || fallback;
  if (value && typeof value === "object") {
    return Object.entries(value as JsonObject).map(([key, nested]) => `${key}: ${display(nested, "—")}`).join("；") || fallback;
  }
  return fallback;
}

function paperKnowledge(graph: KnowledgeGraphResponse) {
  const paper = graph.nodes.find((node) => node.type === "paper" && node.id === graph.focusNodeId)
    ?? graph.nodes.find((node) => node.type === "paper");
  const problem = object(paper?.payload.problem_card ?? graph.nodes.find((node) => node.type === "problem_solution")?.payload);
  const bundle = object(paper?.payload.usage_bundle ?? graph.nodes.find((node) => node.type === "usage_bundle")?.payload);
  return { paper, problem, bundle };
}

function Evidence({ value }: { value: unknown }) {
  const evidence = objects(value);
  if (evidence.length === 0) return <p className="module-empty">没有记录原文证据</p>;
  return (
    <div className="module-evidence">
      {evidence.slice(0, 4).map((item, index) => (
        <blockquote key={`${display(item.source_id)}-${index}`}><b>{display(item.page_or_section, display(item.source_id))}</b><p>{display(item.quote)}</p></blockquote>
      ))}
      {evidence.length > 4 && <small>另有 {evidence.length - 4} 条证据，可在原始卡片中继续核查</small>}
    </div>
  );
}

export function PaperPlanView({ graph }: { graph: KnowledgeGraphResponse }) {
  const { paper, problem, bundle } = paperKnowledge(graph);
  const steps = objects(bundle.steps);
  const [selectedId, setSelectedId] = useState("");
  useEffect(() => { setSelectedId(display(steps[0]?.step_id, "")); }, [graph.focusId]);
  const selected = steps.find((step) => display(step.step_id, "") === selectedId) ?? steps[0] ?? {};
  const selectedIndex = Math.max(0, steps.indexOf(selected));

  return (
    <section className="paper-plan-module">
      <header className="module-heading">
        <div><span>论文问题与实验 PLAN</span><h2>{paper?.title ?? graph.focusId}</h2><p>点击任意步骤，查看这篇论文在该步骤中的输入、依赖、输出和原文证据。</p></div>
        <dl><div><dt>问题</dt><dd>{Object.keys(problem).length ? 1 : 0}</dd></div><div><dt>步骤</dt><dd>{steps.length}</dd></div><div><dt>数据用法</dt><dd>{objects(bundle.data_usages).length}</dd></div></dl>
      </header>
      <article className="paper-problem-card">
        <FileText />
        <div><span>ProblemSolutionCard · {display(problem.card_id)}</span><h3>{display(problem.problem)}</h3><p>{display(problem.solution_summary)}</p></div>
      </article>
      <div className="plan-module-grid">
        <nav className="plan-step-nav" aria-label="实验 Plan 步骤">
          <h3><GitBranch /> 实验流程 DAG</h3>
          {steps.map((step, index) => {
            const id = display(step.step_id, String(index + 1));
            return (
              <button key={id} type="button" className={id === display(selected.step_id, "") ? "active" : ""} onClick={() => setSelectedId(id)}>
                <i>{index + 1}</i><span><b>{id}</b><small>{display(step.action)}</small>{values(step.depends_on_step_ids).length > 0 && <em>依赖 {values(step.depends_on_step_ids).join("、")}</em>}</span>
              </button>
            );
          })}
          {steps.length === 0 && <p className="module-empty">这篇论文尚未记录 Plan 步骤</p>}
        </nav>
        <article className="plan-step-inspector">
          <header><span>STEP {selectedIndex + 1} / {steps.length}</span><h3>{display(selected.step_id, "未选择步骤")}</h3></header>
          <section><h4>执行动作</h4><p className="inspector-lead">{display(selected.action)}</p></section>
          <dl>
            <div><dt>前置依赖</dt><dd>{display(selected.depends_on_step_ids, "无前置依赖")}</dd></div>
            <div><dt>输入数据用法</dt><dd>{display(selected.input_usage_ids)}</dd></div>
            <div><dt>预期输出</dt><dd>{display(selected.output)}</dd></div>
            <div><dt>推断状态</dt><dd>{display(selected.inference_status)}</dd></div>
          </dl>
          <section><h4>原文证据</h4><Evidence value={selected.evidence} /></section>
        </article>
      </div>
    </section>
  );
}

function FieldList({ fields }: { fields: JsonObject[] }) {
  if (fields.length === 0) return <p className="module-empty">未记录变量字段</p>;
  return <div className="norm-field-table" role="table" aria-label="数据集字段">
    <div className="norm-table-head" role="row"><b>原始字段名</b><b>字段说明</b><b>单位</b><b>维度</b><b>有效范围</b><b>质量规则</b></div>
    {fields.slice(0, 24).map((field, index) => <div role="row" key={`${display(field.raw_name)}-${index}`}><code>{display(field.raw_name)}</code><span>{display(field.description)}</span><small>{display(field.unit, "未记录")}</small><small>{display(field.dimensions, "未记录")}</small><small>{display(field.valid_range, "未记录")}</small><small>{display(field.quality_rule, display(field.quality_field, "未记录"))}</small></div>)}
  </div>;
}

export function NormativeKnowledgeView({ graph }: { graph: KnowledgeGraphResponse }) {
  const { paper, problem, bundle } = paperKnowledge(graph);
  const datasets = useMemo(() => graph.nodes.filter((node): node is KnowledgeGraphNode => node.type === "dataset"), [graph.nodes]);
  const [datasetId, setDatasetId] = useState("");
  useEffect(() => { setDatasetId(datasets[0]?.entityId ?? ""); }, [graph.focusId]);
  const dataset = datasets.find((item) => item.entityId === datasetId) ?? datasets[0];
  const usages = objects(bundle.data_usages);
  const selectedUsages = usages.filter((usage) => display(usage.dataset_id, "") === dataset?.entityId);
  const steps = objects(bundle.steps);
  const fields = objects(dataset?.payload.fields);

  return (
    <section className="normative-knowledge-module">
      <header className="module-heading">
        <div><span>THREE-LAYER NORMATIVE KNOWLEDGE</span><h2>三层规范知识层</h2><p>“规范知识卡”是 ProblemSolutionCard、UsageBundleCard、DatasetCard 三类结构化记录的统称，统计来自 Ocean-RAG 的三个 cards/*.jsonl。前两类描述某篇论文的问题与实验，DatasetCard 描述可跨论文复用的数据产品事实。Plan 是 steps 实验 DAG；Usage 是数据集在论文中的角色、字段、子集与处理；`steps.input_usage_ids → data_usages.usage_id → DatasetCard.dataset_id` 把两者连接起来。</p></div>
        <div className="norm-paper-name"><FileText /><span><small>当前论文</small><b>{paper?.title ?? graph.focusId}</b></span></div>
      </header>

      <article className="normative-review-card problem-card">
        <header><FileText /><div><span>第一层</span><h3>问题方案卡（ProblemSolutionCard）</h3></div><code>{display(problem.card_id)}</code></header>
        <div className="norm-card-columns">
          <section><h4>研究问题</h4><p className="norm-lead">{display(problem.problem)}</p></section>
          <section><h4>解决方案摘要</h4><p>{display(problem.solution_summary)}</p></section>
        </div>
        <dl><div><dt>论文 ID</dt><dd>{display(problem.paper_id)}</dd></div><div><dt>研究领域</dt><dd>{display(problem.research_field)}</dd></div><div><dt>Bundle ID</dt><dd>{display(problem.bundle_id)}</dd></div></dl>
      </article>
      <div className="norm-layer-connector"><ArrowDown /><span>bundle_id</span></div>

      <article className="normative-review-card bundle-card">
        <header><Flask /><div><span>第二层</span><h3>实验用法包（UsageBundleCard）</h3></div><code>{display(bundle.bundle_id)}</code></header>
        <div className="norm-summary-counters"><span><b>{steps.length}</b>实验步骤</span><span><b>{usages.length}</b>数据用法</span><span><b>{objects(bundle.data_relations).length}</b>数据关系</span><span><b>{objects(bundle.validation).length}</b>验证规则</span></div>
        <div className="norm-usage-table" role="table" aria-label="论文数据用法">
          <div className="norm-table-head" role="row"><b>Usage ID</b><b>Dataset ID</b><b>用途角色</b><b>使用字段</b><b>使用子集</b><b>预处理 / 质量控制</b></div>
          {usages.map((usage, index) => <div role="row" key={`${display(usage.usage_id)}-${index}`}><code>{display(usage.usage_id)}</code><b>{display(usage.dataset_id)}</b><span>{display(usage.role, "实验数据")}</span><small>{display(usage.fields, "未记录字段")}</small><small>{display(usage.subset, "未记录子集")}</small><small>{display(usage.preprocessing, "未记录")}；QC：{display(usage.quality_control, "未记录")}</small></div>)}
        </div>
      </article>
      <div className="norm-layer-connector"><ArrowDown /><span>dataset_id</span></div>

      <article className="normative-review-card dataset-card">
        <header><Database /><div><span>第三层</span><h3>数据集卡（DatasetCard）</h3></div><code>{datasets.length} 个关联数据集</code></header>
        <div className="norm-dataset-tabs" role="tablist">
          {datasets.map((item) => <button type="button" role="tab" aria-selected={item.entityId === dataset?.entityId} className={item.entityId === dataset?.entityId ? "active" : ""} key={item.id} onClick={() => setDatasetId(item.entityId)}>{item.title}</button>)}
        </div>
        {dataset ? (
          <div className="norm-dataset-detail">
            <div className="norm-card-columns">
              <section><h4>{dataset.title}</h4><p className="norm-lead">{display(dataset.payload.description)}</p></section>
              <dl>
                <div><dt>Dataset ID</dt><dd>{display(dataset.payload.dataset_id)}</dd></div><div><dt>产品 / 提供方</dt><dd>{display(dataset.payload.product_id)} / {display(dataset.payload.provider)}</dd></div><div><dt>版本</dt><dd>{display(dataset.payload.version)}</dd></div><div><dt>覆盖范围</dt><dd>{display(dataset.payload.coverage)}</dd></div><div><dt>分辨率</dt><dd>{display(dataset.payload.resolution)}</dd></div>
              </dl>
            </div>
            {selectedUsages.length > 0 && <section className="norm-selected-usages"><h4><CheckCircle /> 本论文中的用法</h4>{selectedUsages.map((usage, index) => <p key={`${display(usage.usage_id)}-${index}`}><b>{display(usage.role)}</b><span>{display(usage.subset)}</span><small>预处理：{display(usage.preprocessing)}</small></p>)}</section>}
            <section><h4>字段与科学变量</h4><FieldList fields={fields} /></section>
            {objects(dataset.payload.access).map((item, index) => {
              const url = display(item.url, "");
              return url.startsWith("http") ? <a className="norm-access" href={url} target="_blank" rel="noreferrer" key={`${url}-${index}`}><LinkSimple /> {display(item.type, "数据入口")}</a> : null;
            })}
          </div>
        ) : <p className="module-empty">这篇论文没有关联 DatasetCard</p>}
      </article>
    </section>
  );
}
