import ReactMarkdown, { type Components } from "react-markdown";
import remarkGfm from "remark-gfm";

const artifactUrl = /^\/api\/artifacts\/[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}\/[^/?#]+$/i;

const components: Components = {
  a: ({ node: _node, href, children, ...props }) => {
    if (!href || !artifactUrl.test(href)) {
      const external = href?.startsWith("//") || /^https?:\/\//i.test(href ?? "");
      return <a href={href} {...props} target={external ? "_blank" : undefined}
        rel={external ? "noopener noreferrer" : undefined}>{children}</a>;
    }
    const encodedName = href.slice(href.lastIndexOf("/") + 1);
    let name = encodedName;
    try { name = decodeURIComponent(encodedName); } catch { /* Keep the URL text as a fallback. */ }
    return <a href={href} {...props} className="artifact-download-link" download={name} title={`下载 ${name}`}>
      {children}<span className="artifact-download-label">↓ 下载</span>
    </a>;
  },
};

export function MarkdownContent({ children }: { children: string }) {
  return <ReactMarkdown remarkPlugins={[remarkGfm]} components={components}>{children}</ReactMarkdown>;
}
