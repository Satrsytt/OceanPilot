import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  root: "frontend",
  plugins: [react()],
  server: {
    host: "127.0.0.1",
    port: 5173,
    proxy: {
      "/api": process.env.OCEAN_API_PROXY ?? "http://127.0.0.1:3210",
    },
  },
  build: {
    outDir: "dist",
    emptyOutDir: true,
  },
});
