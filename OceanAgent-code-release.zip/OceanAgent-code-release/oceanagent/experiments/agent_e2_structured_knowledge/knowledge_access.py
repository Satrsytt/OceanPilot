from __future__ import annotations

import hashlib
import importlib.util
import json
import sys
from dataclasses import dataclass
from pathlib import Path
from types import ModuleType
from typing import Any, Iterable, Mapping, Sequence


SPLIT_PREDECESSORS = {
    "dev": ("train",),
    "test": ("train", "dev"),
}
BLOCKED_SPLITS = {
    "dev": ("dev", "test"),
    "test": ("test",),
}
VISIBLE_KNOWLEDGE_POLICY_VERSION = "heldout-blocked-plus-auxiliary-v2"


def iter_jsonl(path: Path) -> Iterable[dict[str, Any]]:
    with path.open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, start=1):
            if not line.strip():
                continue
            value = json.loads(line)
            if not isinstance(value, dict):
                raise ValueError(f"expected a JSON object at {path}:{line_number}")
            yield value


def read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"expected a JSON object: {path}")
    return value


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def sha256_json(value: Any) -> str:
    payload = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def unique_index(
    rows: Sequence[Mapping[str, Any]], key: str, *, source: str
) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    for row in rows:
        identity = str(row.get(key) or "")
        if not identity or identity in result:
            raise ValueError(f"{source} contains an empty or duplicate {key}: {identity!r}")
        result[identity] = dict(row)
    return result


def load_benchmark_common(knowledge_root: Path) -> ModuleType:
    path = knowledge_root / "benchmark" / "common.py"
    spec = importlib.util.spec_from_file_location("oceanagent_e2_benchmark_common", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot import benchmark safeguards from {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


@dataclass(frozen=True)
class VisibleKnowledgeView:
    target_split: str
    allowed_split_names: tuple[str, ...]
    allowed_source_group_ids: frozenset[str]
    blocked_source_group_ids: frozenset[str]
    problem_solution_cards: Mapping[str, Mapping[str, Any]]
    usage_bundle_cards: Mapping[str, Mapping[str, Any]]
    dataset_cards: Mapping[str, Mapping[str, Any]]
    audit: Mapping[str, Any]


def source_group_id(card: Mapping[str, Any]) -> str:
    return str(card.get("source_group_id") or card.get("paper_id") or "")


def split_group_sets(split_manifest: Mapping[str, Any]) -> dict[str, set[str]]:
    splits = split_manifest.get("splits")
    if not isinstance(splits, Mapping):
        raise ValueError("split_manifest.json has no splits object")
    result: dict[str, set[str]] = {}
    for split_name in ("train", "dev", "test"):
        item = splits.get(split_name)
        if not isinstance(item, Mapping):
            raise ValueError(f"split_manifest.json is missing {split_name!r}")
        groups = {str(value) for value in item.get("source_group_ids") or []}
        if not groups:
            raise ValueError(f"split {split_name!r} has no source_group_ids")
        result[split_name] = groups
    if any(
        result[left].intersection(result[right])
        for left, right in (("train", "dev"), ("train", "test"), ("dev", "test"))
    ):
        raise RuntimeError("source-group split leakage detected in split_manifest.json")
    return result


def build_visible_knowledge_view(
    knowledge_root: Path,
    *,
    target_split: str,
) -> VisibleKnowledgeView:
    if target_split not in SPLIT_PREDECESSORS:
        raise ValueError("formal E2 knowledge retrieval supports held-out dev or test only")
    knowledge_root = knowledge_root.resolve()
    benchmark_root = knowledge_root / "benchmark"
    cards_root = knowledge_root / "cards"

    common = load_benchmark_common(knowledge_root)
    # Keep this guard explicit.  Leakage PASS is valid only for the exact
    # canonical Card snapshot recorded by the Benchmark build.
    source_snapshot_audit = common.require_source_snapshot_current(
        benchmark_root=benchmark_root,
        repository_root=knowledge_root,
    )
    leakage_audit = common.require_leakage_pass(benchmark_root=benchmark_root)
    split_manifest_path = benchmark_root / "splits" / "split_manifest.json"
    split_manifest = read_json(split_manifest_path)
    groups_by_split = split_group_sets(split_manifest)

    psc_path = cards_root / "problem_solution_cards.jsonl"
    ubc_path = cards_root / "usage_bundle_cards.jsonl"
    dataset_path = cards_root / "dataset_cards.jsonl"
    all_psc = list(iter_jsonl(psc_path))
    all_ubc = unique_index(
        list(iter_jsonl(ubc_path)),
        "bundle_id",
        source="UsageBundleCard",
    )
    all_datasets = unique_index(
        list(iter_jsonl(dataset_path)),
        "dataset_id",
        source="DatasetCard",
    )

    all_psc_source_groups: set[str] = set()
    for card in all_psc:
        card_id = str(card.get("card_id") or "")
        group_id = source_group_id(card)
        if not card_id or not group_id:
            raise ValueError("ProblemSolutionCard is missing card_id or source-group identity")
        all_psc_source_groups.add(group_id)

    benchmark_groups = set().union(*groups_by_split.values())
    auxiliary_groups = all_psc_source_groups - benchmark_groups
    allowed_split_names = SPLIT_PREDECESSORS[target_split]
    visible_benchmark_groups = set().union(
        *(groups_by_split[name] for name in allowed_split_names)
    )
    blocked_groups = set().union(
        *(groups_by_split[name] for name in BLOCKED_SPLITS[target_split])
    )
    auxiliary_blocked_overlap = auxiliary_groups.intersection(blocked_groups)
    if auxiliary_blocked_overlap:
        raise RuntimeError(
            "auxiliary source groups overlap benchmark held-out groups: "
            f"{sorted(auxiliary_blocked_overlap)[:10]}"
        )
    visible_groups = visible_benchmark_groups.union(auxiliary_groups)
    if visible_groups.intersection(blocked_groups):
        raise RuntimeError("visible and blocked source-group sets overlap")

    expected_visible_benchmark = set().union(
        *(groups_by_split[name] for name in allowed_split_names)
    )
    if not expected_visible_benchmark.issubset(visible_groups):
        raise RuntimeError("visible knowledge is missing an allowed benchmark source group")
    if not auxiliary_groups.issubset(visible_groups):
        raise RuntimeError("visible knowledge is missing an auxiliary source group")

    visible_psc_rows: list[dict[str, Any]] = []
    blocked_psc_rows: list[dict[str, Any]] = []
    unclassified_psc_ids: list[str] = []
    for card in all_psc:
        card_id = str(card.get("card_id") or "")
        group_id = source_group_id(card)
        if group_id in visible_groups:
            visible_psc_rows.append(dict(card))
        elif group_id in blocked_groups:
            blocked_psc_rows.append(dict(card))
        else:
            unclassified_psc_ids.append(card_id)
    if unclassified_psc_ids:
        raise RuntimeError(
            "ProblemSolutionCards were not classified as visible or blocked: "
            f"{unclassified_psc_ids[:10]}"
        )
    visible_psc = unique_index(
        visible_psc_rows,
        "card_id",
        source="visible ProblemSolutionCard corpus",
    )

    visible_bundle_ids = {str(card.get("bundle_id") or "") for card in visible_psc.values()}
    if "" in visible_bundle_ids:
        raise ValueError("visible ProblemSolutionCard is missing bundle_id")
    blocked_bundle_ids = {
        str(card.get("bundle_id") or "")
        for card in all_psc
        if source_group_id(card) in blocked_groups
    }
    overlap = visible_bundle_ids.intersection(blocked_bundle_ids)
    if overlap:
        raise RuntimeError(
            "a UsageBundleCard is linked from both visible and blocked source groups: "
            f"{sorted(overlap)[:10]}"
        )
    missing_bundles = sorted(visible_bundle_ids - set(all_ubc))
    if missing_bundles:
        raise RuntimeError(f"visible PSC references unknown UBC IDs: {missing_bundles[:10]}")
    visible_ubc = {
        bundle_id: all_ubc[bundle_id]
        for bundle_id in sorted(visible_bundle_ids)
    }

    leaked_psc = sorted(
        card_id
        for card_id, card in visible_psc.items()
        if source_group_id(card) in blocked_groups
    )
    leaked_ubc = sorted(set(visible_ubc).intersection(blocked_bundle_ids))
    if leaked_psc or leaked_ubc:
        raise RuntimeError(
            "source-group filtering failed; blocked knowledge entered the visible view: "
            f"psc={leaked_psc[:10]}, ubc={leaked_ubc[:10]}"
        )

    # DatasetCards are shared across splits, but their source quotations may
    # cite a held-out paper's exact dataset use. Keep product metadata visible
    # while excluding that task-level evidence from structured retrieval/RTC.
    blocked_source_ids = {
        str(card["paper_id"]) for card in blocked_psc_rows if card.get("paper_id")
    }
    visible_datasets: dict[str, dict[str, Any]] = {}
    redacted_dataset_source_count = 0
    redacted_dataset_ids: list[str] = []
    for dataset_id, card in all_datasets.items():
        visible_card = dict(card)
        sources = card.get("sources")
        if isinstance(sources, list):
            retained_sources = [
                source
                for source in sources
                if not (
                    isinstance(source, Mapping)
                    and str(source.get("source_id") or "") in blocked_source_ids
                )
            ]
            removed = len(sources) - len(retained_sources)
            if removed:
                visible_card["sources"] = retained_sources
                redacted_dataset_source_count += removed
                redacted_dataset_ids.append(dataset_id)
        visible_datasets[dataset_id] = visible_card

    if any(
        isinstance(source, Mapping)
        and str(source.get("source_id") or "") in blocked_source_ids
        for card in visible_datasets.values()
        for source in (card.get("sources") or [])
    ):
        raise RuntimeError("held-out paper evidence remains in visible DatasetCards")

    audit = {
        "schema_version": "1.0",
        "policy": VISIBLE_KNOWLEDGE_POLICY_VERSION,
        "target_split": target_split,
        "allowed_split_names": list(allowed_split_names),
        "allowed_source_group_count": len(visible_groups),
        "benchmark_train_source_group_count": len(groups_by_split["train"]),
        "benchmark_dev_source_group_count": len(groups_by_split["dev"]),
        "benchmark_test_source_group_count": len(groups_by_split["test"]),
        "auxiliary_source_group_count": len(auxiliary_groups),
        "visible_auxiliary_source_group_count": len(
            auxiliary_groups.intersection(visible_groups)
        ),
        "blocked_source_group_count": len(blocked_groups),
        "visible_psc_count": len(visible_psc),
        "blocked_psc_count": len(blocked_psc_rows),
        "visible_ubc_count": len(visible_ubc),
        "visible_dataset_card_count": len(visible_datasets),
        "dataset_source_evidence_filter": "heldout-paper-source-id-v1",
        "redacted_dataset_source_evidence_count": redacted_dataset_source_count,
        "redacted_dataset_card_count": len(redacted_dataset_ids),
        "auxiliary_source_group_ids_sha256": sha256_json(sorted(auxiliary_groups)),
        "visible_psc_ids_sha256": sha256_json(sorted(visible_psc)),
        "visible_ubc_ids_sha256": sha256_json(sorted(visible_ubc)),
        "visible_dataset_ids_sha256": sha256_json(sorted(all_datasets)),
        "visible_dataset_cards_sha256": sha256_json(visible_datasets),
        "canonical_input_sha256": {
            "problem_solution_cards": sha256_file(psc_path),
            "usage_bundle_cards": sha256_file(ubc_path),
            "dataset_cards": sha256_file(dataset_path),
            "split_manifest": sha256_file(split_manifest_path),
        },
        "benchmark_leakage_audit_status": leakage_audit.get("status"),
        "source_snapshot_audit": source_snapshot_audit,
        "blocked_knowledge_detected": False,
    }
    return VisibleKnowledgeView(
        target_split=target_split,
        allowed_split_names=tuple(allowed_split_names),
        allowed_source_group_ids=frozenset(visible_groups),
        blocked_source_group_ids=frozenset(blocked_groups),
        problem_solution_cards=visible_psc,
        usage_bundle_cards=visible_ubc,
        dataset_cards=visible_datasets,
        audit=audit,
    )


def recommender_payload_extension(
    *,
    condition_id: str,
    budgeted_knowledge_context: Mapping[str, Any],
) -> dict[str, Any]:
    if condition_id not in {"A0", "A1", "A2"}:
        raise ValueError(f"unknown E2 condition: {condition_id}")
    return {
        "structured_knowledge_context": dict(budgeted_knowledge_context),
    }
