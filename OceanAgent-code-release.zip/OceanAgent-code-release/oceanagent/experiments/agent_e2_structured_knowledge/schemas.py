from __future__ import annotations

from dataclasses import asdict, dataclass
from enum import Enum
from pathlib import Path
from typing import Any, Mapping


VISIBLE_KNOWLEDGE_POLICY_VERSION = "heldout-blocked-plus-auxiliary-v2"


class ConditionId(str, Enum):
    A0 = "A0"
    A1 = "A1"
    A2 = "A2"


class AblationId(str, Enum):
    C0 = "C0"
    C1 = "C1"
    C2 = "C2"
    C3 = "C3"
    C4 = "C4"


@dataclass(frozen=True)
class KnowledgeAccessPolicy:
    condition_id: ConditionId
    dataset_cards: bool
    problem_solution_cards: bool
    usage_bundle_cards: bool
    requirement_trace_context: bool


@dataclass(frozen=True)
class AblationSwitches:
    ablation_id: AblationId
    requirement_decomposition: bool
    capability_reranking: bool
    bundle_composition: bool
    compatibility_check: bool


@dataclass(frozen=True)
class ParityContract:
    backbone_model: str | None
    model_version: str | None
    fixed_task_spec_source: str
    fixed_task_spec_sha256: str | None
    dataset_corpus_sha256: str | None
    recommender_prompt_version: str
    top_k: int
    temperature: float
    context_token_budget: int
    output_token_budget: int
    tokenizer_version: str
    ranking_chain_version: str
    output_schema_path: str


@dataclass(frozen=True)
class ExperimentPlan:
    experiment_id: str
    split: str
    condition: KnowledgeAccessPolicy
    ablation: AblationSwitches
    parity_contract: ParityContract
    execution_enabled: bool

    def to_dict(self) -> dict[str, Any]:
        condition = asdict(self.condition)
        condition["condition_id"] = self.condition.condition_id.value
        ablation = asdict(self.ablation)
        ablation["ablation_id"] = self.ablation.ablation_id.value
        return {
            "experiment_id": self.experiment_id,
            "split": self.split,
            "condition": condition,
            "ablation": ablation,
            "parity_contract": asdict(self.parity_contract),
            "execution_enabled": self.execution_enabled,
        }


def knowledge_policy(config: Mapping[str, Any], condition_id: str) -> KnowledgeAccessPolicy:
    try:
        condition = ConditionId(condition_id)
    except ValueError as exc:
        raise ValueError(f"unknown E2 condition: {condition_id}") from exc
    raw = config["conditions"][condition.value]["knowledge_access"]
    policy = KnowledgeAccessPolicy(
        condition_id=condition,
        dataset_cards=bool(raw["dataset_cards"]),
        problem_solution_cards=bool(raw["problem_solution_cards"]),
        usage_bundle_cards=bool(raw["usage_bundle_cards"]),
        requirement_trace_context=bool(raw["requirement_trace_context"]),
    )
    expected = {
        ConditionId.A0: (True, False, False, False),
        ConditionId.A1: (True, True, True, False),
        ConditionId.A2: (True, True, True, True),
    }[condition]
    observed = (
        policy.dataset_cards,
        policy.problem_solution_cards,
        policy.usage_bundle_cards,
        policy.requirement_trace_context,
    )
    if observed != expected:
        raise ValueError(
            f"{condition.value} knowledge scope violates the locked E2 definition: {observed}"
        )
    return policy


def ablation_switches(config: Mapping[str, Any], ablation_id: str) -> AblationSwitches:
    try:
        ablation = AblationId(ablation_id)
    except ValueError as exc:
        raise ValueError(f"unknown E2 ablation: {ablation_id}") from exc
    raw = config["ablations"][ablation.value]
    switches = AblationSwitches(
        ablation_id=ablation,
        requirement_decomposition=bool(raw["requirement_decomposition"]),
        capability_reranking=bool(raw["capability_reranking"]),
        bundle_composition=bool(raw["bundle_composition"]),
        compatibility_check=bool(raw["compatibility_check"]),
    )
    expected = {
        AblationId.C0: (False, False, False, False),
        AblationId.C1: (True, False, False, False),
        AblationId.C2: (True, True, False, False),
        AblationId.C3: (True, True, True, False),
        AblationId.C4: (True, True, True, True),
    }[ablation]
    observed = (
        switches.requirement_decomposition,
        switches.capability_reranking,
        switches.bundle_composition,
        switches.compatibility_check,
    )
    if observed != expected:
        raise ValueError(f"{ablation.value} switches violate the cumulative ablation design")
    return switches


def parity_contract(config: Mapping[str, Any], config_dir: Path) -> ParityContract:
    raw = config["parity_contract"]
    output_schema_path = (config_dir / str(raw["output_schema_path"])).resolve()
    contract = ParityContract(
        backbone_model=raw.get("backbone_model"),
        model_version=raw.get("model_version"),
        fixed_task_spec_source=str(raw["fixed_task_spec_source"]),
        fixed_task_spec_sha256=raw.get("fixed_task_spec_sha256"),
        dataset_corpus_sha256=raw.get("dataset_corpus_sha256"),
        recommender_prompt_version=str(raw["recommender_prompt_version"]),
        top_k=int(raw["top_k"]),
        temperature=float(raw["temperature"]),
        context_token_budget=int(raw["context_token_budget"]),
        output_token_budget=int(raw["output_token_budget"]),
        tokenizer_version=str(raw["tokenizer_version"]),
        ranking_chain_version=str(raw["ranking_chain_version"]),
        output_schema_path=str(output_schema_path),
    )
    if contract.top_k != 10:
        raise ValueError("E2 fixes K=10")
    if contract.temperature != 0.0:
        raise ValueError("E2 fixes temperature=0")
    if contract.context_token_budget <= contract.output_token_budget:
        raise ValueError("E2 total context budget must exceed its output token budget")
    if not contract.tokenizer_version or not contract.ranking_chain_version:
        raise ValueError("E2 tokenizer and ranking-chain versions must be frozen")
    if contract.tokenizer_version != "deterministic-mixed-regex-v1":
        raise ValueError("E2 context accounting must use deterministic-mixed-regex-v1")
    if contract.fixed_task_spec_source != "e1_t1_predictions":
        raise ValueError("E2 must freeze the E1-T1 TaskSpec for all three conditions")
    if not output_schema_path.is_file():
        raise FileNotFoundError(f"shared recommendation schema is missing: {output_schema_path}")
    return contract


def build_plan(
    config: Mapping[str, Any],
    config_path: Path,
    *,
    condition_id: str,
    ablation_id: str,
    split: str,
) -> ExperimentPlan:
    if bool(config.get("execution_enabled", False)):
        raise RuntimeError(
            "Agent-E2 execution remains disabled; this scaffold may only build or audit plans"
        )
    if config.get("confirmatory_comparisons") != ["A1-A0", "A2-A1"]:
        raise ValueError("E2 confirmatory comparisons must be exactly A1-A0 and A2-A1")
    visible = config.get("visible_knowledge")
    if not isinstance(visible, Mapping) or visible.get("dev_allowed_splits") != ["train"]:
        raise ValueError("E2 dev knowledge view must contain train benchmark sources")
    if visible.get("test_allowed_splits") != ["train", "dev"]:
        raise ValueError("E2 test knowledge view must contain train+dev benchmark sources")
    if visible.get("policy_version") != VISIBLE_KNOWLEDGE_POLICY_VERSION:
        raise ValueError("E2 visible-knowledge policy version is not frozen correctly")
    if visible.get("auxiliary_source_groups_visible") is not True:
        raise ValueError("E2 visible knowledge must include auxiliary source groups")
    if visible.get("heldout_source_groups_blocked") is not True:
        raise ValueError("E2 visible knowledge must block held-out benchmark source groups")
    if visible.get("require_source_snapshot_current") is not True:
        raise ValueError("E2 must fail closed on a stale canonical Card snapshot")
    if visible.get("require_benchmark_leakage_pass") is not True:
        raise ValueError("E2 requires the existing Benchmark leakage audit to pass")
    contract = parity_contract(config, config_path.parent)
    rtc_reserved = int(config["rtc"]["reserved_token_budget"])
    if rtc_reserved <= 0 or rtc_reserved >= (
        contract.context_token_budget - contract.output_token_budget
    ):
        raise ValueError("RTC reserved budget must fit inside the shared input budget")
    return ExperimentPlan(
        experiment_id=str(config["experiment_id"]),
        split=split,
        condition=knowledge_policy(config, condition_id),
        ablation=ablation_switches(config, ablation_id),
        parity_contract=contract,
        execution_enabled=bool(config.get("execution_enabled", False)),
    )

