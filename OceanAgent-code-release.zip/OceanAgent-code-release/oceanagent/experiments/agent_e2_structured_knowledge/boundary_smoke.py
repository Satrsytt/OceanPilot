from __future__ import annotations

from collections import Counter
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping, Sequence

from context_budget import sha256_json
from requirement_retrieval import decompose_task_spec


BOUNDARY_SMOKE_SELECTOR_VERSION = "dev-four-factor-rank-sum-v1"
BOUNDARY_SMOKE_AUDIT_VERSION = "boundary-smoke-attempt-audit-v1"
BOUNDARY_SMOKE_QUERY_COUNT = 10
MANDATORY_BOUNDARY_QUERY_IDS = (
    "query_9d55905c37458cc5",
    "query_ab06b134f928152d",
)
RISK_METRICS = (
    "formal_requirement_count",
    "task_spec_serialized_token_count",
    "a2_input_token_count",
    "output_pressure",
)


def _unique_descending_ranks(values: Mapping[str, Any]) -> dict[str, int]:
    ordered_values = sorted(set(values.values()), reverse=True)
    value_ranks = {value: index for index, value in enumerate(ordered_values, start=1)}
    return {query_id: value_ranks[value] for query_id, value in values.items()}


def build_boundary_smoke_selection(
    *,
    split_query_ids: Sequence[str],
    task_specs: Mapping[str, Mapping[str, Any]],
    preflight_rows: Mapping[str, Mapping[str, Any]],
    token_counter: Callable[[Any], int],
    source_fingerprints: Mapping[str, str],
) -> dict[str, Any]:
    query_ids = [str(item) for item in split_query_ids]
    if len(query_ids) != 108 or len(query_ids) != len(set(query_ids)):
        raise ValueError("boundary smoke requires exactly 108 unique DEV query IDs")
    if set(task_specs) != set(query_ids):
        raise ValueError("frozen TaskSpecs do not exactly match the DEV split")
    if set(preflight_rows) != set(query_ids):
        raise ValueError("preflight rows do not exactly match the DEV split")
    missing_mandatory = sorted(set(MANDATORY_BOUNDARY_QUERY_IDS) - set(query_ids))
    if missing_mandatory:
        raise ValueError(f"mandatory boundary queries are absent: {missing_mandatory}")

    metric_values: dict[str, dict[str, Any]] = {
        metric: {} for metric in RISK_METRICS
    }
    raw_audits: dict[str, dict[str, Any]] = {}
    for query_id in query_ids:
        row = preflight_rows[query_id]
        if row.get("status") != "success":
            raise ValueError(f"preflight row is not successful: {query_id}")
        condition_tokens = row.get("condition_input_token_counts")
        if not isinstance(condition_tokens, Mapping):
            raise ValueError(f"preflight row has no condition token audit: {query_id}")
        requirement_count = len(decompose_task_spec(task_specs[query_id]))
        task_spec_tokens = int(token_counter(task_specs[query_id]))
        a2_tokens = int(condition_tokens["A2"])
        worst_case_tokens = int(row["worst_case_output_token_count"])
        fixed_overhead_tokens = int(row["fixed_output_field_overhead_token_count"])
        output_pressure = (worst_case_tokens, fixed_overhead_tokens)
        metric_values["formal_requirement_count"][query_id] = requirement_count
        metric_values["task_spec_serialized_token_count"][query_id] = task_spec_tokens
        metric_values["a2_input_token_count"][query_id] = a2_tokens
        metric_values["output_pressure"][query_id] = output_pressure
        raw_audits[query_id] = {
            "formal_requirement_count": requirement_count,
            "task_spec_serialized_token_count": task_spec_tokens,
            "a2_input_token_count": a2_tokens,
            "worst_case_output_token_count": worst_case_tokens,
            "fixed_output_field_overhead_token_count": fixed_overhead_tokens,
        }

    metric_ranks = {
        metric: _unique_descending_ranks(values)
        for metric, values in metric_values.items()
    }
    aggregate_rank_sums = {
        query_id: sum(metric_ranks[metric][query_id] for metric in RISK_METRICS)
        for query_id in query_ids
    }
    risk_order = sorted(
        query_ids,
        key=lambda query_id: (
            aggregate_rank_sums[query_id],
            -raw_audits[query_id]["formal_requirement_count"],
            -raw_audits[query_id]["task_spec_serialized_token_count"],
            -raw_audits[query_id]["a2_input_token_count"],
            -raw_audits[query_id]["worst_case_output_token_count"],
            -raw_audits[query_id]["fixed_output_field_overhead_token_count"],
            query_id,
        ),
    )
    aggregate_positions = {
        query_id: index for index, query_id in enumerate(risk_order, start=1)
    }
    selected_query_ids = list(MANDATORY_BOUNDARY_QUERY_IDS)
    for query_id in risk_order:
        if query_id not in selected_query_ids:
            selected_query_ids.append(query_id)
        if len(selected_query_ids) == BOUNDARY_SMOKE_QUERY_COUNT:
            break
    if len(selected_query_ids) != BOUNDARY_SMOKE_QUERY_COUNT:
        raise RuntimeError("boundary selector did not produce exactly 10 queries")

    selected_queries: list[dict[str, Any]] = []
    for query_id in selected_query_ids:
        is_mandatory = query_id in MANDATORY_BOUNDARY_QUERY_IDS
        selected_queries.append(
            {
                "query_id": query_id,
                "selection_reason": (
                    "mandatory_prior_stable_failure"
                    if is_mandatory
                    else "highest_equal_weight_four_factor_rank_sum_after_deduplication"
                ),
                "mandatory": is_mandatory,
                "aggregate_risk_position": aggregate_positions[query_id],
                "aggregate_rank_sum": aggregate_rank_sums[query_id],
                "metric_values": raw_audits[query_id],
                "metric_ranks": {
                    metric: metric_ranks[metric][query_id]
                    for metric in RISK_METRICS
                },
            }
        )

    return {
        "schema_version": "1.0",
        "analysis_type": "e2_v4_boundary_smoke_selection",
        "engineering_validation_only": True,
        "formal_contract_mutated": False,
        "selector_version": BOUNDARY_SMOKE_SELECTOR_VERSION,
        "selection_algorithm": {
            "method": "equal-weight sum of descending dense ranks",
            "metric_order": list(RISK_METRICS),
            "output_pressure_order": [
                "worst_case_output_token_count",
                "fixed_output_field_overhead_token_count",
            ],
            "aggregate_tie_break": [
                "formal_requirement_count_desc",
                "task_spec_serialized_token_count_desc",
                "a2_input_token_count_desc",
                "worst_case_output_token_count_desc",
                "fixed_output_field_overhead_token_count_desc",
                "query_id_asc",
            ],
            "mandatory_query_ids_are_inserted_first": True,
        },
        "dev_query_count": len(query_ids),
        "selection_count": BOUNDARY_SMOKE_QUERY_COUNT,
        "conditions": ["A0", "A1", "A2"],
        "expected_work_unit_count": BOUNDARY_SMOKE_QUERY_COUNT * 3,
        "mandatory_query_ids": list(MANDATORY_BOUNDARY_QUERY_IDS),
        "selected_query_ids": selected_query_ids,
        "selected_queries": selected_queries,
        "all_query_risk_order": risk_order,
        "source_fingerprints": dict(source_fingerprints),
    }


def classify_attempt_failure(error_type: str, error: str) -> str:
    message = f"{error_type}: {error}".lower()
    if "invalid json" in message or "jsondecodeerror" in message:
        return "invalid_json"
    if "exceeds output token budget" in message:
        return "output_budget_violation"
    api_markers = (
        "transient api",
        "api http",
        "api connection",
        "api returned",
        "remote disconnected",
        "timed out",
        "timeout",
        "connection reset",
        "connection aborted",
        "broken pipe",
    )
    if any(marker in message for marker in api_markers):
        return "transport_api_failure"
    return "validation_or_other_failure"


def formal_contract_basis(run_contract: Mapping[str, Any]) -> dict[str, Any]:
    keys = (
        "runner_version",
        "experiment_id",
        "split",
        "model",
        "model_version",
        "base_url",
        "provider_identifier",
        "top_k",
        "temperature",
        "prompt_version",
        "system_prompt_sha256",
        "ranking_chain_version",
        "tokenizer_version",
        "context_budgeter_version",
        "candidate_context_representation_version",
        "context_token_budget",
        "output_token_budget",
        "rtc_reserved_token_budget",
        "candidate_pool_size",
        "dataset_retriever",
        "structured_retrieval",
        "task_spec_fingerprint",
        "dataset_corpus_fingerprint",
        "card_fingerprints",
        "split_manifest_fingerprint",
        "split_fingerprint",
        "split_query_ids_fingerprint",
        "recommendation_schema_fingerprint",
        "recommendation_schema_file_fingerprint",
        "locked_config_fingerprint",
        "frozen_task_specs_file_fingerprint",
        "conditions",
    )
    missing = [key for key in keys if key not in run_contract]
    if missing:
        raise ValueError("run contract is missing freeze fields: " + ", ".join(missing))
    return {key: run_contract[key] for key in keys}


def build_boundary_smoke_summary(
    *,
    selection: Mapping[str, Any],
    run_contract: Mapping[str, Any],
    predictions: Iterable[Mapping[str, Any]],
    failures: Iterable[Mapping[str, Any]],
) -> dict[str, Any]:
    selected_ids = [str(item) for item in selection["selected_query_ids"]]
    expected_units = {
        (query_id, condition_id)
        for query_id in selected_ids
        for condition_id in ("A0", "A1", "A2")
    }
    successful_units: set[tuple[str, str]] = set()
    prediction_rows = list(predictions)
    failure_rows = list(failures)
    for row in prediction_rows:
        key = (str(row.get("query_id") or ""), str(row.get("condition_id") or ""))
        if key not in expected_units or key in successful_units or row.get("status") != "success":
            raise ValueError(f"invalid boundary-smoke prediction work unit: {key}")
        successful_units.add(key)

    category_counts: Counter[str] = Counter()
    retry_count = 0
    attempted_invocation_count = 0
    for row in [*failure_rows, *prediction_rows]:
        audit = row.get("attempt_audit")
        if not isinstance(audit, Mapping):
            raise ValueError("boundary-smoke row is missing attempt_audit")
        attempted_invocation_count += 1
        retry_count += int(audit.get("retry_count") or 0)
        attempt_failures = audit.get("attempt_failures") or []
        if not isinstance(attempt_failures, list):
            raise ValueError("boundary-smoke attempt_failures is not an array")
        for failure in attempt_failures:
            if not isinstance(failure, Mapping):
                raise ValueError("boundary-smoke attempt failure is not an object")
            category = str(failure.get("category") or "")
            if category not in {
                "invalid_json",
                "output_budget_violation",
                "transport_api_failure",
                "validation_or_other_failure",
            }:
                raise ValueError(f"unknown boundary-smoke attempt failure category: {category}")
            category_counts[category] += 1

    success = successful_units == expected_units
    basis = formal_contract_basis(run_contract)
    return {
        "schema_version": "1.0",
        "analysis_type": "e2_v4_boundary_smoke_summary",
        "engineering_validation_only": True,
        "formal_paper_metric": False,
        "audit_version": BOUNDARY_SMOKE_AUDIT_VERSION,
        "selector_version": selection["selector_version"],
        "selection_sha256": sha256_json(selection),
        "selected_query_ids": selected_ids,
        "selected_queries": selection["selected_queries"],
        "expected_work_unit_count": len(expected_units),
        "successful_work_unit_count": len(successful_units),
        "success_30_of_30": success,
        "remaining_work_units": len(expected_units - successful_units),
        "invalid_json_count": category_counts["invalid_json"],
        "output_budget_violation_count": category_counts[
            "output_budget_violation"
        ],
        "transport_api_failure_count": category_counts["transport_api_failure"],
        "other_validation_failure_count": category_counts[
            "validation_or_other_failure"
        ],
        "retry_count": retry_count,
        "attempted_invocation_count": attempted_invocation_count,
        "failure_record_count": len(failure_rows),
        "currently_incomplete_work_units": [
            {"query_id": query_id, "condition_id": condition_id}
            for query_id, condition_id in sorted(expected_units - successful_units)
        ],
        "formal_contract_frozen": success,
        "formal_contract_basis": basis,
        "formal_contract_basis_sha256": sha256_json(basis),
        "run_contract_sha256": sha256_json(run_contract),
    }


def validate_formal_contract_freeze(
    freeze: Mapping[str, Any],
    run_contract: Mapping[str, Any],
) -> None:
    if freeze.get("formal_contract_frozen") is not True:
        raise RuntimeError("boundary smoke has not frozen the formal v4 contract")
    if freeze.get("success_30_of_30") is not True:
        raise RuntimeError("boundary smoke did not complete 30/30 work units")
    basis = formal_contract_basis(run_contract)
    if freeze.get("formal_contract_basis") != basis:
        raise RuntimeError("formal v4 contract differs from the boundary-smoke freeze")
    if freeze.get("formal_contract_basis_sha256") != sha256_json(basis):
        raise RuntimeError("boundary-smoke formal contract freeze hash is invalid")


def read_jsonl_rows(path: Path) -> list[dict[str, Any]]:
    import json

    rows: list[dict[str, Any]] = []
    if not path.is_file():
        return rows
    with path.open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, start=1):
            if not line.strip():
                continue
            value = json.loads(line)
            if not isinstance(value, dict):
                raise ValueError(f"expected object at {path}:{line_number}")
            rows.append(value)
    return rows
