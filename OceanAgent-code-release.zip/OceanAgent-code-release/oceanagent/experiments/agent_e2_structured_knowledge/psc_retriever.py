from __future__ import annotations

import math
import re
from collections import Counter
from dataclasses import asdict, dataclass
from typing import Any, Mapping, Sequence

from context_budget import sha256_json


TOKEN_PATTERN = re.compile(r"[a-z0-9]+(?:[._/-][a-z0-9]+)*", re.IGNORECASE)
RETRIEVER_VERSION = "e2-visible-psc-bm25-v1"


def tokens(value: str) -> list[str]:
    return TOKEN_PATTERN.findall(value.casefold())


def flatten_strings(value: Any) -> list[str]:
    if isinstance(value, str):
        return [value]
    if isinstance(value, Mapping):
        return [text for key in sorted(value) for text in flatten_strings(value[key])]
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
        return [text for item in value for text in flatten_strings(item)]
    return []


def task_spec_query(fixed_task_spec: Mapping[str, Any]) -> str:
    fields = (
        "research_goal",
        "research_domain",
        "target_outputs",
        "variables",
        "spatial_scope",
        "temporal_scope",
        "depth_scope",
        "methodological_constraints",
        "data_constraints",
        "validation_expectations",
        "retrieval_terms",
    )
    values = [fixed_task_spec.get(field) for field in fields]
    query = "\n".join(text for value in values for text in flatten_strings(value) if text)
    if not query.strip():
        raise ValueError("fixed ScientificTaskSpec contains no searchable text")
    return query


def psc_document(card: Mapping[str, Any]) -> str:
    evidence = card.get("evidence") if isinstance(card.get("evidence"), list) else []
    values = [
        card.get("research_field"),
        card.get("problem"),
        card.get("solution_summary"),
        [
            {
                "page_or_section": item.get("page_or_section"),
                "quote": item.get("quote"),
            }
            for item in evidence
            if isinstance(item, Mapping)
        ],
    ]
    return " ".join(text for value in values for text in flatten_strings(value) if text)


@dataclass(frozen=True)
class PscSearchHit:
    rank: int
    card_id: str
    score: float
    retriever_version: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class PscSearchResult:
    task_spec_query_sha256: str
    visible_psc_ids_sha256: str
    hits: tuple[PscSearchHit, ...]

    def to_dict(self) -> dict[str, Any]:
        return {
            "task_spec_query_sha256": self.task_spec_query_sha256,
            "visible_psc_ids_sha256": self.visible_psc_ids_sha256,
            "hits": [hit.to_dict() for hit in self.hits],
        }


class VisiblePscBm25Retriever:
    def __init__(
        self,
        cards: Sequence[Mapping[str, Any]],
        *,
        k1: float = 1.5,
        b: float = 0.75,
    ) -> None:
        if not cards:
            raise ValueError("visible PSC corpus is empty")
        self.cards = [dict(card) for card in cards]
        self.k1 = float(k1)
        self.b = float(b)
        identities = [str(card.get("card_id") or "") for card in self.cards]
        if "" in identities or len(identities) != len(set(identities)):
            raise ValueError("visible PSC corpus contains empty or duplicate card IDs")
        self.visible_psc_ids_sha256 = sha256_json(sorted(identities))
        self.term_frequencies: list[Counter[str]] = []
        document_frequencies: Counter[str] = Counter()
        lengths: list[int] = []
        for card in self.cards:
            terms = tokens(psc_document(card))
            frequencies = Counter(terms)
            self.term_frequencies.append(frequencies)
            document_frequencies.update(frequencies.keys())
            lengths.append(len(terms))
        self.lengths = lengths
        self.average_length = sum(lengths) / len(lengths) if lengths else 1.0
        count = len(self.cards)
        self.idf = {
            term: math.log(1.0 + (count - frequency + 0.5) / (frequency + 0.5))
            for term, frequency in document_frequencies.items()
        }

    def search(
        self,
        fixed_task_spec: Mapping[str, Any],
        *,
        top_k: int,
        minimum_score: float = 0.0,
    ) -> PscSearchResult:
        if top_k <= 0:
            raise ValueError("PSC top_k must be positive")
        query = task_spec_query(fixed_task_spec)
        query_terms = Counter(tokens(query))
        scored: list[tuple[float, str]] = []
        for card, frequencies, document_length in zip(
            self.cards,
            self.term_frequencies,
            self.lengths,
        ):
            score = 0.0
            length_norm = 1.0 - self.b + self.b * document_length / self.average_length
            for term, query_frequency in query_terms.items():
                term_frequency = frequencies.get(term, 0)
                if not term_frequency:
                    continue
                numerator = term_frequency * (self.k1 + 1.0)
                denominator = term_frequency + self.k1 * length_norm
                score += self.idf.get(term, 0.0) * numerator / denominator * query_frequency
            if score > minimum_score:
                scored.append((score, str(card["card_id"])))
        scored.sort(key=lambda item: (-item[0], item[1]))
        hits = tuple(
            PscSearchHit(
                rank=rank,
                card_id=card_id,
                score=score,
                retriever_version=RETRIEVER_VERSION,
            )
            for rank, (score, card_id) in enumerate(scored[:top_k], start=1)
        )
        return PscSearchResult(
            task_spec_query_sha256=sha256_json(query),
            visible_psc_ids_sha256=self.visible_psc_ids_sha256,
            hits=hits,
        )
