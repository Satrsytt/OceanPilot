from __future__ import annotations

import hashlib
import json
import re
from dataclasses import asdict, dataclass
from typing import Any, Mapping, Sequence


TOKENIZER_VERSION = "deterministic-mixed-regex-v1"
CONTEXT_BUDGETER_VERSION = "deterministic-shared-slices-v2"
TOKEN_PATTERN = re.compile(
    r"[A-Za-z0-9]+(?:[._/-][A-Za-z0-9]+)*|[\u3400-\u4dbf\u4e00-\u9fff]|[^\s]",
    re.UNICODE,
)


def canonical_json(value: Any) -> str:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    )


def sha256_json(value: Any) -> str:
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def token_count(value: Any) -> int:
    return len(TOKEN_PATTERN.findall(canonical_json(value)))


def stable_evidence_id(value: Mapping[str, Any]) -> str:
    identity = {
        "provenance_kind": value.get("provenance_kind"),
        "source_type": value.get("source_type"),
        "source_id": value.get("source_id"),
        "page_or_section": value.get("page_or_section"),
        "quote": value.get("quote"),
        "url": value.get("url"),
        "source_field": value.get("source_field"),
        "origin_source_id": value.get("origin_source_id"),
        "text": value.get("text"),
    }
    return "evidence_" + sha256_json(identity)[:16]


@dataclass(frozen=True)
class ContextUnit:
    unit_id: str
    kind: str
    priority: int
    payload: Mapping[str, Any]
    evidence_ids: tuple[str, ...] = ()


@dataclass(frozen=True)
class BudgetedContext:
    condition_id: str
    context_budgeter_version: str
    tokenizer_version: str
    total_context_token_budget: int
    output_token_budget: int
    input_token_budget: int
    invariant_token_count: int
    knowledge_token_budget: int
    structured_knowledge_token_budget: int
    rtc_token_budget: int
    selected_knowledge_token_count: int
    selected_structured_token_count: int
    selected_rtc_token_count: int
    total_input_token_count: int
    remaining_input_tokens: int
    invariant_context_hash: str
    selected_unit_ids: tuple[str, ...]
    selected_structured_unit_ids: tuple[str, ...]
    selected_rtc_unit_ids: tuple[str, ...]
    selected_evidence_ids: tuple[str, ...]
    dropped_unit_ids: tuple[str, ...]
    context_hash: str
    selected_context: tuple[Mapping[str, Any], ...]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def validate_units(units: Sequence[ContextUnit]) -> None:
    identities = [unit.unit_id for unit in units]
    if any(not identity for identity in identities) or len(identities) != len(set(identities)):
        raise ValueError("context units contain an empty or duplicate unit_id")
    if any(unit.priority < 0 for unit in units):
        raise ValueError("context unit priority must be non-negative")


def select_units(
    units: Sequence[ContextUnit], token_limit: int
) -> tuple[list[ContextUnit], list[ContextUnit], int]:
    selected: list[ContextUnit] = []
    dropped: list[ContextUnit] = []
    used = 0
    for unit in sorted(units, key=lambda item: (item.priority, item.unit_id)):
        unit_tokens = token_count(unit.payload)
        if used + unit_tokens <= token_limit:
            selected.append(unit)
            used += unit_tokens
        else:
            dropped.append(unit)
    return selected, dropped, used


def build_budget_record(
    *,
    condition_id: str,
    invariant_context: Mapping[str, Any],
    total_context_token_budget: int,
    output_token_budget: int,
    knowledge_token_budget: int,
    structured_knowledge_token_budget: int,
    rtc_token_budget: int,
    selected_structured: Sequence[ContextUnit],
    selected_rtc: Sequence[ContextUnit],
    dropped: Sequence[ContextUnit],
) -> BudgetedContext:
    input_budget = total_context_token_budget - output_token_budget
    invariant_tokens = token_count(invariant_context)
    structured_used = sum(token_count(unit.payload) for unit in selected_structured)
    rtc_used = sum(token_count(unit.payload) for unit in selected_rtc)
    if structured_used > structured_knowledge_token_budget:
        raise RuntimeError("selected structured knowledge exceeds its reserved budget")
    if rtc_used > rtc_token_budget:
        raise RuntimeError("selected RTC knowledge exceeds its reserved budget")
    selected = [*selected_structured, *selected_rtc]
    used = structured_used + rtc_used
    if used > knowledge_token_budget:
        raise RuntimeError("selected knowledge exceeds the shared knowledge budget")
    selected_context = tuple(
        {
            "unit_id": unit.unit_id,
            "kind": unit.kind,
            "payload": dict(unit.payload),
        }
        for unit in selected
    )
    evidence_ids = tuple(
        sorted({evidence_id for unit in selected for evidence_id in unit.evidence_ids})
    )
    invariant_hash = sha256_json(invariant_context)
    context_hash = sha256_json(
        {
            "invariant_context_hash": invariant_hash,
            "selected_context": selected_context,
            "context_budgeter_version": CONTEXT_BUDGETER_VERSION,
            "tokenizer_version": TOKENIZER_VERSION,
        }
    )
    return BudgetedContext(
        condition_id=condition_id,
        context_budgeter_version=CONTEXT_BUDGETER_VERSION,
        tokenizer_version=TOKENIZER_VERSION,
        total_context_token_budget=total_context_token_budget,
        output_token_budget=output_token_budget,
        input_token_budget=input_budget,
        invariant_token_count=invariant_tokens,
        knowledge_token_budget=knowledge_token_budget,
        structured_knowledge_token_budget=structured_knowledge_token_budget,
        rtc_token_budget=rtc_token_budget,
        selected_knowledge_token_count=used,
        selected_structured_token_count=structured_used,
        selected_rtc_token_count=rtc_used,
        total_input_token_count=invariant_tokens + used,
        remaining_input_tokens=knowledge_token_budget - used,
        invariant_context_hash=invariant_hash,
        selected_unit_ids=tuple(unit.unit_id for unit in selected),
        selected_structured_unit_ids=tuple(unit.unit_id for unit in selected_structured),
        selected_rtc_unit_ids=tuple(unit.unit_id for unit in selected_rtc),
        selected_evidence_ids=evidence_ids,
        dropped_unit_ids=tuple(unit.unit_id for unit in dropped),
        context_hash=context_hash,
        selected_context=selected_context,
    )


def budget_context(
    *,
    condition_id: str,
    invariant_context: Mapping[str, Any],
    knowledge_units: Sequence[ContextUnit],
    total_context_token_budget: int,
    output_token_budget: int,
) -> BudgetedContext:
    if condition_id not in {"A0", "A1", "A2"}:
        raise ValueError(f"unknown E2 condition: {condition_id}")
    if total_context_token_budget <= 0 or output_token_budget <= 0:
        raise ValueError("context and output budgets must be positive")
    if output_token_budget >= total_context_token_budget:
        raise ValueError("output token budget must be smaller than total context budget")
    validate_units(knowledge_units)

    input_budget = total_context_token_budget - output_token_budget
    invariant_tokens = token_count(invariant_context)
    if invariant_tokens > input_budget:
        raise RuntimeError(
            "invariant prompt/TaskSpec/DatasetCard context exceeds the shared input budget"
        )
    knowledge_budget = input_budget - invariant_tokens
    selected, dropped, _ = select_units(knowledge_units, knowledge_budget)
    return build_budget_record(
        condition_id=condition_id,
        invariant_context=invariant_context,
        total_context_token_budget=total_context_token_budget,
        output_token_budget=output_token_budget,
        knowledge_token_budget=knowledge_budget,
        structured_knowledge_token_budget=knowledge_budget,
        rtc_token_budget=0,
        selected_structured=selected,
        selected_rtc=(),
        dropped=dropped,
    )


def budget_e2_condition_contexts(
    *,
    invariant_context: Mapping[str, Any],
    structured_units: Sequence[ContextUnit],
    rtc_units: Sequence[ContextUnit],
    total_context_token_budget: int,
    output_token_budget: int,
    rtc_reserved_token_budget: int,
) -> dict[str, BudgetedContext]:
    if total_context_token_budget <= 0 or output_token_budget <= 0:
        raise ValueError("context and output budgets must be positive")
    if output_token_budget >= total_context_token_budget:
        raise ValueError("output token budget must be smaller than total context budget")
    validate_units(structured_units)
    validate_units(rtc_units)
    all_ids = [unit.unit_id for unit in (*structured_units, *rtc_units)]
    if len(all_ids) != len(set(all_ids)):
        raise ValueError("structured and RTC context unit IDs overlap")
    input_budget = total_context_token_budget - output_token_budget
    invariant_tokens = token_count(invariant_context)
    if invariant_tokens > input_budget:
        raise RuntimeError(
            "invariant prompt/TaskSpec/DatasetCard context exceeds the shared input budget"
        )
    knowledge_budget = input_budget - invariant_tokens
    if rtc_reserved_token_budget < 0:
        raise ValueError("RTC reserved budget must be non-negative")
    rtc_budget = min(rtc_reserved_token_budget, knowledge_budget)
    structured_budget = knowledge_budget - rtc_budget
    selected_structured, dropped_structured, _ = select_units(
        structured_units,
        structured_budget,
    )
    selected_rtc, dropped_rtc, _ = select_units(rtc_units, rtc_budget)
    if structured_units and not selected_structured:
        raise RuntimeError("shared structured-knowledge slice cannot fit any context unit")
    if rtc_units and not selected_rtc:
        raise RuntimeError("reserved RTC slice cannot fit any supported requirement trace")
    records = {
        "A0": build_budget_record(
            condition_id="A0",
            invariant_context=invariant_context,
            total_context_token_budget=total_context_token_budget,
            output_token_budget=output_token_budget,
            knowledge_token_budget=knowledge_budget,
            structured_knowledge_token_budget=structured_budget,
            rtc_token_budget=rtc_budget,
            selected_structured=(),
            selected_rtc=(),
            dropped=(),
        ),
        "A1": build_budget_record(
            condition_id="A1",
            invariant_context=invariant_context,
            total_context_token_budget=total_context_token_budget,
            output_token_budget=output_token_budget,
            knowledge_token_budget=knowledge_budget,
            structured_knowledge_token_budget=structured_budget,
            rtc_token_budget=rtc_budget,
            selected_structured=selected_structured,
            selected_rtc=(),
            dropped=dropped_structured,
        ),
        "A2": build_budget_record(
            condition_id="A2",
            invariant_context=invariant_context,
            total_context_token_budget=total_context_token_budget,
            output_token_budget=output_token_budget,
            knowledge_token_budget=knowledge_budget,
            structured_knowledge_token_budget=structured_budget,
            rtc_token_budget=rtc_budget,
            selected_structured=selected_structured,
            selected_rtc=selected_rtc,
            dropped=[*dropped_structured, *dropped_rtc],
        ),
    }
    validate_condition_budget_parity(records)
    return records


def validate_condition_budget_parity(
    records: Mapping[str, BudgetedContext],
) -> dict[str, Any]:
    if set(records) != {"A0", "A1", "A2"}:
        raise ValueError("budget parity requires exactly A0, A1, and A2 records")
    fields = (
        "context_budgeter_version",
        "tokenizer_version",
        "total_context_token_budget",
        "output_token_budget",
        "input_token_budget",
        "invariant_token_count",
        "knowledge_token_budget",
        "structured_knowledge_token_budget",
        "rtc_token_budget",
        "invariant_context_hash",
    )
    mismatches: dict[str, dict[str, Any]] = {}
    for field in fields:
        values = {condition: getattr(record, field) for condition, record in records.items()}
        if len(set(values.values())) != 1:
            mismatches[field] = values
    over_budget = {
        condition: record.total_input_token_count
        for condition, record in records.items()
        if record.total_input_token_count > record.input_token_budget
    }
    if mismatches or over_budget:
        raise RuntimeError(
            f"A0/A1/A2 context budget parity failed: mismatches={mismatches}, "
            f"over_budget={over_budget}"
        )
    if records["A0"].selected_unit_ids:
        raise RuntimeError("A0 must not contain structured knowledge units")
    if records["A1"].selected_rtc_unit_ids:
        raise RuntimeError("A1 must not contain RTC units")
    if (
        records["A1"].selected_structured_unit_ids
        != records["A2"].selected_structured_unit_ids
    ):
        raise RuntimeError("A1/A2 structured knowledge slices differ")
    a1_structured_context = records["A1"].selected_context
    a2_structured_context = records["A2"].selected_context[
        : len(records["A2"].selected_structured_unit_ids)
    ]
    if canonical_json(a1_structured_context) != canonical_json(a2_structured_context):
        raise RuntimeError("A1/A2 structured knowledge payloads are not byte-identical")
    structured_slice_sha256 = sha256_json(a1_structured_context)
    return {
        "status": "pass",
        "a1_a2_structured_slice_identical": True,
        "structured_slice_sha256": structured_slice_sha256,
        "shared_fields": {
            field: getattr(records["A0"], field)
            for field in fields
        },
        "condition_token_counts": {
            condition: {
                "total_input_token_count": record.total_input_token_count,
                "selected_knowledge_token_count": record.selected_knowledge_token_count,
                "selected_structured_token_count": record.selected_structured_token_count,
                "selected_rtc_token_count": record.selected_rtc_token_count,
                "selected_evidence_ids": list(record.selected_evidence_ids),
                "context_hash": record.context_hash,
            }
            for condition, record in records.items()
        },
    }
