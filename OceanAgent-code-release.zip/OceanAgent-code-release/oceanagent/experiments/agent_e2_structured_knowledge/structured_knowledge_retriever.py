from __future__ import annotations

from dataclasses import asdict, dataclass
import json
from typing import Any, Mapping, Sequence

from context_budget import ContextUnit, sha256_json, stable_evidence_id
from knowledge_access import VisibleKnowledgeView
from psc_retriever import PscSearchResult, VisiblePscBm25Retriever


EXPANSION_VERSION = "psc-ubc-datasetcard-exact-audited-compact-v2"

STRUCTURED_TEXT_MAX_CHARS = 360
STRUCTURED_LONG_TEXT_MAX_CHARS = 640
STRUCTURED_LIST_MAX_ITEMS = 8
STRUCTURED_USAGE_MAX_ITEMS = 8
STRUCTURED_STEP_MAX_ITEMS = 10
STRUCTURED_RELATION_MAX_ITEMS = 8
STRUCTURED_FIELD_MAX_ITEMS = 12


@dataclass(frozen=True)
class ExpansionEdge:
    source_type: str
    source_id: str
    relation: str
    target_type: str
    target_id: str


@dataclass(frozen=True)
class UnresolvedDatasetReference:
    bundle_id: str
    usage_id: str
    dataset_id: str


@dataclass(frozen=True)
class StructuredKnowledgeResult:
    search: PscSearchResult
    problem_solution_cards: tuple[Mapping[str, Any], ...]
    usage_bundle_cards: tuple[Mapping[str, Any], ...]
    dataset_cards: tuple[Mapping[str, Any], ...]
    expansion_edges: tuple[ExpansionEdge, ...]
    unresolved_dataset_references: tuple[UnresolvedDatasetReference, ...]
    retrieval_hash: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": "1.0",
            "expansion_version": EXPANSION_VERSION,
            "search": self.search.to_dict(),
            "problem_solution_cards": [dict(item) for item in self.problem_solution_cards],
            "usage_bundle_cards": [dict(item) for item in self.usage_bundle_cards],
            "dataset_cards": [dict(item) for item in self.dataset_cards],
            "expansion_edges": [asdict(item) for item in self.expansion_edges],
            "unresolved_dataset_references": [
                asdict(item) for item in self.unresolved_dataset_references
            ],
            "unresolved_reference_count": len(self.unresolved_dataset_references),
            "retrieval_hash": self.retrieval_hash,
        }


def retrieve_structured_knowledge(
    fixed_task_spec: Mapping[str, Any],
    visible_view: VisibleKnowledgeView,
    *,
    psc_top_k: int,
    k1: float = 1.5,
    b: float = 0.75,
    minimum_score: float = 0.0,
) -> StructuredKnowledgeResult:
    serialized_task_spec = json.dumps(
        fixed_task_spec,
        ensure_ascii=False,
        sort_keys=True,
    ).casefold()
    leaked_link_ids = sorted(
        identity
        for identity in (
            *visible_view.problem_solution_cards.keys(),
            *visible_view.usage_bundle_cards.keys(),
        )
        if identity.casefold() in serialized_task_spec
    )
    if leaked_link_ids:
        raise ValueError(
            "fixed ScientificTaskSpec contains PSC/UBC link identifiers: "
            f"{leaked_link_ids[:10]}"
        )
    retriever = VisiblePscBm25Retriever(
        list(visible_view.problem_solution_cards.values()),
        k1=k1,
        b=b,
    )
    search = retriever.search(
        fixed_task_spec,
        top_k=psc_top_k,
        minimum_score=minimum_score,
    )
    psc_cards: list[dict[str, Any]] = []
    ubc_by_id: dict[str, dict[str, Any]] = {}
    dataset_by_id: dict[str, dict[str, Any]] = {}
    edges: list[ExpansionEdge] = []
    unresolved_references: list[UnresolvedDatasetReference] = []

    for hit in search.hits:
        psc = visible_view.problem_solution_cards.get(hit.card_id)
        if psc is None:
            raise RuntimeError(f"retriever returned a PSC outside the visible corpus: {hit.card_id}")
        psc_copy = dict(psc)
        psc_cards.append(psc_copy)
        bundle_id = str(psc_copy.get("bundle_id") or "")
        if not bundle_id:
            raise ValueError(f"retrieved PSC has no bundle_id: {hit.card_id}")
        ubc = visible_view.usage_bundle_cards.get(bundle_id)
        if ubc is None:
            raise RuntimeError(
                f"retrieved PSC cannot expand to a visible UsageBundleCard: {hit.card_id}"
            )
        ubc_by_id[bundle_id] = dict(ubc)
        edges.append(
            ExpansionEdge(
                "ProblemSolutionCard",
                hit.card_id,
                "bundle_id_exact",
                "UsageBundleCard",
                bundle_id,
            )
        )

    for bundle_id in sorted(ubc_by_id):
        ubc = ubc_by_id[bundle_id]
        data_usages = ubc.get("data_usages")
        if not isinstance(data_usages, list):
            raise ValueError(f"UsageBundleCard has invalid data_usages: {bundle_id}")
        for usage_index, usage in enumerate(data_usages, start=1):
            if not isinstance(usage, Mapping):
                raise ValueError(f"UsageBundleCard contains a non-object data usage: {bundle_id}")
            dataset_id = str(usage.get("dataset_id") or "")
            if not dataset_id:
                raise ValueError(f"UsageBundleCard data usage has no dataset_id: {bundle_id}")
            dataset = visible_view.dataset_cards.get(dataset_id)
            if dataset is None:
                unresolved_references.append(
                    UnresolvedDatasetReference(
                        bundle_id=bundle_id,
                        usage_id=str(usage.get("usage_id") or f"usage_{usage_index:04d}"),
                        dataset_id=dataset_id,
                    )
                )
                continue
            dataset_by_id[dataset_id] = dict(dataset)
            edges.append(
                ExpansionEdge(
                    "UsageBundleCard",
                    bundle_id,
                    "data_usages.dataset_id_exact",
                    "DatasetCard",
                    dataset_id,
                )
            )

    audit_payload = {
        "search": search.to_dict(),
        "psc_ids": [str(card["card_id"]) for card in psc_cards],
        "ubc_ids": sorted(ubc_by_id),
        "dataset_ids": sorted(dataset_by_id),
        "edges": [asdict(edge) for edge in edges],
        "unresolved_dataset_references": [
            asdict(item) for item in unresolved_references
        ],
        "unresolved_reference_count": len(unresolved_references),
        "visible_view_hashes": {
            "psc": visible_view.audit["visible_psc_ids_sha256"],
            "ubc": visible_view.audit["visible_ubc_ids_sha256"],
            "dataset": visible_view.audit["visible_dataset_ids_sha256"],
        },
    }
    return StructuredKnowledgeResult(
        search=search,
        problem_solution_cards=tuple(psc_cards),
        usage_bundle_cards=tuple(ubc_by_id[key] for key in sorted(ubc_by_id)),
        dataset_cards=tuple(dataset_by_id[key] for key in sorted(dataset_by_id)),
        expansion_edges=tuple(edges),
        unresolved_dataset_references=tuple(unresolved_references),
        retrieval_hash=sha256_json(audit_payload),
    )


def bounded_text(value: Any, max_chars: int = STRUCTURED_TEXT_MAX_CHARS) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    if not text:
        return None
    return text[:max_chars]


def compact_value(
    value: Any,
    *,
    string_limit: int = STRUCTURED_TEXT_MAX_CHARS,
    list_limit: int = STRUCTURED_LIST_MAX_ITEMS,
) -> Any:
    if isinstance(value, str):
        return bounded_text(value, string_limit)
    if isinstance(value, Mapping):
        return {
            str(key): compact_value(
                value[key],
                string_limit=string_limit,
                list_limit=list_limit,
            )
            for key in sorted(value)[:list_limit]
        }
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
        return [
            compact_value(item, string_limit=string_limit, list_limit=list_limit)
            for item in list(value)[:list_limit]
        ]
    if value is None or isinstance(value, (bool, int, float)):
        return value
    return bounded_text(value, string_limit)


def evidence_payload(
    *,
    source_type: str,
    source_id: str,
    source_field: str,
    value: Mapping[str, Any],
    provenance_kind: str,
) -> tuple[dict[str, Any], str]:
    if provenance_kind not in {"source_evidence", "card_field"}:
        raise ValueError(f"unknown provenance kind: {provenance_kind}")
    evidence = {
        "provenance_kind": provenance_kind,
        "source_type": source_type,
        "source_id": source_id,
        "source_field": source_field,
        "origin_source_id": bounded_text(value.get("source_id"), 160),
        "page_or_section": bounded_text(value.get("page_or_section"), 160),
        "quote": bounded_text(value.get("quote"), STRUCTURED_LONG_TEXT_MAX_CHARS),
        "url": bounded_text(value.get("url"), 320),
        "accessed_at": bounded_text(value.get("accessed_at"), 64),
        "text": bounded_text(value.get("text"), STRUCTURED_LONG_TEXT_MAX_CHARS),
    }
    evidence_id = stable_evidence_id(evidence)
    evidence["evidence_id"] = evidence_id
    return evidence, evidence_id


def field_evidence(
    *,
    source_type: str,
    source_id: str,
    source_field: str,
    text: str,
) -> tuple[dict[str, Any], str]:
    return evidence_payload(
        source_type=source_type,
        source_id=source_id,
        source_field=source_field,
        value={"text": text},
        provenance_kind="card_field",
    )


def nested_evidence_items(
    value: Any,
    *,
    path: str = "",
) -> list[tuple[str, Mapping[str, Any]]]:
    """Collect explicit evidence blocks without promoting surrounding card fields."""
    found: list[tuple[str, Mapping[str, Any]]] = []
    if isinstance(value, Mapping):
        for key in sorted(value):
            child = value[key]
            child_path = f"{path}.{key}" if path else str(key)
            if key == "evidence":
                items = child if isinstance(child, list) else [child]
                for index, item in enumerate(items):
                    if isinstance(item, Mapping):
                        found.append((f"{child_path}[{index}]", item))
            else:
                found.extend(nested_evidence_items(child, path=child_path))
    elif isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
        for index, item in enumerate(value):
            found.extend(nested_evidence_items(item, path=f"{path}[{index}]"))
    return found


def structured_context_units(result: StructuredKnowledgeResult) -> list[ContextUnit]:
    """Build deterministic, bounded model-visible units from the exact expansion result."""
    units: list[ContextUnit] = []
    unresolved_usage_keys = {
        (item.bundle_id, item.usage_id, item.dataset_id)
        for item in result.unresolved_dataset_references
    }

    for card in result.problem_solution_cards:
        card_id = str(card["card_id"])
        core = {
            "card_id": card_id,
            "problem": bounded_text(card.get("problem"), STRUCTURED_LONG_TEXT_MAX_CHARS),
            "solution_summary": bounded_text(
                card.get("solution_summary"),
                STRUCTURED_LONG_TEXT_MAX_CHARS,
            ),
            "bundle_id": bounded_text(card.get("bundle_id"), 240),
        }
        core_evidence, core_evidence_id = field_evidence(
            source_type="ProblemSolutionCard",
            source_id=card_id,
            source_field="problem+solution_summary",
            text=" ".join(str(value or "") for value in core.values()),
        )
        core["provenance"] = core_evidence
        units.append(ContextUnit(f"psc_core:{card_id}", "psc_core", 10, core, (core_evidence_id,)))
        for index, item in enumerate(card.get("evidence") or [], start=1):
            if not isinstance(item, Mapping):
                continue
            evidence, evidence_id = evidence_payload(
                source_type="ProblemSolutionCard",
                source_id=card_id,
                source_field=f"evidence[{index - 1}]",
                value=item,
                provenance_kind="source_evidence",
            )
            units.append(
                ContextUnit(
                    f"psc_evidence:{card_id}:{index:04d}",
                    "psc_evidence",
                    40,
                    evidence,
                    (evidence_id,),
                )
            )

    for card in result.usage_bundle_cards:
        bundle_id = str(card["bundle_id"])
        resolved_usages: list[Mapping[str, Any]] = []
        compact_usages: list[dict[str, Any]] = []
        resolved_usage_ids: set[str] = set()
        for index, usage in enumerate(card.get("data_usages") or [], start=1):
            if not isinstance(usage, Mapping):
                continue
            usage_id = str(usage.get("usage_id") or f"usage_{index:04d}")
            dataset_id = str(usage.get("dataset_id") or "")
            if (bundle_id, usage_id, dataset_id) in unresolved_usage_keys:
                continue
            resolved_usages.append(usage)
            resolved_usage_ids.add(usage_id)
            if len(compact_usages) < STRUCTURED_USAGE_MAX_ITEMS:
                compact_usages.append(
                    {
                        "usage_id": bounded_text(usage_id, 160),
                        "dataset_id": bounded_text(dataset_id, 240),
                        "role": bounded_text(usage.get("role"), 180),
                        "fields": compact_value(
                            usage.get("fields"),
                            string_limit=120,
                            list_limit=STRUCTURED_LIST_MAX_ITEMS,
                        ),
                        "subset": compact_value(
                            usage.get("subset"),
                            string_limit=180,
                            list_limit=6,
                        ),
                        "preprocessing": compact_value(
                            usage.get("preprocessing"),
                            string_limit=180,
                            list_limit=6,
                        ),
                        "quality_control": compact_value(
                            usage.get("quality_control"),
                            string_limit=180,
                            list_limit=6,
                        ),
                    }
                )

        compact_steps: list[dict[str, Any]] = []
        for index, step in enumerate(card.get("steps") or [], start=1):
            if not isinstance(step, Mapping):
                continue
            step_id = str(step.get("step_id") or f"step_{index:04d}")
            input_usage_ids = [
                str(item)
                for item in (step.get("input_usage_ids") or [])
                if str(item) in resolved_usage_ids
            ][:STRUCTURED_LIST_MAX_ITEMS]
            compact_steps.append(
                {
                    "step_id": bounded_text(step_id, 160),
                    "action": bounded_text(step.get("action"), STRUCTURED_TEXT_MAX_CHARS),
                    "input_usage_ids": input_usage_ids,
                    "depends_on_step_ids": compact_value(
                        step.get("depends_on_step_ids"),
                        string_limit=160,
                        list_limit=STRUCTURED_LIST_MAX_ITEMS,
                    ),
                    "output": bounded_text(step.get("output"), STRUCTURED_TEXT_MAX_CHARS),
                    "inference_status": bounded_text(step.get("inference_status"), 80),
                }
            )
            if len(compact_steps) >= STRUCTURED_STEP_MAX_ITEMS:
                break

        compact_relations: list[dict[str, Any]] = []
        for relation in card.get("data_relations") or []:
            if not isinstance(relation, Mapping):
                continue
            from_usage_id = str(relation.get("from_usage_id") or "")
            to_usage_id = str(relation.get("to_usage_id") or "")
            if from_usage_id not in resolved_usage_ids or to_usage_id not in resolved_usage_ids:
                continue
            compact_relations.append(
                {
                    "from_usage_id": bounded_text(from_usage_id, 160),
                    "to_usage_id": bounded_text(to_usage_id, 160),
                    "relation": bounded_text(relation.get("relation"), 160),
                    "reason": bounded_text(relation.get("reason"), STRUCTURED_TEXT_MAX_CHARS),
                    "alignment": bounded_text(
                        relation.get("alignment"),
                        STRUCTURED_TEXT_MAX_CHARS,
                    ),
                }
            )
            if len(compact_relations) >= STRUCTURED_RELATION_MAX_ITEMS:
                break

        core = {
            "bundle_id": bundle_id,
            "steps": compact_steps,
            "data_usages": compact_usages,
            "data_relations": compact_relations,
        }
        provenance, evidence_id = field_evidence(
            source_type="UsageBundleCard",
            source_id=bundle_id,
            source_field="steps+data_usages+data_relations",
            text=json_text(core),
        )
        core["provenance"] = provenance
        units.append(
            ContextUnit(
                f"ubc_core:{bundle_id}",
                "ubc_core",
                20,
                core,
                (evidence_id,),
            )
        )

        visible_card = dict(card)
        visible_card["data_usages"] = resolved_usages
        for evidence_index, (source_field, item) in enumerate(
            nested_evidence_items(visible_card), start=1
        ):
            evidence, item_id = evidence_payload(
                source_type="UsageBundleCard",
                source_id=bundle_id,
                source_field=source_field,
                value=item,
                provenance_kind="source_evidence",
            )
            units.append(
                ContextUnit(
                    f"ubc_source_evidence:{bundle_id}:{evidence_index:04d}",
                    "ubc_evidence",
                    35,
                    evidence,
                    (item_id,),
                )
            )

    for card in result.dataset_cards:
        dataset_id = str(card["dataset_id"])
        raw_fields = card.get("fields") or card.get("variables") or []
        compact_fields: list[dict[str, Any]] = []
        if isinstance(raw_fields, Sequence) and not isinstance(raw_fields, (str, bytes)):
            for field in list(raw_fields)[:STRUCTURED_FIELD_MAX_ITEMS]:
                if not isinstance(field, Mapping):
                    continue
                compact_fields.append(
                    {
                        "name": bounded_text(
                            field.get("name") or field.get("raw_name"),
                            160,
                        ),
                        "description": bounded_text(field.get("description"), 240),
                        "unit": bounded_text(field.get("unit"), 80),
                    }
                )
        core = {
            "dataset_id": dataset_id,
            "name": bounded_text(card.get("name") or card.get("product_name"), 200),
            "provider": bounded_text(card.get("provider"), 200),
            "description": bounded_text(card.get("description"), STRUCTURED_LONG_TEXT_MAX_CHARS),
            "coverage": compact_value(card.get("coverage"), string_limit=200, list_limit=8),
            "resolution": compact_value(card.get("resolution"), string_limit=160, list_limit=8),
            "fields": compact_fields,
        }
        provenance, evidence_id = field_evidence(
            source_type="DatasetCard",
            source_id=dataset_id,
            source_field="core_metadata",
            text=json_text(core),
        )
        core["provenance"] = provenance
        units.append(
            ContextUnit(
                f"dataset_core:{dataset_id}",
                "dataset_card",
                30,
                core,
                (evidence_id,),
            )
        )
        for index, source in enumerate(card.get("sources") or [], start=1):
            if not isinstance(source, Mapping):
                continue
            evidence, source_evidence_id = evidence_payload(
                source_type="DatasetCard",
                source_id=dataset_id,
                source_field=f"sources[{index - 1}]",
                value=source,
                provenance_kind="source_evidence",
            )
            units.append(
                ContextUnit(
                    f"dataset_source:{dataset_id}:{index:04d}",
                    "dataset_source_evidence",
                    50,
                    evidence,
                    (source_evidence_id,),
                )
            )
    return units


def json_text(value: Any) -> str:
    return str(value) if isinstance(value, str) else sha_safe_json(value)


def sha_safe_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
