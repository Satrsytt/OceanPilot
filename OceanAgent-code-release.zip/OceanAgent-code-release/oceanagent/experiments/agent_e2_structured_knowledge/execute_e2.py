from __future__ import annotations

import argparse
import atexit
import hashlib
import json
import os
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

from boundary_smoke import (
    BOUNDARY_SMOKE_AUDIT_VERSION,
    BOUNDARY_SMOKE_QUERY_COUNT,
    BOUNDARY_SMOKE_SELECTOR_VERSION,
    MANDATORY_BOUNDARY_QUERY_IDS,
    build_boundary_smoke_summary,
    classify_attempt_failure,
    read_jsonl_rows,
    validate_formal_contract_freeze,
)
from context_budget import (
    CONTEXT_BUDGETER_VERSION,
    BudgetedContext,
    TOKENIZER_VERSION,
    sha256_json,
    token_count,
)
from knowledge_access import build_visible_knowledge_view, load_benchmark_common, sha256_file
from output_contract import validate_recommendation_output_contract
from prompt_contract import (
    CANDIDATE_CONTEXT_REPRESENTATION_VERSION,
    PROMPT_VERSION,
    SYSTEM_PROMPT,
    build_invariant_context,
    build_model_messages,
)
from requirement_retrieval import load_dataset_corpus, load_e1_runner
from rtc_builder import validate_rtc_provenance
from run_experiment import prepare_condition_contexts
from schemas import knowledge_policy, parity_contract
from schemas import VISIBLE_KNOWLEDGE_POLICY_VERSION


EXPERIMENT_ROOT = Path(__file__).resolve().parent
CONDITIONS = ("A0", "A1", "A2")
PREDICTION_SCHEMA_VERSION = "1.0"
EXECUTION_RUNNER_VERSION = "agent-e2-formal-runner-v1"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Execute the locked Agent-E2 A0/A1/A2 experiment. API access is protected "
            "by execution_enabled=true plus two explicit command-line acknowledgements."
        )
    )
    parser.add_argument("--knowledge-root", type=Path, required=True)
    parser.add_argument("--locked-config", type=Path, required=True)
    parser.add_argument("--frozen-task-specs", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--split", choices=("dev", "test"), required=True)
    parser.add_argument(
        "--smoke-query-count",
        type=int,
        help=(
            "Run a deterministic dev-only smoke on the first N frozen split queries. "
            "Omit for the complete formal split."
        ),
    )
    parser.add_argument(
        "--smoke-query-id",
        action="append",
        default=[],
        help=(
            "Select one explicit DEV query for a deterministic targeted smoke. Repeat for "
            "additional queries. Cannot be combined with --smoke-query-count."
        ),
    )
    parser.add_argument(
        "--boundary-smoke-selection",
        type=Path,
        help=(
            "Run the DEV-only 10-query/30-unit engineering boundary smoke from a "
            "deterministic selector artifact. Cannot be combined with other smoke selectors."
        ),
    )
    parser.add_argument(
        "--formal-contract-freeze",
        type=Path,
        help=(
            "For E2 v4 formal_full, require the 30/30 boundary-smoke contract freeze "
            "artifact and reject any formal-contract fingerprint change."
        ),
    )
    parser.add_argument(
        "--allow-test-split",
        action="store_true",
        help="Explicit acknowledgement required for the frozen test split.",
    )
    parser.add_argument(
        "--execute",
        action="store_true",
        help="First explicit acknowledgement that real model calls are intended.",
    )
    parser.add_argument(
        "--confirm-api-calls",
        action="store_true",
        help="Second explicit acknowledgement that billable API calls are intended.",
    )
    return parser.parse_args()


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"expected a JSON object: {path}")
    return value


def iter_jsonl(path: Path) -> Iterable[dict[str, Any]]:
    with path.open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, start=1):
            if not line.strip():
                continue
            value = json.loads(line)
            if not isinstance(value, dict):
                raise ValueError(f"expected a JSON object at {path}:{line_number}")
            yield value


def atomic_write_json(path: Path, value: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(
        json.dumps(dict(value), ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
    )
    os.replace(temporary, path)


def append_jsonl(path: Path, value: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(dict(value), ensure_ascii=False, sort_keys=True) + "\n")
        handle.flush()
        os.fsync(handle.fileno())


def is_relative_to(path: Path, parent: Path) -> bool:
    try:
        path.relative_to(parent)
        return True
    except ValueError:
        return False


def require_safe_output_dir(output_dir: Path, knowledge_root: Path) -> None:
    agent_root = EXPERIMENT_ROOT.parents[1]
    protected = (
        agent_root / "experiments" / "agent_e1_taskcompiler",
        agent_root / "outputs" / "agent_e1" / "dev_full",
        knowledge_root / "benchmark" / "gold",
        knowledge_root / "benchmark" / "splits",
        knowledge_root / "cards",
    )
    for root in protected:
        if output_dir == root.resolve() or is_relative_to(output_dir, root.resolve()):
            raise RuntimeError(f"E2 output directory overlaps a protected path: {root}")


def require_execution_unlock(config: Mapping[str, Any], args: argparse.Namespace) -> None:
    missing: list[str] = []
    if config.get("execution_enabled") is not True:
        missing.append("locked_config.execution_enabled=true")
    if not args.execute:
        missing.append("--execute")
    if not args.confirm_api_calls:
        missing.append("--confirm-api-calls")
    if missing:
        raise RuntimeError(
            "Agent-E2 execution is hard-locked; no API call is permitted. Missing: "
            + ", ".join(missing)
        )


def load_split_query_ids(path: Path) -> tuple[list[str], str]:
    query_ids: list[str] = []
    seen: set[str] = set()
    for row in iter_jsonl(path):
        query_id = str(row.get("query_id") or "")
        if not query_id or query_id in seen:
            raise ValueError(f"split contains an empty or duplicate query_id: {query_id!r}")
        seen.add(query_id)
        query_ids.append(query_id)
    if not query_ids:
        raise ValueError(f"split contains no queries: {path}")
    return query_ids, sha256_json(query_ids)


def select_run_query_ids(
    *,
    split: str,
    split_query_ids: list[str],
    smoke_query_count: int | None,
    smoke_query_ids: Sequence[str] = (),
) -> tuple[str, list[str]]:
    requested_ids = [str(item) for item in smoke_query_ids]
    if smoke_query_count is not None and requested_ids:
        raise ValueError("--smoke-query-count and --smoke-query-id cannot be combined")
    if requested_ids:
        if split != "dev":
            raise RuntimeError("--smoke-query-id is permitted only with --split dev")
        if len(requested_ids) != len(set(requested_ids)):
            raise ValueError("--smoke-query-id contains a duplicate query ID")
        unknown = sorted(set(requested_ids) - set(split_query_ids))
        if unknown:
            raise ValueError(f"--smoke-query-id is outside the DEV split: {unknown}")
        requested_set = set(requested_ids)
        return "smoke", [
            query_id for query_id in split_query_ids if query_id in requested_set
        ]
    if smoke_query_count is None:
        return "formal_full", list(split_query_ids)
    if split != "dev":
        raise RuntimeError("--smoke-query-count is permitted only with --split dev")
    if smoke_query_count <= 0:
        raise ValueError("--smoke-query-count must be positive")
    if smoke_query_count > len(split_query_ids):
        raise ValueError(
            "--smoke-query-count exceeds the number of queries in the dev split"
        )
    return "smoke", list(split_query_ids[:smoke_query_count])


def load_boundary_smoke_selection(
    path: Path,
    *,
    config: Mapping[str, Any],
    config_path: Path,
    frozen_path: Path,
    split_path: Path,
    split_query_ids: Sequence[str],
    split_query_ids_sha256: str,
) -> dict[str, Any]:
    selection = read_json(path)
    if selection.get("selector_version") != BOUNDARY_SMOKE_SELECTOR_VERSION:
        raise ValueError("boundary-smoke selector version is incompatible")
    if selection.get("engineering_validation_only") is not True:
        raise ValueError("boundary-smoke selection is not marked engineering-only")
    if selection.get("formal_contract_mutated") is not False:
        raise ValueError("boundary-smoke selection claims a formal-contract mutation")
    if int(selection.get("dev_query_count", -1)) != 108:
        raise ValueError("boundary-smoke selection was not derived from all 108 DEV queries")
    selected_query_ids = [str(item) for item in selection.get("selected_query_ids") or []]
    if (
        len(selected_query_ids) != BOUNDARY_SMOKE_QUERY_COUNT
        or len(selected_query_ids) != len(set(selected_query_ids))
    ):
        raise ValueError("boundary-smoke selection must contain exactly 10 unique queries")
    if not set(MANDATORY_BOUNDARY_QUERY_IDS).issubset(selected_query_ids):
        raise ValueError("boundary-smoke selection omits a mandatory prior failure query")
    unknown = sorted(set(selected_query_ids) - set(split_query_ids))
    if unknown:
        raise ValueError(f"boundary-smoke selection is outside the DEV split: {unknown}")
    selected_queries = selection.get("selected_queries")
    if not isinstance(selected_queries, list) or [
        str(item.get("query_id") or "")
        for item in selected_queries
        if isinstance(item, Mapping)
    ] != selected_query_ids:
        raise ValueError("boundary-smoke selected-query reasons are incomplete or reordered")
    fingerprints = selection.get("source_fingerprints")
    if not isinstance(fingerprints, Mapping):
        raise ValueError("boundary-smoke selection has no source fingerprints")
    expected_fingerprints = {
        "experiment_id": str(config["experiment_id"]),
        "locked_config_sha256": sha256_file(config_path),
        "frozen_task_specs_sha256": sha256_file(frozen_path),
        "dev_split_sha256": sha256_file(split_path),
        "split_query_ids_sha256": split_query_ids_sha256,
    }
    mismatches = [
        key for key, value in expected_fingerprints.items()
        if fingerprints.get(key) != value
    ]
    if mismatches:
        raise RuntimeError(
            "boundary-smoke selection input fingerprints are stale: "
            + ", ".join(mismatches)
        )
    return selection


def finalize_attempt_audit(attempt_audit: dict[str, Any]) -> None:
    failures = attempt_audit.get("attempt_failures") or []
    if not isinstance(failures, list):
        raise RuntimeError("attempt audit failures must be an array")
    for failure in failures:
        if not isinstance(failure, dict):
            raise RuntimeError("attempt audit failure must be an object")
        failure["category"] = classify_attempt_failure(
            str(failure.get("error_type") or ""),
            str(failure.get("error") or ""),
        )
    attempt_audit["audit_version"] = BOUNDARY_SMOKE_AUDIT_VERSION


def load_frozen_task_specs(path: Path) -> dict[str, dict[str, Any]]:
    frozen: dict[str, dict[str, Any]] = {}
    e1 = load_e1_runner()
    for row in iter_jsonl(path):
        if set(row) != {"query_id", "task_spec", "task_spec_sha256"}:
            raise ValueError("frozen TaskSpec row has an unexpected schema")
        query_id = str(row.get("query_id") or "")
        task_spec = row.get("task_spec")
        if not query_id or query_id in frozen or not isinstance(task_spec, Mapping):
            raise ValueError("frozen TaskSpec artifact has an invalid or duplicate row")
        e1.validate_task_spec(task_spec)
        actual_hash = sha256_json(task_spec)
        if row.get("task_spec_sha256") != actual_hash:
            raise RuntimeError(f"frozen TaskSpec hash mismatch for {query_id}")
        frozen[query_id] = dict(task_spec)
    if not frozen:
        raise ValueError("frozen TaskSpec artifact is empty")
    return frozen


def aggregate_task_spec_fingerprint(task_specs: Mapping[str, Mapping[str, Any]]) -> str:
    return sha256_json({query_id: task_specs[query_id] for query_id in sorted(task_specs)})


def validate_locked_config(config: Mapping[str, Any], config_path: Path, split: str) -> dict[str, Any]:
    if config.get("confirmatory_comparisons") != ["A1-A0", "A2-A1"]:
        raise ValueError("formal E2 permits only A1-A0 and A2-A1 confirmatory comparisons")
    if str(config.get("split")) != split:
        raise ValueError("locked config split does not match --split")
    visible = config.get("visible_knowledge")
    if not isinstance(visible, Mapping):
        raise ValueError("locked config is missing visible_knowledge")
    if visible.get("require_source_snapshot_current") is not True:
        raise ValueError("formal E2 requires an explicit source snapshot guard")
    if visible.get("require_benchmark_leakage_pass") is not True:
        raise ValueError("formal E2 requires the Benchmark leakage audit")
    if visible.get("policy_version") != VISIBLE_KNOWLEDGE_POLICY_VERSION:
        raise ValueError("locked config uses an obsolete visible-knowledge policy")
    if visible.get("auxiliary_source_groups_visible") is not True:
        raise ValueError("formal E2 visible knowledge must include auxiliary source groups")
    if visible.get("heldout_source_groups_blocked") is not True:
        raise ValueError("formal E2 must block held-out benchmark source groups")
    for condition_id in CONDITIONS:
        knowledge_policy(config, condition_id)
    contract = parity_contract(config, config_path.parent)
    required_locked = {
        "backbone_model": contract.backbone_model,
        "model_version": contract.model_version,
        "fixed_task_spec_sha256": contract.fixed_task_spec_sha256,
        "dataset_corpus_sha256": contract.dataset_corpus_sha256,
    }
    missing = sorted(key for key, value in required_locked.items() if not value)
    if missing:
        raise RuntimeError("locked config is not frozen; missing fields: " + ", ".join(missing))
    if contract.recommender_prompt_version != PROMPT_VERSION:
        raise ValueError("locked config prompt version does not match prompt_contract.py")
    if contract.tokenizer_version != TOKENIZER_VERSION:
        raise ValueError("locked config tokenizer version does not match context_budget.py")
    shared_components = config.get("shared_components")
    if not isinstance(shared_components, Mapping):
        raise ValueError("locked config is missing shared_components")
    if shared_components.get("context_budgeter") != CONTEXT_BUDGETER_VERSION:
        raise ValueError("locked config context budgeter version does not match context_budget.py")
    if (
        shared_components.get("candidate_context_representation")
        != CANDIDATE_CONTEXT_REPRESENTATION_VERSION
    ):
        raise ValueError("locked candidate representation version does not match prompt_contract.py")
    runtime_model = config.get("runtime_model")
    if not isinstance(runtime_model, Mapping):
        raise ValueError("locked config is missing runtime_model")
    required_model_fields = (
        "model",
        "model_version",
        "base_url",
        "provider_identifier",
        "api_key_env",
        "timeout_seconds",
        "max_attempts",
    )
    if any(runtime_model.get(field) in (None, "") for field in required_model_fields):
        raise ValueError("locked runtime_model is incomplete")
    if runtime_model["model"] != contract.backbone_model:
        raise ValueError("runtime model and parity-contract backbone model differ")
    if runtime_model["model_version"] != contract.model_version:
        raise ValueError("runtime model version and parity contract differ")
    if float(contract.temperature) != 0.0 or int(contract.top_k) != 10:
        raise ValueError("formal E2 fixes temperature=0 and K=10")
    return {"contract": contract, "runtime_model": dict(runtime_model)}


def budgeted_context_from_dict(value: Mapping[str, Any]) -> BudgetedContext:
    tuple_fields = {
        "selected_unit_ids",
        "selected_structured_unit_ids",
        "selected_rtc_unit_ids",
        "selected_evidence_ids",
        "dropped_unit_ids",
        "selected_context",
    }
    converted = {
        key: tuple(item) if key in tuple_fields else item
        for key, item in value.items()
    }
    return BudgetedContext(**converted)


def condition_order(query_id: str) -> tuple[str, str, str]:
    offset = int(hashlib.sha256(query_id.encode("utf-8")).hexdigest()[-2:], 16) % 3
    return CONDITIONS[offset:] + CONDITIONS[:offset]


def build_run_contract(
    *,
    config: Mapping[str, Any],
    config_path: Path,
    frozen_task_specs_path: Path,
    split_path: Path,
    split_manifest_path: Path,
    dataset_corpus_path: Path,
    recommendation_schema_path: Path,
    recommendation_schema: Mapping[str, Any],
    task_spec_fingerprint: str,
    split_query_ids_fingerprint: str,
    run_type: str,
    selected_query_ids: list[str],
    smoke_query_count: int | None,
    visible_audit: Mapping[str, Any],
    source_snapshot_audit: Mapping[str, Any],
    targeted_smoke_query_ids: Sequence[str] = (),
    boundary_smoke_selection: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    parity = config["parity_contract"]
    runtime_model = config["runtime_model"]
    canonical = visible_audit["canonical_input_sha256"]
    contract = {
        "runner_version": EXECUTION_RUNNER_VERSION,
        "experiment_id": config["experiment_id"],
        "split": config["split"],
        "run_type": run_type,
        "smoke_query_count": smoke_query_count,
        "selected_query_ids": list(selected_query_ids),
        "selected_query_ids_fingerprint": sha256_json(selected_query_ids),
        "model": runtime_model["model"],
        "model_version": runtime_model["model_version"],
        "base_url": runtime_model["base_url"],
        "provider_identifier": runtime_model["provider_identifier"],
        "top_k": int(parity["top_k"]),
        "temperature": float(parity["temperature"]),
        "prompt_version": parity["recommender_prompt_version"],
        "system_prompt_sha256": sha256_json(SYSTEM_PROMPT),
        "ranking_chain_version": parity["ranking_chain_version"],
        "tokenizer_version": parity["tokenizer_version"],
        "context_budgeter_version": config["shared_components"]["context_budgeter"],
        "candidate_context_representation_version": config["shared_components"][
            "candidate_context_representation"
        ],
        "context_token_budget": int(parity["context_token_budget"]),
        "output_token_budget": int(parity["output_token_budget"]),
        "rtc_reserved_token_budget": int(config["rtc"]["reserved_token_budget"]),
        "candidate_pool_size": int(config["candidate_pool_size"]),
        "dataset_retriever": dict(config["shared_components"]["retriever"]),
        "structured_retrieval": dict(config["structured_retrieval"]),
        "task_spec_fingerprint": task_spec_fingerprint,
        "dataset_corpus_fingerprint": sha256_file(dataset_corpus_path),
        "card_fingerprints": {
            "problem_solution_cards": canonical["problem_solution_cards"],
            "usage_bundle_cards": canonical["usage_bundle_cards"],
            "dataset_cards": canonical["dataset_cards"],
        },
        "split_manifest_fingerprint": sha256_file(split_manifest_path),
        "split_fingerprint": sha256_file(split_path),
        "split_query_ids_fingerprint": split_query_ids_fingerprint,
        "recommendation_schema_fingerprint": sha256_json(recommendation_schema),
        "recommendation_schema_file_fingerprint": sha256_file(
            recommendation_schema_path
        ),
        "locked_config_fingerprint": sha256_file(config_path),
        "frozen_task_specs_file_fingerprint": sha256_file(frozen_task_specs_path),
        "visible_knowledge_audit": dict(visible_audit),
        "source_snapshot_audit": dict(source_snapshot_audit),
        "conditions": list(CONDITIONS),
    }
    if targeted_smoke_query_ids:
        contract["targeted_smoke_query_ids"] = list(targeted_smoke_query_ids)
    if boundary_smoke_selection is not None:
        contract["engineering_validation"] = {
            "type": "boundary_smoke",
            "formal_paper_metric": False,
            "selector_version": boundary_smoke_selection["selector_version"],
            "selection_sha256": sha256_json(boundary_smoke_selection),
            "selected_queries": boundary_smoke_selection["selected_queries"],
            "expected_work_unit_count": boundary_smoke_selection[
                "expected_work_unit_count"
            ],
        }
    return contract


def create_or_validate_manifest(
    path: Path,
    *,
    run_contract: Mapping[str, Any],
    split_query_count: int,
) -> dict[str, Any]:
    selected_query_ids = list(run_contract["selected_query_ids"])
    query_count = len(selected_query_ids)
    run_type = str(run_contract["run_type"])
    contract_hash = sha256_json(run_contract)
    if path.is_file():
        existing = read_json(path)
        existing_run_type = str(existing.get("run_type") or "")
        if existing_run_type != run_type:
            raise RuntimeError(
                "output directory run_type is incompatible; formal_full runs must never "
                "resume, read, or reuse smoke predictions"
            )
        existing_contract = existing.get("run_contract")
        if not isinstance(existing_contract, Mapping):
            raise RuntimeError("existing E2 manifest has no run_contract")
        if sha256_json(existing_contract) != existing.get("run_contract_sha256"):
            raise RuntimeError("existing E2 manifest's own contract hash is invalid")
        if existing.get("run_contract_sha256") != contract_hash:
            raise RuntimeError(
                "output directory contains an incompatible E2 manifest; refusing to continue"
            )
        if int(existing.get("query_count", -1)) != query_count:
            raise RuntimeError("existing E2 manifest query count is incompatible")
        expected_top_level = {
            "experiment_id": run_contract["experiment_id"],
            "split": run_contract["split"],
            "run_type": run_type,
            "split_query_count": split_query_count,
            "query_count_selected": query_count,
            "smoke_query_count": run_contract["smoke_query_count"],
            "selected_query_ids": selected_query_ids,
            "top_k": run_contract["top_k"],
            "conditions": list(run_contract["conditions"]),
            "visible_knowledge_audit": run_contract["visible_knowledge_audit"],
            "source_snapshot_audit": run_contract["source_snapshot_audit"],
        }
        if "targeted_smoke_query_ids" in run_contract:
            expected_top_level["targeted_smoke_query_ids"] = run_contract[
                "targeted_smoke_query_ids"
            ]
        if "engineering_validation" in run_contract:
            expected_top_level["engineering_validation"] = run_contract[
                "engineering_validation"
            ]
        mismatches = [
            key for key, value in expected_top_level.items() if existing.get(key) != value
        ]
        if mismatches:
            raise RuntimeError(
                "existing E2 manifest top-level audit fields are incompatible: "
                + ", ".join(mismatches)
            )
        return existing
    manifest = {
        "schema_version": "1.0",
        "created_at": utc_now(),
        "experiment_id": run_contract["experiment_id"],
        "split": run_contract["split"],
        "run_type": run_type,
        "split_query_count": split_query_count,
        "query_count": query_count,
        "query_count_selected": query_count,
        "smoke_query_count": run_contract["smoke_query_count"],
        "selected_query_ids": selected_query_ids,
        "top_k": run_contract["top_k"],
        "conditions": list(run_contract["conditions"]),
        "visible_knowledge_audit": run_contract["visible_knowledge_audit"],
        "source_snapshot_audit": run_contract["source_snapshot_audit"],
        "work_unit": "query_id+condition_id",
        "predictions_file": "predictions.jsonl",
        "failures_file": "failures.jsonl",
        "run_contract": dict(run_contract),
        "run_contract_sha256": contract_hash,
    }
    if "targeted_smoke_query_ids" in run_contract:
        manifest["targeted_smoke_query_ids"] = run_contract["targeted_smoke_query_ids"]
    if "engineering_validation" in run_contract:
        manifest["engineering_validation"] = run_contract["engineering_validation"]
    atomic_write_json(path, manifest)
    return manifest


def acquire_output_lock(output_dir: Path) -> tuple[Path, int]:
    lock_path = output_dir / ".execute_e2.lock"
    try:
        descriptor = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError as exc:
        raise RuntimeError(
            "another E2 runner may be active, or a prior run ended uncleanly; "
            f"inspect the lock before manual removal: {lock_path}"
        ) from exc
    os.write(descriptor, f"pid={os.getpid()} created_at={utc_now()}\n".encode("utf-8"))
    os.fsync(descriptor)
    return lock_path, descriptor


def release_output_lock(lock_path: Path, descriptor: int) -> None:
    try:
        os.close(descriptor)
    finally:
        try:
            lock_path.unlink()
        except FileNotFoundError:
            pass


def load_existing_predictions(path: Path) -> dict[tuple[str, str], dict[str, Any]]:
    rows: dict[tuple[str, str], dict[str, Any]] = {}
    if not path.is_file():
        return rows
    for row in iter_jsonl(path):
        key = (str(row.get("query_id") or ""), str(row.get("condition_id") or ""))
        if not all(key) or key[1] not in CONDITIONS or key in rows:
            raise RuntimeError(f"invalid or duplicate E2 prediction work unit: {key}")
        if row.get("status") != "success":
            raise RuntimeError("predictions.jsonl may contain successful results only")
        rows[key] = row
    return rows


def execution_unit_contract(
    *,
    run_contract_sha256: str,
    query_id: str,
    condition_id: str,
    task_spec_sha256: str,
    candidate_pool_sha256: str,
    structured_retrieval_sha256: str,
    context: Mapping[str, Any],
) -> dict[str, Any]:
    return {
        "run_contract_sha256": run_contract_sha256,
        "query_id": query_id,
        "condition_id": condition_id,
        "task_spec_sha256": task_spec_sha256,
        "candidate_pool_sha256": candidate_pool_sha256,
        "structured_retrieval_sha256": structured_retrieval_sha256,
        "context_hash": context["context_hash"],
        "model_visible_payload_basis_sha256": sha256_json(
            {
                "invariant_context_hash": context["invariant_context_hash"],
                "selected_context": context["selected_context"],
            }
        ),
    }


def validate_existing_prediction(
    row: Mapping[str, Any],
    *,
    expected_unit: Mapping[str, Any],
    candidate_ids: set[str],
    top_k: int,
    e1: Any,
    run_contract: Mapping[str, Any],
    recommendation_schema: Mapping[str, Any],
) -> None:
    required = {
        "schema_version",
        "experiment_id",
        "status",
        "query_id",
        "condition_id",
        "execution_unit",
        "execution_unit_sha256",
        "recommendations",
        "context_budget",
        "fixed_task_spec_sha256",
        "dataset_corpus_sha256",
        "candidate_dataset_ids",
        "candidate_pool_sha256",
        "structured_retrieval_sha256",
        "rtc",
        "model",
        "model_version",
        "provider_identifier",
        "prompt_audit",
        "recommender_prompt_version",
        "system_prompt_sha256",
        "top_k",
        "temperature",
        "output_token_budget",
        "ranking_chain_version",
        "output_schema_sha256",
        "request_sha256",
        "output_token_count",
    }
    missing = sorted(required - set(row))
    if missing:
        raise RuntimeError("existing E2 prediction is incomplete: " + ", ".join(missing))
    if row["execution_unit"] != expected_unit:
        raise RuntimeError("existing E2 prediction does not match the current execution unit")
    if row["execution_unit_sha256"] != sha256_json(expected_unit):
        raise RuntimeError("existing E2 prediction execution-unit hash is invalid")
    if row.get("context_budget", {}).get("context_hash") != expected_unit["context_hash"]:
        raise RuntimeError("existing E2 prediction context hash is invalid")
    expected_values = {
        "query_id": expected_unit["query_id"],
        "condition_id": expected_unit["condition_id"],
        "fixed_task_spec_sha256": expected_unit["task_spec_sha256"],
        "dataset_corpus_sha256": run_contract["dataset_corpus_fingerprint"],
        "candidate_pool_sha256": expected_unit["candidate_pool_sha256"],
        "structured_retrieval_sha256": expected_unit[
            "structured_retrieval_sha256"
        ],
        "model": run_contract["model"],
        "model_version": run_contract["model_version"],
        "provider_identifier": run_contract["provider_identifier"],
        "recommender_prompt_version": run_contract["prompt_version"],
        "system_prompt_sha256": run_contract["system_prompt_sha256"],
        "top_k": run_contract["top_k"],
        "temperature": run_contract["temperature"],
        "output_token_budget": run_contract["output_token_budget"],
        "ranking_chain_version": run_contract["ranking_chain_version"],
        "output_schema_sha256": run_contract["recommendation_schema_fingerprint"],
    }
    mismatches = [
        key for key, value in expected_values.items() if row.get(key) != value
    ]
    if mismatches:
        raise RuntimeError(
            "existing E2 prediction parity/hash fields are incompatible: "
            + ", ".join(mismatches)
        )
    if not isinstance(row["candidate_dataset_ids"], list):
        raise RuntimeError("existing E2 prediction candidate Dataset IDs are not an array")
    candidate_list = [str(value) for value in row["candidate_dataset_ids"]]
    if len(candidate_list) != len(candidate_ids) or set(candidate_list) != candidate_ids:
        raise RuntimeError("existing E2 prediction candidate Dataset IDs are incompatible")
    condition_id = str(row["condition_id"])
    if condition_id == "A2":
        if not isinstance(row.get("rtc"), Mapping):
            raise RuntimeError("existing A2 prediction has no RTC")
        if row["rtc"].get("structured_retrieval_sha256") != expected_unit[
            "structured_retrieval_sha256"
        ]:
            raise RuntimeError("existing A2 RTC retrieval hash is incompatible")
        validate_rtc_provenance(row["rtc"])
    elif row.get("rtc") is not None:
        raise RuntimeError("A0/A1 prediction must not contain RTC")
    prompt_audit = row.get("prompt_audit")
    if not isinstance(prompt_audit, Mapping):
        raise RuntimeError("existing E2 prediction has no prompt audit")
    if (
        prompt_audit.get("prompt_version") != run_contract["prompt_version"]
        or prompt_audit.get("system_prompt_sha256")
        != run_contract["system_prompt_sha256"]
        or prompt_audit.get("invariant_context_hash")
        != row["context_budget"].get("invariant_context_hash")
        or prompt_audit.get("condition_id_not_model_visible") is not True
    ):
        raise RuntimeError("existing E2 prediction prompt audit is incompatible")
    if not isinstance(row.get("request_sha256"), str) or not row["request_sha256"]:
        raise RuntimeError("existing E2 prediction has no request hash")
    if (
        not isinstance(row.get("output_token_count"), int)
        or row["output_token_count"] > int(run_contract["output_token_budget"])
    ):
        raise RuntimeError("existing E2 prediction exceeds its output token budget")
    parsed = {"recommendations": [
        {key: item[key] for key in ("dataset_id", "reason", "matched_requirements")}
        for item in row["recommendations"]
    ]}
    e1.validate_recommendations(parsed, candidate_ids=candidate_ids, top_k=top_k)
    if recommendation_schema.get("x-oceanagent-contract-version"):
        validate_recommendation_output_contract(parsed, recommendation_schema)


def main() -> None:
    args = parse_args()
    config_path = args.locked_config.resolve()
    frozen_path = args.frozen_task_specs.resolve()
    knowledge_root = args.knowledge_root.resolve()
    output_dir = args.output_dir.resolve()
    config = read_json(config_path)

    # These three independent locks are evaluated before any API helper can be
    # reached.  The repository config remains false until an explicit freeze.
    require_execution_unlock(config, args)
    if args.smoke_query_count is not None and args.split != "dev":
        raise RuntimeError("--smoke-query-count is permitted only with --split dev")
    if args.smoke_query_count is not None and args.smoke_query_count <= 0:
        raise ValueError("--smoke-query-count must be positive")
    active_smoke_selectors = sum(
        (
            args.smoke_query_count is not None,
            bool(args.smoke_query_id),
            args.boundary_smoke_selection is not None,
        )
    )
    if active_smoke_selectors > 1:
        raise ValueError(
            "--smoke-query-count, --smoke-query-id, and --boundary-smoke-selection "
            "are mutually exclusive"
        )
    if args.smoke_query_id and args.split != "dev":
        raise RuntimeError("--smoke-query-id is permitted only with --split dev")
    if args.boundary_smoke_selection is not None and args.split != "dev":
        raise RuntimeError("--boundary-smoke-selection is permitted only with --split dev")
    if args.split == "test" and not args.allow_test_split:
        raise RuntimeError("test split requires --allow-test-split")
    require_safe_output_dir(output_dir, knowledge_root)
    locked = validate_locked_config(config, config_path, args.split)
    contract = locked["contract"]
    runtime_model = locked["runtime_model"]

    benchmark_root = knowledge_root / "benchmark"
    split_path = benchmark_root / "splits" / f"{args.split}.jsonl"
    split_manifest_path = benchmark_root / "splits" / "split_manifest.json"
    dataset_corpus_path = benchmark_root / "corpus" / "dataset_corpus.jsonl"
    recommendation_schema_path = Path(contract.output_schema_path)
    common = load_benchmark_common(knowledge_root)
    source_snapshot_audit = common.require_source_snapshot_current(
        benchmark_root=benchmark_root,
        repository_root=knowledge_root,
    )
    visible_view = build_visible_knowledge_view(knowledge_root, target_split=args.split)

    split_query_ids, split_query_ids_hash = load_split_query_ids(split_path)
    boundary_smoke_selection: dict[str, Any] | None = None
    if args.boundary_smoke_selection is not None:
        boundary_smoke_selection = load_boundary_smoke_selection(
            args.boundary_smoke_selection.resolve(),
            config=config,
            config_path=config_path,
            frozen_path=frozen_path,
            split_path=split_path,
            split_query_ids=split_query_ids,
            split_query_ids_sha256=split_query_ids_hash,
        )
        run_type = "boundary_smoke"
        selected_query_ids = [
            str(item) for item in boundary_smoke_selection["selected_query_ids"]
        ]
    else:
        run_type, selected_query_ids = select_run_query_ids(
            split=args.split,
            split_query_ids=split_query_ids,
            smoke_query_count=args.smoke_query_count,
            smoke_query_ids=args.smoke_query_id,
        )
    effective_smoke_query_count = (
        len(selected_query_ids) if run_type in {"smoke", "boundary_smoke"} else None
    )
    targeted_smoke_query_ids = selected_query_ids if args.smoke_query_id else []
    frozen = load_frozen_task_specs(frozen_path)
    if set(frozen) != set(split_query_ids):
        raise RuntimeError("frozen TaskSpec task set does not exactly match the target split")
    task_spec_fingerprint = aggregate_task_spec_fingerprint(frozen)
    if task_spec_fingerprint != contract.fixed_task_spec_sha256:
        raise RuntimeError("frozen TaskSpec aggregate fingerprint differs from locked config")
    if sha256_file(dataset_corpus_path) != contract.dataset_corpus_sha256:
        raise RuntimeError("Dataset corpus fingerprint differs from locked config")

    dataset_corpus = load_dataset_corpus(knowledge_root)
    e1 = load_e1_runner()
    retriever_config = config["shared_components"]["retriever"]
    index = e1.BM25Index(
        dataset_corpus,
        k1=float(retriever_config["k1"]),
        b=float(retriever_config["b"]),
    )
    recommendation_schema = read_json(recommendation_schema_path)
    recommendation_schema["properties"]["recommendations"]["minItems"] = contract.top_k
    recommendation_schema["properties"]["recommendations"]["maxItems"] = contract.top_k
    if boundary_smoke_selection is not None:
        selection_fingerprints = boundary_smoke_selection["source_fingerprints"]
        if (
            selection_fingerprints.get("recommendation_schema_sha256")
            != sha256_json(recommendation_schema)
            or selection_fingerprints.get("recommendation_schema_file_sha256")
            != sha256_file(recommendation_schema_path)
        ):
            raise RuntimeError(
                "boundary-smoke selection recommendation schema fingerprints are stale"
            )

    run_contract = build_run_contract(
        config=config,
        config_path=config_path,
        frozen_task_specs_path=frozen_path,
        split_path=split_path,
        split_manifest_path=split_manifest_path,
        dataset_corpus_path=dataset_corpus_path,
        recommendation_schema_path=recommendation_schema_path,
        recommendation_schema=recommendation_schema,
        task_spec_fingerprint=task_spec_fingerprint,
        split_query_ids_fingerprint=split_query_ids_hash,
        run_type=run_type,
        selected_query_ids=selected_query_ids,
        smoke_query_count=effective_smoke_query_count,
        visible_audit=visible_view.audit,
        source_snapshot_audit=source_snapshot_audit,
        targeted_smoke_query_ids=targeted_smoke_query_ids,
        boundary_smoke_selection=boundary_smoke_selection,
    )
    if run_type == "formal_full" and config.get("experiment_id") in {
        "agent-e2-structured-knowledge-v4",
        "agent-e2-structured-knowledge-v4-heldout-quote-filter-v2",
    }:
        if args.formal_contract_freeze is None:
            raise RuntimeError(
                "E2 v4 formal_full requires --formal-contract-freeze from a 30/30 "
                "boundary smoke"
            )
        validate_formal_contract_freeze(
            read_json(args.formal_contract_freeze.resolve()),
            run_contract,
        )
    elif args.formal_contract_freeze is not None:
        raise ValueError(
            "--formal-contract-freeze is accepted only for E2 v4 formal_full"
        )
    output_dir.mkdir(parents=True, exist_ok=True)
    lock_path, lock_descriptor = acquire_output_lock(output_dir)
    atexit.register(release_output_lock, lock_path, lock_descriptor)
    manifest = create_or_validate_manifest(
        output_dir / "manifest.json",
        run_contract=run_contract,
        split_query_count=len(split_query_ids),
    )
    if boundary_smoke_selection is not None:
        atomic_write_json(
            output_dir / "boundary_smoke_selection.json",
            boundary_smoke_selection,
        )
    predictions_path = output_dir / "predictions.jsonl"
    failures_path = output_dir / "failures.jsonl"
    existing = load_existing_predictions(predictions_path)
    selected_query_id_set = set(selected_query_ids)
    unknown_existing = sorted(
        key
        for key in existing
        if key[0] not in selected_query_id_set or key[1] not in CONDITIONS
    )
    if unknown_existing:
        raise RuntimeError(f"predictions contain work units outside this run: {unknown_existing[:5]}")

    api_key_env = str(runtime_model["api_key_env"])
    api_key = os.environ.get(api_key_env, "")
    if not api_key:
        raise RuntimeError(f"missing API key in environment variable {api_key_env}")
    model_config = {
        "model": runtime_model["model"],
        "base_url": runtime_model["base_url"],
        "api_key": api_key,
        "temperature": contract.temperature,
        "timeout": int(runtime_model["timeout_seconds"]),
        "max_attempts": int(runtime_model["max_attempts"]),
    }

    for query_id in selected_query_ids:
        fixed_task_spec = frozen[query_id]
        task_spec_sha256 = sha256_json(fixed_task_spec)
        retrieval_text = "\n".join(e1.flatten_strings(fixed_task_spec))
        candidate_cards = index.search(retrieval_text, int(config["candidate_pool_size"]))
        if len(candidate_cards) < contract.top_k:
            raise RuntimeError(f"candidate pool is smaller than K=10 for {query_id}")
        compact_candidates = [e1.compact_card(card) for card in candidate_cards]
        candidate_ids = {str(card.get("dataset_id") or "") for card in compact_candidates}
        if "" in candidate_ids or len(candidate_ids) != len(compact_candidates):
            raise RuntimeError(f"candidate pool has empty or duplicate Dataset IDs for {query_id}")
        invariant_context = build_invariant_context(
            fixed_task_spec=fixed_task_spec,
            candidate_dataset_cards=compact_candidates,
            top_k=contract.top_k,
            output_schema=recommendation_schema,
            output_schema_sha256=run_contract["recommendation_schema_fingerprint"],
            ranking_chain_version=contract.ranking_chain_version,
        )
        model_visible_candidates = invariant_context["candidate_dataset_cards"]
        candidate_pool_sha256 = sha256_json(model_visible_candidates)
        prepared = prepare_condition_contexts(
            fixed_task_spec=fixed_task_spec,
            invariant_context=invariant_context,
            visible_knowledge_view=visible_view,
            config=config,
        )
        validate_rtc_provenance(prepared["rtc"])

        for condition_id in condition_order(query_id):
            context_dict = prepared["condition_contexts"][condition_id]
            unit = execution_unit_contract(
                run_contract_sha256=manifest["run_contract_sha256"],
                query_id=query_id,
                condition_id=condition_id,
                task_spec_sha256=task_spec_sha256,
                candidate_pool_sha256=candidate_pool_sha256,
                structured_retrieval_sha256=prepared["structured_retrieval_sha256"],
                context=context_dict,
            )
            key = (query_id, condition_id)
            if key in existing:
                validate_existing_prediction(
                    existing[key],
                    expected_unit=unit,
                    candidate_ids=candidate_ids,
                    top_k=contract.top_k,
                    e1=e1,
                    run_contract=run_contract,
                    recommendation_schema=recommendation_schema,
                )
                print(f"skip valid completed unit {query_id} {condition_id}", flush=True)
                continue

            budgeted_context = budgeted_context_from_dict(context_dict)
            messages, prompt_audit = build_model_messages(
                invariant_context=invariant_context,
                budgeted_context=budgeted_context,
            )
            started = time.perf_counter()
            attempt_audit: dict[str, Any] | None = (
                {} if run_type == "boundary_smoke" else None
            )
            try:
                def validate_output(parsed: Mapping[str, Any]) -> list[dict[str, Any]]:
                    recommendations = e1.validate_recommendations(
                        parsed,
                        candidate_ids=candidate_ids,
                        top_k=contract.top_k,
                    )
                    if recommendation_schema.get("x-oceanagent-contract-version"):
                        validate_recommendation_output_contract(
                            parsed,
                            recommendation_schema,
                        )
                    if token_count(parsed) > contract.output_token_budget:
                        raise ValueError("DatasetRecommendation exceeds output token budget")
                    return recommendations

                value, request_sha256, usage = e1.call_json_with_retry(
                    common,
                    model_config=model_config,
                    messages=messages,
                    schema_name="DatasetRecommendation",
                    schema=recommendation_schema,
                    validator=validate_output,
                    attempt_audit=attempt_audit,
                )
                recommendations = validate_output(value)
            except (RuntimeError, ValueError) as exc:
                failure_row: dict[str, Any] = {
                    "schema_version": "1.0",
                    "experiment_id": config["experiment_id"],
                    "query_id": query_id,
                    "condition_id": condition_id,
                    "execution_unit_sha256": sha256_json(unit),
                    "error_type": type(exc).__name__,
                    "error": str(exc),
                    "created_at": utc_now(),
                }
                if attempt_audit is not None:
                    finalize_attempt_audit(attempt_audit)
                    failure_row["attempt_audit"] = attempt_audit
                append_jsonl(
                    failures_path,
                    failure_row,
                )
                print(f"failed {query_id} {condition_id}; unit remains resumable", flush=True)
                continue

            if key in existing:
                raise RuntimeError(f"refusing duplicate prediction append for {key}")
            prediction = {
                "schema_version": PREDICTION_SCHEMA_VERSION,
                "experiment_id": config["experiment_id"],
                "status": "success",
                "query_id": query_id,
                "condition_id": condition_id,
                "fixed_task_spec_sha256": task_spec_sha256,
                "dataset_corpus_sha256": run_contract["dataset_corpus_fingerprint"],
                "candidate_dataset_ids": [str(card["dataset_id"]) for card in compact_candidates],
                "candidate_pool_sha256": candidate_pool_sha256,
                "structured_retrieval_sha256": prepared["structured_retrieval_sha256"],
                "rtc": prepared["rtc"] if condition_id == "A2" else None,
                "context_budget": context_dict,
                "recommendations": recommendations,
                "model": runtime_model["model"],
                "model_version": runtime_model["model_version"],
                "provider_identifier": runtime_model["provider_identifier"],
                "prompt_audit": prompt_audit,
                "recommender_prompt_version": PROMPT_VERSION,
                "system_prompt_sha256": sha256_json(SYSTEM_PROMPT),
                "top_k": contract.top_k,
                "temperature": contract.temperature,
                "output_token_budget": contract.output_token_budget,
                "ranking_chain_version": contract.ranking_chain_version,
                "recommendation_schema_sha256": run_contract[
                    "recommendation_schema_fingerprint"
                ],
                "output_schema_sha256": run_contract[
                    "recommendation_schema_fingerprint"
                ],
                "execution_unit": unit,
                "execution_unit_sha256": sha256_json(unit),
                "request_sha256": request_sha256,
                "output_token_count": token_count(value),
                "usage": usage,
                "elapsed_seconds": round(time.perf_counter() - started, 6),
                "created_at": utc_now(),
            }
            if attempt_audit is not None:
                finalize_attempt_audit(attempt_audit)
                prediction["attempt_audit"] = attempt_audit
            validate_existing_prediction(
                prediction,
                expected_unit=unit,
                candidate_ids=candidate_ids,
                top_k=contract.top_k,
                e1=e1,
                run_contract=run_contract,
                recommendation_schema=recommendation_schema,
            )
            append_jsonl(predictions_path, prediction)
            existing[key] = prediction
            print(f"completed {query_id} {condition_id}", flush=True)

    if boundary_smoke_selection is not None:
        boundary_summary = build_boundary_smoke_summary(
            selection=boundary_smoke_selection,
            run_contract=run_contract,
            predictions=existing.values(),
            failures=read_jsonl_rows(failures_path),
        )
        atomic_write_json(
            output_dir / "boundary_smoke_summary.json",
            boundary_summary,
        )
        if boundary_summary["success_30_of_30"]:
            atomic_write_json(
                output_dir / "formal_contract_freeze.json",
                boundary_summary,
            )
        print(
            "boundary smoke summary: "
            f"{boundary_summary['successful_work_unit_count']}/"
            f"{boundary_summary['expected_work_unit_count']} success; "
            f"invalid_json={boundary_summary['invalid_json_count']}; "
            "output_budget_violations="
            f"{boundary_summary['output_budget_violation_count']}; "
            "transport_api_failures="
            f"{boundary_summary['transport_api_failure_count']}; "
            f"retries={boundary_summary['retry_count']}",
            flush=True,
        )

    release_output_lock(lock_path, lock_descriptor)
    atexit.unregister(release_output_lock)


if __name__ == "__main__":
    main()
