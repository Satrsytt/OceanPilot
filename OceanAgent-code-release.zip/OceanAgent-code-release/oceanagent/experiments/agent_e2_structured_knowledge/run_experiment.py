from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any, Iterable, Mapping

from context_budget import (
    CONTEXT_BUDGETER_VERSION,
    budget_e2_condition_contexts,
    validate_condition_budget_parity,
)
from prompt_contract import (
    CANDIDATE_CONTEXT_REPRESENTATION_VERSION,
    PROMPT_VERSION,
    SYSTEM_PROMPT,
)
from requirement_retrieval import load_e1_runner
from rtc_builder import RTC_BUILDER_VERSION, build_rtc, rtc_context_units
from schemas import AblationId, ConditionId, build_plan
from structured_knowledge_retriever import (
    EXPANSION_VERSION,
    retrieve_structured_knowledge,
    structured_context_units,
)


EXPERIMENT_ROOT = Path(__file__).resolve().parent
DEFAULT_CONFIG = EXPERIMENT_ROOT / "experiment_config_v4.json"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Build or audit an Agent-E2 experiment plan. This scaffold is intentionally "
            "non-executing and never calls an LLM/API."
        )
    )
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--split", choices=("train", "dev", "test"))
    parser.add_argument(
        "--condition",
        choices=tuple(item.value for item in ConditionId),
        default="A0",
    )
    parser.add_argument(
        "--ablation",
        choices=tuple(item.value for item in AblationId),
        default="C0",
    )
    parser.add_argument(
        "--mode",
        choices=("plan", "audit-e1-t1"),
        default="plan",
    )
    parser.add_argument(
        "--e1-run-dir",
        type=Path,
        help="Completed E1 run directory; required only for --mode audit-e1-t1.",
    )
    return parser.parse_args()


def read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"expected a JSON object: {path}")
    return value


def iter_jsonl(path: Path) -> Iterable[dict[str, Any]]:
    with path.open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, start=1):
            if not line.strip():
                continue
            value = json.loads(line)
            if not isinstance(value, dict):
                raise ValueError(f"expected a JSON object at {path}:{line_number}")
            yield value


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def sha256_json(value: Any) -> str:
    payload = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def prepare_condition_contexts(
    *,
    fixed_task_spec: Mapping[str, Any],
    invariant_context: Mapping[str, Any],
    visible_knowledge_view: Any,
    config: Mapping[str, Any],
) -> dict[str, Any]:
    load_e1_runner().validate_task_spec(fixed_task_spec)
    if invariant_context.get("scientific_task_spec") != fixed_task_spec:
        raise ValueError("invariant context must contain the exact frozen ScientificTaskSpec")
    if config["parity_contract"]["recommender_prompt_version"] != PROMPT_VERSION:
        raise ValueError("configured recommender prompt version does not match prompt_contract.py")
    if invariant_context.get("recommender_prompt_version") != PROMPT_VERSION:
        raise ValueError("invariant context does not use the locked E2 prompt version")
    if invariant_context.get("system_prompt") != SYSTEM_PROMPT:
        raise ValueError("invariant context does not contain the locked E2 system prompt")
    shared_components = config["shared_components"]
    if shared_components.get("context_budgeter") != CONTEXT_BUDGETER_VERSION:
        raise ValueError("configured context budgeter version does not match context_budget.py")
    if (
        shared_components.get("candidate_context_representation")
        != CANDIDATE_CONTEXT_REPRESENTATION_VERSION
    ):
        raise ValueError("configured candidate representation version does not match prompt_contract.py")
    if (
        invariant_context.get("candidate_context_representation_version")
        != CANDIDATE_CONTEXT_REPRESENTATION_VERSION
    ):
        raise ValueError("invariant context does not use the locked candidate representation")
    if config["rtc"]["builder_version"] != RTC_BUILDER_VERSION:
        raise ValueError("configured RTC builder version does not match rtc_builder.py")
    retrieval_config = config["structured_retrieval"]
    if retrieval_config.get("expansion_version") != EXPANSION_VERSION:
        raise ValueError(
            "configured structured expansion version does not match "
            "structured_knowledge_retriever.py"
        )
    retrieval = retrieve_structured_knowledge(
        fixed_task_spec,
        visible_knowledge_view,
        psc_top_k=int(retrieval_config["psc_top_k"]),
        k1=float(retrieval_config["k1"]),
        b=float(retrieval_config["b"]),
        minimum_score=float(retrieval_config["minimum_score_exclusive"]),
    )
    rtc = build_rtc(
        fixed_task_spec,
        retrieval,
        max_evidence_per_requirement=int(config["rtc"]["max_evidence_per_requirement"]),
    )
    parity = config["parity_contract"]
    records = budget_e2_condition_contexts(
        invariant_context=invariant_context,
        structured_units=structured_context_units(retrieval),
        rtc_units=rtc_context_units(rtc),
        total_context_token_budget=int(parity["context_token_budget"]),
        output_token_budget=int(parity["output_token_budget"]),
        rtc_reserved_token_budget=int(config["rtc"]["reserved_token_budget"]),
    )
    parity_audit = validate_condition_budget_parity(records)
    return {
        "structured_retrieval_sha256": retrieval.retrieval_hash,
        "structured_retrieval": retrieval.to_dict(),
        "rtc": rtc,
        "condition_contexts": {
            condition: record.to_dict() for condition, record in records.items()
        },
        "context_budget_parity": parity_audit,
    }


def comparison(
    name: str,
    expected: Any,
    observed: Any,
    *,
    required: bool = True,
) -> dict[str, Any]:
    if expected is None or observed is None:
        status = "unresolved" if required else "not_required"
    else:
        status = "match" if expected == observed else "mismatch"
    return {
        "field": name,
        "expected": expected,
        "observed": observed,
        "status": status,
    }


def task_spec_fingerprint(predictions_path: Path) -> tuple[str | None, int]:
    task_specs: dict[str, Mapping[str, Any]] = {}
    for row in iter_jsonl(predictions_path):
        if row.get("condition_id") != "t1_task_spec":
            continue
        query_id = str(row.get("query_id") or "")
        task_spec = row.get("task_spec")
        if not query_id or not isinstance(task_spec, Mapping) or query_id in task_specs:
            raise ValueError("E1 T1 predictions contain an invalid or duplicate TaskSpec row")
        task_specs[query_id] = dict(task_spec)
    if not task_specs:
        return None, 0
    ordered = {query_id: task_specs[query_id] for query_id in sorted(task_specs)}
    return sha256_json(ordered), len(task_specs)


def audit_e1_t1_reuse(
    plan: Mapping[str, Any],
    e1_run_dir: Path,
) -> dict[str, Any]:
    manifest_path = e1_run_dir / "manifest.json"
    predictions_path = e1_run_dir / "predictions.jsonl"
    if not manifest_path.is_file() or not predictions_path.is_file():
        raise FileNotFoundError("completed E1 run must contain manifest.json and predictions.jsonl")
    manifest = read_json(manifest_path)
    parity = plan["parity_contract"]
    task_spec_sha256, t1_count = task_spec_fingerprint(predictions_path)
    manifest_input_hashes = manifest.get("input_sha256")
    if not isinstance(manifest_input_hashes, Mapping):
        manifest_input_hashes = {}
    prompts = manifest.get("prompts")
    if not isinstance(prompts, Mapping):
        prompts = {}
    output_schema_path = Path(str(parity["output_schema_path"]))
    checks = [
        comparison("backbone_model", parity.get("backbone_model"), manifest.get("model")),
        comparison("model_version", parity.get("model_version"), manifest.get("model_version")),
        comparison(
            "fixed_task_spec_sha256",
            parity.get("fixed_task_spec_sha256"),
            task_spec_sha256,
        ),
        comparison(
            "dataset_corpus_sha256",
            parity.get("dataset_corpus_sha256"),
            manifest_input_hashes.get("dataset_corpus"),
        ),
        comparison(
            "recommender_prompt_version",
            parity.get("recommender_prompt_version"),
            prompts.get("dataset_recommender"),
        ),
        comparison("top_k", parity.get("top_k"), manifest.get("top_k")),
        comparison("temperature", parity.get("temperature"), manifest.get("temperature")),
        comparison(
            "context_token_budget",
            parity.get("context_token_budget"),
            manifest.get("context_token_budget"),
        ),
        comparison(
            "output_token_budget",
            parity.get("output_token_budget"),
            manifest.get("output_token_budget"),
        ),
        comparison(
            "output_schema_sha256",
            sha256_file(output_schema_path),
            manifest_input_hashes.get("recommendation_schema"),
        ),
    ]
    expected_t1_count = int(manifest.get("query_count_selected", -1))
    run_complete = (
        manifest.get("condition_selection") == "both"
        and expected_t1_count > 0
        and t1_count == expected_t1_count
    )
    mismatches = [item["field"] for item in checks if item["status"] == "mismatch"]
    unresolved = [item["field"] for item in checks if item["status"] == "unresolved"]
    return {
        "schema_version": "1.0",
        "audit": "E1-T1 versus E2-A0 strict parity",
        "e1_run_complete": run_complete,
        "e1_t1_task_spec_count": t1_count,
        "checks": checks,
        "mismatches": mismatches,
        "unresolved": unresolved,
        "theoretically_reusable": not mismatches,
        "strictly_reusable_now": run_complete and not mismatches and not unresolved,
        "decision_rule": (
            "Reuse E1-T1 as E2-A0 only when the run is complete and every required parity "
            "field is an explicit match."
        ),
        "read_only_provenance": {
            "manifest_sha256": sha256_file(manifest_path),
            "predictions_sha256": sha256_file(predictions_path),
        },
    }


def main() -> None:
    args = parse_args()
    config_path = args.config.resolve()
    config = read_json(config_path)
    split = args.split or str(config.get("split") or "dev")
    plan = build_plan(
        config,
        config_path,
        condition_id=args.condition,
        ablation_id=args.ablation,
        split=split,
    ).to_dict()
    plan["visible_knowledge"] = config["visible_knowledge"]
    plan["structured_retrieval"] = config["structured_retrieval"]
    plan["rtc"] = config["rtc"]
    plan["evaluation"] = config["evaluation"]
    plan["formal_execution_blockers"] = [
        field
        for field in (
            "backbone_model",
            "model_version",
            "fixed_task_spec_sha256",
            "dataset_corpus_sha256",
        )
        if plan["parity_contract"].get(field) is None
    ]
    result: dict[str, Any] = {
        "schema_version": "1.0",
        "mode": args.mode,
        "execution": "disabled; this scaffold performs no model or API calls",
        "plan": plan,
    }
    if args.mode == "audit-e1-t1":
        if args.e1_run_dir is None:
            raise ValueError("--e1-run-dir is required for --mode audit-e1-t1")
        result["e1_t1_reuse_audit"] = audit_e1_t1_reuse(
            plan,
            args.e1_run_dir.resolve(),
        )
    print(json.dumps(result, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()

