from __future__ import annotations

import importlib.util
import json
import sys
from dataclasses import dataclass
from pathlib import Path
from types import ModuleType
from typing import Any, Iterable, Mapping, Sequence


E2_ROOT = Path(__file__).resolve().parent
E1_RUNNER_PATH = E2_ROOT.parent / "agent_e1_taskcompiler" / "run_experiment.py"


def load_e1_runner() -> ModuleType:
    spec = importlib.util.spec_from_file_location("oceanagent_e1_retrieval_reuse", E1_RUNNER_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot import the E1 retrieval implementation: {E1_RUNNER_PATH}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def iter_jsonl(path: Path) -> Iterable[dict[str, Any]]:
    with path.open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, start=1):
            if not line.strip():
                continue
            value = json.loads(line)
            if not isinstance(value, dict):
                raise ValueError(f"expected a JSON object at {path}:{line_number}")
            yield value


@dataclass(frozen=True)
class RequirementQuery:
    requirement_id: str
    slot: str
    text: str


def strings(value: Any) -> list[str]:
    if isinstance(value, str):
        return [value] if value.strip() else []
    if isinstance(value, Mapping):
        return [text for key in sorted(value) for text in strings(value[key])]
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
        return [text for item in value for text in strings(item)]
    return []


def decompose_task_spec(task_spec: Mapping[str, Any]) -> list[RequirementQuery]:
    requirements: list[RequirementQuery] = []
    for index, variable in enumerate(task_spec.get("variables") or [], start=1):
        if not isinstance(variable, Mapping):
            continue
        name = str(variable.get("name") or "").strip()
        if name:
            role = str(variable.get("role") or "unknown")
            requirements.append(
                RequirementQuery(f"variable_{index:02d}", "variable", f"{role} {name}")
            )
    for slot, field in (
        ("target_output", "target_outputs"),
        ("spatial_scope", "spatial_scope"),
        ("temporal_scope", "temporal_scope"),
        ("vertical_scope", "depth_scope"),
        ("method", "methodological_constraints"),
        ("data_constraint", "data_constraints"),
        ("validation", "validation_expectations"),
    ):
        for index, text in enumerate(strings(task_spec.get(field)), start=1):
            requirements.append(RequirementQuery(f"{slot}_{index:02d}", slot, text))
    if not requirements:
        goal = str(task_spec.get("research_goal") or "").strip()
        if not goal:
            raise ValueError("fixed ScientificTaskSpec contains no retrievable requirement")
        requirements.append(RequirementQuery("research_goal_01", "research_goal", goal))
    return requirements


class SharedE1Retriever:
    """Thin adapter over E1's canonical BM25 implementation."""

    def __init__(
        self,
        dataset_corpus: Sequence[Mapping[str, Any]],
        *,
        k1: float,
        b: float,
    ) -> None:
        self.e1 = load_e1_runner()
        self.index = self.e1.BM25Index(dataset_corpus, k1=k1, b=b)

    def retrieve(
        self,
        query: str,
        fixed_task_spec: Mapping[str, Any],
        *,
        limit: int,
        requirement_decomposition: bool,
    ) -> list[dict[str, Any]]:
        self.e1.validate_task_spec(fixed_task_spec)
        if not requirement_decomposition:
            retrieval_text = "\n".join(
                [query, *self.e1.flatten_strings(fixed_task_spec)]
            )
            return self.index.search(retrieval_text, limit)

        requirement_queries = decompose_task_spec(fixed_task_spec)
        best_rank: dict[str, int] = {}
        cards: dict[str, dict[str, Any]] = {}
        per_requirement_limit = max(limit, 10)
        for requirement in requirement_queries:
            retrieval_text = "\n".join([query, requirement.text])
            for rank, card in enumerate(
                self.index.search(retrieval_text, per_requirement_limit), start=1
            ):
                dataset_id = str(card.get("dataset_id") or "")
                if not dataset_id:
                    raise ValueError("dataset corpus contains an empty dataset_id")
                cards[dataset_id] = dict(card)
                best_rank[dataset_id] = min(rank, best_rank.get(dataset_id, rank))
        ordered = sorted(cards, key=lambda dataset_id: (best_rank[dataset_id], dataset_id))
        return [cards[dataset_id] for dataset_id in ordered[:limit]]


def load_dataset_corpus(knowledge_root: Path) -> list[dict[str, Any]]:
    path = knowledge_root / "benchmark" / "corpus" / "dataset_corpus.jsonl"
    rows = list(iter_jsonl(path))
    identities = [str(row.get("dataset_id") or "") for row in rows]
    if "" in identities or len(identities) != len(set(identities)):
        raise ValueError("dataset corpus contains empty or duplicate dataset IDs")
    return rows

