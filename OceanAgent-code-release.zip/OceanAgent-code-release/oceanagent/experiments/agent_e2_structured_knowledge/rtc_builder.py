from __future__ import annotations

import json
import re
from dataclasses import dataclass
from typing import Any, Mapping, Sequence

from context_budget import ContextUnit, sha256_json
from requirement_retrieval import decompose_task_spec
from structured_knowledge_retriever import (
    StructuredKnowledgeResult,
    structured_context_units,
)


RTC_BUILDER_VERSION = "evidence-grounded-rtc-v2"
TOKEN_PATTERN = re.compile(r"[a-z0-9]+(?:[._/-][a-z0-9]+)*", re.IGNORECASE)
STOPWORDS = {
    "and",
    "are",
    "data",
    "dataset",
    "for",
    "from",
    "into",
    "of",
    "the",
    "to",
    "using",
    "with",
}


def tokens(value: str) -> set[str]:
    return {
        token
        for token in TOKEN_PATTERN.findall(value.casefold())
        if len(token) > 1 and token not in STOPWORDS
    }


@dataclass(frozen=True)
class EvidenceAtom:
    evidence_id: str
    provenance_kind: str
    source_type: str
    source_id: str
    source_field: str
    text: str
    provenance: Mapping[str, Any]


def evidence_atoms(result: StructuredKnowledgeResult) -> list[EvidenceAtom]:
    atoms: dict[str, EvidenceAtom] = {}
    for unit in structured_context_units(result):
        payload = dict(unit.payload)
        provenance = payload.get("provenance")
        if not isinstance(provenance, Mapping):
            provenance = payload
        source_type = str(provenance.get("source_type") or "")
        source_id = str(provenance.get("source_id") or "")
        source_field = str(provenance.get("source_field") or "")
        evidence_id = str(provenance.get("evidence_id") or "")
        provenance_kind = str(provenance.get("provenance_kind") or "")
        if provenance_kind == "source_evidence":
            # Only the source's own quote/text can support a requirement.  IDs,
            # URLs, and wrapper metadata must never create lexical support.
            raw_text = provenance.get("quote") or provenance.get("text")
        else:
            raw_text = provenance.get("text") or payload.get("text")
        evidence_text = str(raw_text or "").strip()
        if provenance_kind not in {"source_evidence", "card_field"}:
            continue
        if not all((source_type, source_id, source_field, evidence_id, evidence_text)):
            continue
        atom = EvidenceAtom(
            evidence_id=evidence_id,
            provenance_kind=provenance_kind,
            source_type=source_type,
            source_id=source_id,
            source_field=source_field,
            text=evidence_text,
            provenance=dict(provenance),
        )
        atoms[evidence_id] = atom
    return [atoms[key] for key in sorted(atoms)]


def support_score(requirement_text: str, evidence_text: str) -> float:
    requirement_tokens = tokens(requirement_text)
    if not requirement_tokens:
        return 0.0
    overlap = requirement_tokens.intersection(tokens(evidence_text))
    return len(overlap) / len(requirement_tokens)


def build_rtc(
    fixed_task_spec: Mapping[str, Any],
    retrieval: StructuredKnowledgeResult,
    *,
    max_evidence_per_requirement: int = 4,
) -> dict[str, Any]:
    if max_evidence_per_requirement <= 0:
        raise ValueError("max_evidence_per_requirement must be positive")
    requirements = decompose_task_spec(fixed_task_spec)
    atoms = evidence_atoms(retrieval)
    traces: list[dict[str, Any]] = []
    for requirement in requirements:
        ranked = sorted(
            (
                (support_score(requirement.text, atom.text), atom)
                for atom in atoms
            ),
            key=lambda item: (-item[0], item[1].evidence_id),
        )
        matching = [item for item in ranked if item[0] > 0.0]
        source_evidence = [
            item for item in matching if item[1].provenance_kind == "source_evidence"
        ][:max_evidence_per_requirement]
        card_field_evidence = [
            item for item in matching if item[1].provenance_kind == "card_field"
        ][:max_evidence_per_requirement]
        if source_evidence:
            support_status = "supported"
            selected_evidence = source_evidence
        elif card_field_evidence:
            support_status = "weak_support"
            selected_evidence = card_field_evidence
        else:
            support_status = "unsupported"
            selected_evidence = []
        traces.append(
            {
                "requirement_id": requirement.requirement_id,
                "slot": requirement.slot,
                "requirement_text": requirement.text,
                "support_status": support_status,
                "supporting_evidence": [
                    {
                        "evidence_id": atom.evidence_id,
                        "provenance_kind": atom.provenance_kind,
                        "support_score": score,
                        "source_type": atom.source_type,
                        "source_id": atom.source_id,
                        "source_field": atom.source_field,
                        "text": atom.text,
                        "provenance": dict(atom.provenance),
                    }
                    for score, atom in selected_evidence
                ],
            }
        )
    rtc_core = {
        "schema_version": "1.0",
        "builder_version": RTC_BUILDER_VERSION,
        "task_spec_sha256": sha256_json(fixed_task_spec),
        "structured_retrieval_sha256": retrieval.retrieval_hash,
        "source_artifact_ids": {
            "problem_solution_cards": [
                str(card["card_id"]) for card in retrieval.problem_solution_cards
            ],
            "usage_bundle_cards": [
                str(card["bundle_id"]) for card in retrieval.usage_bundle_cards
            ],
            "dataset_cards": [
                str(card["dataset_id"]) for card in retrieval.dataset_cards
            ],
        },
        "requirement_traces": traces,
        "rtc_eligible": any(trace["support_status"] == "supported" for trace in traces),
        "forbidden_inputs": [
            "task_requirement_gold.jsonl",
            "valid_route_gold.jsonl",
            "dataset_gold.jsonl",
            "paper_usage_gold.jsonl",
        ],
    }
    return {**rtc_core, "rtc_id": "rtc_" + sha256_json(rtc_core)[:16]}


def validate_rtc_provenance(rtc: Mapping[str, Any]) -> dict[str, Any]:
    traces = rtc.get("requirement_traces")
    if not isinstance(traces, list) or not traces:
        raise ValueError("RTC must contain requirement_traces")
    evidence_ids: list[str] = []
    supported_count = 0
    for trace in traces:
        if not isinstance(trace, Mapping):
            raise ValueError("RTC trace must be an object")
        status = trace.get("support_status")
        evidence = trace.get("supporting_evidence")
        if status not in {"supported", "weak_support", "unsupported"} or not isinstance(evidence, list):
            raise ValueError("RTC trace has invalid support status or evidence")
        if any(not isinstance(item, Mapping) for item in evidence):
            raise ValueError("RTC supporting evidence must be an object")
        if status == "supported":
            supported_count += 1
            if not evidence:
                raise ValueError("supported RTC trace has no evidence")
            if not any(item.get("provenance_kind") == "source_evidence" for item in evidence):
                raise ValueError(
                    "supported RTC trace requires at least one source_evidence item"
                )
        if status == "weak_support":
            if not evidence:
                raise ValueError("weak_support RTC trace has no evidence")
            if any(item.get("provenance_kind") != "card_field" for item in evidence):
                raise ValueError(
                    "weak_support RTC trace may contain only card_field provenance"
                )
        if status == "unsupported" and evidence:
            raise ValueError("unsupported RTC trace must not contain evidence")
        for item in evidence:
            required = (
                "evidence_id",
                "source_type",
                "source_id",
                "source_field",
                "provenance_kind",
                "provenance",
            )
            if any(not item.get(field) for field in required):
                raise ValueError("RTC evidence is missing provenance fields")
            if item["source_type"] not in {
                "ProblemSolutionCard",
                "UsageBundleCard",
                "DatasetCard",
            }:
                raise ValueError("RTC evidence references a forbidden source type")
            if item["provenance_kind"] not in {"source_evidence", "card_field"}:
                raise ValueError("RTC evidence has an invalid provenance kind")
            evidence_ids.append(str(item["evidence_id"]))
    return {
        "status": "pass",
        "trace_count": len(traces),
        "supported_trace_count": supported_count,
        "selected_evidence_ids": sorted(set(evidence_ids)),
        "rtc_eligible": supported_count > 0,
    }


def rtc_context_units(rtc: Mapping[str, Any]) -> list[ContextUnit]:
    validate_rtc_provenance(rtc)
    units: list[ContextUnit] = []
    for trace in rtc["requirement_traces"]:
        if trace["support_status"] != "supported":
            continue
        evidence_ids = tuple(
            sorted(str(item["evidence_id"]) for item in trace["supporting_evidence"])
        )
        units.append(
            ContextUnit(
                unit_id=f"rtc_trace:{rtc['rtc_id']}:{trace['requirement_id']}",
                kind="rtc_requirement_trace",
                priority=5,
                payload=dict(trace),
                evidence_ids=evidence_ids,
            )
        )
    return units
