from __future__ import annotations

import json
from typing import Any, Mapping, Sequence

from context_budget import BudgetedContext, sha256_json


PROMPT_VERSION = "oceanagent-e2-knowledge-scope-v1"
CANDIDATE_CONTEXT_REPRESENTATION_VERSION = "datasetcard-decision-fields-compact-v2"
CANDIDATE_DESCRIPTION_MAX_CHARS = 360
CANDIDATE_NAME_MAX_CHARS = 180
CANDIDATE_PROVIDER_MAX_CHARS = 180
CANDIDATE_COVERAGE_VALUE_MAX_CHARS = 180
CANDIDATE_RESOLUTION_VALUE_MAX_CHARS = 120
CANDIDATE_FIELD_COUNT_MAX = 4
CANDIDATE_FIELD_NAME_MAX_CHARS = 120
CANDIDATE_FIELD_DESCRIPTION_MAX_CHARS = 120
CANDIDATE_FIELD_UNIT_MAX_CHARS = 80
SYSTEM_PROMPT = (
    "You are OceanAgent's controlled scientific DatasetCard recommender. Rank exactly "
    "the requested number of unique datasets from candidate_dataset_cards. Never output "
    "a dataset outside that candidate list. Use the frozen ScientificTaskSpec as the task "
    "definition. structured_knowledge_context may be empty and may contain only retrieved, "
    "provenance-bearing PSC, UBC, DatasetCard, or RTC material. Do not treat a dataset's "
    "appearance in a paper as proof that it is scientifically sufficient. Cover the stated "
    "variables, roles, spatial/temporal/depth scope, quality control, and validation needs. "
    "Do not invent facts absent from the supplied context."
)


def output_contract_text(
    *, schema_name: str, output_schema: Mapping[str, Any]
) -> str:
    """Mirror benchmark.common.openai_compatible_json's model-visible contract.

    Keeping the exact schema contract in the invariant accounting prevents the
    provider helper's schema injection from silently escaping the input budget.
    """
    schema_text = json.dumps(dict(output_schema), ensure_ascii=False, sort_keys=True)
    return (
        "\n\nOUTPUT CONTRACT (mandatory):\n"
        f"Return exactly one JSON object conforming to the JSON Schema named {schema_name!r}.\n"
        "Return JSON only. Do not use Markdown code fences. Do not add prose before or after JSON.\n"
        "Use the schema field names exactly as written. Do not invent aliases or alternative top-level fields.\n"
        "If a value is unknown, use only a representation permitted by the schema.\n"
        f"JSON Schema:\n{schema_text}"
    )


def _bounded_text(value: Any, max_chars: int) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    if not text:
        return None
    return text[:max_chars]


def _bounded_scope(value: Any, max_chars: int) -> Any:
    if isinstance(value, Mapping):
        return {
            str(key): _bounded_scope(value[key], max_chars)
            for key in sorted(value)
        }
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
        return [_bounded_scope(item, max_chars) for item in list(value)[:8]]
    if isinstance(value, str):
        return _bounded_text(value, max_chars)
    if value is None or isinstance(value, (bool, int, float)):
        return value
    return _bounded_text(value, max_chars)


def compact_candidate_card(card: Mapping[str, Any]) -> dict[str, Any]:
    """Project a DatasetCard onto a deterministic, decision-relevant prompt view."""
    coverage = card.get("coverage") if isinstance(card.get("coverage"), Mapping) else {}
    resolution = card.get("resolution") if isinstance(card.get("resolution"), Mapping) else {}
    raw_fields = card.get("fields") or card.get("variables") or []
    compact_fields: list[dict[str, Any]] = []
    if isinstance(raw_fields, Sequence) and not isinstance(raw_fields, (str, bytes)):
        for field in list(raw_fields)[:CANDIDATE_FIELD_COUNT_MAX]:
            if not isinstance(field, Mapping):
                continue
            compact_fields.append(
                {
                    "name": _bounded_text(
                        field.get("name") or field.get("raw_name"),
                        CANDIDATE_FIELD_NAME_MAX_CHARS,
                    ),
                    "description": _bounded_text(
                        field.get("description"),
                        CANDIDATE_FIELD_DESCRIPTION_MAX_CHARS,
                    ),
                    "unit": _bounded_text(field.get("unit"), CANDIDATE_FIELD_UNIT_MAX_CHARS),
                }
            )
    return {
        "dataset_id": _bounded_text(card.get("dataset_id"), 240),
        "name": _bounded_text(
            card.get("name") or card.get("product_name"),
            CANDIDATE_NAME_MAX_CHARS,
        ),
        "provider": _bounded_text(card.get("provider"), CANDIDATE_PROVIDER_MAX_CHARS),
        "description": _bounded_text(
            card.get("description"),
            CANDIDATE_DESCRIPTION_MAX_CHARS,
        ),
        "coverage": {
            "spatial": _bounded_scope(
                card.get("spatial_coverage") or coverage.get("spatial"),
                CANDIDATE_COVERAGE_VALUE_MAX_CHARS,
            ),
            "temporal": _bounded_scope(
                card.get("temporal_coverage") or coverage.get("temporal"),
                CANDIDATE_COVERAGE_VALUE_MAX_CHARS,
            ),
            "vertical": _bounded_scope(
                card.get("vertical_coverage") or coverage.get("vertical"),
                CANDIDATE_COVERAGE_VALUE_MAX_CHARS,
            ),
        },
        "resolution": {
            "spatial": _bounded_scope(
                card.get("spatial_resolution") or resolution.get("spatial"),
                CANDIDATE_RESOLUTION_VALUE_MAX_CHARS,
            ),
            "temporal": _bounded_scope(
                card.get("temporal_resolution") or resolution.get("temporal"),
                CANDIDATE_RESOLUTION_VALUE_MAX_CHARS,
            ),
            "vertical": _bounded_scope(
                card.get("vertical_resolution") or resolution.get("vertical"),
                CANDIDATE_RESOLUTION_VALUE_MAX_CHARS,
            ),
        },
        "fields": compact_fields,
    }


def compact_candidate_cards(
    cards: Sequence[Mapping[str, Any]],
) -> list[dict[str, Any]]:
    return [compact_candidate_card(card) for card in cards]


def build_invariant_context(
    *,
    fixed_task_spec: Mapping[str, Any],
    candidate_dataset_cards: Sequence[Mapping[str, Any]],
    top_k: int,
    output_schema: Mapping[str, Any],
    output_schema_sha256: str,
    ranking_chain_version: str,
) -> dict[str, Any]:
    if top_k != 10:
        raise ValueError("formal E2 prompt contract fixes K=10")
    compact_candidates = compact_candidate_cards(candidate_dataset_cards)
    dataset_ids = [str(card.get("dataset_id") or "") for card in compact_candidates]
    if "" in dataset_ids or len(dataset_ids) != len(set(dataset_ids)):
        raise ValueError("candidate DatasetCards contain empty or duplicate dataset IDs")
    return {
        "recommender_prompt_version": PROMPT_VERSION,
        "candidate_context_representation_version": CANDIDATE_CONTEXT_REPRESENTATION_VERSION,
        "system_prompt": SYSTEM_PROMPT,
        "scientific_task_spec": dict(fixed_task_spec),
        "candidate_dataset_cards": compact_candidates,
        "top_k": top_k,
        "output_contract": output_contract_text(
            schema_name="DatasetRecommendation",
            output_schema=output_schema,
        ),
        "output_schema_sha256": output_schema_sha256,
        "ranking_chain_version": ranking_chain_version,
    }


def build_model_messages(
    *,
    invariant_context: Mapping[str, Any],
    budgeted_context: BudgetedContext,
) -> tuple[list[dict[str, str]], dict[str, Any]]:
    if invariant_context.get("recommender_prompt_version") != PROMPT_VERSION:
        raise ValueError("invariant context uses an unknown recommender prompt version")
    if invariant_context.get("system_prompt") != SYSTEM_PROMPT:
        raise ValueError("invariant system prompt does not match the locked E2 prompt")
    if (
        invariant_context.get("candidate_context_representation_version")
        != CANDIDATE_CONTEXT_REPRESENTATION_VERSION
    ):
        raise ValueError("invariant context uses an unknown candidate representation version")
    if budgeted_context.invariant_context_hash != sha256_json(invariant_context):
        raise ValueError("budget record does not belong to the supplied invariant context")
    user_payload = {
        "scientific_task_spec": invariant_context["scientific_task_spec"],
        "candidate_dataset_cards": invariant_context["candidate_dataset_cards"],
        "structured_knowledge_context": list(budgeted_context.selected_context),
        "top_k": invariant_context["top_k"],
    }
    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {
            "role": "user",
            "content": json.dumps(
                user_payload,
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
            ),
        },
    ]
    audit = {
        "prompt_version": PROMPT_VERSION,
        "candidate_context_representation_version": CANDIDATE_CONTEXT_REPRESENTATION_VERSION,
        "system_prompt_sha256": sha256_json(SYSTEM_PROMPT),
        "invariant_context_hash": budgeted_context.invariant_context_hash,
        "model_visible_payload_sha256": sha256_json(user_payload),
        "condition_id_not_model_visible": True,
    }
    return messages, audit
