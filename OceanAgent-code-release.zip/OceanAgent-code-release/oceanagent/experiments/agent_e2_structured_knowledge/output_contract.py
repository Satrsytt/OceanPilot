from __future__ import annotations

from dataclasses import asdict, dataclass
import re
from typing import Any, Callable, Mapping, Sequence

from requirement_retrieval import decompose_task_spec


OUTPUT_CONTRACT_AUDIT_VERSION = "bounded-recommendation-worst-case-v1"


@dataclass(frozen=True)
class RecommendationOutputCaps:
    recommendation_count: int
    dataset_id_max_length: int
    reason_max_length: int
    matched_requirements_max_items: int
    matched_requirement_max_length: int
    reason_pattern: str
    matched_requirement_pattern: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def recommendation_output_caps(
    schema: Mapping[str, Any],
) -> RecommendationOutputCaps:
    recommendations = schema["properties"]["recommendations"]
    minimum = int(recommendations["minItems"])
    maximum = int(recommendations["maxItems"])
    if minimum != maximum:
        raise ValueError("recommendation output schema must fix an exact item count")
    properties = recommendations["items"]["properties"]
    matched = properties["matched_requirements"]
    return RecommendationOutputCaps(
        recommendation_count=maximum,
        dataset_id_max_length=int(properties["dataset_id"]["maxLength"]),
        reason_max_length=int(properties["reason"]["maxLength"]),
        matched_requirements_max_items=int(matched["maxItems"]),
        matched_requirement_max_length=int(matched["items"]["maxLength"]),
        reason_pattern=str(properties["reason"]["pattern"]),
        matched_requirement_pattern=str(matched["items"]["pattern"]),
    )


def _validate_bounded_string(
    value: str,
    *,
    field: str,
    max_length: int,
    pattern: str,
) -> None:
    if len(value) > max_length:
        raise ValueError(f"{field} exceeds schema maxLength={max_length}")
    if re.fullmatch(pattern, value) is None:
        raise ValueError(f"{field} violates the bounded-text schema pattern")


def validate_recommendation_output_contract(
    value: Mapping[str, Any],
    schema: Mapping[str, Any],
) -> None:
    caps = recommendation_output_caps(schema)
    recommendations = value.get("recommendations")
    if not isinstance(recommendations, list) or len(recommendations) != caps.recommendation_count:
        raise ValueError(
            "recommendations does not satisfy the schema's exact item count"
        )
    for index, recommendation in enumerate(recommendations, start=1):
        if not isinstance(recommendation, Mapping):
            raise ValueError(f"recommendation {index} is not an object")
        dataset_id = recommendation.get("dataset_id")
        reason = recommendation.get("reason")
        matched = recommendation.get("matched_requirements")
        if not isinstance(dataset_id, str) or len(dataset_id) > caps.dataset_id_max_length:
            raise ValueError(
                f"recommendation {index} dataset_id exceeds schema maxLength="
                f"{caps.dataset_id_max_length}"
            )
        if not isinstance(reason, str):
            raise ValueError(f"recommendation {index} reason is not a string")
        _validate_bounded_string(
            reason,
            field=f"recommendation {index} reason",
            max_length=caps.reason_max_length,
            pattern=caps.reason_pattern,
        )
        if not isinstance(matched, list):
            raise ValueError(
                f"recommendation {index} matched_requirements is not an array"
            )
        if len(matched) > caps.matched_requirements_max_items:
            raise ValueError(
                f"recommendation {index} matched_requirements exceeds schema maxItems="
                f"{caps.matched_requirements_max_items}"
            )
        for item_index, item in enumerate(matched, start=1):
            if not isinstance(item, str):
                raise ValueError(
                    f"recommendation {index} matched requirement {item_index} is not a string"
                )
            _validate_bounded_string(
                item,
                field=f"recommendation {index} matched requirement {item_index}",
                max_length=caps.matched_requirement_max_length,
                pattern=caps.matched_requirement_pattern,
            )


def formal_requirement_structure_audit(
    task_specs: Mapping[str, Mapping[str, Any]],
    schema: Mapping[str, Any],
) -> dict[str, Any]:
    caps = recommendation_output_caps(schema)
    counts: dict[str, int] = {}
    requirement_ids: list[str] = []
    for query_id in sorted(task_specs):
        requirements = decompose_task_spec(task_specs[query_id])
        counts[query_id] = len(requirements)
        requirement_ids.extend(item.requirement_id for item in requirements)
    maximum_count = max(counts.values())
    maximum_id_length = max(len(item) for item in requirement_ids)
    output_capacity = caps.recommendation_count * caps.matched_requirements_max_items
    if output_capacity < maximum_count:
        raise RuntimeError(
            "matched-requirement capacity cannot represent the largest formal TaskSpec"
        )
    if caps.matched_requirement_max_length < maximum_id_length:
        raise RuntimeError(
            "matched-requirement maxLength cannot represent every formal requirement ID"
        )
    return {
        "audit_version": OUTPUT_CONTRACT_AUDIT_VERSION,
        "query_count": len(task_specs),
        "minimum_requirement_count": min(counts.values()),
        "maximum_requirement_count": maximum_count,
        "maximum_requirement_count_query_ids": sorted(
            query_id for query_id, count in counts.items() if count == maximum_count
        ),
        "maximum_requirement_id_length": maximum_id_length,
        "maximum_requirement_ids": sorted(
            {item for item in requirement_ids if len(item) == maximum_id_length}
        ),
        "matched_requirement_capacity": output_capacity,
        "caps": caps.to_dict(),
        "status": "pass",
    }


def worst_case_output_for_candidates(
    candidate_dataset_ids: Sequence[str],
    schema: Mapping[str, Any],
    *,
    token_counter: Callable[[Any], int],
) -> dict[str, Any]:
    caps = recommendation_output_caps(schema)
    if len(candidate_dataset_ids) < caps.recommendation_count:
        raise ValueError("candidate pool is smaller than the required recommendation count")
    if any(len(dataset_id) > caps.dataset_id_max_length for dataset_id in candidate_dataset_ids):
        raise RuntimeError("formal candidate Dataset ID exceeds schema maxLength")
    worst_ids = sorted(
        (str(item) for item in candidate_dataset_ids),
        key=lambda item: (-token_counter(item), item),
    )[: caps.recommendation_count]
    maximal_character = "界"
    if re.fullmatch(caps.reason_pattern, maximal_character) is None or re.fullmatch(
        caps.matched_requirement_pattern, maximal_character
    ) is None:
        raise RuntimeError("bounded-text schema pattern rejects the audit character")
    worst_case = {
        "recommendations": [
            {
                "dataset_id": dataset_id,
                "reason": maximal_character * caps.reason_max_length,
                "matched_requirements": [
                    maximal_character * caps.matched_requirement_max_length
                ]
                * caps.matched_requirements_max_items,
            }
            for dataset_id in worst_ids
        ]
    }
    fixed_overhead = {
        "recommendations": [
            {
                "dataset_id": dataset_id,
                "reason": "x",
                "matched_requirements": [],
            }
            for dataset_id in worst_ids
        ]
    }
    validate_recommendation_output_contract(worst_case, schema)
    return {
        "audit_version": OUTPUT_CONTRACT_AUDIT_VERSION,
        "worst_case_token_count": token_counter(worst_case),
        "fixed_field_overhead_token_count": token_counter(fixed_overhead),
        "candidate_dataset_ids": worst_ids,
        "escaping_bound": (
            "reason and matched-requirement patterns exclude control characters, "
            "ASCII quotes, and backslashes, so canonical JSON escaping cannot expand "
            "the bounded free-text fields"
        ),
    }
