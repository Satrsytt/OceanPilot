from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import math
import os
import re
import sys
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from types import ModuleType
from typing import Any, Iterable, Mapping, MutableMapping, Sequence


EXPERIMENT_ROOT = Path(__file__).resolve().parent
AGENT_ROOT = EXPERIMENT_ROOT.parents[1]
DEFAULT_CONFIG = EXPERIMENT_ROOT / "experiment_config.json"
TASK_SPEC_SCHEMA_PATH = EXPERIMENT_ROOT / "schemas" / "scientific_task_spec.schema.json"
RECOMMENDATION_SCHEMA_PATH = EXPERIMENT_ROOT / "schemas" / "recommendation_output.schema.json"
CONDITIONS = ("t0_raw_query", "t1_task_spec")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run the paired Agent-E1 TaskCompiler dataset-recommendation experiment."
    )
    parser.add_argument("--knowledge-root", type=Path)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--split", choices=("train", "dev", "test"))
    parser.add_argument(
        "--condition",
        choices=("both", *CONDITIONS),
        default="both",
    )
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--query-id", action="append", default=[])
    parser.add_argument("--max-queries", type=int)
    parser.add_argument(
        "--allow-test-split",
        action="store_true",
        help="Explicit acknowledgement required to run the frozen test split.",
    )
    return parser.parse_args()


def read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"expected a JSON object: {path}")
    return value


def iter_jsonl(path: Path) -> Iterable[dict[str, Any]]:
    with path.open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, start=1):
            if not line.strip():
                continue
            value = json.loads(line)
            if not isinstance(value, dict):
                raise ValueError(f"expected a JSON object at {path}:{line_number}")
            yield value


def load_runtime_query_view(path: Path) -> list[dict[str, str | None]]:
    """Project a benchmark split onto fields permitted during Agent inference."""
    rows: list[dict[str, str | None]] = []
    seen: set[str] = set()
    for source_row in iter_jsonl(path):
        query_id = str(source_row.get("query_id") or "")
        query = str(source_row.get("query") or "")
        if not query_id or not query:
            raise ValueError(f"runtime split row is missing query_id or query: {path}")
        if query_id in seen:
            raise ValueError(f"runtime split contains duplicate query_id {query_id!r}: {path}")
        seen.add(query_id)
        rows.append(
            {
                "query_id": query_id,
                "benchmark_id": (
                    str(source_row["benchmark_id"])
                    if source_row.get("benchmark_id") is not None
                    else None
                ),
                "query": query,
            }
        )
    return rows


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def sha256_json(value: Any) -> str:
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def resolve_knowledge_root(explicit: Path | None) -> Path:
    candidates: list[Path] = []
    if explicit is not None:
        candidates.append(explicit)
    environment_value = os.environ.get("OCEAN_RAG_ROOT")
    if environment_value:
        candidates.append(Path(environment_value))
    candidates.extend(
        [
            AGENT_ROOT.parent / "benchmark" / "knowledge_snapshot",
            AGENT_ROOT / "Ocean-RAG",
            AGENT_ROOT.parent.parent / "OceanKnowledgeBase" / "Ocean-RAG",
        ]
    )
    checked: list[str] = []
    for candidate in candidates:
        root = candidate.expanduser().resolve()
        checked.append(str(root))
        if (
            (root / "benchmark" / "splits" / "dev.jsonl").is_file()
            and (root / "benchmark" / "corpus" / "dataset_corpus.jsonl").is_file()
            and (root / "benchmark" / "common.py").is_file()
        ):
            return root
    raise FileNotFoundError(
        "could not locate a complete Ocean-RAG benchmark; checked: " + "; ".join(checked)
    )


def load_benchmark_common(knowledge_root: Path) -> ModuleType:
    path = knowledge_root / "benchmark" / "common.py"
    spec = importlib.util.spec_from_file_location("oceanagentbench_common", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot import benchmark helpers from {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def resolve_model_config(config: Mapping[str, Any]) -> dict[str, Any]:
    block = config.get("model")
    if not isinstance(block, dict):
        raise ValueError("experiment_config.json must contain a model object")
    return {
        "model": os.environ.get(str(block["model_env"]), str(block["default_model"])),
        "base_url": os.environ.get(
            str(block["base_url_env"]), str(block["default_base_url"])
        ),
        "api_key": os.environ.get(str(block["api_key_env"]), ""),
        "temperature": float(block.get("temperature", 0.0)),
        "timeout": int(block.get("timeout_seconds", 180)),
        "max_attempts": int(block.get("max_attempts", 3)),
    }


TOKEN_PATTERN = re.compile(r"[a-z0-9]+|[\u4e00-\u9fff]", flags=re.IGNORECASE)


def tokenize(value: str) -> list[str]:
    return TOKEN_PATTERN.findall(value.casefold())


def flatten_strings(value: Any) -> list[str]:
    if isinstance(value, str):
        return [value]
    if isinstance(value, list):
        result: list[str] = []
        for item in value:
            result.extend(flatten_strings(item))
        return result
    if isinstance(value, dict):
        result = []
        for key in sorted(value):
            result.extend(flatten_strings(value[key]))
        return result
    return []


def dataset_document(card: Mapping[str, Any]) -> str:
    coverage = card.get("coverage") if isinstance(card.get("coverage"), dict) else {}
    resolution = card.get("resolution") if isinstance(card.get("resolution"), dict) else {}
    fields = card.get("variables") or card.get("fields") or []
    field_text: list[str] = []
    for field in fields[:20] if isinstance(fields, list) else []:
        if not isinstance(field, dict):
            continue
        field_text.extend(
            str(field.get(key) or "")
            for key in ("raw_name", "description", "unit", "dimensions")
        )
    values = [
        card.get("dataset_id"),
        card.get("product_name") or card.get("name"),
        card.get("aliases"),
        card.get("description"),
        card.get("provider"),
        card.get("spatial_coverage") or coverage.get("spatial"),
        card.get("temporal_coverage") or coverage.get("temporal"),
        card.get("vertical_coverage") or coverage.get("vertical"),
        card.get("spatial_resolution") or resolution.get("spatial"),
        card.get("temporal_resolution") or resolution.get("temporal"),
        card.get("vertical_resolution") or resolution.get("vertical"),
        field_text,
    ]
    return " ".join(item for value in values for item in flatten_strings(value) if item)


class BM25Index:
    def __init__(
        self,
        cards: Sequence[Mapping[str, Any]],
        *,
        k1: float,
        b: float,
    ) -> None:
        self.cards = [dict(card) for card in cards]
        self.k1 = k1
        self.b = b
        self.term_frequencies: list[Counter[str]] = []
        document_frequencies: Counter[str] = Counter()
        lengths: list[int] = []
        for card in self.cards:
            terms = tokenize(dataset_document(card))
            frequencies = Counter(terms)
            self.term_frequencies.append(frequencies)
            document_frequencies.update(frequencies.keys())
            lengths.append(len(terms))
        self.lengths = lengths
        self.average_length = sum(lengths) / len(lengths) if lengths else 1.0
        count = len(self.cards)
        self.idf = {
            term: math.log(1.0 + (count - frequency + 0.5) / (frequency + 0.5))
            for term, frequency in document_frequencies.items()
        }

    def search(self, text: str, limit: int) -> list[dict[str, Any]]:
        query_terms = Counter(tokenize(text))
        scored: list[tuple[float, str, dict[str, Any]]] = []
        for card, frequencies, document_length in zip(
            self.cards, self.term_frequencies, self.lengths
        ):
            score = 0.0
            length_norm = 1.0 - self.b + self.b * document_length / self.average_length
            for term, query_frequency in query_terms.items():
                term_frequency = frequencies.get(term, 0)
                if not term_frequency:
                    continue
                numerator = term_frequency * (self.k1 + 1.0)
                denominator = term_frequency + self.k1 * length_norm
                score += self.idf.get(term, 0.0) * numerator / denominator * query_frequency
            dataset_id = str(card.get("dataset_id") or "")
            scored.append((score, dataset_id, card))
        scored.sort(key=lambda item: (-item[0], item[1]))
        return [card for _, _, card in scored[:limit]]


def compact_card(card: Mapping[str, Any]) -> dict[str, Any]:
    coverage = card.get("coverage") if isinstance(card.get("coverage"), dict) else {}
    resolution = card.get("resolution") if isinstance(card.get("resolution"), dict) else {}
    fields = card.get("variables") or card.get("fields") or []
    compact_fields = []
    for field in fields[:12] if isinstance(fields, list) else []:
        if isinstance(field, dict):
            compact_fields.append(
                {
                    "name": field.get("raw_name"),
                    "description": field.get("description"),
                    "unit": field.get("unit"),
                }
            )
    return {
        "dataset_id": card.get("dataset_id"),
        "name": card.get("product_name") or card.get("name"),
        "aliases": (card.get("aliases") or [])[:5],
        "description": str(card.get("description") or "")[:900],
        "provider": card.get("provider"),
        "coverage": {
            "spatial": card.get("spatial_coverage") or coverage.get("spatial"),
            "temporal": card.get("temporal_coverage") or coverage.get("temporal"),
            "vertical": card.get("vertical_coverage") or coverage.get("vertical"),
        },
        "resolution": {
            "spatial": card.get("spatial_resolution") or resolution.get("spatial"),
            "temporal": card.get("temporal_resolution") or resolution.get("temporal"),
            "vertical": card.get("vertical_resolution") or resolution.get("vertical"),
        },
        "fields": compact_fields,
    }


def validate_task_spec(value: Mapping[str, Any]) -> None:
    required = {
        "research_goal",
        "research_domain",
        "target_outputs",
        "variables",
        "spatial_scope",
        "temporal_scope",
        "depth_scope",
        "methodological_constraints",
        "data_constraints",
        "validation_expectations",
        "unresolved_items",
        "retrieval_terms",
    }
    if set(value) != required:
        raise ValueError(
            f"ScientificTaskSpec fields must be exactly {sorted(required)}; got {sorted(value)}"
        )
    if not isinstance(value["research_goal"], str) or not value["research_goal"].strip():
        raise ValueError("ScientificTaskSpec.research_goal must be a non-empty string")
    if not isinstance(value["research_domain"], str) or not value["research_domain"].strip():
        raise ValueError("ScientificTaskSpec.research_domain must be a non-empty string")
    for key in (
        "target_outputs",
        "methodological_constraints",
        "data_constraints",
        "validation_expectations",
        "retrieval_terms",
    ):
        if not isinstance(value[key], list) or any(
            not isinstance(item, str) or not item.strip() for item in value[key]
        ):
            raise ValueError(f"ScientificTaskSpec.{key} must be an array of non-empty strings")
    if not isinstance(value["variables"], list):
        raise ValueError("ScientificTaskSpec.variables must be an array")
    for variable in value["variables"]:
        if not isinstance(variable, dict) or set(variable) != {
            "name",
            "role",
            "measurement_or_unit",
        }:
            raise ValueError("each ScientificTaskSpec variable has an invalid shape")
        if not isinstance(variable["name"], str) or not variable["name"].strip():
            raise ValueError("ScientificTaskSpec variable names must be non-empty strings")
        if variable["role"] not in {"target", "predictor", "control", "context", "unknown"}:
            raise ValueError(f"invalid ScientificTaskSpec variable role: {variable['role']!r}")
        if variable["measurement_or_unit"] is not None and not isinstance(
            variable["measurement_or_unit"], str
        ):
            raise ValueError("ScientificTaskSpec variable measurement_or_unit must be string or null")
    for key in ("spatial_scope", "temporal_scope", "depth_scope"):
        scope = value[key]
        if not isinstance(scope, dict) or set(scope) != {"description", "resolution"}:
            raise ValueError(f"ScientificTaskSpec.{key} has an invalid shape")
        if any(item is not None and not isinstance(item, str) for item in scope.values()):
            raise ValueError(f"ScientificTaskSpec.{key} values must be string or null")
    if not isinstance(value["unresolved_items"], list):
        raise ValueError("ScientificTaskSpec.unresolved_items must be an array")
    for item in value["unresolved_items"]:
        if not isinstance(item, dict) or set(item) != {"field", "question", "impact"}:
            raise ValueError("each ScientificTaskSpec unresolved item has an invalid shape")
        if any(not isinstance(item[key], str) or not item[key].strip() for key in item):
            raise ValueError("ScientificTaskSpec unresolved item values must be non-empty strings")


def reject_known_dataset_ids(
    task_spec: Mapping[str, Any], known_dataset_ids: set[str]
) -> None:
    serialized = json.dumps(task_spec, ensure_ascii=False).casefold()
    leaked = sorted(
        dataset_id
        for dataset_id in known_dataset_ids
        if dataset_id and dataset_id.casefold() in serialized
    )
    if leaked:
        raise ValueError(
            "TaskCompiler output must be dataset-agnostic; found canonical Dataset IDs: "
            + ", ".join(leaked[:10])
        )


def validate_recommendations(
    value: Mapping[str, Any],
    *,
    candidate_ids: set[str],
    top_k: int,
) -> list[dict[str, Any]]:
    if set(value) != {"recommendations"} or not isinstance(value["recommendations"], list):
        raise ValueError("recommendation output must contain only a recommendations array")
    recommendations = value["recommendations"]
    if len(recommendations) != top_k:
        raise ValueError(f"expected exactly {top_k} recommendations; got {len(recommendations)}")
    result: list[dict[str, Any]] = []
    seen: set[str] = set()
    for rank, recommendation in enumerate(recommendations, start=1):
        if not isinstance(recommendation, dict) or set(recommendation) != {
            "dataset_id",
            "reason",
            "matched_requirements",
        }:
            raise ValueError(f"recommendation at rank {rank} has an invalid shape")
        dataset_id = recommendation["dataset_id"]
        if not isinstance(dataset_id, str) or dataset_id not in candidate_ids:
            raise ValueError(f"recommendation at rank {rank} is outside the candidate pool")
        if dataset_id in seen:
            raise ValueError(f"duplicate recommended dataset_id: {dataset_id}")
        if not isinstance(recommendation["reason"], str) or not recommendation["reason"].strip():
            raise ValueError(f"recommendation at rank {rank} has an empty reason")
        if not isinstance(recommendation["matched_requirements"], list) or any(
            not isinstance(item, str) or not item.strip()
            for item in recommendation["matched_requirements"]
        ):
            raise ValueError(f"recommendation at rank {rank} has invalid matched_requirements")
        seen.add(dataset_id)
        result.append({"rank": rank, **recommendation})
    return result


def call_json_with_retry(
    common: ModuleType,
    *,
    model_config: Mapping[str, Any],
    messages: list[dict[str, str]],
    schema_name: str,
    schema: dict[str, Any],
    validator: Any,
    attempt_audit: MutableMapping[str, Any] | None = None,
) -> tuple[dict[str, Any], str, dict[str, Any]]:
    attempts = int(model_config["max_attempts"])
    last_error: Exception | None = None
    if attempt_audit is not None:
        attempt_audit.clear()
        attempt_audit.update(
            {
                "max_attempts": attempts,
                "attempts_made": 0,
                "retry_count": 0,
                "attempt_failures": [],
                "outcome": "running",
            }
        )
    for attempt in range(1, attempts + 1):
        if attempt_audit is not None:
            attempt_audit["attempts_made"] = attempt
            attempt_audit["retry_count"] = attempt - 1
        try:
            parsed, request_body, raw = common.openai_compatible_json(
                base_url=str(model_config["base_url"]),
                api_key=str(model_config["api_key"]),
                model=str(model_config["model"]),
                messages=messages,
                temperature=float(model_config["temperature"]),
                schema_name=schema_name,
                schema=schema,
                timeout=int(model_config["timeout"]),
            )
            validator(parsed)
            usage = raw.get("usage") if isinstance(raw, dict) else None
            if attempt_audit is not None:
                attempt_audit["outcome"] = "success"
            return parsed, sha256_json(request_body), usage if isinstance(usage, dict) else {}
        except (RuntimeError, ValueError) as exc:
            last_error = exc
            if attempt_audit is not None:
                attempt_audit["attempt_failures"].append(
                    {
                        "attempt": attempt,
                        "error_type": type(exc).__name__,
                        "error": str(exc),
                    }
                )
            if attempt < attempts:
                time.sleep(min(2 ** (attempt - 1), 8))
    if attempt_audit is not None:
        attempt_audit["outcome"] = "failed"
    raise RuntimeError(f"{schema_name} failed after {attempts} attempts: {last_error}")


def compile_task_spec(
    common: ModuleType,
    *,
    query: str,
    schema: dict[str, Any],
    model_config: Mapping[str, Any],
) -> tuple[dict[str, Any], str, dict[str, Any]]:
    messages = [
        {
            "role": "system",
            "content": (
                "You are OceanAgent's TaskCompiler. Convert only the user's stated marine "
                "research question into a ScientificTaskSpec. Do not retrieve evidence, name "
                "datasets, infer hidden geographic or temporal facts, or assume values that the "
                "query does not state. Preserve uncertainty explicitly: use null for an unknown "
                "scope value and add a focused unresolved_items question when the missing value "
                "could change data selection. retrieval_terms may contain faithful technical "
                "paraphrases but must not contain dataset identifiers."
            ),
        },
        {
            "role": "user",
            "content": "Research question:\n" + query,
        },
    ]
    return call_json_with_retry(
        common,
        model_config=model_config,
        messages=messages,
        schema_name="ScientificTaskSpec",
        schema=schema,
        validator=validate_task_spec,
    )


def recommend_datasets(
    common: ModuleType,
    *,
    query: str,
    task_spec: Mapping[str, Any] | None,
    candidates: Sequence[Mapping[str, Any]],
    schema: dict[str, Any],
    model_config: Mapping[str, Any],
    top_k: int,
) -> tuple[list[dict[str, Any]], str, dict[str, Any]]:
    candidate_payload = [compact_card(card) for card in candidates]
    candidate_ids = {str(card["dataset_id"]) for card in candidate_payload}
    input_payload = {
        "research_question": query,
        "scientific_task_spec": task_spec,
        "candidate_dataset_cards": candidate_payload,
        "top_k": top_k,
    }
    messages = [
        {
            "role": "system",
            "content": (
                "You are OceanAgent's controlled DatasetCard recommender. Rank exactly the "
                "requested number of unique datasets from the supplied candidate_dataset_cards. "
                "Never output a dataset outside that list. Prefer a scientifically sufficient "
                "bundle: cover the observations, variables, spatial/temporal/depth scope, quality "
                "control, and validation needs actually present in the input. Do not reward a "
                "dataset merely because it appeared in a source paper. matched_requirements must "
                "briefly name the task needs supported by that dataset."
            ),
        },
        {
            "role": "user",
            "content": json.dumps(input_payload, ensure_ascii=False, sort_keys=True),
        },
    ]
    value, request_hash, usage = call_json_with_retry(
        common,
        model_config=model_config,
        messages=messages,
        schema_name="DatasetRecommendation",
        schema=schema,
        validator=lambda parsed: validate_recommendations(
            parsed, candidate_ids=candidate_ids, top_k=top_k
        ),
    )
    recommendations = validate_recommendations(
        value, candidate_ids=candidate_ids, top_k=top_k
    )
    return recommendations, request_hash, usage


def load_existing_predictions(path: Path) -> tuple[list[dict[str, Any]], set[tuple[str, str]]]:
    if not path.is_file():
        return [], set()
    rows = list(iter_jsonl(path))
    keys: set[tuple[str, str]] = set()
    for row in rows:
        key = (str(row.get("query_id") or ""), str(row.get("condition_id") or ""))
        if not all(key) or key in keys:
            raise ValueError(f"invalid or duplicate prediction key in {path}: {key}")
        keys.add(key)
    return rows, keys


def append_jsonl(path: Path, value: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(dict(value), ensure_ascii=False, sort_keys=True) + "\n")
        handle.flush()
        os.fsync(handle.fileno())


def balanced_condition_order(query_id: str) -> tuple[str, str]:
    parity = int(hashlib.sha256(query_id.encode("utf-8")).hexdigest()[-1], 16) % 2
    return CONDITIONS if parity == 0 else tuple(reversed(CONDITIONS))


def main() -> None:
    args = parse_args()
    config_path = args.config.resolve()
    config = read_json(config_path)
    split = args.split or str(config.get("split") or "dev")
    if split == "test" and not args.allow_test_split:
        raise RuntimeError(
            "test split is frozen and must not be used during development; pass --allow-test-split "
            "only for the final locked evaluation"
        )
    if args.max_queries is not None and args.max_queries <= 0:
        raise ValueError("--max-queries must be positive")
    top_k = int(config["top_k"])
    candidate_pool_size = int(config["candidate_pool_size"])
    if top_k != 10:
        raise ValueError("Agent-E1 v1 fixes top_k at 10")
    if candidate_pool_size < top_k:
        raise ValueError("candidate_pool_size must be at least top_k")

    knowledge_root = resolve_knowledge_root(args.knowledge_root)
    benchmark_root = knowledge_root / "benchmark"
    split_path = benchmark_root / "splits" / f"{split}.jsonl"
    corpus_path = benchmark_root / "corpus" / "dataset_corpus.jsonl"
    common = load_benchmark_common(knowledge_root)
    source_audit = common.require_source_snapshot_current(
        benchmark_root=benchmark_root,
        repository_root=knowledge_root,
    )

    # The source split contains evaluation labels for historical reasons. Drop
    # every field except identity and query immediately, before any model or
    # retrieval code receives the row.
    rows = load_runtime_query_view(split_path)
    requested_query_ids = set(args.query_id)
    if requested_query_ids:
        found_query_ids = {str(row.get("query_id")) for row in rows}
        missing = sorted(requested_query_ids - found_query_ids)
        if missing:
            raise ValueError(f"query IDs are not present in split {split!r}: {missing}")
        rows = [row for row in rows if row.get("query_id") in requested_query_ids]
    if args.max_queries is not None:
        rows = rows[: args.max_queries]

    cards = list(iter_jsonl(corpus_path))
    known_dataset_ids = {str(card.get("dataset_id") or "") for card in cards}
    if "" in known_dataset_ids or len(known_dataset_ids) != len(cards):
        raise ValueError("dataset corpus contains an empty or duplicate dataset_id")
    retriever_config = config["retriever"]
    index = BM25Index(
        cards,
        k1=float(retriever_config["k1"]),
        b=float(retriever_config["b"]),
    )
    task_spec_schema = read_json(TASK_SPEC_SCHEMA_PATH)
    recommendation_schema = read_json(RECOMMENDATION_SCHEMA_PATH)
    recommendation_schema["properties"]["recommendations"]["minItems"] = top_k
    recommendation_schema["properties"]["recommendations"]["maxItems"] = top_k
    model_config = resolve_model_config(config)
    if not model_config["api_key"]:
        raise RuntimeError(
            f"missing API key in environment variable {config['model']['api_key_env']}"
        )

    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    manifest_path = output_dir / "manifest.json"
    predictions_path = output_dir / "predictions.jsonl"
    manifest = {
        "schema_version": "1.0",
        "experiment_id": config["experiment_id"],
        "created_at": utc_now(),
        "split": split,
        "condition_selection": args.condition,
        "query_count_selected": len(rows),
        "top_k": top_k,
        "candidate_pool_size": candidate_pool_size,
        "random_seed": int(config["random_seed"]),
        "model": model_config["model"],
        "base_url": model_config["base_url"],
        "temperature": model_config["temperature"],
        "prompts": config["prompts"],
        "retriever": retriever_config,
        "knowledge_root": str(knowledge_root),
        "allowed_runtime_inputs": [str(split_path), str(corpus_path)],
        "forbidden_runtime_inputs": [str(benchmark_root / "gold")],
        "gold_access": "forbidden_during_inference",
        "input_sha256": {
            "split": sha256_file(split_path),
            "runtime_query_view": sha256_json(rows),
            "dataset_corpus": sha256_file(corpus_path),
            "experiment_config": sha256_file(config_path),
            "task_spec_schema": sha256_file(TASK_SPEC_SCHEMA_PATH),
            "recommendation_schema": sha256_file(RECOMMENDATION_SCHEMA_PATH),
        },
        "source_snapshot_audit": source_audit,
    }
    if manifest_path.is_file():
        existing_manifest = read_json(manifest_path)
        comparable_keys = (
            "experiment_id",
            "split",
            "top_k",
            "candidate_pool_size",
            "model",
            "base_url",
            "temperature",
            "prompts",
            "retriever",
            "input_sha256",
        )
        mismatches = [
            key for key in comparable_keys if existing_manifest.get(key) != manifest.get(key)
        ]
        if mismatches:
            raise RuntimeError(
                "output directory contains an incompatible run manifest; mismatched fields: "
                + ", ".join(mismatches)
            )
    else:
        common.write_json(manifest_path, manifest)

    _, completed = load_existing_predictions(predictions_path)
    for row in rows:
        query_id = str(row["query_id"])
        query = str(row["query"])
        if args.condition == "both":
            condition_order: Sequence[str] = balanced_condition_order(query_id)
        else:
            condition_order = (args.condition,)
        for condition_id in condition_order:
            if (query_id, condition_id) in completed:
                continue
            started_at = time.perf_counter()
            compiler_request_hash: str | None = None
            compiler_usage: dict[str, Any] = {}
            task_spec: dict[str, Any] | None = None
            if condition_id == "t1_task_spec":
                task_spec, compiler_request_hash, compiler_usage = compile_task_spec(
                    common,
                    query=query,
                    schema=task_spec_schema,
                    model_config=model_config,
                )
                reject_known_dataset_ids(task_spec, known_dataset_ids)
                retrieval_text = "\n".join([query, *flatten_strings(task_spec)])
            else:
                retrieval_text = query
            candidates = index.search(retrieval_text, candidate_pool_size)
            recommendations, recommender_request_hash, recommender_usage = recommend_datasets(
                common,
                query=query,
                task_spec=task_spec,
                candidates=candidates,
                schema=recommendation_schema,
                model_config=model_config,
                top_k=top_k,
            )
            prediction = {
                "schema_version": "1.0",
                "experiment_id": config["experiment_id"],
                "condition_id": condition_id,
                "query_id": query_id,
                "benchmark_id": row.get("benchmark_id"),
                "query": query,
                "task_spec": task_spec,
                "candidate_dataset_ids": [str(card["dataset_id"]) for card in candidates],
                "recommendations": recommendations,
                "model": model_config["model"],
                "prompt_versions": config["prompts"],
                "request_sha256": {
                    "task_compiler": compiler_request_hash,
                    "dataset_recommender": recommender_request_hash,
                },
                "usage": {
                    "task_compiler": compiler_usage,
                    "dataset_recommender": recommender_usage,
                },
                "elapsed_seconds": round(time.perf_counter() - started_at, 6),
                "created_at": utc_now(),
            }
            append_jsonl(predictions_path, prediction)
            completed.add((query_id, condition_id))
            print(f"completed {query_id} {condition_id}", flush=True)


if __name__ == "__main__":
    main()
