from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import math
import os
import random
import sys
from datetime import datetime, timezone
from pathlib import Path
from types import ModuleType
from typing import Any, Iterable, Mapping, Sequence


EXPERIMENT_ROOT = Path(__file__).resolve().parent
AGENT_ROOT = EXPERIMENT_ROOT.parents[1]
DEFAULT_CONFIG = EXPERIMENT_ROOT / "experiment_config.json"
CONDITIONS = ("t0_raw_query", "t1_task_spec")
SCIENCE_METRICS = (
    "trc_at_10",
    "vrc_at_10",
    "sts_at_10",
    "requirement_aware_alpha_ndcg_at_10",
)
FORMAL_EVALUATION_PROTOCOL = "paper-route-v2-task-paired-bootstrap"
PILOT_METRICS = (
    "paper_recall_at_10",
    "paper_mrr_at_10",
    "paper_bundle_success_at_10",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Evaluate paired Agent-E1 predictions without exposing Gold to inference."
    )
    parser.add_argument("--predictions", type=Path, required=True)
    parser.add_argument("--knowledge-root", type=Path)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--split", choices=("train", "dev", "test"))
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument(
        "--allow-test-split",
        action="store_true",
        help="Explicit acknowledgement required to evaluate the frozen test split.",
    )
    parser.add_argument(
        "--paper-fidelity-pilot",
        action="store_true",
        help=(
            "Allow an explicitly non-formal plumbing evaluation with dataset_gold.jsonl when "
            "independent scientific Gold is not yet available."
        ),
    )
    parser.add_argument(
        "--allow-partial",
        action="store_true",
        help="Evaluate only query IDs that have both conditions; never use for a formal result.",
    )
    return parser.parse_args()


def read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"expected a JSON object: {path}")
    return value


def iter_jsonl(path: Path) -> Iterable[dict[str, Any]]:
    with path.open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, start=1):
            if not line.strip():
                continue
            value = json.loads(line)
            if not isinstance(value, dict):
                raise ValueError(f"expected a JSON object at {path}:{line_number}")
            yield value


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def resolve_knowledge_root(explicit: Path | None) -> Path:
    candidates: list[Path] = []
    if explicit is not None:
        candidates.append(explicit)
    environment_value = os.environ.get("OCEAN_RAG_ROOT")
    if environment_value:
        candidates.append(Path(environment_value))
    candidates.extend(
        [
            AGENT_ROOT.parent / "benchmark" / "knowledge_snapshot",
            AGENT_ROOT / "Ocean-RAG",
            AGENT_ROOT.parent.parent / "OceanKnowledgeBase" / "Ocean-RAG",
        ]
    )
    checked: list[str] = []
    for candidate in candidates:
        root = candidate.expanduser().resolve()
        checked.append(str(root))
        if (
            (root / "benchmark" / "splits" / "dev.jsonl").is_file()
            and (root / "benchmark" / "common.py").is_file()
        ):
            return root
    raise FileNotFoundError(
        "could not locate a complete Ocean-RAG benchmark; checked: " + "; ".join(checked)
    )


def load_benchmark_common(knowledge_root: Path) -> ModuleType:
    path = knowledge_root / "benchmark" / "common.py"
    spec = importlib.util.spec_from_file_location("oceanagentbench_common_eval", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot import benchmark helpers from {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def ranked_dataset_ids(prediction: Mapping[str, Any], top_k: int) -> list[str]:
    recommendations = prediction.get("recommendations")
    if not isinstance(recommendations, list) or len(recommendations) != top_k:
        raise ValueError(
            f"{prediction.get('query_id')} {prediction.get('condition_id')} must contain "
            f"exactly {top_k} recommendations"
        )
    ordered = sorted(recommendations, key=lambda item: int(item.get("rank", 0)))
    ids = [str(item.get("dataset_id") or "") for item in ordered]
    if any(not item for item in ids) or len(ids) != len(set(ids)):
        raise ValueError(
            f"{prediction.get('query_id')} {prediction.get('condition_id')} contains empty or "
            "duplicate dataset IDs"
        )
    if [int(item.get("rank", 0)) for item in ordered] != list(range(1, top_k + 1)):
        raise ValueError(
            f"{prediction.get('query_id')} {prediction.get('condition_id')} has invalid ranks"
        )
    return ids


def index_predictions(
    rows: Sequence[Mapping[str, Any]], top_k: int
) -> dict[tuple[str, str], dict[str, Any]]:
    result: dict[tuple[str, str], dict[str, Any]] = {}
    for row in rows:
        query_id = str(row.get("query_id") or "")
        condition = str(row.get("condition_id") or "")
        if not query_id or condition not in CONDITIONS:
            raise ValueError(f"invalid prediction identity: query={query_id!r}, condition={condition!r}")
        key = (query_id, condition)
        if key in result:
            raise ValueError(f"duplicate prediction: {key}")
        ranked_dataset_ids(row, top_k)
        result[key] = dict(row)
    return result


def select_evaluation_queries(
    split_query_ids: Sequence[str],
    predictions: Mapping[tuple[str, str], Mapping[str, Any]],
    *,
    allow_partial: bool,
) -> list[str]:
    split_set = set(split_query_ids)
    out_of_split = sorted({query_id for query_id, _ in predictions} - split_set)
    if out_of_split:
        raise ValueError(f"predictions contain query IDs outside the requested split: {out_of_split}")
    complete = [
        query_id
        for query_id in split_query_ids
        if all((query_id, condition) in predictions for condition in CONDITIONS)
    ]
    if not allow_partial:
        missing = [
            (query_id, condition)
            for query_id in split_query_ids
            for condition in CONDITIONS
            if (query_id, condition) not in predictions
        ]
        if missing:
            raise RuntimeError(
                f"formal paired evaluation requires exact split coverage; missing {len(missing)} "
                f"query-condition rows, first entries: {missing[:10]}"
            )
    if not complete:
        raise RuntimeError("no query has predictions for both T0 and T1")
    return complete


def formal_query_ids(
    requirement_rows: Sequence[Mapping[str, Any]],
    route_rows: Sequence[Mapping[str, Any]],
    split_query_ids: Sequence[str],
) -> tuple[list[str], list[str]]:
    """Mirror E2's fail-closed formal-Gold admission rule."""
    requirement_ids = [str(row.get("query_id") or "") for row in requirement_rows]
    route_ids = [str(row.get("query_id") or "") for row in route_rows]
    if "" in requirement_ids or len(requirement_ids) != len(set(requirement_ids)):
        raise ValueError("Task Requirement Gold contains empty or duplicate query IDs")
    if "" in route_ids or len(route_ids) != len(set(route_ids)):
        raise ValueError("Valid Route Gold contains empty or duplicate query IDs")
    if set(requirement_ids) != set(route_ids):
        raise RuntimeError("formal Task Requirement and Valid Route Gold task sets differ")
    split_set = set(split_query_ids)
    outside = sorted(set(requirement_ids) - split_set)
    if outside:
        raise RuntimeError(f"formal Gold contains out-of-split queries: {outside[:10]}")
    formal_set = set(requirement_ids)
    return (
        [query_id for query_id in split_query_ids if query_id in formal_set],
        [query_id for query_id in split_query_ids if query_id not in formal_set],
    )


def validate_science_gold(
    requirement_rows: Sequence[Mapping[str, Any]],
    route_rows: Sequence[Mapping[str, Any]],
    query_ids: Sequence[str],
) -> tuple[dict[str, dict[str, Any]], dict[str, dict[str, Any]]]:
    requirements = {str(row.get("query_id") or ""): dict(row) for row in requirement_rows}
    routes = {str(row.get("query_id") or ""): dict(row) for row in route_rows}
    if "" in requirements or len(requirements) != len(requirement_rows):
        raise ValueError("task_requirement_gold.jsonl contains an empty or duplicate query_id")
    if "" in routes or len(routes) != len(route_rows):
        raise ValueError("valid_route_gold.jsonl contains an empty or duplicate query_id")
    missing_requirements = sorted(set(query_ids) - set(requirements))
    missing_routes = sorted(set(query_ids) - set(routes))
    if missing_requirements or missing_routes:
        raise RuntimeError(
            "formal scientific evaluation requires adjudicated Gold for every evaluated query; "
            f"missing requirement rows={missing_requirements[:10]}, "
            f"missing route rows={missing_routes[:10]}"
        )
    allowed_slots = {
        "input_observation",
        "target_variable",
        "spatial_scope",
        "temporal_scope",
        "vertical_scope",
        "quality_control",
        "validation",
        "other",
    }
    for query_id in query_ids:
        requirement_row = requirements[query_id]
        route_row = routes[query_id]
        if set(requirement_row) - {
            "schema_version",
            "query_id",
            "annotation_status",
            "requirements",
            "notes",
        }:
            raise ValueError(f"Task Requirement Gold has unexpected fields for {query_id}")
        if set(route_row) - {
            "schema_version",
            "query_id",
            "annotation_status",
            "valid_routes",
            "notes",
        }:
            raise ValueError(f"Valid Route Gold has unexpected fields for {query_id}")
        if requirement_row.get("schema_version") != "1.0":
            raise ValueError(f"Task Requirement Gold schema_version must be 1.0 for {query_id}")
        if route_row.get("schema_version") != "1.0":
            raise ValueError(f"Valid Route Gold schema_version must be 1.0 for {query_id}")
        if requirement_row.get("annotation_status") != "adjudicated":
            raise ValueError(f"Task Requirement Gold is not adjudicated for {query_id}")
        if route_row.get("annotation_status") != "adjudicated":
            raise ValueError(f"Valid Route Gold is not adjudicated for {query_id}")
        items = requirement_row.get("requirements")
        if not isinstance(items, list) or not items:
            raise ValueError(f"Task Requirement Gold has no requirements for {query_id}")
        requirement_ids: set[str] = set()
        for item in items:
            if not isinstance(item, dict):
                raise ValueError(f"invalid requirement row for {query_id}")
            requirement_id = str(item.get("requirement_id") or "")
            acceptable_ids = item.get("acceptable_dataset_ids")
            weight = item.get("weight")
            if (
                set(item)
                != {
                    "requirement_id",
                    "slot",
                    "description",
                    "required",
                    "weight",
                    "acceptable_dataset_ids",
                }
                or not requirement_id
                or requirement_id in requirement_ids
                or item.get("slot") not in allowed_slots
                or not isinstance(item.get("description"), str)
                or not item["description"].strip()
                or not isinstance(item.get("required"), bool)
                or not isinstance(acceptable_ids, list)
                or not acceptable_ids
                or any(not isinstance(value, str) or not value for value in acceptable_ids)
                or len(acceptable_ids) != len(set(acceptable_ids))
                or not isinstance(weight, (int, float))
                or isinstance(weight, bool)
                or float(weight) != (2.0 if bool(item.get("required")) else 1.0)
            ):
                raise ValueError(f"invalid requirement definition for {query_id}: {item}")
            requirement_ids.add(requirement_id)
        required_ids = {
            str(item["requirement_id"])
            for item in items
            if bool(item["required"])
        }
        if not required_ids:
            raise ValueError(f"Task Requirement Gold has no required item for {query_id}")
        valid_routes = route_row.get("valid_routes")
        if not isinstance(valid_routes, list) or not valid_routes:
            raise ValueError(f"Valid Route Gold has no routes for {query_id}")
        route_ids: set[str] = set()
        for route in valid_routes:
            if not isinstance(route, dict):
                raise ValueError(f"invalid route definition for {query_id}")
            route_id = str(route.get("route_id") or "")
            groups = route.get("dataset_groups")
            covered_values = route.get("covers_requirement_ids")
            covered = set(covered_values) if isinstance(covered_values, list) else set()
            if (
                set(route)
                != {
                    "route_id",
                    "description",
                    "dataset_groups",
                    "covers_requirement_ids",
                }
                or not route_id
                or route_id in route_ids
                or not isinstance(route.get("description"), str)
                or not route["description"].strip()
                or not isinstance(groups, list)
                or not groups
                or any(not isinstance(group, list) or not group for group in groups)
                or any(
                    any(not isinstance(value, str) or not value for value in group)
                    or len(group) != len(set(group))
                    for group in groups
                )
                or not isinstance(covered_values, list)
                or any(not isinstance(value, str) or not value for value in covered_values)
                or len(covered_values) != len(covered)
                or not covered
                or not covered.issubset(requirement_ids)
                or not required_ids.issubset(covered)
            ):
                raise ValueError(f"invalid route definition for {query_id}: {route}")
            requirements_by_id = {
                str(item["requirement_id"]): item for item in items
            }
            route_dataset_ids = {
                str(value) for group in groups for value in group
            }
            acceptable_for_covered = {
                str(dataset_id)
                for requirement_id in covered
                for dataset_id in requirements_by_id[requirement_id][
                    "acceptable_dataset_ids"
                ]
            }
            if not route_dataset_ids.issubset(acceptable_for_covered):
                raise ValueError(
                    f"route uses datasets outside its covered requirements for {query_id}: "
                    f"{route}"
                )
            for requirement_id in covered:
                acceptable = {
                    str(value)
                    for value in requirements_by_id[requirement_id][
                        "acceptable_dataset_ids"
                    ]
                }
                if not any(
                    {str(value) for value in group}.issubset(acceptable)
                    for group in groups
                ):
                    raise ValueError(
                        f"route does not provide a valid OR group for {requirement_id} "
                        f"in {query_id}"
                    )
            for group in groups:
                normalized_group = {str(value) for value in group}
                if not any(
                    normalized_group.issubset(
                        {
                            str(value)
                            for value in requirements_by_id[requirement_id][
                                "acceptable_dataset_ids"
                            ]
                        }
                    )
                    for requirement_id in covered
                ):
                    raise ValueError(
                        f"route contains an OR group without a covered requirement for "
                        f"{query_id}: {group}"
                    )
            route_ids.add(route_id)
    return requirements, routes


def route_metrics(
    ranking: Sequence[str],
    requirements: Sequence[Mapping[str, Any]],
    valid_routes: Sequence[Mapping[str, Any]],
) -> tuple[float, float, float, set[str], list[str]]:
    """Paper TRC=max route coverage, VRC=complete-route fraction, STS=any complete route."""
    predicted = set(ranking)
    requirements_by_id = {
        str(item["requirement_id"]): item for item in requirements
    }
    covered_ids = {
        str(item["requirement_id"])
        for item in requirements
        if predicted.intersection(str(value) for value in item["acceptable_dataset_ids"])
    }
    coverages: list[float] = []
    satisfied: list[str] = []
    for route in valid_routes:
        route_requirements = [str(value) for value in route["covers_requirement_ids"]]
        if not route_requirements or any(
            requirement_id not in requirements_by_id
            for requirement_id in route_requirements
        ):
            raise ValueError(f"invalid route requirement IDs: {route}")
        coverage = sum(
            requirement_id in covered_ids for requirement_id in route_requirements
        ) / len(route_requirements)
        coverages.append(coverage)
        if coverage == 1.0:
            satisfied.append(str(route["route_id"]))
    if not coverages:
        raise ValueError("formal route metrics require at least one route")
    trc = max(coverages)
    vrc = len(satisfied) / len(valid_routes)
    return trc, vrc, float(vrc > 0), covered_ids, satisfied


def alpha_dcg(
    ranking: Sequence[str],
    requirements: Sequence[Mapping[str, Any]],
    *,
    alpha: float,
) -> float:
    coverage_count = {str(item["requirement_id"]): 0 for item in requirements}
    score = 0.0
    for rank, dataset_id in enumerate(ranking, start=1):
        gain = 0.0
        for item in requirements:
            requirement_id = str(item["requirement_id"])
            if dataset_id in {str(value) for value in item["acceptable_dataset_ids"]}:
                gain += float(item["weight"]) * (1.0 - alpha) ** coverage_count[requirement_id]
                coverage_count[requirement_id] += 1
        score += gain / math.log2(rank + 1.0)
    return score


def ideal_alpha_dcg(
    requirements: Sequence[Mapping[str, Any]], *, alpha: float, top_k: int
) -> float:
    remaining = sorted(
        {
            str(dataset_id)
            for item in requirements
            for dataset_id in item["acceptable_dataset_ids"]
        }
    )
    selected: list[str] = []
    coverage_count = {str(item["requirement_id"]): 0 for item in requirements}
    for _ in range(min(top_k, len(remaining))):
        best_id: str | None = None
        best_gain = -1.0
        for dataset_id in remaining:
            gain = 0.0
            for item in requirements:
                requirement_id = str(item["requirement_id"])
                if dataset_id in {str(value) for value in item["acceptable_dataset_ids"]}:
                    gain += float(item["weight"]) * (
                        (1.0 - alpha) ** coverage_count[requirement_id]
                    )
            if gain > best_gain or (gain == best_gain and (best_id is None or dataset_id < best_id)):
                best_id, best_gain = dataset_id, gain
        if best_id is None or best_gain <= 0:
            break
        selected.append(best_id)
        remaining.remove(best_id)
        for item in requirements:
            requirement_id = str(item["requirement_id"])
            if best_id in {str(value) for value in item["acceptable_dataset_ids"]}:
                coverage_count[requirement_id] += 1
    return alpha_dcg(selected, requirements, alpha=alpha)


def science_metrics_for_query(
    ranking: Sequence[str],
    requirement_row: Mapping[str, Any],
    route_row: Mapping[str, Any],
    *,
    alpha: float,
    top_k: int,
) -> dict[str, Any]:
    requirements = requirement_row["requirements"]
    trc, vrc, sts, covered, satisfied_routes = route_metrics(
        ranking, requirements, route_row["valid_routes"]
    )
    dcg = alpha_dcg(ranking[:top_k], requirements, alpha=alpha)
    ideal = ideal_alpha_dcg(requirements, alpha=alpha, top_k=top_k)
    return {
        "trc_at_10": trc,
        "vrc_at_10": vrc,
        "sts_at_10": sts,
        "requirement_aware_alpha_ndcg_at_10": dcg / ideal if ideal > 0 else 0.0,
        "covered_requirement_ids": sorted(covered),
        "satisfied_route_ids": satisfied_routes,
    }


def paper_metrics_for_query(ranking: Sequence[str], gold_ids: Sequence[str]) -> dict[str, float]:
    gold = set(gold_ids)
    predicted = set(ranking)
    first_rank = next((rank for rank, item in enumerate(ranking, start=1) if item in gold), None)
    return {
        "paper_recall_at_10": len(predicted.intersection(gold)) / len(gold) if gold else 1.0,
        "paper_mrr_at_10": 1.0 / first_rank if first_rank is not None else 0.0,
        "paper_bundle_success_at_10": 1.0 if gold.issubset(predicted) else 0.0,
    }


def mean(values: Sequence[float]) -> float:
    return sum(values) / len(values) if values else 0.0


def percentile(sorted_values: Sequence[float], probability: float) -> float:
    if not sorted_values:
        return 0.0
    position = (len(sorted_values) - 1) * probability
    lower = math.floor(position)
    upper = math.ceil(position)
    if lower == upper:
        return sorted_values[lower]
    fraction = position - lower
    return sorted_values[lower] * (1.0 - fraction) + sorted_values[upper] * fraction


def bootstrap_mean_delta_ci(
    deltas: Sequence[float], *, resamples: int, seed: int
) -> tuple[float, float]:
    generator = random.Random(seed)
    count = len(deltas)
    samples = sorted(
        mean([deltas[generator.randrange(count)] for _ in range(count)])
        for _ in range(resamples)
    )
    return percentile(samples, 0.025), percentile(samples, 0.975)


def paired_permutation_pvalue(
    deltas: Sequence[float], *, resamples: int, seed: int
) -> float:
    observed = abs(mean(deltas))
    nonzero = [value for value in deltas if value != 0]
    if not nonzero:
        return 1.0
    if len(nonzero) <= 16:
        total = 1 << len(nonzero)
        extreme = 0
        for mask in range(total):
            permuted = [
                value if mask & (1 << index) else -value
                for index, value in enumerate(nonzero)
            ]
            if abs(sum(permuted) / len(deltas)) >= observed - 1e-15:
                extreme += 1
        return extreme / total
    generator = random.Random(seed)
    extreme = 0
    for _ in range(resamples):
        permuted_mean = sum(
            value if generator.random() < 0.5 else -value for value in nonzero
        ) / len(deltas)
        if abs(permuted_mean) >= observed - 1e-15:
            extreme += 1
    return (extreme + 1.0) / (resamples + 1.0)


def exact_mcnemar_pvalue(t0: Sequence[float], t1: Sequence[float]) -> tuple[float, int, int]:
    improvements = sum(1 for left, right in zip(t0, t1) if left == 0.0 and right == 1.0)
    regressions = sum(1 for left, right in zip(t0, t1) if left == 1.0 and right == 0.0)
    discordant = improvements + regressions
    if discordant == 0:
        return 1.0, improvements, regressions
    tail = sum(math.comb(discordant, index) for index in range(min(improvements, regressions) + 1))
    p_value = min(1.0, 2.0 * tail / (2**discordant))
    return p_value, improvements, regressions


def holm_adjust(p_values: Mapping[str, float]) -> dict[str, float]:
    ordered = sorted(p_values.items(), key=lambda item: item[1])
    adjusted: dict[str, float] = {}
    running = 0.0
    count = len(ordered)
    for index, (name, p_value) in enumerate(ordered):
        candidate = min(1.0, (count - index) * p_value)
        running = max(running, candidate)
        adjusted[name] = running
    return adjusted


def collapse_queries_to_tasks(
    per_query: Sequence[Mapping[str, Any]],
    query_to_task: Mapping[str, str],
    metric_names: Sequence[str],
) -> list[dict[str, Any]]:
    """Average both query variants within a task before paired inference."""
    grouped: dict[str, list[Mapping[str, Any]]] = {}
    for row in per_query:
        query_id = str(row["query_id"])
        task_id = query_to_task.get(query_id)
        if not task_id:
            raise ValueError(f"missing source task for formal query {query_id}")
        grouped.setdefault(task_id, []).append(row)
    if any(len(rows) != 2 for rows in grouped.values()):
        malformed = {task: len(rows) for task, rows in grouped.items() if len(rows) != 2}
        raise ValueError(f"formal task must have exactly two query variants: {malformed}")
    return [
        {
            "task_id": task_id,
            "query_ids": sorted(str(row["query_id"]) for row in rows),
            "metrics": {
                condition: {
                    metric: mean([
                        float(row["metrics"][condition][metric]) for row in rows
                    ])
                    for metric in metric_names
                }
                for condition in CONDITIONS
            },
        }
        for task_id, rows in sorted(grouped.items())
    ]


def summarize_pairs(
    per_query: Sequence[Mapping[str, Any]],
    metric_names: Sequence[str],
    *,
    binary_metrics: set[str],
    bootstrap_resamples: int,
    permutation_resamples: int,
    seed: int,
) -> dict[str, Any]:
    summaries: dict[str, Any] = {}
    raw_p_values: dict[str, float] = {}
    for metric_index, metric_name in enumerate(metric_names):
        t0 = [float(row["metrics"]["t0_raw_query"][metric_name]) for row in per_query]
        t1 = [float(row["metrics"]["t1_task_spec"][metric_name]) for row in per_query]
        deltas = [right - left for left, right in zip(t0, t1)]
        ci_low, ci_high = bootstrap_mean_delta_ci(
            deltas,
            resamples=bootstrap_resamples,
            seed=seed + metric_index,
        )
        if metric_name in binary_metrics:
            p_value, improvements, regressions = exact_mcnemar_pvalue(t0, t1)
            test = "exact_mcnemar_two_sided"
        else:
            p_value = paired_permutation_pvalue(
                deltas,
                resamples=permutation_resamples,
                seed=seed + 1000 + metric_index,
            )
            improvements = sum(delta > 0 for delta in deltas)
            regressions = sum(delta < 0 for delta in deltas)
            test = "paired_sign_flip_permutation_two_sided"
        raw_p_values[metric_name] = p_value
        summaries[metric_name] = {
            "n": len(t0),
            "t0_mean": mean(t0),
            "t1_mean": mean(t1),
            "paired_mean_delta_t1_minus_t0": mean(deltas),
            "paired_delta_bootstrap_95_ci": [ci_low, ci_high],
            "wins": improvements,
            "losses": regressions,
            "ties": len(deltas) - improvements - regressions,
            "test": test,
            "p_value_raw": p_value,
        }
    adjusted = holm_adjust(raw_p_values)
    for metric_name, p_value in adjusted.items():
        summaries[metric_name]["p_value_holm"] = p_value
    return summaries


def markdown_report(report: Mapping[str, Any]) -> str:
    level = str(report["evaluation_level"])
    title = "Agent-E1 TaskCompiler 实验结果"
    lines = [
        f"# {title}",
        "",
        f"_OceanAgentBench 配对实验；评价级别：`{level}`_",
        "",
        "---",
        "",
        "## 📋 运行摘要",
        "",
        f"- 实验：`{report['experiment_id']}`",
        f"- 评价协议：`{report['evaluation_protocol_version']}`",
        f"- 结果标识：`{report['result_id']}`",
        f"- 划分：`{report['split']}`",
        f"- Split 查询数：`{report['split_query_count']}`",
        f"- 完整 T0/T1 prediction 查询数：`{report['paired_prediction_query_count']}`",
        f"- Formal Gold 查询数：`{report['formal_gold_query_count']}`",
        f"- Excluded 查询数：`{report['excluded_query_count']}`",
        f"- 科学指标查询数：`{report['query_count']}`",
        f"- 统计单位：`{report['analysis_unit']}`，共 `{report['analysis_unit_count']}` 个",
        f"- 评价级别：`{level}`",
        "",
    ]
    if report["excluded_query_ids"]:
        lines.extend(
            [
                "### Excluded query IDs",
                "",
                *[f"- `{query_id}`" for query_id in report["excluded_query_ids"]],
                "",
            ]
        )
    if level == "paper_fidelity_pilot":
        lines.extend(
            [
                "> ⚠️ **限制：** 本报告只验证实验管线和论文数据集复现度，不能作为科学任务成功结论。",
                "",
            ]
        )
    else:
        lines.extend(
            [
                "> 冻结 Gold 用于操作性评分；该评分不表示独立海洋专家已验证 Gold 或路线的科学充分性。",
                "",
            ]
        )
    lines.extend(
        [
            "## 📊 配对结果",
            "",
            "| 指标 | T0 均值 | T1 均值 | T1−T0 | 95% CI | Holm p |",
            "| --- | ---: | ---: | ---: | --- | ---: |",
        ]
    )
    for metric_name, item in report["summary"].items():
        interval = item["paired_delta_bootstrap_95_ci"]
        lines.append(
            f"| `{metric_name}` | {item['t0_mean']:.4f} | {item['t1_mean']:.4f} | "
            f"{item['paired_mean_delta_t1_minus_t0']:+.4f} | "
            f"[{interval[0]:+.4f}, {interval[1]:+.4f}] | {item['p_value_holm']:.4g} |"
        )
    lines.extend(
        [
            "",
            "## 🔍 解释边界",
            "",
            "- 正差值表示加入 `ScientificTaskSpec` 后指标提高",
            f"- 置信区间来自{('任务级（先合并两个 Query）' if level == 'formal_scientific' else '查询级')}配对 bootstrap",
            "- 正式科学指标使用双侧配对符号翻转检验；pilot 二元指标使用双侧精确 McNemar 检验",
            "- 四个科学指标或全部 pilot 指标统一使用 Holm 校正",
            "- 统计显著性不替代效应量与逐样本错误分析",
            "",
        ]
    )
    return "\n".join(lines)


def main() -> None:
    args = parse_args()
    config = read_json(args.config.resolve())
    split = args.split or str(config.get("split") or "dev")
    if split == "test" and not args.allow_test_split:
        raise RuntimeError(
            "test split is frozen and must not be evaluated during development; pass "
            "--allow-test-split only for the final locked evaluation"
        )
    top_k = int(config["top_k"])
    if top_k != 10:
        raise ValueError("this evaluator reports @10 metrics and requires top_k=10")
    alpha = float(config["alpha_ndcg"])
    seed = int(config["random_seed"])
    knowledge_root = resolve_knowledge_root(args.knowledge_root)
    benchmark_root = knowledge_root / "benchmark"
    split_path = benchmark_root / "splits" / f"{split}.jsonl"
    split_rows = list(iter_jsonl(split_path))
    split_query_ids = [str(row["query_id"]) for row in split_rows]
    if len(split_query_ids) != len(set(split_query_ids)):
        raise ValueError(f"split contains duplicate query IDs: {split_path}")
    query_to_task = {
        str(row["query_id"]): str(row.get("problem_solution_card_id") or "")
        for row in split_rows
    }

    common = load_benchmark_common(knowledge_root)
    common.require_source_snapshot_current(
        benchmark_root=benchmark_root,
        repository_root=knowledge_root,
    )
    prediction_path = args.predictions.resolve()
    prediction_rows = list(iter_jsonl(prediction_path))
    predictions = index_predictions(prediction_rows, top_k)
    query_ids = select_evaluation_queries(
        split_query_ids,
        predictions,
        allow_partial=args.allow_partial,
    )

    requirement_path = benchmark_root / "gold" / "task_requirement_gold.jsonl"
    route_path = benchmark_root / "gold" / "valid_route_gold.jsonl"
    formal_science_gold_available = requirement_path.is_file() and route_path.is_file()
    formal_gold_query_ids: list[str] | None = None
    excluded_query_ids: list[str] = []
    if formal_science_gold_available:
        if args.allow_partial:
            raise RuntimeError(
                "--allow-partial is diagnostic-only and cannot be combined with formal "
                "scientific evaluation"
            )
        common.require_leakage_pass(benchmark_root=benchmark_root)
        requirement_rows = list(iter_jsonl(requirement_path))
        route_rows = list(iter_jsonl(route_path))
        formal_gold_query_ids, excluded_query_ids = formal_query_ids(
            requirement_rows,
            route_rows,
            split_query_ids,
        )
        requirements, routes = validate_science_gold(
            requirement_rows,
            route_rows,
            formal_gold_query_ids,
        )
        evaluation_level = "formal_scientific"
        metric_names = SCIENCE_METRICS
        # Each task has two query variants. Their mean is the paired inference unit.
        binary_metrics: set[str] = set()
        per_query: list[dict[str, Any]] = []
        for query_id in formal_gold_query_ids:
            condition_metrics: dict[str, Any] = {}
            for condition in CONDITIONS:
                ranking = ranked_dataset_ids(predictions[(query_id, condition)], top_k)
                condition_metrics[condition] = science_metrics_for_query(
                    ranking,
                    requirements[query_id],
                    routes[query_id],
                    alpha=alpha,
                    top_k=top_k,
                )
            per_query.append({"query_id": query_id, "metrics": condition_metrics})
        gold_hashes = {
            "task_requirement_gold": sha256_file(requirement_path),
            "valid_route_gold": sha256_file(route_path),
        }
        analysis_rows = collapse_queries_to_tasks(per_query, query_to_task, metric_names)
        analysis_unit = "task_after_mean_of_two_queries"
        evaluation_protocol = FORMAL_EVALUATION_PROTOCOL
    else:
        if not args.paper_fidelity_pilot:
            missing = [
                str(path)
                for path in (requirement_path, route_path)
                if not path.is_file()
            ]
            raise RuntimeError(
                "formal Agent-E1 evaluation is blocked because scientific Gold is "
                "missing: "
                + ", ".join(missing)
                + ". Create and adjudicate these files before scoring against route Gold. "
                "Use --paper-fidelity-pilot only to check the pipeline."
            )
        dataset_gold_path = benchmark_root / "gold" / "dataset_gold.jsonl"
        dataset_gold = {
            str(row["query_id"]): row for row in iter_jsonl(dataset_gold_path)
        }
        missing = sorted(set(query_ids) - set(dataset_gold))
        if missing:
            raise RuntimeError(f"dataset_gold.jsonl is missing evaluated queries: {missing[:10]}")
        evaluation_level = "paper_fidelity_pilot"
        metric_names = PILOT_METRICS
        binary_metrics = {"paper_bundle_success_at_10"}
        per_query = []
        for query_id in query_ids:
            condition_metrics = {}
            for condition in CONDITIONS:
                ranking = ranked_dataset_ids(predictions[(query_id, condition)], top_k)
                condition_metrics[condition] = paper_metrics_for_query(
                    ranking,
                    dataset_gold[query_id].get("gold_dataset_ids") or [],
                )
            per_query.append({"query_id": query_id, "metrics": condition_metrics})
        gold_hashes = {"dataset_gold": sha256_file(dataset_gold_path)}
        analysis_rows = per_query
        analysis_unit = "query"
        evaluation_protocol = "paper-fidelity-pilot-v1"

    summary = summarize_pairs(
        analysis_rows,
        metric_names,
        binary_metrics=binary_metrics,
        bootstrap_resamples=int(config["bootstrap_resamples"]),
        permutation_resamples=int(config["permutation_resamples"]),
        seed=seed,
    )
    prediction_hash = sha256_file(prediction_path)
    split_hash = sha256_file(split_path)
    result_fingerprint = hashlib.sha256(
        json.dumps(
            {
                "prediction_sha256": prediction_hash,
                "split_sha256": split_hash,
                "gold_sha256": gold_hashes,
                "evaluation_protocol_version": evaluation_protocol,
            },
            sort_keys=True,
        ).encode("utf-8")
    ).hexdigest()[:16]
    report = {
        "schema_version": "1.0",
        "experiment_id": config["experiment_id"],
        "evaluation_protocol_version": evaluation_protocol,
        "evaluation_id": f"{config['experiment_id']}-{evaluation_protocol}",
        "result_id": f"{config['experiment_id']}-{evaluation_protocol}-{result_fingerprint}",
        "evaluation_level": evaluation_level,
        "created_at": utc_now(),
        "split": split,
        "split_query_count": len(split_query_ids),
        "paired_prediction_query_count": len(query_ids),
        "formal_gold_query_count": (
            len(formal_gold_query_ids) if formal_gold_query_ids is not None else None
        ),
        "excluded_query_count": len(excluded_query_ids),
        "excluded_query_ids": excluded_query_ids,
        "query_count": len(per_query),
        "analysis_unit": analysis_unit,
        "analysis_unit_count": len(analysis_rows),
        "partial_evaluation": bool(args.allow_partial),
        "top_k": top_k,
        "alpha_ndcg": alpha if evaluation_level == "formal_scientific" else None,
        "predictions_sha256": prediction_hash,
        "split_sha256": split_hash,
        "gold_sha256": gold_hashes,
        "multiple_comparison_correction": "holm",
        "summary": summary,
    }
    output_dir = args.output_dir.resolve()
    result_paths = [
        output_dir / "evaluation.json",
        output_dir / "per_query_metrics.jsonl",
        output_dir / "per_task_metrics.jsonl",
        output_dir / "report.md",
    ]
    existing = [str(path) for path in result_paths if path.exists()]
    if existing:
        raise FileExistsError(
            "refusing to overwrite existing evaluation artifacts; choose a new output directory: "
            + ", ".join(existing)
        )
    output_dir.mkdir(parents=True, exist_ok=True)
    common.write_json(output_dir / "evaluation.json", report)
    common.write_jsonl(output_dir / "per_query_metrics.jsonl", per_query)
    if evaluation_level == "formal_scientific":
        common.write_jsonl(output_dir / "per_task_metrics.jsonl", analysis_rows)
    (output_dir / "report.md").write_text(markdown_report(report) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
