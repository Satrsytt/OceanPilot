// Run after build:api. Real public-data requests; no model calls or benchmark changes.
import { randomUUID } from "node:crypto";
import { readFile, writeFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { resolve } from "node:path";
import { acquireDatasets } from "../dist/data-access/acquire.js";
import { safeFetch } from "../dist/data-access/safe-http.js";
import { RunTelemetry, hashText, withRunTelemetry } from "../dist/telemetry/run-telemetry.js";

const root = fileURLToPath(new URL("..", import.meta.url));
const runId = randomUUID();
const trace = new RunTelemetry(resolve(root, "eval_logs"), {
  taskId: "public-data-noaa-smoke", runId, model: "interface-validation-no-llm", provider: null,
  knowledgeMode: "off", inputHash: hashText("NOAA OISST ASCAT California May 2022 bounded interface validation"),
  configHash: hashText("16MiB/file 32MiB/total"), gitCommit: null, datasetSnapshot: null, knowledgeSnapshot: null,
});
const budget = { used: 0, limit: 32 * 1024 * 1024 };
const sources = [
  { datasetId: "ncdcOisst21Agg_LonPM180", variables: ["sst"] },
  { datasetId: "erdQMwind1day", variables: ["x_wind", "y_wind"] },
];
let status = "failed";
try {
  await withRunTelemetry(trace, async () => {
    const observedTimes = {};
    for (const source of sources) {
      const response = await safeFetch(`https://coastwatch.pfeg.noaa.gov/erddap/griddap/${source.datasetId}.json?time[(2022-05-01T00:00:00Z):1:(2022-05-31T23:59:59Z)]`, {
        maxBytes: 64 * 1024, budget, datasetId: source.datasetId,
        onEvent: (event, payload) => trace.emit(event, payload),
      });
      observedTimes[source.datasetId] = JSON.parse(response.body.toString()).table.rows.map(row => row[0])
        .filter(time => time >= "2022-05-01" && time < "2022-06-01");
      if (!observedTimes[source.datasetId].length) throw new Error(`${source.datasetId}: no observed May time coordinates`);
    }
    const requests = (tiny) => sources.map(s => ({ ...s,
      urls: [`https://coastwatch.pfeg.noaa.gov/erddap/griddap/${s.datasetId}`],
      timeStart: tiny ? observedTimes[s.datasetId][0] : "2022-05-01T00:00:00Z",
      timeEnd: tiny ? observedTimes[s.datasetId][0] : "2022-05-31T23:59:59Z",
      bbox: tiny ? [-123.5, 35.5, -123, 36] : [-124, 35, -122, 37],
    }));
    const options = { cacheDir: resolve(root, "data/scientific-cache"), budget,
      maxTotalBytes: budget.limit, maxFileBytes: 16 * 1024 * 1024,
      onEvent: (event, payload) => trace.emit(event, payload) };
    // Each source must pass a genuinely small request before the monthly combination.
    for (const request of requests(true)) {
      const call = `tiny-${request.datasetId}`; trace.toolStarted(call, "acquire_scientific_data", request);
      try {
        const tiny = await acquireDatasets([request], options);
        trace.toolEnded(call, false, { details: tiny });
      } catch (error) { trace.toolEnded(call, true, undefined, error.code ?? error.name); throw error; }
    }
    const call = "monthly-combination"; trace.toolStarted(call, "acquire_scientific_data", requests(false));
    const result = await acquireDatasets(requests(false), options);
    trace.toolEnded(call, false, { details: result });
    const checks = result.datasets.map(d => ({ datasetId: d.datasetId, path: d.path,
      sha256: d.sha256, bytes: d.bytes, validation: d.validation, transformations: d.transformations }));
    // Read the actual normalized files independently of the acquisition return value.
    for (const d of result.datasets) {
      const file = JSON.parse(await readFile(d.path, "utf8"));
      const xi = file.table.columnNames.indexOf("longitude");
      if (!file.table.rows.length || xi < 0 || file.table.rows.some(r => r[xi] < -180 || r[xi] >= 180)) {
        throw new Error("Independent longitude/nonempty check failed");
      }
    }
    await writeFile(resolve(trace.runDir, "validation.json"), JSON.stringify({ checks,
      compatibility: result.compatibility, observedTimes, networkBytes: budget.used }, null, 2));
    trace.emit("data_validation", { status: "independently_checked", downloaded_bytes_total: budget.used,
      check: "local files nonempty; all longitude values normalized to [-180,180)" });
    trace.reportGenerated(`# NOAA public-data interface validation\n\n` +
      `Run: ${runId}\n\nTiny slices passed before the May 2022 California subset (124–122°W, 35–37°N).\n\n` +
      checks.map(d => `- ${d.datasetId}: ${d.validation.rowCount} rows; valid samples ${JSON.stringify(d.validation.validSamples)}; ${d.bytes} local bytes.\n`).join("") +
      `\nNetwork bytes (including metadata and pilot requests): ${budget.used}.\n\n` +
      `Compatibility: ${JSON.stringify(result.compatibility)}\n\nNo model or end-to-end research run was performed.\n`, { status: "completed" });
    console.log(JSON.stringify({ status: "passed", runDir: trace.runDir, networkBytes: budget.used,
      datasets: checks.map(d => ({ id: d.datasetId, rows: d.validation.rowCount, valid: d.validation.validSamples })),
      compatibility: result.compatibility }, null, 2));
    status = "completed";
  });
} catch (error) {
  trace.emit("data_validation", { status: "failed", error_type: error.code ?? error.name,
    downloaded_bytes_total: budget.used });
  trace.reportGenerated(`# NOAA interface validation failed\n\n${error.message}\n`, { status: "failed" });
  console.error(JSON.stringify({ status: "failed", errorType: error.code ?? error.name,
    reason: error.message, runDir: trace.runDir }));
  process.exitCode = 1;
} finally { trace.finish(status, status === "completed" ? null : "INTERFACE_VALIDATION_FAILED"); }
