"""Read-only DEV diagnostic for the frozen E1 BM25 score; never reads TEST."""

from __future__ import annotations

import importlib.util
import json
import os
from collections import Counter
from pathlib import Path
from statistics import median
import sys


ROOT = Path(__file__).resolve().parents[1]
BENCHMARK = Path(os.environ.get("OCEAN_RAG_ROOT", ROOT.parent / "benchmark" / "knowledge_snapshot")) / "benchmark"
E1 = ROOT / "experiments/agent_e1_taskcompiler/run_experiment.py"


def rows(path: Path):
    with path.open(encoding="utf-8") as source:
        for line in source:
            if line.strip():
                yield json.loads(line)


def main() -> None:
    spec = importlib.util.spec_from_file_location("e1_score_diagnostic", E1)
    if spec is None or spec.loader is None:
        raise RuntimeError("Cannot load frozen E1 BM25 implementation")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    config = json.loads((ROOT / "experiments/agent_e1_taskcompiler/experiment_config.json").read_text(encoding="utf-8"))
    bm25 = config["retriever"]
    index = module.BM25Index(list(rows(BENCHMARK / "corpus/dataset_corpus.jsonl")),
                             k1=float(bm25["k1"]), b=float(bm25["b"]))
    positive, negative, hit_any = [], [], 0
    labeled = 0
    for query in rows(BENCHMARK / "splits/dev.jsonl"):
        gold = set(query.get("gold_dataset_ids", []))
        terms = Counter(module.tokenize(query["query"]))
        scores = []
        for card, frequencies, length in zip(index.cards, index.term_frequencies, index.lengths):
            norm = 1 - index.b + index.b * length / index.average_length
            score = sum(index.idf.get(term, 0.0) * count * (frequency * (index.k1 + 1))
                        / (frequency + index.k1 * norm)
                        for term, count in terms.items()
                        if (frequency := frequencies.get(term, 0)))
            scores.append((score, str(card.get("dataset_id", ""))))
        scores.sort(key=lambda item: (-item[0], item[1]))
        visible_gold = gold.intersection(dataset_id for _, dataset_id in scores)
        if not visible_gold:
            continue
        labeled += 1
        positive.extend(score for score, dataset_id in scores if dataset_id in visible_gold)
        negative.extend(score for score, dataset_id in scores[:6] if dataset_id not in visible_gold)
        hit_any += bool(visible_gold.intersection(dataset_id for _, dataset_id in scores[:6]))
    print(json.dumps({
        "split": "DEV only", "method": "frozen E1 BM25", "labeled_queries": labeled,
        "any_gold_at_6": hit_any / labeled if labeled else None,
        "positive_score_median": median(positive) if positive else None,
        "top6_negative_score_median": median(negative) if negative else None,
        "interpretation": "Ranking diagnostic only. No probability or production threshold is inferred.",
        "runtime_score_limit": "DEV has no runtime query embeddings or SQLite FTS score labels",
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
