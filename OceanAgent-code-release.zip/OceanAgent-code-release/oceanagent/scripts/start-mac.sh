#!/usr/bin/env bash
set -euo pipefail
OCEAN_APP_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
if [[ -z "${OCEAN_NODE_BIN:-}" ]]; then
  OCEAN_NODE_BIN="$(command -v node || true)"
  if [[ -z "$OCEAN_NODE_BIN" ]]; then
    for candidate in /opt/homebrew/bin/node /usr/local/bin/node "$HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node"; do
      if [[ -x "$candidate" ]]; then OCEAN_NODE_BIN="$candidate"; break; fi
    done
  fi
fi
if [[ -z "$OCEAN_NODE_BIN" || ! -x "$OCEAN_NODE_BIN" ]]; then
  printf '%s\n' '需要 Node >=22.19；安装 Node 或设置 OCEAN_NODE_BIN 为本机可执行文件。' >&2
  exit 1
fi
cd "$OCEAN_APP_ROOT"
export PATH="$(dirname "$OCEAN_NODE_BIN"):$PATH"

"$OCEAN_NODE_BIN" --input-type=module -e '
const [major, minor] = process.versions.node.split(".").map(Number);
if (major < 22 || (major === 22 && minor < 19)) {
  console.error("需要 Node >=22.19.0；请设置 OCEAN_NODE_BIN。"); process.exit(1);
}
'
for dependency in node_modules/typescript/bin/tsc node_modules/vite/bin/vite.js; do
  if [[ ! -f "$dependency" ]]; then
    printf '%s\n' '缺少项目依赖，请先在 oceanagent 目录执行 npm ci。' >&2
    exit 1
  fi
done

# The paper UI has its own port and DB; Stage 3 still uses its isolated unit config.
export OCEAN_PROJECT_ROLE=paper-experiments
export VITE_OCEAN_PROJECT_ROLE=paper-experiments
export PORT="${PORT:-3211}"
export OCEAN_DB_PATH="$OCEAN_APP_ROOT/data/ocean-agent.sqlite"
# A fresh release has no derived retrieval index; build it from the frozen cards.
# Controlled experiments use separate unit configs and disable automatic syncing.
export OCEAN_RAG_AUTO_SYNC="${OCEAN_RAG_AUTO_SYNC:-true}"
if [[ -z "${OCEAN_PYTHON_PATH:-}" && -x "$OCEAN_APP_ROOT/.venv/bin/python" ]]; then
  export OCEAN_PYTHON_PATH="$OCEAN_APP_ROOT/.venv/bin/python"
fi
"$OCEAN_NODE_BIN" --input-type=module -e '
if (!/^\d+$/.test(process.env.PORT ?? "") || Number(process.env.PORT) < 1 || Number(process.env.PORT) > 65535) {
  console.error("PORT 必须是 1–65535 的整数。"); process.exit(1);
}
'
printf 'OceanAgent 论文实验版\n地址：http://127.0.0.1:%s\n数据库：%s\n使用发布的知识快照；此命令只启动工作台。\n正在重新构建后端和前端…\n' \
  "$PORT" "$OCEAN_DB_PATH"
"$OCEAN_NODE_BIN" node_modules/typescript/bin/tsc -p tsconfig.json
"$OCEAN_NODE_BIN" node_modules/vite/bin/vite.js build --config frontend/vite.config.ts
exec "$OCEAN_NODE_BIN" dist/server.js
