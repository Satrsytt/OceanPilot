# Optional SST analysis scripts

This is the compact analysis implementation for the built-in SST example. Downloaded NetCDF data, caches, historical runs and reports are excluded. Install `requirements.txt`; inspect `case.json` for the declared NOAA source and bounds.

```bash
python run.py prepare --mode download --out runs/example
python run.py quality --out runs/example
python run.py analyze --out runs/example
python run.py plot --out runs/example
python run.py report --out runs/example
python run.py verify --out runs/example
```

Commands resolve their files relative to this directory. Download mode requires network access; the default cache mode expects a separately obtained file. Run `python run.py --help` for available actions. This optional example is separate from benchmark evaluation.
