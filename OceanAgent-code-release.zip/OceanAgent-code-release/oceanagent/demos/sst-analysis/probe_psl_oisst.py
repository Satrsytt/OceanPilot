﻿import xarray as xr, numpy as np
url = "https://psl.noaa.gov/thredds/dodsC/Datasets/noaa.oisst.v2.highres/sst.mon.mean.nc"
ds = xr.open_dataset(url, engine="netcdf4")
s = ds["sst"].sel(time=slice("2003-01-01","2016-12-01"), lat=slice(8,36), lon=slice(330,355))
print("shape", s.shape)
v = s.values
print("mean %.3f  nanfrac %.4f  min %.2f max %.2f" % (np.nanmean(v), np.isnan(v).mean(), np.nanmin(v), np.nanmax(v)))
print("times", s.time.size, str(s.time.values[0]), str(s.time.values[-1]))
print("lat", float(s.lat.min()), float(s.lat.max()), "lon", float(s.lon.min()), float(s.lon.max()))
