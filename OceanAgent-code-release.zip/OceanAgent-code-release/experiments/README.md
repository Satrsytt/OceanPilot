# Retrieval code and configurations

This directory contains inference, retrieval, canonical-ID mapping and evaluation source. The inputs are the retrieval projection in `benchmark/knowledge_snapshot/`: query text, source-level splits, DatasetCards, PSC/UBC knowledge and dataset/requirement/route references. `paper_e1/config.json` hashes these released inputs. It does not assert byte identity with the earlier complete research snapshot.

Commands below run from the repository root with CPython 3.11. No saved predictions, experiment results, original runtime caches or provider credentials are supplied.

## Offline checks and a real lexical smoke run

```bash
python3.11 -B -m unittest discover -s experiments/paper_e1/scripts -p test_evaluate.py -v
python3.11 -B -m unittest discover -s experiments/paper_e1/scripts -p test_retrieval.py -v
python3.11 -B -m unittest discover -s experiments/paper_e1/scripts -p test_run.py -v
python3.11 -B -m unittest discover -s experiments/agentic_baseline -p test_agentic.py -v

# Omit --execute to inspect the selected units without running them.
python3.11 -B experiments/paper_e1/scripts/run.py --methods 'BM25 Retrieval' --split dev --limit 2
python3.11 -B experiments/paper_e1/scripts/run.py --methods 'BM25 Retrieval' --split dev --limit 2 --execute --output-dir runs/bm25-smoke
python3.11 -B experiments/paper_e1/scripts/evaluate.py --predictions runs/bm25-smoke/e1_predictions.jsonl --knowledge-root benchmark/knowledge_snapshot --output-dir runs/bm25-smoke/scores --method 'BM25 Retrieval'
```

The two-query lexical smoke run uses the supplied corpus and inherited BM25 implementation and makes no model request. Evaluation uses the full prescribed population: queries absent from this small run stay unavailable, and only complete observed two-query tasks contribute means. The generated files under `runs/` belong to the new local run.

`test_evaluate.py` covers metric/denominator semantics; `test_retrieval.py` covers held-out evidence isolation, metadata projection and actual graph traversal; `test_run.py` and the TAAR suite use mocked model responses. Dense numerical tests require NumPy:

```bash
python3.11 -B -m unittest discover -s experiments/paper_e1/scripts -p test_dense_retrieval.py -v
```

## Included implementations

| Source | Purpose |
|---|---|
| `paper_e1/scripts/retrieval.py` | Frozen lexical retrieval; Flat RAG, StructuredRAG and local dataset co-usage GraphRAG contexts; held-out PSC/UBC access filtering |
| `paper_e1/scripts/dense_retrieval.py` | MiniLM ONNX encoding, masked mean pooling, L2 normalization and cosine ranking |
| `paper_e1/scripts/run.py` | BM25/Dense wrappers, catalog-free Direct LLM, fixed-context methods and OceanAgent TaskCompiler plus bounded tool loop |
| `paper_e1/scripts/evaluate.py` | Canonical-ID retrieval metrics and complete two-query task aggregation |
| `agentic_baseline/` | TAAR and OceanAgent bounded retrieval tool loops with shared raw-query Top-30 and common metadata view |
| `kats_comparison/` | Original KATS I/O/model/cache/catalog adapters, PDF source isolation, exact canonical mapping and output parsing |
| `../third_party/KATS/` | Bundled upstream KATS source and MIT license |

The inherited lexical runner is available as CPython 3.11 bytecode rather than recovered source. `retrieval.py` verifies its SHA256 before loading it. This limitation and the legacy loader are documented in `benchmark/README.md`; the package does not invent an alternative implementation.

## Retrieval metric definitions

The public metric names are Recall@K, MRR, MAP, TRC@K, SCC@K, CSA@K and alpha-nDCG@K. The evaluator retains the existing implementation and uses the canonical SCC/CSA labels for its route-completion fraction and any-complete-route indicator. For a selected dataset list B and each reference configuration g:

- Cov(g,B) is the unweighted fraction of g's requirement IDs supported by at least one selected dataset.
- TRC is the maximum Cov across configurations.
- SCC is the fraction of configurations with Cov equal to one.
- CSA is one if at least one configuration has complete coverage, and zero otherwise.

These are requirement-coverage computations. Dataset-group compatibility constraints are not an extra predicate in these functions. alpha-nDCG retains alpha=0.5, the supplied requirement weights and the existing greedy ideal. The alpha helpers remain in `oceanagent/experiments/agent_e1_taskcompiler/evaluate_experiment.py`. Null ranking slots preserve their positions; failures and unavailable observations are not scientific zeros. AP uses the complete relevant reference set as its denominator. The default seven-method table retains MRR/MAP at depth 20; the `--method` interface exposes the same existing calculations at K=5,10,20 and avoids generating unrelated method tables.

The JSONL scoring interface requires `method`, `split`, `task_id`, `query_id`, `status`, `ranking` (canonical IDs or null slots), and `available_depth`. Repeat `--method` to evaluate another retrieval cohort with the same functions. Inference code does not import the evaluator or read reference labels.

## Model-backed execution

Install/build OceanAgent and initialize new local model settings as described in `oceanagent/README.md`. `runtime_bridge.mjs` reads those settings inside a separate process. API credentials and encrypted databases are not bundled. Set `paper_e1/config.json:model` to the configured provider/model key. The release removes author-specific dispatch grants; the Python runner retains its per-unit call, tool, retry, output and timeout limits. Use `--execute` only for an intended new run; model methods can incur provider charges.

Dense retrieval requires separately obtained weights and the pinned model revision in the configuration:

```bash
python3.11 -m venv .venv-dense
.venv-dense/bin/python -m pip install -r experiments/paper_e1/scripts/requirements-dense.txt
.venv-dense/bin/python experiments/paper_e1/scripts/dense_retrieval.py --revision 1110a243fdf4706b3f48f1d95db1a4f5529b4d41
```

This writes a new local embedding/ranking cache. There are no packaged weights or precomputed rankings. Run the Dense method after generating that cache. The TAAR entry point is `python3.11 experiments/agentic_baseline/run_agentic.py --prepare`; inference additionally needs `--smoke --execute` or the subsequent guarded `--formal --execute` stage. Its original retrieval prompts, shared candidate ordering and tool loop are retained. See `kats_comparison/README.md` for KATS external inputs and commands.
