#!/usr/bin/env python3
"""Read fresh KATS CSV rankings and reuse the existing retrieval evaluator.

The CSV parser is retained from the original KATS adapter. Metric definitions
and task aggregation come from paper_e1/scripts/evaluate.py.
"""
from __future__ import annotations
import argparse
from collections import defaultdict
import csv
import json
from pathlib import Path
import sys
from typing import Mapping
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "experiments/paper_e1/scripts"))
import evaluate as e

def read_kats(path: Path, queries: Mapping, canonical_ids: set[str]):
    with path.open(encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
    grouped = defaultdict(list)
    modes = {r["mode"] for r in rows}
    if len(modes) != 1 or next(iter(modes)) not in {
            "KATS-Official", "KATS-Adapted", "KATS-Partial", "KATS-SharedKnowledge"}:
        raise ValueError("Predictions must declare exactly one recognized KATS mode")
    mode = next(iter(modes))
    for row in rows:
        key = row["split"], row["query_id"]
        q = queries.get(key)
        if q is None or row["task_id"] != q["task_id"] or str(row["query_variant"]) != str(q["query_variant"]):
            raise ValueError(f"KATS query/task/variant identity mismatch: {key}")
        grouped[key].append(row)
    if set(grouped) != set(queries):
        raise ValueError("KATS prediction ledger must cover the full admitted population")
    predictions = []
    for (split, qid), ranked in sorted(grouped.items()):
        statuses = {r["status"] for r in ranked}
        depths = {int(r["available_depth"]) for r in ranked}
        if len(statuses) != len(depths) or len(statuses) != 1:
            raise ValueError(f"Inconsistent status/depth: {qid}")
        status, depth = next(iter(statuses)), next(iter(depths))
        if status not in ("success", "failed", "unavailable"):
            raise ValueError(f"Unknown KATS status: {status}")
        ranked.sort(key=lambda r: int(r["rank"]))
        ranks = [int(r["rank"]) for r in ranked]
        if ranks == [0]:
            if status == "success" or depth != 0 or ranked[0]["canonical_dataset_id"]:
                raise ValueError(f"rank=0 is reserved for no-output failures: {qid}")
            ranking = []
        else:
            if ranks != list(range(1, len(ranked) + 1)) or len(ranked) > depth:
                raise ValueError(f"Invalid rank sequence/depth: {qid}")
            ranking = []
            seen = set()
            for r in ranked:
                dataset = r["canonical_dataset_id"] or None
                if dataset is not None and dataset not in canonical_ids:
                    raise ValueError(f"Out-of-universe mapped dataset: {dataset}")
                if dataset is not None and dataset in seen:
                    raise ValueError(f"Duplicate canonical dataset must be a null slot: {qid}")
                if dataset is not None and r["mapping_status"] != "mapped":
                    raise ValueError(f"Canonical ID requires mapped status: {qid}")
                seen.add(dataset)
                ranking.append(dataset)
        predictions.append(dict(method=mode, split=split, task_id=queries[split, qid]["task_id"],
                                query_id=qid, status=status, ranking=ranking, available_depth=depth,
                                error=ranked[0].get("error", "")))
    return predictions, mode


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--predictions", type=Path, required=True)
    p.add_argument("--output-dir", type=Path, required=True)
    p.add_argument("--knowledge-root", type=Path, default=ROOT / "benchmark/knowledge_snapshot")
    args = p.parse_args()
    gold = e.load_gold(args.knowledge_root)
    queries = {(r["split"], r["query_id"]): r for r in e.read_jsonl(ROOT / "experiments/paper_e1/runtime_queries.jsonl")}
    # DEV and TEST are independently generated and may be scored separately.
    with args.predictions.open(encoding="utf-8", newline="") as h:
        selected = {(r["split"], r["query_id"]) for r in csv.DictReader(h)}
    if not selected <= queries.keys():
        raise ValueError("KATS predictions contain unknown query identities")
    expected = {key: row for key, row in queries.items() if key[0] in {s for s, _ in selected}}
    predictions, method = read_kats(args.predictions, expected, gold.canonical_ids)
    indexed = e.index_predictions(predictions, gold, methods=(method,))
    query_rows = e.query_metrics(indexed, gold, e.load_alpha_helpers(args.knowledge_root),
                                 methods=(method,), all_ranking_cutoffs=True)
    tasks, summaries = e.aggregate(query_rows)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    e.write_csv(args.output_dir / "retrieval_metrics.csv", query_rows + tasks + summaries)
    print(json.dumps({"method": method, "input_queries": len(predictions), "new_model_calls": 0}))

if __name__ == "__main__":
    main()
