"""Small leakage and source-coverage checks; no model or Gold access."""
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

spec = importlib.util.spec_from_file_location("kats_corpus_test_target", Path(__file__).with_name("corpus.py"))
corpus = importlib.util.module_from_spec(spec)
spec.loader.exec_module(corpus)


class CorpusTest(unittest.TestCase):
    def fixture(self, root, *, same_pdf=False, missing=False):
        snapshot = root / "agent/knowledge_snapshots/frozen"
        legacy = root / "legacy"
        agent = root / "agent"
        for name in ("benchmark/splits/split_manifest.json", "benchmark/corpus/dataset_corpus.jsonl",
                     "cards/problem_solution_cards.jsonl", "cards/usage_bundle_cards.jsonl", "cards/dataset_cards.jsonl"):
            path = snapshot / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text("{}\n")
        config = root / "experiments/paper_e1/config.json"
        config.parent.mkdir(parents=True)
        config.write_text(json.dumps({"knowledge_root": str(snapshot), "agent_root": str(agent),
                                      "legacy_root": str(legacy)}))
        manifest = legacy / "manifest/papers.jsonl"
        manifest.parent.mkdir(parents=True)
        entries = [{"paper_id": f"paper_{i}", "source_root": "pdfs", "relative_path": f"{i}.pdf"}
                   for i in (1, 2)]
        manifest.write_text("\n".join(json.dumps(x) for x in entries))
        pdf_dir = root / "paper/pdfs"
        pdf_dir.mkdir(parents=True)
        if not missing:
            (pdf_dir / "1.pdf").write_bytes(b"%PDF heldout" if same_pdf else b"%PDF allowed")
        (pdf_dir / "2.pdf").write_bytes(b"%PDF heldout")
        return {"allowed_source_ids": ["paper_1"], "blocked_source_ids": ["paper_2"],
                "allowed_source_group_ids": ["group_1"], "blocked_source_group_ids": ["group_2"],
                "audit": {"policy": "existing-test-source-policy"}}

    def test_original_pdf_inputs_and_idempotency(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            policy = self.fixture(root)
            with patch.object(corpus, "_visible_identity_policy", return_value=policy):
                a = corpus.prepare_corpus(root, root / ".cache/kats")
                b = corpus.prepare_corpus(root, root / ".cache/kats")
            self.assertEqual(a, b)
            self.assertTrue(a["input_ready"])
            self.assertTrue(a["source_coverage_complete"])
            self.assertEqual([p.name for p in Path(a["input_dir"]).iterdir()], ["paper_1.pdf"])
            self.assertTrue(Path(a["sources"][0]["input_pdf"]).is_symlink())

    def test_pdf_identical_to_heldout_is_excluded(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            policy = self.fixture(root, same_pdf=True)
            with patch.object(corpus, "_visible_identity_policy", return_value=policy):
                a = corpus.prepare_corpus(root, root / ".cache/kats")
            self.assertFalse(a["source_coverage_complete"])
            self.assertFalse(a["input_ready"])
            self.assertEqual(a["missing_sources"][0]["reason"], "same_pdf_as_held_out_source")
            self.assertEqual(list(Path(a["input_dir"]).iterdir()), [])

    def test_missing_pdf_is_explicit_not_silent_subset(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            policy = self.fixture(root, missing=True)
            with patch.object(corpus, "_visible_identity_policy", return_value=policy):
                a = corpus.prepare_corpus(root, root / ".cache/kats")
            self.assertFalse(a["source_coverage_complete"])
            self.assertEqual(a["expected_source_count"], 1)
            self.assertEqual(a["available_source_count"], 0)
            self.assertEqual(a["missing_sources"][0]["reason"], "pdf_not_found")

    def test_heldout_alias_and_path_traversal_rejected(self):
        policy = {"allowed_source_ids": ["a"], "blocked_source_ids": ["b"],
                  "allowed_source_group_ids": ["same-doi"], "blocked_source_group_ids": ["same-doi"]}
        with self.assertRaisesRegex(RuntimeError, "Held-out source_group_ids"):
            corpus._assert_disjoint_identities(policy)
        with self.assertRaisesRegex(ValueError, "Unsafe PDF"):
            corpus._pdf_path({"paper_id": "a", "source_root": "pdfs", "relative_path": "../../heldout.pdf"}, [])

    def test_clean_policy_uses_separate_complete_corpus_and_preserves_original_audit(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            original_policy = self.fixture(root, same_pdf=True)
            original_policy["allowed_source_ids"].append("paper_3")
            original_policy["allowed_source_group_ids"].append("group_3")
            manifest = root / "legacy/manifest/papers.jsonl"
            with manifest.open("a") as stream:
                stream.write('\n' + json.dumps({"paper_id": "paper_3", "source_root": "pdfs", "relative_path": "3.pdf"}))
            (root / "paper/pdfs/3.pdf").write_bytes(b"%PDF safe paper")
            with patch.object(corpus, "_visible_identity_policy", return_value=original_policy):
                original = corpus.prepare_corpus(root, root / ".cache/kats")
            original_audit = (root / ".cache/kats/corpus_manifest.json").read_bytes()
            self.assertFalse(original["input_ready"])
            clean_view = {"allowed_source_ids": ["paper_3"], "allowed_source_group_ids": ["group_3"],
                          "blocked_source_ids": ["paper_1", "paper_2"],
                          "blocked_source_group_ids": ["group_1", "group_2"],
                          "audit": {"policy": "verified-clean-policy"}}
            sidecar = {"original_config_sha256": corpus._digest(root / "experiments/paper_e1/config.json"),
                       "policy_id": "verified-clean-policy", "override_sha256": "alias-hash",
                       "policy_fingerprint": "full-policy-hash", "historical_reuse": "Unproven; rerun or verify payload"}
            with patch.object(corpus, "_visible_identity_policy", return_value=clean_view) as load:
                clean = corpus.prepare_corpus(root, root / ".cache/kats/clean", source_policy=sidecar)
            self.assertEqual(load.call_args.kwargs["source_policy"], sidecar)
            self.assertTrue(clean["input_ready"])
            self.assertTrue(clean["source_coverage_complete"])
            self.assertEqual(clean["expected_source_count"], 1)
            self.assertEqual(clean["available_source_count"], 1)
            self.assertEqual(clean["override_sha256"], "alias-hash")
            self.assertEqual(clean["source_fingerprints"], original["source_fingerprints"])
            self.assertEqual((root / ".cache/kats/corpus_manifest.json").read_bytes(), original_audit)


if __name__ == "__main__":
    unittest.main()
