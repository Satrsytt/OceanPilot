"""An external, byte-verified source-alias repair for future matched runs.

The original snapshot, source splits, Gold and historical predictions stay
untouched. No historical model output is declared reusable by this module.
"""
from __future__ import annotations

import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parents[2]
POLICY_ID = "e1-source-identities-plus-verified-pdf-aliases-v2"


def _load_existing():
    name = "_kats_source_policy_existing_e1"
    if name in sys.modules:
        return sys.modules[name]
    path = ROOT / "experiments/paper_e1/scripts/retrieval.py"
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load existing E1 retrieval: {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    previous = sys.dont_write_bytecode
    try:
        sys.dont_write_bytecode = True
        spec.loader.exec_module(module)
    finally:
        sys.dont_write_bytecode = previous
    return module


_existing = _load_existing()
E1Retrieval = _existing.E1Retrieval


def _sha(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _fingerprint(value) -> str:
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                     separators=(",", ":")).encode()).hexdigest()


def _verify_aliases(aliases: list[dict], visible_ids: set[str], blocked_ids: set[str]) -> None:
    """An alias repair must be physically proven and anchored to a held-out ID."""
    if not aliases:
        raise ValueError("No verified held-out PDF aliases supplied")
    for alias in aliases:
        members = set(alias["source_ids"])
        if len(members) < 2 or not members & blocked_ids or not members & visible_ids:
            raise ValueError("PDF alias must connect a visible source with a held-out source")
        proofs = alias["pdfs"]
        if set(proofs) != members:
            raise ValueError("Every PDF alias member needs original-file evidence")
        expected = alias["pdf_sha256"]
        for identity, proof in proofs.items():
            path = Path(proof["path"])
            if not path.is_file() or _sha(path) != expected:
                raise ValueError(f"PDF alias SHA verification failed: {identity}")


def _closed_view(psc: dict, ubc: dict, blocked_sources: set[str],
                 blocked_groups: set[str], aliases: list[dict]) -> dict:
    """Close source/group aliases and deny bundles shared with a denied owner."""
    blocked_sources, blocked_groups = set(blocked_sources), set(blocked_groups)
    changed = True
    while changed:
        before = (len(blocked_sources), len(blocked_groups))
        for alias in aliases:
            members = set(alias["source_ids"])
            if members & blocked_sources:
                blocked_sources.update(members)
        for card in psc.values():
            if (_existing._source_values(card, {"paper_id", "source_id"}) & blocked_sources
                    or _existing._source_values(card, {"source_group_id"}) & blocked_groups):
                paper = str(card.get("paper_id") or "")
                group = str(card.get("source_group_id") or paper)
                if paper:
                    blocked_sources.add(paper)
                if group:
                    blocked_groups.add(group)
        changed = before != (len(blocked_sources), len(blocked_groups))
    provisional = {
        key: value for key, value in psc.items()
        if not (_existing._source_values(value, {"paper_id", "source_id"}) & blocked_sources
                or _existing._source_values(value, {"source_group_id"}) & blocked_groups)
    }
    owners = {}
    for identity, card in psc.items():
        owners.setdefault(card["bundle_id"], []).append(identity)
    clean_ubc = {
        identity: card for identity, card in ubc.items()
        if identity in owners and all(owner in provisional for owner in owners[identity])
        and not (_existing._source_values(card, {"paper_id", "source_id"}) & blocked_sources
                 or _existing._source_values(card, {"source_group_id"}) & blocked_groups)
    }
    clean_psc = {key: value for key, value in provisional.items() if value["bundle_id"] in clean_ubc}
    return {"psc": clean_psc, "ubc": clean_ubc,
            "blocked_sources": blocked_sources, "blocked_groups": blocked_groups}


def _view_ids(retrieval) -> dict:
    return {"source_ids": sorted(retrieval.visible_source_ids),
            "source_group_ids": sorted(retrieval.visible_source_group_ids),
            "psc_ids": sorted(retrieval.visible_psc), "ubc_ids": sorted(retrieval.visible_ubc),
            "blocked_source_ids": sorted(retrieval.blocked_source_ids),
            "blocked_source_group_ids": sorted(retrieval.blocked_source_group_ids)}


class CleanE1Retrieval(E1Retrieval):
    """Original retrieval with repaired source visibility before BM25 construction.

    Pass the dict returned by derive_policy, or its JSON path. DatasetCard and
    DatasetCorpus visibility are unchanged; the repair removes source evidence.
    """
    def __init__(self, snapshot: str | Path, agent_root: str | Path | None = None,
                 *, source_policy: dict | str | Path | None = None):
        if source_policy is None:
            source_policy = ROOT / ".cache/kats/clean_source_policy.json"
        self.source_policy = (copy.deepcopy(source_policy) if isinstance(source_policy, dict)
                              else json.loads(Path(source_policy).read_text(encoding="utf-8")))
        policy = self.source_policy
        if policy.get("policy_id") != POLICY_ID:
            raise ValueError("Unsupported clean source policy")
        if policy.get("override_sha256") != _fingerprint(policy["aliases"]):
            raise ValueError("Source alias override fingerprint changed")
        if "policy_fingerprint" in policy:
            body = {key: value for key, value in policy.items() if key != "policy_fingerprint"}
            if policy["policy_fingerprint"] != _fingerprint(body):
                raise ValueError("Clean source policy fingerprint changed")
        if Path(snapshot).resolve() != Path(policy["snapshot"]).resolve():
            raise ValueError("Clean source policy belongs to another snapshot")
        for relative, expected in policy["input_sha256"].items():
            if _sha(Path(snapshot) / relative) != expected:
                raise ValueError(f"Clean source policy input changed: {relative}")
        super().__init__(snapshot, agent_root)

    def _build_visible_view(self) -> None:
        super()._build_visible_view()
        original = _view_ids(self)
        if original != self.source_policy["original_view_ids"]:
            raise ValueError("Existing E1 source identities changed after alias audit")
        aliases = self.source_policy["aliases"]
        _verify_aliases(aliases, set(self.visible_source_ids), set(self.blocked_source_ids))
        cleaned = _closed_view(self.visible_psc, self.visible_ubc, set(self.blocked_source_ids),
                               set(self.blocked_source_group_ids), aliases)
        removed_psc = set(self.visible_psc) - set(cleaned["psc"])
        removed_ubc = set(self.visible_ubc) - set(cleaned["ubc"])
        self.visible_psc, self.visible_ubc = cleaned["psc"], cleaned["ubc"]
        self._blocked_psc_ids = frozenset(set(self._blocked_psc_ids) | removed_psc)
        self._blocked_ubc_ids = frozenset(set(self._blocked_ubc_ids) | removed_ubc)
        self.blocked_source_ids = frozenset(cleaned["blocked_sources"])
        self.blocked_source_group_ids = frozenset(cleaned["blocked_groups"])
        self.visible_source_ids = frozenset(card["paper_id"] for card in self.visible_psc.values())
        self.visible_source_group_ids = frozenset(card.get("source_group_id") or card["paper_id"]
                                                   for card in self.visible_psc.values())
        if (self.visible_source_ids & self.blocked_source_ids
                or self.visible_source_group_ids & self.blocked_source_group_ids):
            raise RuntimeError("Held-out aliases survived clean source policy")
        if "clean_view_ids" in self.source_policy and _view_ids(self) != self.source_policy["clean_view_ids"]:
            raise ValueError("Clean view no longer matches frozen alias repair")
        split_manifest = json.loads((self.snapshot / "benchmark/splits/split_manifest.json").read_text())
        known_groups = set().union(*(set(split["source_group_ids"])
                                    for split in split_manifest["splits"].values()))
        audit = self.audit
        audit["original_policy"] = audit["policy"]
        audit["policy"] = POLICY_ID
        audit["source_alias_override_sha256"] = self.source_policy["override_sha256"]
        audit["original_visible_source_count"] = len(original["source_ids"])
        audit["removed_psc_ids"] = sorted(removed_psc)
        audit["removed_ubc_ids"] = sorted(removed_ubc)
        audit["visible_psc_count"], audit["visible_ubc_count"] = len(self.visible_psc), len(self.visible_ubc)
        audit["blocked_psc_count"], audit["blocked_ubc_count"] = len(self._blocked_psc_ids), len(self._blocked_ubc_ids)
        audit["visible_source_count"] = len(self.visible_source_ids)
        audit["visible_source_group_count"] = len(self.visible_source_group_ids)
        audit["blocked_source_count"] = len(self.blocked_source_ids)
        audit["blocked_source_group_count"] = len(self.blocked_source_group_ids)
        audit["auxiliary_source_group_count"] = len(self.visible_source_group_ids - known_groups)
        audit["visible_source_ids"], audit["blocked_source_ids"] = sorted(self.visible_source_ids), sorted(self.blocked_source_ids)
        audit["visible_source_group_ids"] = sorted(self.visible_source_group_ids)
        audit["blocked_source_group_ids"] = sorted(self.blocked_source_group_ids)
        audit["visible_psc_ids_sha256"] = _existing._sha(sorted(self.visible_psc))
        audit["visible_ubc_ids_sha256"] = _existing._sha(sorted(self.visible_ubc))
        audit["denied_psc_reasons"] = {**audit["denied_psc_reasons"],
                                       "identical_pdf_to_held_out_source": len(removed_psc)}
        audit["prior_policy_identical_pdf_alias_exposure"] = True


def derive_policy(root: Path, cache: Path) -> dict:
    """Write only an independent source-policy sidecar, using no Gold/query text."""
    root, cache = Path(root).resolve(), Path(cache).resolve()
    config_path = root / "experiments/paper_e1/config.json"
    config = json.loads(config_path.read_text(encoding="utf-8"))
    corpus_path = cache / "corpus_manifest.json"
    corpus = json.loads(corpus_path.read_text(encoding="utf-8"))
    if corpus["config_sha256"] != _sha(config_path):
        raise ValueError("Original PDF audit belongs to another E1 config")
    snapshot, agent_root = Path(config["knowledge_root"]), Path(config["agent_root"])
    original = E1Retrieval(snapshot, agent_root)
    for relative, observed in original.audit["input_sha256"].items():
        if observed != config["source_sha256"].get(relative):
            raise ValueError(f"Original snapshot fingerprint changed: {relative}")
    manifest_path = Path(os.environ.get("KATS_PAPER_MANIFEST", str(Path(config["legacy_root"]) / "manifest/papers.jsonl"))).expanduser()
    if _sha(manifest_path) != corpus["manifest_sha256"]:
        raise ValueError("Original PDF source manifest changed")
    manifest = [json.loads(line) for line in manifest_path.read_text(encoding="utf-8").splitlines() if line.strip()]
    by_id = {}
    for record in manifest:
        identity = record["paper_id"]
        if identity in by_id:
            raise ValueError(f"Ambiguous PDF identity: {identity}")
        by_id[identity] = record
    aliases = []
    for collision in corpus["missing_sources"]:
        if collision["reason"] != "same_pdf_as_held_out_source":
            continue
        members = sorted({collision["source_id"], *collision["blocked_source_ids"]})
        proofs = {}
        for identity in members:
            record = by_id[identity]
            relative = Path(str(record["relative_path"]).replace("\\", "/"))
            if record["source_root"] not in {"papers", "pdfs"} or relative.is_absolute() or ".." in relative.parts:
                raise ValueError("Unsafe original PDF manifest path")
            paper_root = Path(os.environ.get("KATS_PAPER_ROOT", str(agent_root.parent / "paper"))).expanduser()
            pdf = paper_root / record["source_root"] / relative
            if not pdf.is_file():
                pdf = Path(config["legacy_root"]).parent / "OceanAgent-main2.0/paper" / record["source_root"] / relative
            proofs[identity] = {"path": str(pdf.resolve()), "size_bytes": pdf.stat().st_size}
        aliases.append({"source_ids": members, "pdf_sha256": collision["pdf_sha256"],
                        "basis": "Identical original PDF bytes; no Gold/query comparison", "pdfs": proofs})
    _verify_aliases(aliases, set(original.visible_source_ids), set(original.blocked_source_ids))
    policy = {"schema_version": "kats-clean-source-policy-v1", "policy_id": POLICY_ID,
              "snapshot": str(snapshot.resolve()), "agent_root": str(agent_root.resolve()),
              "original_config_sha256": _sha(config_path), "corpus_audit_sha256": _sha(corpus_path),
              "source_manifest_sha256": _sha(manifest_path),
              "input_sha256": original.audit["input_sha256"],
              "recorded_original_split_fingerprints": {key: value for key, value in config["source_sha256"].items()
                                                        if key.startswith("benchmark/splits/")},
              "original_view_ids": _view_ids(original), "aliases": aliases,
              "override_sha256": _fingerprint(aliases),
              "historical_reuse": "Unproven. Require identical effective model payload/tool responses or rerun under this policy.",
              "benchmark_mutation": False}
    clean = CleanE1Retrieval(snapshot, agent_root, source_policy=policy)
    policy["clean_view_ids"] = _view_ids(clean)
    policy["removed_psc_ids"] = sorted(set(original.visible_psc) - set(clean.visible_psc))
    policy["removed_ubc_ids"] = sorted(set(original.visible_ubc) - set(clean.visible_ubc))
    policy["counts"] = {"original_visible_sources": len(original.visible_source_ids),
                        "clean_visible_sources": len(clean.visible_source_ids),
                        "original_visible_psc": len(original.visible_psc), "clean_visible_psc": len(clean.visible_psc),
                        "original_visible_ubc": len(original.visible_ubc), "clean_visible_ubc": len(clean.visible_ubc),
                        "dataset_candidates_unchanged": original.dataset_ids == clean.dataset_ids}
    policy["policy_fingerprint"] = _fingerprint(policy)
    destination = cache / "clean_source_policy.json"
    destination.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(policy, ensure_ascii=False, indent=2) + "\n"
    if not destination.exists() or destination.read_text(encoding="utf-8") != payload:
        temporary = destination.with_suffix(".json.tmp")
        temporary.write_text(payload, encoding="utf-8")
        temporary.replace(destination)
    return policy


if __name__ == "__main__":
    result = derive_policy(ROOT, ROOT / ".cache/kats")
    print(json.dumps({"policy_id": result["policy_id"], "counts": result["counts"],
                      "removed_psc_ids": result["removed_psc_ids"], "removed_ubc_ids": result["removed_ubc_ids"],
                      "override_sha256": result["override_sha256"],
                      "historical_reuse": result["historical_reuse"]}, ensure_ascii=False, indent=2))
