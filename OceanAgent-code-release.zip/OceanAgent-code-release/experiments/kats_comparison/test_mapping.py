"""Small fixture tests for the actual frozen mapping policy; no benchmark labels."""
import json
from pathlib import Path
import tempfile
import unittest

from mapping import DatasetMapper


class MappingTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        rows = [
            {"dataset_id": "x-v1", "product_name": "Product X v1",
             "product_id": "X1", "aliases": ["X first", "shared"]},
            {"dataset_id": "x-v2", "product_name": "Product X v2",
             "product_id": "X2", "aliases": ["shared"]},
        ]
        self.corpus = self.root / "dataset_corpus.jsonl"
        self.cards = self.root / "dataset_cards.jsonl"
        for path in (self.corpus, self.cards):
            path.write_text("\n".join(json.dumps(row) for row in rows), encoding="utf-8")
        self.mapper = DatasetMapper(self.corpus, self.cards)

    def tearDown(self):
        self.tmp.cleanup()

    def test_exact_alias_unknown_and_strict_punctuation(self):
        self.assertEqual(self.mapper.resolve(" Ｘ FIRST ")["canonical_dataset_id"], "x-v1")
        for value in ("Product X", "X-first", "unknown", "X v3"):
            self.assertEqual(self.mapper.resolve(value)["mapping_status"], "unmapped")

    def test_ambiguity_is_not_resolved_to_an_answer(self):
        result = self.mapper.resolve("shared")
        self.assertIsNone(result["canonical_dataset_id"])
        self.assertEqual(result["mapping_status"], "ambiguous")
        self.assertEqual(self.mapper.ambiguous_count, 1)

    def test_versions_are_separate_and_duplicate_slots_retained(self):
        results = self.mapper.resolve_ranking(["Product X v1", "Product X v2", "X1"])
        self.assertEqual([r["canonical_dataset_id"] for r in results], ["x-v1", "x-v2", None])
        self.assertEqual(results[-1]["mapping_status"], "duplicate_canonical_id")

    def test_gold_path_and_fields_are_refused(self):
        gold = self.root / "dataset_gold.jsonl"
        gold.write_text(self.corpus.read_text())
        with self.assertRaisesRegex(ValueError, "Gold"):
            DatasetMapper(gold, self.cards)
        self.corpus.write_text(json.dumps({"dataset_id": "x", "task_id": "secret"}))
        with self.assertRaisesRegex(ValueError, "Label/query"):
            DatasetMapper(self.corpus, self.cards)

    def test_hash_is_stable_and_cards_do_not_expand_primary_aliases(self):
        self.assertEqual(self.mapper.manifest_hash,
                         DatasetMapper(self.corpus, self.cards).manifest_hash)
        cards = [json.loads(line) for line in self.cards.read_text().splitlines()]
        cards[0]["aliases"].append("cards-only alias")
        self.cards.write_text("\n".join(json.dumps(row) for row in cards))
        other = DatasetMapper(self.corpus, self.cards)
        self.assertEqual(other.resolve("cards-only alias")["mapping_status"], "unmapped")
        self.assertFalse(other.manifest["gold_access"])


if __name__ == "__main__":
    unittest.main()
