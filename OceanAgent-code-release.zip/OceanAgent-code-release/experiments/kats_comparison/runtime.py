#!/usr/bin/env python3
"""Execute the unmodified official KATS core through external I/O adapters.

Smoke results are explicitly KATS-Partial and remain outside formal results.
Formal stages fail closed on source leakage, changed inputs, incomplete candidate
coverage, or an unapproved model substitution. This module never opens Gold.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from datetime import datetime, timezone
import csv
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sys
import threading
import time
from types import SimpleNamespace
from urllib.parse import urlsplit, urlunsplit
from uuid import NAMESPACE_URL, uuid5

from mapping import DatasetMapper

ROOT = Path(__file__).resolve().parents[2]
COMMIT = "d66382ad677f16bb98800c3c869a1125021706ea"
SEED = 20261110
ORIGINAL_MODELS = ("gpt-4o-mini", "gpt-4o-mini", "text-embedding-3-small", 1536)
FIELDS = ["split", "task_id", "query_id", "query_variant", "rank", "raw_dataset_name",
          "canonical_dataset_id", "score", "match_type", "mapping_status", "status",
          "available_depth", "mode", "error", "configuration_fingerprint"]


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def digest(value) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                     separators=(",", ":")).encode()).hexdigest()


def write_json(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def rows(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def redact(value, secrets=()) -> str:
    text = str(value)
    for secret in secrets:
        if secret:
            text = text.replace(secret, "[REDACTED]")
    return re.sub(r"(?:sk-|Bearer\s+)[A-Za-z0-9_.-]{8,}", "[REDACTED]", text, flags=re.I)[:1600]


def env_file(path: Path) -> dict[str, str]:
    result = {}
    if path.is_file():
        for line in path.read_text(encoding="utf-8").splitlines():
            match = re.match(r"^\s*(?:export\s+)?([A-Z][A-Z0-9_]*)\s*=\s*(.*?)\s*$", line)
            if match:
                value = match[2]
                if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
                    value = value[1:-1]
                result[match[1]] = value
    return result


@dataclass
class Models:
    api_key: str = field(repr=False)
    base_url: str | None = None
    chat_model: str = "gpt-4o-mini"
    qa_model: str = "gpt-4o-mini"
    embed_model: str = "text-embedding-3-small"
    embed_dim: int = 1536
    source: str = "environment"

    @property
    def original(self) -> bool:
        return (self.chat_model, self.qa_model, self.embed_model, self.embed_dim) == ORIGINAL_MODELS

    def public(self) -> dict:
        parts = urlsplit(self.base_url) if self.base_url else None
        endpoint = urlunsplit((parts.scheme, parts.hostname or "", parts.path, "", "")) if parts else "https://api.openai.com/v1"
        return {"chat_model": self.chat_model, "qa_model": self.qa_model,
                "embed_model": self.embed_model, "embed_dim": self.embed_dim,
                "base_url": endpoint, "source": self.source, "original_models": self.original,
                "extraction_temperature": 0.1, "qa_temperature": 1,
                "max_tokens": 8192, "timeout_seconds": 60, "sdk_max_retries": 0,
                "embedding_batch_size": 10, "monetary_cost": None,
                "cost_note": "Report token usage only; actual provider charges unavailable"}


def discover_models(root: Path, environ: dict | None = None) -> Models:
    config = json.loads((root / "experiments/paper_e1/config.json").read_text())
    agent = Path(config["agent_root"])
    values = {}
    for filename in (".env", ".env.local", ".env.loacl"):
        values.update(env_file(agent / filename))
    values.update(os.environ if environ is None else environ)
    if values.get("KATS_API_KEY"):
        key, source = values["KATS_API_KEY"], "explicit KATS environment"
        base = values.get("KATS_BASE_URL") or values.get("OPENAI_BASE_URL")
        defaults = ORIGINAL_MODELS
    elif values.get("OPENAI_API_KEY"):
        key, source = values["OPENAI_API_KEY"], "OPENAI_API_KEY"
        base = values.get("KATS_BASE_URL") or values.get("OPENAI_BASE_URL")
        defaults = ORIGINAL_MODELS
    elif values.get("DASHSCOPE_API_KEY"):
        key, source = values["DASHSCOPE_API_KEY"], "existing DashScope configuration"
        base = values.get("KATS_BASE_URL") or values.get("QWEN_BASE_URL") or "https://dashscope.aliyuncs.com/compatible-mode/v1"
        defaults = ("qwen-plus", "qwen-plus", "qwen3.7-text-embedding", 1024)
    else:
        raise RuntimeError("No API key: set OPENAI_API_KEY or explicit KATS_API_KEY/model configuration")
    return Models(key, base, values.get("KATS_CHAT_MODEL", defaults[0]),
                  values.get("KATS_QA_MODEL", defaults[1]),
                  values.get("KATS_EMBED_MODEL", defaults[2]),
                  int(values.get("KATS_EMBED_DIM", defaults[3])), source)


class APICache:
    """Cache exact requests including model/endpoint; never serialize credentials."""
    def __init__(self, directory: Path, models: Models):
        self.directory, self.models = Path(directory), models
        self.directory.mkdir(parents=True, exist_ok=True)
        self.lock = threading.Lock()
        self.request_locks = {}
        self.context = threading.local()

    def call(self, kind: str, request: dict, invoke, retry_attempt=0) -> dict:
        identity = {"kind": kind, "base_url": self.models.public()["base_url"], "request": request}
        if retry_attempt:
            identity["retry_attempt"] = retry_attempt
        key = digest(identity)
        with self.lock:
            request_lock = self.request_locks.setdefault(key, threading.Lock())
        with request_lock:
            return self._locked_call(kind, request, invoke, key, retry_attempt)

    def _locked_call(self, kind: str, request: dict, invoke, key: str, retry_attempt: int) -> dict:
        path = self.directory / f"{key}.json"
        started = time.monotonic()
        cached = path.is_file()
        try:
            if cached:
                result = json.loads(path.read_text())["response"]
            else:
                response = invoke()
                result = response.model_dump(mode="json")
                write_json(path, {"request_sha256": key, "kind": kind, "model": request["model"],
                                  "response": result})
            event = {"request_sha256": key, "kind": kind, "model": request["model"],
                     "cache_hit": cached, "status": "success", "usage": result.get("usage"),
                     "elapsed_seconds": round(time.monotonic() - started, 3)}
            return result
        except Exception as exc:
            event = {"request_sha256": key, "kind": kind, "model": request["model"],
                     "cache_hit": cached, "status": "failed", "error": redact(exc, [self.models.api_key]),
                     "elapsed_seconds": round(time.monotonic() - started, 3)}
            raise
        finally:
            event["retry_attempt"] = retry_attempt
            if kind == "chat" and str(getattr(self.context, "purpose", "")).startswith("er_") and event["status"] == "success":
                try:
                    content = result["choices"][0]["message"]["content"]
                    parsed = json.loads(re.search(r"\{.*\}", content, re.S)[0])
                    event["er_response_parseable"] = isinstance(parsed, dict)
                    event["er_bool_schema_valid"] = isinstance(parsed, dict) and type(parsed.get("is_same")) is bool
                except Exception:
                    event["er_response_parseable"] = False
            for name in ("purpose", "er_batch", "er_pair", "query_id"):
                if getattr(self.context, name, None):
                    event[name] = getattr(self.context, name)
            with self.lock:
                with (self.directory / "usage.jsonl").open("a", encoding="utf-8") as stream:
                    stream.write(json.dumps(event, ensure_ascii=False) + "\n")

    def summary(self) -> dict:
        ledger = self.directory / "usage.jsonl"
        events = rows(ledger) if ledger.exists() else []
        totals = {}
        for event in events:
            if event["cache_hit"] or event["status"] != "success":
                continue
            for key, value in (event.get("usage") or {}).items():
                if isinstance(value, int):
                    totals[key] = totals.get(key, 0) + value
        consumed = {(event.get("er_batch"), tuple(event.get("er_pair", [])))
                    for event in events if event.get("purpose") == "er_consume"}
        prefetched = [event for event in events if event.get("purpose") == "er_prefetch"
                      and not event["cache_hit"] and event["status"] == "success"]
        extra = [event for event in prefetched
                 if (event.get("er_batch"), tuple(event.get("er_pair", []))) not in consumed]
        extra_tokens = {}
        for event in extra:
            for key, value in (event.get("usage") or {}).items():
                if isinstance(value, int):
                    extra_tokens[key] = extra_tokens.get(key, 0) + value
        return {"network_successes": sum(not e["cache_hit"] and e["status"] == "success" for e in events),
                "network_failures": sum(not e["cache_hit"] and e["status"] == "failed" for e in events),
                "cache_hits": sum(e["cache_hit"] for e in events), "tokens": totals,
                "er_prefetch_paid_requests": len(prefetched),
                "er_prefetch_paid_unconsumed_requests": len(extra),
                "er_prefetch_paid_unconsumed_tokens": extra_tokens,
                "monetary_cost": None, "cost_note": "Actual charged price unavailable"}


def vector_key(models: Models, text: str) -> str:
    return digest({"endpoint": models.public()["base_url"], "model": models.embed_model,
                   "dimension": models.embed_dim, "complete_input_text": text.replace("\n", " ")})


def seed_embedding_vectors(core: Path, cache: APICache):
    import pandas as pd
    destination = cache.directory / "embedding_vectors"
    destination.mkdir(exist_ok=True)
    for kind in ("tasks", "datasets"):
        path = core / f"{kind}.parquet"
        fingerprint = sha(path)
        for row in pd.read_parquet(path).to_dict(orient="records"):
            target = destination / f"{vector_key(cache.models, row['text'])}.json"
            if not target.exists():
                write_json(target, {"embedding": list(map(float, row["embedding"])),
                                    "source": "verified_official_parquet", "parquet_sha256": fingerprint,
                                    "entity_id": row["hex_id"], "model": cache.models.embed_model,
                                    "dimension": cache.models.embed_dim})


ALIAS_CYCLE_POLICY = "Detect repeated alias IDs; prefer a live graph representative, then a live alias-owner representative, then the smallest declared-equivalent UUID; record repairs; thresholds and DSU unchanged"


def cycle_safe_normalize(title: str, aliases: dict, graph, on_cycle=None) -> str:
    # This prefix is deliberately identical to official _normalize_title.
    text = re.sub(r"[^\w\s-]", "", title.lower())
    text = re.sub(r"\b(a|the|an|dataset|corpus|data)\b", "", text)
    current = re.sub(r"\s+", " ", text).strip()
    path, positions = [], {}
    while current in aliases and aliases[current] != current:
        if current in positions:
            cycle = path[positions[current]:]
            live = [node for node in cycle if node in graph and graph.nodes[node].get("type") == "dataset"]
            owners = []
            if not live:
                for node, attrs in graph.nodes(data=True):
                    linked = attrs.get("aliases", [])
                    linked = linked.split(",") if isinstance(linked, str) else linked
                    if attrs.get("type") == "dataset" and set(linked).intersection(cycle):
                        owners.append(node)
            representative = min(live or owners or cycle)
            for alias in path:
                aliases[alias] = representative
            aliases[representative] = representative
            if on_cycle:
                on_cycle({"cycle": cycle, "resolved_to": representative,
                          "resolution_source": "live_graph_node" if live else "live_alias_owner" if owners else "stable_equivalent_uuid"})
            return representative
        positions[current] = len(path)
        path.append(current)
        current = aliases[current]
    return current


def install_official_adapters(core: Path, models: Models, cache: APICache):
    """Change clients/cache routing only; official extraction and ranking stay intact."""
    from openai import OpenAI
    from openai.types.chat import ChatCompletion
    from openai.types.create_embedding_response import CreateEmbeddingResponse
    from task_oriented_dataset_search import pipeline
    from task_oriented_dataset_search.extraction.client import OpenAIClient
    from task_oriented_dataset_search.embedding.embedder import OpenAIAPITextEmbedder
    from task_oriented_dataset_search.preprocessing import processor
    from task_oriented_dataset_search.utils.cache import CacheManager
    from task_oriented_dataset_search.graph.dataset_merger import DatasetMerger
    DatasetMerger = getattr(DatasetMerger, "_official", DatasetMerger)

    processor.cache_manager = CacheManager(str(core))
    official_extract_file = pipeline.extract_file
    # Reinstallation in one process must not stack wrappers.
    official_extract_file = getattr(official_extract_file, "_official", official_extract_file)

    def record_extraction(txt_path, extractor, extraction_cache, *args, **kwargs):
        started = time.monotonic()
        event = {"pdf_sha256": Path(txt_path).stem, "status": "failed"}
        try:
            result = official_extract_file(txt_path, extractor, extraction_cache, *args, **kwargs)
            event["status"] = "success"
            return result
        except Exception as exc:
            event["error"] = redact(exc, [models.api_key])
            event["error_type"] = type(exc).__name__
            raise
        finally:
            event["elapsed_seconds"] = round(time.monotonic() - started, 3)
            with cache.lock:
                with (core.parent / "extraction_attempts.jsonl").open("a", encoding="utf-8") as stream:
                    stream.write(json.dumps(event, ensure_ascii=False) + "\n")
    record_extraction._official = official_extract_file
    pipeline.extract_file = record_extraction

    class PrefetchDatasetMerger(DatasetMerger):
        """Prefetch static official judge requests; consume with official DSU order."""
        _official = DatasetMerger

        def _normalize_title(self, title):
            def record(event):
                event.update(er_batch=getattr(self, "_batch", None), policy=ALIAS_CYCLE_POLICY)
                with cache.lock:
                    with (core.parent / "alias_cycle_repairs.jsonl").open("a", encoding="utf-8") as stream:
                        stream.write(json.dumps(event) + "\n")
            return cycle_safe_normalize(title, self.alias_dict, self.graph, record)

        def _prefetch(self, candidates, kind):
            eligible = []
            for left, right, _ in candidates:
                pair = tuple(sorted((left, right)))
                if (self.dsu.connected(left, right) or pair in self.different_pairs_set
                        or left not in self.dataset_details or right not in self.dataset_details):
                    continue
                a = self._normalize_title(self.dataset_details[left]["title"])
                b = self._normalize_title(self.dataset_details[right]["title"])
                if a and a == b:
                    continue
                eligible.append((left, right))
            self._planned_prefetch = len(eligible)
            self._prefetched = set()
            self._consumed = set()
            self._batch = digest({"kind": kind, "pairs": eligible})
            self._kind = kind
            failed = threading.Event()
            original_retries = self.llm_retries
            self.llm_retries = 1  # Prefetch transport failure aborts; original consumption keeps original retry setting.
            def warm(pair):
                if failed.is_set():
                    return
                with cache.lock:
                    self._prefetched.add(tuple(sorted(pair)))
                cache.context.purpose, cache.context.er_batch = "er_prefetch", self._batch
                cache.context.er_pair = list(sorted(pair))
                cache.context.er_retry_attempt = 0
                try:
                    # The superclass constructs the exact same official prompt
                    # from static title/description/link; no DSU update occurs.
                    DatasetMerger._call_llm_judge(self, *pair)
                    a, b = (self.dataset_details[identity] for identity in pair)
                    prompt = self._read_prompt("dataset_identity_prompt.txt").format(
                        title1=a["title"], description1=a["description"], link1=a["link"],
                        title2=b["title"], description2=b["description"], link2=b["link"])
                    request = {"model": models.chat_model, "messages": [{"role": "user", "content": prompt}],
                               "temperature": self.llm_client.temperature, "max_tokens": 8192}
                    key = digest({"kind": "chat", "base_url": models.public()["base_url"], "request": request})
                    if not (cache.directory / f"{key}.json").is_file():
                        failed.set()
                finally:
                    cache.context.purpose = cache.context.er_batch = cache.context.er_pair = None
                    cache.context.er_retry_attempt = 0
            try:
                with ThreadPoolExecutor(max_workers=6) as executor:
                    list(executor.map(warm, eligible))
            finally:
                self.llm_retries = original_retries
            if failed.is_set():
                raise RuntimeError("ER prefetch transport failure; stopped before DSU consumption; successful exact responses remain cached")

        def _call_llm_judge(self, left, right):
            self._consumed.add(tuple(sorted((left, right))))
            cache.context.purpose, cache.context.er_batch = "er_consume", self._batch
            cache.context.er_pair = list(sorted((left, right)))
            cache.context.er_retry_attempt = 0
            try:
                return super()._call_llm_judge(left, right)
            finally:
                cache.context.purpose = cache.context.er_batch = cache.context.er_pair = None
                cache.context.er_retry_attempt = 0

        def _record_prefetch(self):
            if not hasattr(self, "_prefetched"):
                return
            event = {"kind": self._kind, "er_batch": self._batch,
                     "planned_prefetch_pairs": self._planned_prefetch,
                     "prefetched_pairs": len(self._prefetched), "consumed_pairs": len(self._consumed),
                     "extra_prefetched_pairs": len(self._prefetched - self._consumed),
                     "extra_pairs": [list(pair) for pair in sorted(self._prefetched - self._consumed)]}
            with cache.lock:
                with (core.parent / "er_prefetch.jsonl").open("a", encoding="utf-8") as stream:
                    stream.write(json.dumps(event) + "\n")

        def _generate_candidates(self):
            result = super()._generate_candidates()
            self._prefetch(result, "native")
            return result

        def merge_datasets(self):
            try:
                return super().merge_datasets()
            finally:
                self._record_prefetch()

        def merge_new_datasets(self, new_ids):
            import numpy as np
            new_frame = self.dataset_df[self.dataset_df.index.isin(new_ids)]
            candidates, seen = [], set()
            if not new_frame.empty:
                distances, neighbors = self.faiss_index.search(
                    np.stack(new_frame["embedding"].tolist()), min(self.k_neighbors, self.faiss_index.ntotal))
                for index, left in enumerate(new_frame.index):
                    for j, integer in enumerate(neighbors[index]):
                        if integer == -1 or distances[index, j] < self.similarity_threshold:
                            continue
                        right = self.int64_to_hex_map.get(integer)
                        if not right or left == right:
                            continue
                        pair = tuple(sorted((left, right)))
                        if pair not in seen:
                            candidates.append((left, right, distances[index, j]))
                            seen.add(pair)
            try:
                self._prefetch(candidates, "catalog_prefix")
                return super().merge_new_datasets(new_ids)
            finally:
                self._record_prefetch()

    pipeline.DatasetMerger = PrefetchDatasetMerger

    class CachedClient(OpenAIClient):
        def __init__(self, api_key, model="gpt-4o-mini", base_url=None, temperature=0.1):
            self._client = OpenAI(api_key=api_key, base_url=base_url, timeout=60, max_retries=0)
            self._model, self.temperature = model, temperature

        def chat(self, messages, temperature=None, max_tokens=None, **kwargs):
            request = {"model": self._model, "messages": messages,
                       "temperature": self.temperature if temperature is None else temperature,
                       "max_tokens": max_tokens or 8192, **kwargs}
            attempt = 0
            if str(getattr(cache.context, "purpose", "")).startswith("er_"):
                attempt = getattr(cache.context, "er_retry_attempt", 0)
                cache.context.er_retry_attempt = attempt + 1
            response = cache.call("chat", request, lambda: self._client.chat.completions.create(**request), retry_attempt=attempt)
            return ChatCompletion.model_validate(response)

    def make_embedder(api_key, api_base=None, **kwargs):
        embedder = OpenAIAPITextEmbedder(api_key=api_key, api_base=api_base,
                                        model_name=models.embed_model, batch_size=10)
        embedder._dimension = models.embed_dim
        sdk = OpenAI(api_key=api_key, base_url=api_base, timeout=60, max_retries=0)

        def create(**request):
            if models.embed_model != "text-embedding-3-small":
                request["dimensions"] = models.embed_dim
            vector_directory = cache.directory / "embedding_vectors"
            vector_directory.mkdir(exist_ok=True)
            paths = [vector_directory / f"{vector_key(models, text)}.json" for text in request["input"]]
            if all(path.is_file() for path in paths):
                values = [json.loads(path.read_text())["embedding"] for path in paths]
                event = {"kind": "embedding_vector", "model": models.embed_model, "cache_hit": True,
                         "status": "success", "usage": None,
                         "request_sha256": digest({"kind": "embedding", "base_url": models.public()["base_url"], "request": request}),
                         "vector_provenance": [path.stem for path in paths], "elapsed_seconds": 0}
                for name in ("purpose", "query_id"):
                    if getattr(cache.context, name, None):
                        event[name] = getattr(cache.context, name)
                with cache.lock:
                    with (cache.directory / "usage.jsonl").open("a", encoding="utf-8") as stream:
                        stream.write(json.dumps(event) + "\n")
                return SimpleNamespace(data=[SimpleNamespace(embedding=value) for value in values])
            response = cache.call("embedding", request, lambda: sdk.embeddings.create(**request))
            for path, item in zip(paths, response["data"]):
                if not path.exists():
                    write_json(path, {"embedding": item["embedding"], "source": "exact_official_embedding_response",
                                      "model": models.embed_model, "dimension": models.embed_dim,
                                      "request_sha256": digest({"kind": "embedding", "base_url": models.public()["base_url"], "request": request})})
            return CreateEmbeddingResponse.model_validate(response)
        embedder._client = SimpleNamespace(embeddings=SimpleNamespace(create=create))
        return embedder

    pipeline.OpenAIClient = CachedClient
    pipeline.OpenAIAPITextEmbedder = make_embedder
    return pipeline


class QAAbstention(ValueError):
    """A real model refusal to recommend a relevant candidate; never a ranking."""


def classify_qa_output(answer: str) -> str:
    numbered = re.search(r"^\s*(?:#{1,6}\s*)?\d+[.)、]\s+", answer, re.M)
    leading_refusal = re.match(r"^\s*(?:none of the (?:provided |listed |available )?datasets|no (?:suitable |related |relevant )datasets?)", answer, re.I)
    if (not numbered or leading_refusal) and re.search(
        r"none of the (?:provided |listed |available )?datasets|no (?:suitable |related |relevant )datasets?"
        r"|cannot find any (?:related |relevant )dataset|no dataset.+(?:relevant|suitable)"
        r"|没有(?:相关|合适|符合).{0,8}数据集|均不(?:相关|适合)", answer, re.I):
        return "abstained"
    return "ranking" if numbered else "unparseable"


QA_PARSING_POLICY = "Use the last contiguous numbered ranking block; remove balanced Markdown code-span display; accept an explicitly only/only-valid-answer single highlighted recommendation; never pad or infer names"


def _display_title(content: str) -> str:
    bold = re.match(r"\*\*(.+?)\*\*(.*)$", content)
    if bold:
        title, tail = bold[1].strip(), bold[2].strip()
        if title.casefold().rstrip(":") in {"dataset", "dataset title", "title"}:
            title = tail.lstrip(": ").strip()
            named = re.match(r"\*\*(.+?)\*\*", title)
            title = named[1] if named else title
    else:
        title = content
    title = re.split(r"\s+[—–]\s+", title, maxsplit=1)[0].strip().rstrip(":")
    code = re.fullmatch(r"(`+)(.+?)\1", title)
    if code:
        title = code[2].strip()
    if not title:
        raise ValueError("QA rank has no dataset title")
    return title


def parse_ranked_answer(answer: str, top_k=10) -> list[str]:
    """Read explicit final presentation order; no model or relevance inference."""
    if classify_qa_output(answer) == "abstained":
        raise QAAbstention("QA explicitly abstained: no relevant dataset was recommended")
    blocks, current = [], []
    for line in answer.splitlines():
        match = re.match(r"^\s*(?:#{1,6}\s*)?(\d+)[.)、]\s+(.+?)\s*$", line)
        if not match:
            continue
        rank, content = int(match[1]), match[2]
        if rank == 1 and current:
            blocks.append(current)
            current = []
        # Explicit empty-slot text is a refusal to add a dataset, not a name.
        if re.match(r"^[*_(`\s]*(?:no further|no additional|no more|none remaining)\b", content, re.I):
            continue
        current.append((rank, content))
    if current:
        blocks.append(current)
    if blocks:
        final = blocks[-1]
        if [rank for rank, _ in final] != list(range(1, len(final) + 1)) or len(final) > top_k:
            raise ValueError("QA final numbered ranks are non-contiguous or exceed top_k")
        return [_display_title(content) for _, content in final]
    markers = list(re.finditer(
        r"(?:top and only relevant dataset|only valid answer|most relevant dataset\s*\(ranked\s*#?1\))[^\n]*\n",
        answer, re.I))
    if markers:
        candidates = []
        for line in answer[markers[-1].end():].splitlines():
            text = line.strip()
            if re.match(r"^[-+]\s+\*\*", text):
                candidates.append(_display_title(re.sub(r"^[-+]\s+", "", text)))
            elif re.fullmatch(r"\*\*[^*]+\*\*\s*", text):
                candidates.append(_display_title(text))
        if len(candidates) == 1:
            return candidates
    raise ValueError("QA has no unambiguous parseable dataset ranking")


def ensure_formal_ready(manifest: dict, models: Models, allow_model_substitution=False):
    if not manifest.get("input_ready") or not manifest.get("source_coverage_complete"):
        raise RuntimeError("Formal KATS blocked: corpus input_ready/source_coverage_complete is false; resolve source leakage/coverage under the frozen protocol")
    if not models.original and not allow_model_substitution:
        raise RuntimeError("Formal KATS blocked: original models unavailable; provide OpenAI configuration or explicitly --allow-model-substitution for KATS-Adapted")


def load_inputs(root: Path, cache_root: Path):
    config_path = root / "experiments/paper_e1/config.json"
    config = json.loads(config_path.read_text())
    manifest = json.loads((cache_root / "corpus_manifest.json").read_text())
    if manifest.get("config_sha256") != sha(config_path):
        raise ValueError("Corpus manifest belongs to a different E1 configuration")
    for relative, observed in manifest.get("source_fingerprints", {}).items():
        if observed != config["source_sha256"].get(relative):
            raise ValueError(f"Corpus policy fingerprint changed: {relative}")
    queries_path = root / "experiments/paper_e1/runtime_queries.jsonl"
    if sha(queries_path) != config["runtime_queries_sha256"]:
        raise ValueError("Frozen runtime query fingerprint changed")
    snapshot = Path(config["knowledge_root"])
    for relative in ("benchmark/corpus/dataset_corpus.jsonl", "cards/dataset_cards.jsonl"):
        if sha(snapshot / relative) != config["source_sha256"][relative]:
            raise ValueError(f"Frozen metadata changed: {relative}")
    return config, manifest, rows(queries_path), DatasetMapper(
        snapshot / "benchmark/corpus/dataset_corpus.jsonl", snapshot / "cards/dataset_cards.jsonl")


def select_smoke(manifest: dict, destination: Path, count=5) -> list[dict]:
    blocked = set(manifest["blocked_source_ids"])
    selected = sorted((row for row in manifest["sources"] if not row.get("duplicate_of")),
                      key=lambda row: (row["size_bytes"], row["source_id"]))[:count]
    if len(selected) != count or any(row["source_id"] in blocked for row in selected):
        raise ValueError("Insufficient safe, independent source PDFs for smoke")
    destination.mkdir(parents=True, exist_ok=True)
    expected = {f"{row['source_id']}.pdf" for row in selected}
    if {p.name for p in destination.iterdir()} - expected:
        raise ValueError("Unexpected existing smoke input files")
    for row in selected:
        original = Path(row["pdf_path"])
        if sha(original) != row["pdf_sha256"]:
            raise ValueError(f"PDF changed: {row['source_id']}")
        target = destination / f"{row['source_id']}.pdf"
        if target.exists() or target.is_symlink():
            if target.resolve() != original.resolve():
                raise ValueError("Smoke input target mismatch")
        else:
            target.symlink_to(original)
    return selected


def validate_input_directory(manifest: dict):
    directory = Path(manifest["input_dir"])
    expected = {Path(row["input_pdf"]).name: row["pdf_sha256"]
                for row in manifest["sources"] if not row.get("duplicate_of")}
    actual = {path.name: path for path in directory.iterdir()}
    if actual.keys() != expected.keys():
        raise RuntimeError("Formal PDF input filenames differ from audited source manifest")
    for name, expected_sha in expected.items():
        if not actual[name].is_file() or sha(actual[name]) != expected_sha:
            raise RuntimeError(f"Formal PDF input changed: {name}")


def smoke_queries(queries: list[dict], count=5) -> list[dict]:
    task_ids = list(dict.fromkeys(q["task_id"] for q in queries if q["split"] == "dev"))[:count]
    return [q for q in queries if q["split"] == "dev" and q["task_id"] in task_ids]


def engine_for(core: Path, input_dir: Path, models: Models, api: APICache):
    pipeline = install_official_adapters(core, models, api)
    cfg = pipeline.PipelineConfig(input_folder=str(input_dir), api_key=models.api_key,
                                  cache_root=str(core), api_base=models.base_url,
                                  model=models.chat_model, qa_model=models.qa_model,
                                  extract_workers=int(os.environ.get("KATS_EXTRACT_WORKERS", "6")),
                                  preprocess_workers=1, retry_limit=1,
                                  llm_retries=1, llm_retry_delay=0)
    engine = pipeline.TodsEngine(config=cfg)
    engine._adapter_api_cache = api
    return engine


def validate_build(core: Path, input_dir: Path, allow_recorded_failures=False) -> dict:
    import faiss
    import numpy as np
    import pandas as pd
    from tinydb import TinyDB
    expected = {sha(path) for path in input_dir.iterdir() if path.is_file()}
    observed = {path.stem for path in (core / "extraction").glob("*.json")}
    missing = sorted(expected - observed)
    if missing and not allow_recorded_failures:
        raise RuntimeError(f"Official extraction incomplete: {len(missing)}/{len(expected)} input PDFs lack successful extraction")
    if missing:
        attempts_path = core.parent / "extraction_attempts.jsonl"
        attempts = rows(attempts_path) if attempts_path.is_file() else []
        failures = {event["pdf_sha256"]: event for event in attempts if event["status"] == "failed"}
        if any(fingerprint not in failures for fingerprint in missing):
            raise RuntimeError("Missing extraction without a recorded real failed attempt")
    if observed - expected:
        raise RuntimeError("Unexpected extraction SHA outside audited PDF inputs")
    expected_records = {"documents": {}, "datasets": {}, "tasks": {}}
    for path in sorted((core / "extraction").glob("*.json")):
        value = json.loads(path.read_text())
        if (not isinstance(value, dict) or type(value.get("datasets_used")) is not bool
                or not isinstance(value.get("datasets"), list)
                or (value["datasets_used"] is False and value["datasets"])):
            raise RuntimeError(f"Invalid official extraction cache: {path.name}")
        if value["datasets_used"] is False:
            continue
        fingerprint = path.stem
        expected_records["documents"][fingerprint] = {"id": fingerprint}
        for dataset in value["datasets"]:
            if not isinstance(dataset, dict):
                raise RuntimeError(f"Invalid extracted dataset record: {path.name}")
            title = dataset.get("title", "")
            dataset_id = uuid5(NAMESPACE_URL, f"{fingerprint}:{title}").hex
            expected_records["datasets"].setdefault(dataset_id, {
                "id": dataset_id, "document_id": fingerprint, "title": title,
                "description": dataset.get("description", ""), "link": dataset.get("link", "")})
            task_description = dataset.get("task_description", "")
            task_id = uuid5(NAMESPACE_URL, f"{dataset_id}:{task_description}").hex
            expected_records["tasks"].setdefault(task_id, {
                "id": task_id, "dataset_id": dataset_id, "task_description": task_description,
                "keywords": dataset.get("task", "")})
    needed = ("tiny_db.json", "faiss_tasks.index", "faiss_datasets.index", "tasks.parquet",
              "datasets.parquet", "original_kg.graphml", "processed_kg.graphml", "tasks_kg.graphml")
    if any(not (core / name).is_file() for name in needed):
        raise RuntimeError("Official build missing one or more graph/index artifacts")
    with TinyDB(core / "tiny_db.json") as db:
        actual_records = {kind: db.table(kind).all() for kind in expected_records}
        if any(len(db.table(kind)) for kind in db.tables() - expected_records.keys()):
            raise RuntimeError("Unexpected nonempty TinyDB table")
    # Official entity resolution mutates graph nodes only, not TinyDB records.
    # The sole supported source of additional DB entities is the official
    # catalog-add operation, reconstructed from its checkpoint and public cards.
    catalog_path = core.parent / "catalog_checkpoint.json"
    if catalog_path.is_file():
        checkpoint = json.loads(catalog_path.read_text())
        configuration = json.loads((core.parent / "configuration.json").read_text())
        if checkpoint["configuration_fingerprint"] != digest(configuration):
            raise RuntimeError("Catalog checkpoint configuration mismatch")
        corpus_path = Path(checkpoint["corpus_path"])
        if sha(corpus_path) != checkpoint["corpus_sha256"]:
            raise RuntimeError("Catalog source fingerprint mismatch")
        catalog = {card["dataset_id"]: card for card in rows(corpus_path)}
        for canonical, addition in checkpoint["entries"].items():
            if addition.get("status") != "added":
                continue
            if canonical not in catalog:
                raise RuntimeError("Catalog checkpoint has an out-of-universe candidate")
            description, link = catalog_metadata(catalog[canonical])
            dataset_id = uuid5(NAMESPACE_URL, f"{canonical}:{description}").hex
            if dataset_id != addition["official_dataset_id"] or dataset_id in expected_records["datasets"]:
                raise RuntimeError("Invalid/duplicate official catalog dataset UUID")
            expected_records["datasets"][dataset_id] = {
                "id": dataset_id, "document_id": None, "title": canonical,
                "description": description, "link": link}
            for nearest in addition["nearest_dataset_ids"]:
                if nearest not in expected_records["datasets"] or nearest == dataset_id:
                    raise RuntimeError("Catalog nearest dataset is not a previously validated entity")
                copied = [task for task in list(expected_records["tasks"].values())
                          if task["dataset_id"] == nearest]
                for task in copied:
                    description_text = task["task_description"]
                    task_id = uuid5(NAMESPACE_URL, f"{dataset_id}:{description_text}").hex
                    expected_records["tasks"][task_id] = {
                        "id": task_id, "dataset_id": dataset_id,
                        "task_description": description_text, "keywords": task["keywords"]}
    counts = {}
    for kind, records in actual_records.items():
        if any(not isinstance(record, dict) or not isinstance(record.get("id"), str) for record in records):
            raise RuntimeError(f"Malformed TinyDB {kind} record")
        actual = {record["id"]: dict(record) for record in records}
        if len(actual) != len(records) or actual != expected_records[kind]:
            raise RuntimeError(f"TinyDB {kind} differs from official extraction/catalog UUID records")
        counts[kind] = len(actual)
    if not counts["datasets"] or not counts["tasks"]:
        raise RuntimeError("Official build contains no searchable task/dataset entities")
    configured = core.parent / "configuration.json"
    expected_dimension = (json.loads(configured.read_text()).get("models", {}).get("embed_dim")
                          if configured.is_file() else None)
    index_audit = {}
    dimensions = set()
    for kind in ("tasks", "datasets"):
        frame = pd.read_parquet(core / f"{kind}.parquet")
        index = faiss.read_index(str(core / f"faiss_{kind}.index"))
        dimensions.add(index.d)
        if expected_dimension is not None and index.d != expected_dimension:
            raise RuntimeError(f"FAISS {kind} dimension differs from configured model")
        required_columns = {"hex_id", "int64_id", "embedding", "text"}
        if not required_columns.issubset(frame.columns) or frame.empty or index.ntotal != len(frame):
            raise RuntimeError(f"FAISS/parquet {kind} row count or schema mismatch")
        eligible = {identity: record for identity, record in expected_records[kind].items()
                    if (record.get("task_description") if kind == "tasks"
                        else record.get("title") or record.get("description"))}
        if frame["hex_id"].duplicated().any() or set(frame["hex_id"]) != set(eligible):
            raise RuntimeError(f"Parquet {kind} IDs differ from searchable TinyDB records")
        int_ids = []
        for record in frame.to_dict(orient="records"):
            identity = record["hex_id"]
            expected_int = int(identity, 16) & ((1 << 63) - 1)
            vector = np.asarray(record["embedding"], dtype="float32")
            if int(record["int64_id"]) != expected_int or vector.shape != (index.d,) or not np.isfinite(vector).all():
                raise RuntimeError(f"Invalid parquet {kind} UUID/vector dimension")
            source = eligible[identity]
            text = source["task_description"] if kind == "tasks" else f"{source['title']} {source['description']}".strip()
            if record["text"] != text:
                raise RuntimeError(f"Parquet {kind} embedded text differs from source entity")
            int_ids.append(expected_int)
        if len(set(int_ids)) != len(int_ids) or not hasattr(index, "id_map"):
            raise RuntimeError(f"Invalid FAISS {kind} ID map")
        actual_int_ids = faiss.vector_to_array(index.id_map).tolist()
        if len(actual_int_ids) != len(int_ids) or set(actual_int_ids) != set(int_ids):
            raise RuntimeError(f"FAISS/parquet {kind} IDs differ")
        index_audit[kind] = {"faiss_ntotal": int(index.ntotal), "parquet_rows": len(frame), "dimension": index.d}
    if len(dimensions) != 1:
        raise RuntimeError("Task and dataset index dimensions differ")
    return {"input_pdfs": len(expected), "successful_extractions": len(observed & expected),
            "failed_extraction_count": len(missing), "failed_extraction_sha256": missing,
            "corpus_extraction_complete": not missing,
            **counts, "index_validation": index_audit,
            "artifact_sha256": {name: sha(core / name) for name in needed}}


def catalog_metadata(card: dict) -> tuple[str, str]:
    description = json.dumps({key: card[key] for key in (
        "product_name", "name", "description", "aliases", "official_version",
        "provider", "spatial_coverage", "temporal_coverage") if key in card},
        ensure_ascii=False, sort_keys=True)
    access = card.get("access") if isinstance(card.get("access"), list) else []
    link = next((item["url"] for item in access if isinstance(item, dict)
                 and isinstance(item.get("url"), str) and item["url"].startswith("http")), "")
    return description, link


CATALOG_MUTABLE = ("tiny_db.json", "faiss_tasks.index", "faiss_datasets.index",
                   "tasks.parquet", "datasets.parquet", "processed_kg.graphml")


def catalog_snapshot(core: Path, directory: Path, identity: str) -> dict:
    backup = directory / "catalog_transaction"
    before = backup / "before"
    if before.exists():
        shutil.rmtree(before)
    before.mkdir(parents=True)
    paths = [Path(name) for name in CATALOG_MUTABLE]
    paths.extend(path.relative_to(core) for path in (core / "aliases").glob("*.json"))
    hashes = {}
    for relative in paths:
        source = core / relative
        if source.exists():
            target = before / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
            hashes[str(relative)] = sha(source)
    transaction = {"dataset_id": identity, "state": "pending", "before_sha256": hashes}
    write_json(backup / "transaction.json", transaction)
    return transaction


def catalog_rollback(core: Path, directory: Path, transaction: dict):
    backup = directory / "catalog_transaction"
    paths = {Path(name) for name in CATALOG_MUTABLE}
    paths.update(path.relative_to(core) for path in (core / "aliases").glob("*.json"))
    paths.update(Path(name) for name in transaction["before_sha256"])
    for relative in paths:
        target = core / relative
        expected = transaction["before_sha256"].get(str(relative))
        if expected is None:
            if target.is_file():
                target.unlink()
            continue
        source = backup / "before" / relative
        if sha(source) != expected:
            raise RuntimeError("Catalog rollback snapshot checksum mismatch")
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
    transaction["state"] = "rolled_back"
    write_json(backup / "transaction.json", transaction)


def resolve_candidate_entity(entity: dict, mapper: DatasetMapper) -> dict:
    """Validate explicit catalog IDs; apply E1 exact name/URL union to native text."""
    title = entity.get("title")
    if entity.get("document_id") is None and title in mapper.canonical:
        return {"canonical_dataset_id": title, "match_type": "canonical_id",
                "mapping_status": "exact_unique", "candidate_ids": [title]}
    return mapper.resolve({"name": title, "url": entity.get("link")})


OUTPUT_MAPPING_POLICY = "Exact literal canonical IDs use direct membership; free names use frozen E1 exact-name mapping; duplicate canonical ranks remain null without promotion"


def resolve_output_ranking(mapper: DatasetMapper, names: list[str]) -> list[dict]:
    """An alias collision cannot veto a known ID; no new alias is inferred."""
    output, seen = [], set()
    for name in names:
        if name in mapper.canonical:
            resolved = {"canonical_dataset_id": name, "match_type": "canonical_id",
                        "mapping_status": "exact_unique", "candidate_ids": [name],
                        "signals": [{"field": "canonical_id", "value": name, "exact_matches": [name]}]}
        else:
            resolved = mapper.resolve(name)
        identity = resolved["canonical_dataset_id"]
        if identity is not None and identity in seen:
            resolved = {**resolved, "canonical_dataset_id": None, "match_type": "none",
                        "mapping_status": "duplicate_canonical_id"}
        elif identity is not None:
            seen.add(identity)
        output.append(resolved)
    return output


def candidate_coverage(core: Path, mapper: DatasetMapper) -> dict:
    import networkx as nx
    from tinydb import TinyDB
    with TinyDB(core / "tiny_db.json") as db:
        extracted = db.table("datasets").all()
    graph = nx.read_graphml(core / "processed_kg.graphml")
    reachable_ids = {node for node, attrs in graph.nodes(data=True)
                     if attrs.get("type") == "dataset" and graph.degree(node) > 0}
    mapped = [resolve_candidate_entity(row, mapper) for row in extracted
              if row["id"] in reachable_ids]
    ids = {m["canonical_dataset_id"] for m in mapped if m["canonical_dataset_id"]}
    checkpoint_path = core.parent / "catalog_checkpoint.json"
    checkpoint = json.loads(checkpoint_path.read_text()) if checkpoint_path.is_file() else {}
    entries = checkpoint.get("entries", {})
    input_ids = {identity for identity, entry in entries.items()
                 if identity in mapper.canonical and entry.get("status") in ("added", "already_in_native_graph")}
    input_complete = (input_ids == mapper.canonical
                      and checkpoint.get("corpus_sha256") == mapper.manifest["corpus_sha256"])
    by_id = {row["id"]: row for row in extracted}
    cross_canonical_clusters = []
    alias_clusters = 0
    for representative, attrs in graph.nodes(data=True):
        if attrs.get("type") != "dataset" or not attrs.get("aliases"):
            continue
        alias_clusters += 1
        aliases = attrs["aliases"].split(",") if isinstance(attrs["aliases"], str) else attrs["aliases"]
        canonical = set()
        for entity_id in [representative, *aliases]:
            entity = by_id.get(entity_id, {})
            result = resolve_candidate_entity(entity, mapper)
            if result["canonical_dataset_id"]:
                canonical.add(result["canonical_dataset_id"])
        if len(canonical) > 1:
            cross_canonical_clusters.append({"representative": representative,
                                             "canonical_ids": sorted(canonical)})
    return {"required_candidates": len(mapper.canonical), "mapped_extracted_candidates": len(ids),
            "catalog_input_count": len(input_ids), "catalog_input_complete": input_complete,
            "candidate_universe_complete": input_complete,
            "post_ER_reachable_mapped_count": len(ids),
            "post_ER_reachable_canonical_complete": ids == mapper.canonical,
            "post_ER_removed_dataset_nodes": len(extracted) - sum(a.get("type") == "dataset" for _, a in graph.nodes(data=True)),
            "alias_cluster_count": alias_clusters,
            "cross_canonical_merge_cluster_count": len(cross_canonical_clusters),
            "cross_canonical_merge_clusters": cross_canonical_clusters,
            "unmapped_extracted_entities": sum(m["canonical_dataset_id"] is None for m in mapped)}


def add_catalog(engine, core: Path, directory: Path, corpus_path: Path,
                mapper: DatasetMapper, configuration: dict) -> dict:
    """Use the official dataset-addition operation, never invent tasks from Gold.

    Canonical IDs serve as public titles for new entries; product names and
    descriptions remain in the description. The official operation embeds each
    description, copies nearest existing tasks, links tasks and resolves entities.
    Dataset resolution can collapse entries: completeness is audited afterward,
    and formal evaluation stays blocked if any canonical candidate is absent.
    """
    import networkx as nx
    from tinydb import TinyDB
    from task_oriented_dataset_search.graph.builder import GraphBuilder

    corpus = rows(corpus_path)
    path = directory / "catalog_checkpoint.json"
    checkpoint = json.loads(path.read_text()) if path.exists() else {
        "configuration_fingerprint": digest(configuration), "corpus_sha256": sha(corpus_path),
        "corpus_path": str(corpus_path.resolve()),
        "official_operation": "TodsEngine.add_dataset_from_description(copy_top_k=1)",
        "entries": {}, "status": "running"}
    if (checkpoint["configuration_fingerprint"] != digest(configuration)
            or checkpoint["corpus_sha256"] != sha(corpus_path)):
        raise RuntimeError("Catalog checkpoint configuration changed")
    transaction_path = directory / "catalog_transaction/transaction.json"
    if transaction_path.is_file():
        transaction = json.loads(transaction_path.read_text())
        if transaction["state"] == "pending":
            catalog_rollback(core, directory, transaction)
            checkpoint["entries"][transaction["dataset_id"]] = {
                "status": "failed", "error": "Interrupted official addition rolled back to a verified prefix",
                "attempts": checkpoint["entries"].get(transaction["dataset_id"], {}).get("attempts", 1)}
            write_json(path, checkpoint)
        elif transaction["state"] == "completed":
            checkpoint["entries"][transaction["dataset_id"]] = transaction["outcome"]
            write_json(path, checkpoint)
    # Determine coverage from actual surviving graph nodes, including exact URL
    # signals. Nodes removed by official resolution do not count as candidates.
    graph = nx.read_graphml(core / "processed_kg.graphml")
    with TinyDB(core / "tiny_db.json") as db:
        entities = db.table("datasets").all()
    covered = set()
    for row in entities:
        if row["id"] in graph and graph.degree(row["id"]) > 0:
            result = resolve_candidate_entity(row, mapper)
            if result["canonical_dataset_id"]:
                covered.add(result["canonical_dataset_id"])
    initial_coverage_path = directory / "catalog_initial_native_coverage.json"
    if initial_coverage_path.exists():
        initial = json.loads(initial_coverage_path.read_text())
        if (initial["corpus_sha256"] != sha(corpus_path)
                or initial["mapping_manifest_hash"] != mapper.manifest_hash
                or not set(initial["canonical_ids"]).issubset(mapper.canonical)):
            raise RuntimeError("Initial native candidate coverage belongs to a different corpus/mapping")
        covered = set(initial["canonical_ids"])
    else:
        write_json(initial_coverage_path, {"canonical_ids": sorted(covered), "corpus_sha256": sha(corpus_path),
            "mapping_manifest_hash": mapper.manifest_hash,
            "source": "Native graph before any official catalog additions; fixed across resumptions"})
    # Batch complete texts only. Additions retain their official sequential
    # prefix because nearest datasets/tasks depend on preceding additions.
    cache = engine._adapter_api_cache
    seed_embedding_vectors(core, cache)
    texts = []
    for card in corpus:
        identity = card["dataset_id"]
        if identity in covered or checkpoint["entries"].get(identity, {}).get("status") == "added":
            continue
        description, _ = catalog_metadata(card)
        # Both the official nearest-dataset query and dataset index use this
        # identical title+description text; do not preheat an unused variant.
        texts.append(f"{identity} {description}".strip())
    if texts:
        from task_oriented_dataset_search import pipeline
        embedder = pipeline.OpenAIAPITextEmbedder(api_key=engine.cfg.api_key, api_base=engine.cfg.api_base)
        for offset in range(0, len(texts), 10):
            embedder.embed(texts[offset:offset + 10])
            if offset % 100 == 0:
                print(json.dumps({"stage": "catalog_embedding_prewarm", "texts": min(offset + 10, len(texts)),
                                  "total_texts": len(texts)}), flush=True)
    write_json(directory / "embedding_prewarm.json", {"complete_catalog_texts": len(texts),
        "policy": "Exact full input text, endpoint, model, dimension; unchanged vectors; official sequential prefix preserved"})
    for index, card in enumerate(corpus, 1):
        identity = card["dataset_id"]
        if identity in covered:
            checkpoint["entries"].setdefault(identity, {"status": "already_in_native_graph"})
            continue
        previous = checkpoint["entries"].get(identity, {})
        if previous.get("status") == "added":
            # A completed but merged-away entry must not be repeatedly re-added.
            continue
        attempts = previous.get("attempts", 0)
        if attempts >= int(os.environ.get("KATS_CATALOG_MAX_ATTEMPTS", "2")):
            raise RuntimeError(f"Catalog candidate {identity} exhausted finite retries; inspect checkpoint error")
        description, link = catalog_metadata(card)
        transaction = catalog_snapshot(core, directory, identity)
        checkpoint["entries"][identity] = {"status": "adding", "attempts": attempts + 1}
        write_json(path, checkpoint)
        started = time.monotonic()
        try:
            dataset, neighbors = engine.add_dataset_from_description(
                description=description, title=identity, link=link, copy_top_k=1)
            checkpoint["entries"][identity] = {"status": "added", "official_dataset_id": dataset,
                "nearest_dataset_ids": neighbors, "attempts": attempts + 1,
                "elapsed_seconds": round(time.monotonic() - started, 3)}
            transaction.update(state="completed", outcome=checkpoint["entries"][identity])
            write_json(transaction_path, transaction)
        except Exception as exc:
            catalog_rollback(core, directory, transaction)
            checkpoint["entries"][identity] = {"status": "failed", "error": redact(exc, [engine.cfg.api_key]),
                "attempts": attempts + 1, "elapsed_seconds": round(time.monotonic() - started, 3)}
            write_json(path, checkpoint)
            raise
        write_json(path, checkpoint)
        print(json.dumps({"stage": "catalog", "processed": index, "candidates": len(corpus),
                          "dataset_id": identity, "status": "added"}), flush=True)
    # The official incremental-add operation does not regenerate the separated
    # task graph. Re-run the official builder rather than synthesizing edges.
    builder = GraphBuilder(db_path=engine.cfg.db_path, graph_path=engine.cfg.graph_processed_path,
                           save_path=engine.cfg.graph_tasks_path)
    builder.build_and_save_task_similarity_graph()
    engine.searcher_instance = None
    engine.qa_engine_instance = None
    checkpoint["coverage"] = candidate_coverage(core, mapper)
    checkpoint["status"] = "success" if checkpoint["coverage"]["catalog_input_complete"] else "incomplete"
    write_json(path, checkpoint)
    return checkpoint


def validate_dev_completion(summary: dict, queries: list[dict], configuration: dict,
                            directory: Path | None = None):
    expected = [q for q in queries if q["split"] == "dev"]
    if (summary.get("configuration_fingerprint") != digest(configuration)
            or summary.get("queries") != len(expected)
            or summary.get("successful_queries", -1) + summary.get("failed_queries", -1) != len(expected)
            or summary.get("tasks") != len({q["task_id"] for q in expected})):
        raise RuntimeError("Freeze blocked: every admitted DEV query must have a recorded success/failure under the current configuration")
    if directory is None:
        return
    with (directory / "kats_predictions.csv").open(newline="", encoding="utf-8") as stream:
        predictions = list(csv.DictReader(stream))
    expected_ids = {q["query_id"] for q in expected}
    if {row["query_id"] for row in predictions} != expected_ids:
        raise RuntimeError("Freeze blocked: DEV prediction CSV identity population mismatch")
    successful, failed = 0, 0
    for query in expected:
        raw = json.loads((directory / "queries" / f"{query['query_id']}.json").read_text())
        if (raw.get("configuration_fingerprint") != digest(configuration)
                or any(raw.get(key) != query.get(key) for key in (
                    "split", "query_id", "task_id", "query_variant", "query"))
                or raw.get("status") not in ("success", "failed")
                or not isinstance(raw.get("raw_answer"), str)
                or (raw["status"] == "failed" and not raw.get("error"))):
            raise RuntimeError("Freeze blocked: DEV raw outcome missing, inconsistent, or not attempted")
        ranked = [r for r in predictions if r["query_id"] == query["query_id"]]
        if any(r["split"] != "dev" or r["task_id"] != query["task_id"]
               or str(r["query_variant"]) != str(query["query_variant"])
               or r["status"] != raw["status"]
               or r["configuration_fingerprint"] != digest(configuration) for r in ranked):
            raise RuntimeError("Freeze blocked: DEV CSV and raw outcome identity/status mismatch")
        successful += raw["status"] == "success"
        failed += raw["status"] == "failed"
    if (successful, failed) != (summary["successful_queries"], summary["failed_queries"]):
        raise RuntimeError("Freeze blocked: DEV summary status counts disagree with raw outcomes")


def validate_frozen_artifacts(frozen: dict, directory: Path, configuration: dict):
    if (frozen["configuration_fingerprint"] != digest(configuration)
            or frozen["runtime_source_sha256"] != sha(Path(__file__))):
        raise RuntimeError("Frozen algorithm/runtime configuration changed")
    for name, expected_hash in frozen["build_artifact_sha256"].items():
        if sha(directory / "core" / name) != expected_hash:
            raise RuntimeError(f"Frozen build artifact changed: {name}")
    for relative, expected_hash in frozen["dev_artifact_sha256"].items():
        if sha(directory / relative) != expected_hash:
            raise RuntimeError(f"Frozen DEV artifact changed: {relative}")
    for absolute, expected_hash in frozen.get("immutable_artifact_sha256", {}).items():
        if sha(Path(absolute)) != expected_hash:
            raise RuntimeError(f"Frozen source/input/audit artifact changed: {absolute}")


def immutable_freeze_artifacts(root: Path, cache_root: Path, directory: Path, manifest: dict) -> dict:
    """Pin the current retrieval implementation and fresh inference inputs.

    The code release has no historical result exports or dispatch manifests.
    This records the source/input bytes used for a new local run only.
    """
    paths = [Path(__file__), Path(__file__).parent / "mapping.py",
             Path(__file__).parent / "source_policy.py", Path(__file__).parent / "corpus.py",
             root / "experiments/paper_e1/config.json",
             root / "experiments/paper_e1/runtime_queries.jsonl",
             root / "experiments/paper_e1/scripts/retrieval.py",
             directory / "configuration.json", directory / "build_audit.json",
             directory / "catalog_checkpoint.json", cache_root / "corpus_manifest.json",
             directory / "catalog_initial_native_coverage.json"]
    for name in ("native_execution.json", "dev/run_summary.json", "dev/kats_predictions.csv"):
        if (directory / name).is_file():
            paths.append(directory / name)
    if manifest.get("source_policy_path"):
        paths.append(Path(manifest["source_policy_path"]))
    paths.extend((directory / "dev/queries").glob("*.json"))
    paths.extend(p for p in (root / "third_party/KATS").rglob("*") if p.is_file())
    snapshot = Path(json.loads((root / "experiments/paper_e1/config.json").read_text())["knowledge_root"])
    paths.extend(snapshot / name for name in manifest.get("source_fingerprints", {}))
    return {str(path.resolve()): sha(path) for path in paths}


def run_queries(engine, queries: list[dict], directory: Path, mapper: DatasetMapper,
                configuration: dict, mode: str, retry_failed=False, engine_factory=None):
    """Independent read-only KATS engines; shared exact API cache; ordered CSV."""
    from queue import Queue
    raw_dir = directory / "queries"
    raw_dir.mkdir(parents=True, exist_ok=True)
    fingerprint = digest(configuration)
    if len({q["query_id"] for q in queries}) != len(queries):
        raise RuntimeError("Duplicate query IDs would collide in the raw-outcome ledger")
    previous_by_id = {}
    for query in queries:
        path = raw_dir / f"{query['query_id']}.json"
        previous = json.loads(path.read_text()) if path.exists() else None
        if previous and (previous.get("configuration_fingerprint") != fingerprint or
                any(previous.get(key) != query.get(key) for key in
                    ("split", "query_id", "task_id", "query_variant", "query"))):
            raise RuntimeError("Saved query has different configuration/identity; no model request issued")
        previous_by_id[query["query_id"]] = previous
    def needs_request(query):
        previous = previous_by_id[query["query_id"]]
        return not previous or (previous["status"] != "success" and retry_failed)
    pending = sum(needs_request(query) for query in queries)
    requested_workers = int(configuration.get("execution", {}).get("query_workers", 1 if mode == "KATS-Partial" else 6))
    worker_count = min(max(1, requested_workers), pending) if pending else 0
    states = Queue()
    progress_lock = threading.Lock()
    if engine_factory is None:
        def engine_factory():
            from task_oriented_dataset_search import pipeline
            worker = pipeline.TodsEngine(config=engine.cfg)
            worker._adapter_api_cache = engine._adapter_api_cache
            return worker
    def state_for(worker):
        searcher = worker._get_searcher()
        original_search, captured = searcher.search, {}
        def capture(task_description, **kwargs):
            result = original_search(task_description, **kwargs)
            captured["candidates"] = [dict(item) for item in result]
            if mode == "KATS-Partial":
                return result
            permitted, rejected = [], []
            for entity in result:
                resolved = resolve_candidate_entity(entity, mapper)
                if resolved["canonical_dataset_id"]:
                    permitted.append(entity)
                else:
                    rejected.append({"entity": dict(entity), "mapping": resolved})
            captured["canonical_candidates"] = [dict(item) for item in permitted]
            captured["rejected_candidates"] = rejected
            return permitted
        searcher.search = capture
        return worker, captured
    for number in range(worker_count):
        states.put(state_for(engine if number == 0 else engine_factory()))
    def process(item):
        index, query = item
        previous = previous_by_id[query["query_id"]]
        if not needs_request(query):
            outcome = previous
        else:
            worker, captured = states.get()
            api = getattr(worker, "_adapter_api_cache", None)
            started = time.monotonic()
            captured.clear()
            outcome = {**query, "mode": mode, "configuration_fingerprint": fingerprint,
                       "configuration": configuration, "status": "failed", "error": "",
                       "raw_answer": "", "output_status": "error", "ranking": [], "candidate_datasets": []}
            try:
                if api is not None:
                    api.context.purpose, api.context.query_id = f"{query['split']}_query", query["query_id"]
                outcome["raw_answer"] = worker.qa(query["query"], top_k_datasets=10)
                outcome["output_status"] = classify_qa_output(outcome["raw_answer"])
                names = parse_ranked_answer(outcome["raw_answer"], top_k=10)
                mapped = resolve_output_ranking(mapper, names)
                outcome["ranking"] = [{"rank": rank, "raw_dataset_name": name, **mapping}
                                      for rank, (name, mapping) in enumerate(zip(names, mapped), 1)]
                outcome["status"] = "success"
                outcome["output_status"] = "ranking"
            except Exception as exc:
                outcome["error"] = redact(exc, [worker.cfg.api_key])
            finally:
                if api is not None:
                    api.context.purpose = api.context.query_id = None
                outcome["candidate_datasets"] = captured.get("candidates", [])
                outcome["canonical_candidate_datasets"] = captured.get("canonical_candidates", [])
                outcome["rejected_candidate_datasets"] = captured.get("rejected_candidates", [])
                outcome["elapsed_seconds"] = round(time.monotonic() - started, 3)
                if previous:
                    outcome["previous_failure"] = {key: previous[key] for key in (
                        "status", "error", "elapsed_seconds", "raw_answer", "ranking", "output_status") if key in previous}
                write_json(raw_dir / f"{query['query_id']}.json", outcome)
                states.put((worker, captured))
        with progress_lock:
            print(json.dumps({"query": index, "queries": len(queries), "query_id": query["query_id"],
                              "status": outcome["status"], "output_ranks": len(outcome["ranking"])}), flush=True)
        return outcome
    with ThreadPoolExecutor(max_workers=max(1, worker_count)) as executor:
        outcomes = list(executor.map(process, enumerate(queries, 1)))
    predictions = []
    # executor.map preserves the frozen query order regardless of completion.
    for query, outcome in zip(queries, outcomes):
        base = {key: query[key] for key in ("split", "task_id", "query_id", "query_variant")}
        base.update(status=outcome["status"], available_depth=10 if outcome["status"] == "success" else 0,
                    mode=mode, error=outcome["error"], configuration_fingerprint=fingerprint, score="")
        if outcome["ranking"]:
            for item in outcome["ranking"]:
                mapped = item["canonical_dataset_id"] is not None
                predictions.append({**base, **{key: item[key] for key in (
                    "rank", "raw_dataset_name", "canonical_dataset_id", "match_type")},
                    "mapping_status": "mapped" if mapped else item["mapping_status"]})
        else:
            predictions.append({**base, "rank": 0, "raw_dataset_name": "", "canonical_dataset_id": "",
                                "match_type": "none", "mapping_status": "no_output"})
    with (directory / "kats_predictions.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(predictions)
    ranks = [item for outcome in outcomes for item in outcome["ranking"]]
    mapped = sum(item["canonical_dataset_id"] is not None for item in ranks)
    return {"queries": len(outcomes), "tasks": len({q["task_id"] for q in queries}),
            "successful_queries": sum(o["status"] == "success" for o in outcomes),
            "failed_queries": sum(o["status"] != "success" for o in outcomes),
            "output_ranks": len(ranks), "mapped_ranks": mapped,
            "mapping_coverage": mapped / len(ranks) if ranks else None,
            "requested_query_workers": requested_workers,
            "mode": mode, "configuration_fingerprint": fingerprint}


def reparse_saved_queries(queries: list[dict], directory: Path, mapper: DatasetMapper,
                         configuration: dict, mode: str) -> dict:
    """Pre-freeze I/O repair only: preserve every received model response verbatim."""
    if (directory.parent / "frozen.json").exists() or directory.name != "dev":
        raise RuntimeError("Saved responses may be reinterpreted only on DEV before freeze")
    old_summary = json.loads((directory / "run_summary.json").read_text())
    prepared, body_hashes, changed_ids, changed_statuses = [], {}, 0, 0
    for query in queries:
        path = directory / "queries" / f"{query['query_id']}.json"
        previous = json.loads(path.read_text())
        if any(previous.get(key) != query.get(key) for key in (
                "split", "query_id", "task_id", "query_variant", "query")):
            raise RuntimeError("Cannot reparse a different query identity")
        previous_config = dict(previous["configuration"])
        proposed_config = dict(configuration)
        previous_config.pop("output_mapping_policy", None)
        proposed_config.pop("output_mapping_policy", None)
        previous_config.pop("qa_output_parsing_policy", None)
        proposed_config.pop("qa_output_parsing_policy", None)
        if previous_config != proposed_config:
            raise RuntimeError("I/O reparse cannot change model, corpus, prompts or execution settings")
        outcome = dict(previous)
        answer = previous["raw_answer"]
        body_hashes[query["query_id"]] = hashlib.sha256(answer.encode()).hexdigest()
        old_ids = [item["canonical_dataset_id"] for item in previous["ranking"]]
        outcome["ranking"] = []
        outcome["output_status"] = classify_qa_output(answer)
        try:
            names = parse_ranked_answer(answer, top_k=10)
            mapped = resolve_output_ranking(mapper, names)
            outcome["ranking"] = [{"rank": rank, "raw_dataset_name": name, **mapping}
                for rank, (name, mapping) in enumerate(zip(names, mapped), 1)]
            outcome["status"], outcome["error"] = "success", ""
            outcome["output_status"] = "ranking"
        except Exception as exc:
            outcome["status"] = "failed"
            outcome["error"] = str(exc) if answer.strip() else previous["error"]
        changed_ids += old_ids != [item["canonical_dataset_id"] for item in outcome["ranking"]]
        changed_statuses += previous["status"] != outcome["status"]
        outcome["previous_normalization"] = {
            key: previous[key] for key in ("configuration_fingerprint", "status", "error", "ranking")}
        outcome["configuration"] = configuration
        outcome["configuration_fingerprint"] = digest(configuration)
        prepared.append((path, outcome))
    for path, outcome in prepared:
        write_json(path, outcome)
        if hashlib.sha256(json.loads(path.read_text())["raw_answer"].encode()).hexdigest() != body_hashes[outcome["query_id"]]:
            raise RuntimeError("Raw model response changed during I/O repair")
    # Every outcome exists; retry_failed=False guarantees zero engine/API calls.
    summary = run_queries(None, queries, directory, mapper, configuration, mode)
    for key in ("usage", "build"):
        if key in old_summary:
            summary[key] = old_summary[key]
    summary["io_reparse"] = {"raw_response_sha256_unchanged": True, "new_model_requests": 0,
                            "queries_with_changed_canonical_ids": changed_ids,
                            "queries_with_changed_status": changed_statuses}
    write_json(directory / "run_summary.json", summary)
    write_json(directory / "normalization_reparse.json", {
        "reason": "Pre-freeze public-ID identity and observed generic final-list/single-recommendation presentation I/O repairs; no new model request",
        "policy": OUTPUT_MAPPING_POLICY, "model_response_sha256": body_hashes,
        **summary["io_reparse"]})
    return summary


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stage", choices=("smoke", "build", "catalog", "dev", "freeze", "test"))
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--cache", type=Path)
    parser.add_argument("--allow-model-substitution", action="store_true")
    parser.add_argument("--retry-failed", action="store_true")
    parser.add_argument("--execute", action="store_true", help="Required before model/API execution")
    args = parser.parse_args(argv)
    if not args.execute:
        parser.error("--execute is required for KATS inference stages")
    root = args.root.resolve()
    cache_root = (args.cache or root / ".cache/kats").resolve()
    config, manifest, queries, mapper = load_inputs(root, cache_root)
    models = discover_models(root)
    smoke = args.stage == "smoke"
    if not smoke:
        if os.environ.get("PYTHONHASHSEED") != str(SEED):
            raise RuntimeError(f"Formal KATS requires PYTHONHASHSEED={SEED} before Python starts")
        ensure_formal_ready(manifest, models, args.allow_model_substitution)
        validate_input_directory(manifest)
    directory = cache_root / ("smoke" if smoke else "formal")
    core = directory / "core"
    if not smoke and args.stage in ("build", "catalog") and (directory / "frozen.json").exists():
        raise RuntimeError("Frozen TEST configuration forbids rebuilding or adding catalog entries")
    if smoke:
        sources = select_smoke(manifest, directory / "input")
        input_dir = directory / "input"
        selected_queries = smoke_queries(queries)
    else:
        sources, input_dir = manifest["sources"], Path(manifest["input_dir"])
        selected_queries = [q for q in queries if q["split"] == args.stage]
    configuration = {"official_commit": COMMIT, "models": models.public(),
                     "source_pdf_sha256": {r["source_id"]: r["pdf_sha256"] for r in sources},
                     "mapping_manifest_hash": mapper.manifest_hash,
                     "runtime_queries_sha256": config["runtime_queries_sha256"],
                     "mode": "KATS-Partial" if smoke else "KATS-Adapted",
                     "top_k": 10, "initial_faiss_k": 2, "pagerank_alpha": 0.85,
                     "similarity_threshold": 0.85, "min_seed_similarity": 0.6,
                     "qa_search_rate": 2, "seed": SEED,
                     "pythonhashseed": os.environ.get("PYTHONHASHSEED"),
                     "subset_smoke": smoke,
                     "offline_input": "Original safe PDFs only; no Cards/queries/Gold supplied for extraction"}
    if not smoke:
        configuration.update(
            output_mapping_policy=OUTPUT_MAPPING_POLICY,
            qa_output_parsing_policy=QA_PARSING_POLICY,
            source_policy_fingerprint=manifest.get("source_policy_fingerprint"),
            input_manifest_sha256=sha(cache_root / "corpus_manifest.json"),
            execution={"extract_workers": int(os.environ.get("KATS_EXTRACT_WORKERS", "6")),
                       "query_workers": int(os.environ.get("KATS_QUERY_WORKERS", "6")),
                       "preprocess_workers": 1, "retry_limit": 1, "llm_retries": 1,
                       "er_prefetch_workers": 6, "catalog_llm_retries": 3,
                       "catalog_llm_retry_delay": 10, "catalog_k_neighbors": 10,
                       "catalog_similarity_threshold": 0.7,
                       "catalog_max_attempts": int(os.environ.get("KATS_CATALOG_MAX_ATTEMPTS", "2")),
                       "embedding_cache_policy": "Exact complete normalized text/model/endpoint/dimension vectors; official sequential additions retained",
                       "er_retry_cache_policy": "Distinct official retry-attempt cache slots preserve retries after malformed judge responses; first-attempt exact cache unchanged",
                       "alias_cycle_guard": ALIAS_CYCLE_POLICY,
                       "catalog_resume_coverage_policy": "Initial native canonical coverage is fixed before additions and retained across restarts; never recomputed from the evolving post-ER prefix",
                       "native_er_execution": json.loads((directory / "native_execution.json").read_text())
                           if (directory / "native_execution.json").is_file() else {"implementation": "bounded-exact-prefetch", "workers": 6},
                       "prefetch_policy": "Static official prompts, original DSU and candidate sequence consumes exact cached responses; unused prefetch costs recorded"},
            allow_recorded_offline_failures=True,
            formal_candidate_policy="Registered catalog title equal to a canonical ID uses direct membership validation; native free names use E1 exact name/URL union. Original Searcher order retained; rejected raw entities recorded",
            catalog_adapter="Official dataset-addition with canonical public ID as title, metadata description, copy_top_k=1")
    configuration_path = directory / "configuration.json"
    if configuration_path.exists() and json.loads(configuration_path.read_text()) != configuration:
        raise RuntimeError("Existing core cache configuration changed; use a new isolated cache")
    write_json(configuration_path, configuration)
    api = APICache(directory / "api", models)
    engine = engine_for(core, input_dir, models, api)
    audit_path = directory / "build_audit.json"
    try:
        if smoke or args.stage == "build":
            if not audit_path.exists() or json.loads(audit_path.read_text()).get("status") != "success":
                print(json.dumps({"stage": "official_build", "input_pdfs": len(sources),
                                  "mode": configuration["mode"], "models": models.public()}), flush=True)
                engine.build()
            audit = {"status": "success", **validate_build(core, input_dir, allow_recorded_failures=not smoke),
                     **candidate_coverage(core, mapper), "usage": api.summary()}
            write_json(audit_path, audit)
        elif not audit_path.is_file() or json.loads(audit_path.read_text()).get("status") != "success":
            raise RuntimeError("Complete official build required before DEV/freeze/TEST")
        audit = json.loads(audit_path.read_text())
        if args.stage == "catalog":
            if (directory / "frozen.json").exists():
                raise RuntimeError("Cannot add catalog entries after freezing TEST configuration")
            add_catalog(engine, core, directory,
                        Path(config["knowledge_root"]) / "benchmark/corpus/dataset_corpus.jsonl",
                        mapper, configuration)
            audit = {"status": "success", **validate_build(core, input_dir, allow_recorded_failures=True),
                     **candidate_coverage(core, mapper), "usage": api.summary()}
            write_json(audit_path, audit)
        if not smoke and args.stage != "build" and not audit.get("candidate_universe_complete"):
            raise RuntimeError("Formal KATS blocked: all canonical candidate metadata must be processed through native resolution or the official dataset-addition path before evaluation; post-ER losses are reported separately")
        if args.stage == "freeze":
            dev = directory / "dev/run_summary.json"
            if not dev.is_file():
                raise RuntimeError("Full DEV run required before configuration freeze")
            validate_dev_completion(json.loads(dev.read_text()), queries, configuration, dev.parent)
            current = validate_build(core, input_dir, allow_recorded_failures=True)
            if current["artifact_sha256"] != audit["artifact_sha256"]:
                raise RuntimeError("Build artifacts changed after the saved build audit")
            write_json(directory / "frozen.json", {"configuration_fingerprint": digest(configuration),
                                                   "frozen_at_utc": datetime.now(timezone.utc).isoformat(),
                                                   "build_artifact_sha256": audit["artifact_sha256"],
                                                   "dev_artifact_sha256": {relative: sha(directory / relative)
                                                       for relative in ("dev/run_summary.json", "dev/kats_predictions.csv")},
                                                   "immutable_artifact_sha256": immutable_freeze_artifacts(root, cache_root, directory, manifest),
                                                   "runtime_source_sha256": sha(Path(__file__))})
        elif smoke or args.stage in ("dev", "test"):
            if args.stage == "test":
                frozen = json.loads((directory / "frozen.json").read_text())
                validate_frozen_artifacts(frozen, directory, configuration)
            target = directory if smoke else directory / args.stage
            summary = run_queries(engine, selected_queries, target, mapper, configuration,
                                  configuration["mode"], args.retry_failed)
            summary.update(usage=api.summary(), build=audit)
            write_json(target / "run_summary.json", summary)
            print(json.dumps(summary, ensure_ascii=False), flush=True)
    except Exception as exc:
        write_json(directory / "failure.json", {"stage": args.stage, "status": "failed",
                                                "error": redact(exc, [models.api_key]),
                                                "usage": api.summary(), "mode": configuration["mode"]})
        raise


if __name__ == "__main__":
    main()
