"""Gold-free canonical mapping using the frozen E1 Direct LLM exact rule.

No punctuation stripping, fuzzy match, version collapse, or answer-based aliases
are applied. Cards are audited but do not expand the corpus-only primary rule.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path
from typing import Any


_E1_SOURCE = Path(__file__).resolve().parents[1] / "paper_e1/scripts/run.py"


def _original_mapper():
    spec = importlib.util.spec_from_file_location("kats_e1_exact_mapper", _E1_SOURCE)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load frozen E1 mapping: {_E1_SOURCE}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.ExactMapper, module.exact_key


def _metadata(path: Path) -> list[dict[str, Any]]:
    # Refuse obvious label/split inputs before reading their contents.
    if any("gold" in part.casefold() or "annotation" in part.casefold()
           for part in path.parts):
        raise ValueError("DatasetMapper accepts catalog metadata only; Gold is forbidden")
    rows = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()
            if line.strip()]
    forbidden = {"task_id", "query_id", "gold_dataset_ids", "core_dataset_ids",
                 "acceptable_dataset_ids", "requirements", "valid_routes"}
    for row in rows:
        if not isinstance(row, dict) or not isinstance(row.get("dataset_id"), str):
            raise ValueError("Mapping input must contain DatasetCard/catalog records")
        if forbidden.intersection(row):
            raise ValueError("Label/query fields are forbidden in mapping input")
    return rows


class DatasetMapper:
    """Reuse E1 ExactMapper, preserving ambiguous and unmapped rank slots.

    ``resolve`` maps one raw name or the same product_id/name/url record accepted
    by E1. Use ``resolve_ranking`` to retain duplicate-canonical failures too.
    """

    def __init__(self, corpus_path: str | Path, cards_path: str | Path):
        corpus_path, cards_path = Path(corpus_path), Path(cards_path)
        corpus, cards = _metadata(corpus_path), _metadata(cards_path)
        mapper_cls, self.exact_key = _original_mapper()
        self._mapper = mapper_cls(corpus)
        self.canonical = self._mapper.canonical
        if len(corpus) != len(self.canonical):
            raise ValueError("Duplicate canonical dataset ID in corpus")
        if any(card["dataset_id"] not in self.canonical for card in cards):
            raise ValueError("DatasetCard ID outside the canonical candidate universe")
        alias_keys = {self.exact_key(alias) for card in corpus
                      for alias in (card.get("aliases") or [])
                      if isinstance(alias, str) and alias.strip()}
        self.aliases_count = len(alias_keys & self._mapper.index.keys())
        self.ambiguous_count = sum(len(ids) > 1 for ids in self._mapper.index.values())
        self.manifest = {
            "policy": "E1-ExactMapper-corpus-only-NFKC-strip-casefold-v1",
            "source_sha256": hashlib.sha256(_E1_SOURCE.read_bytes()).hexdigest(),
            "corpus_sha256": hashlib.sha256(corpus_path.read_bytes()).hexdigest(),
            "cards_sha256": hashlib.sha256(cards_path.read_bytes()).hexdigest(),
            "candidate_count": len(self.canonical),
            "aliases_count": self.aliases_count,
            "ambiguous_count": self.ambiguous_count,
            "cards_usage": "candidate-ID audit only; no extra primary aliases",
            "version_policy": "literal pre-existing names/aliases only; no version merging",
            "gold_access": False,
        }
        self.manifest_hash = hashlib.sha256(json.dumps(
            self.manifest, ensure_ascii=False, sort_keys=True,
            separators=(",", ":")).encode()).hexdigest()
        self.mapping_manifest_hash = self.manifest_hash

    @staticmethod
    def _record(raw: str | dict[str, Any]) -> dict[str, Any]:
        return dict(raw) if isinstance(raw, dict) else {"name": raw}

    def resolve_ranking(self, raw_names: list[str | dict[str, Any]]) -> list[dict[str, Any]]:
        records = [self._record(raw) for raw in raw_names]
        ranking, audit = self._mapper.map(records)
        return [{"canonical_dataset_id": dataset_id,
                 "match_type": "exact_unique" if dataset_id else "none",
                 "mapping_status": item["resolution"],
                 "candidate_ids": item["candidate_ids"],
                 "signals": item["signals"]}
                for dataset_id, item in zip(ranking, audit)]

    def resolve(self, raw: str | dict[str, Any]) -> dict[str, Any]:
        return self.resolve_ranking([raw])[0]
