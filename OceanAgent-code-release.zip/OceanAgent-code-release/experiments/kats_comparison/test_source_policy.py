"""Source-alias closure tests require neither a model call nor Gold access."""
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

spec = importlib.util.spec_from_file_location("kats_source_policy_tests_target", Path(__file__).with_name("source_policy.py"))
policy = importlib.util.module_from_spec(spec)
spec.loader.exec_module(policy)


class SourcePolicyTest(unittest.TestCase):
    def test_heldout_identical_sha_proof_is_required(self):
        with tempfile.TemporaryDirectory() as folder:
            a, b = Path(folder) / "train.pdf", Path(folder) / "test.pdf"
            a.write_bytes(b"same original PDF")
            b.write_bytes(a.read_bytes())
            aliases = [{"source_ids": ["train", "test"], "pdf_sha256": policy._sha(a),
                        "pdfs": {"train": {"path": str(a)}, "test": {"path": str(b)}}}]
            policy._verify_aliases(aliases, {"train"}, {"test"})
            b.write_bytes(b"different PDF")
            with self.assertRaisesRegex(ValueError, "SHA verification failed"):
                policy._verify_aliases(aliases, {"train"}, {"test"})
            with self.assertRaisesRegex(ValueError, "held-out source"):
                policy._verify_aliases(aliases, {"train", "test"}, {"elsewhere"})

    def test_source_and_group_alias_closure_removes_bundle_only_where_affected(self):
        psc = {"p_alias": {"paper_id": "train_alias", "source_group_id": "g_alias", "bundle_id": "u_alias"},
               "p_other_alias": {"paper_id": "other_alias", "source_group_id": "g_alias", "bundle_id": "u_other_alias"},
               "p_safe": {"paper_id": "safe", "source_group_id": "g_safe", "bundle_id": "u_safe"}}
        ubc = {"u_alias": {}, "u_other_alias": {}, "u_safe": {"data_usages": [{"dataset_id": "unchanged"}]}}
        original_psc, original_ubc = json.dumps(psc, sort_keys=True), json.dumps(ubc, sort_keys=True)
        closed = policy._closed_view(psc, ubc, {"heldout"}, {"heldout_group"},
                                     [{"source_ids": ["train_alias", "heldout"]}])
        self.assertEqual(set(closed["psc"]), {"p_safe"})
        self.assertEqual(set(closed["ubc"]), {"u_safe"})
        self.assertEqual(closed["ubc"]["u_safe"], ubc["u_safe"])
        self.assertEqual(closed["blocked_sources"], {"heldout", "train_alias", "other_alias"})
        self.assertEqual(json.dumps(psc, sort_keys=True), original_psc)
        self.assertEqual(json.dumps(ubc, sort_keys=True), original_ubc)

    def test_shared_bundle_with_removed_owner_cannot_survive(self):
        psc = {"a": {"paper_id": "alias", "bundle_id": "shared"},
               "b": {"paper_id": "safe", "bundle_id": "shared"}}
        clean = policy._closed_view(psc, {"shared": {}}, {"heldout"}, set(),
                                    [{"source_ids": ["alias", "heldout"]}])
        self.assertFalse(clean["psc"])
        self.assertFalse(clean["ubc"])

    def test_no_gold_query_or_historical_file_access_for_alias_proof(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            gold = root / "benchmark/gold/dataset_gold.jsonl"
            gold.parent.mkdir(parents=True)
            gold.write_bytes(b"untouched Gold sentinel")
            original = gold.read_bytes()
            a, b = root / "a.pdf", root / "b.pdf"
            a.write_bytes(b"same PDF")
            b.write_bytes(b"same PDF")
            alias = [{"source_ids": ["a", "b"], "pdf_sha256": policy._sha(a),
                      "pdfs": {"a": {"path": str(a)}, "b": {"path": str(b)}}}]
            real_open = Path.open
            accesses = []
            def guard(path, *args, **kwargs):
                accesses.append(str(path))
                if "/gold/" in str(path) or path.name in {"test.jsonl", "dev.jsonl", "e1_predictions.jsonl"}:
                    raise AssertionError("Gold/query/history accessed")
                return real_open(path, *args, **kwargs)
            with patch.object(Path, "open", guard):
                policy._verify_aliases(alias, {"a"}, {"b"})
            self.assertEqual(set(accesses), {str(a), str(b)})
            self.assertEqual(gold.read_bytes(), original)


if __name__ == "__main__":
    unittest.main()
