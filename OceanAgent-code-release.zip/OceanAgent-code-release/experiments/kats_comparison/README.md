# KATS retrieval adapters

The upstream KATS archive snapshot at revision `d66382ad677f16bb98800c3c869a1125021706ea` is bundled under `third_party/KATS/` with its MIT license and attribution. The revision was recorded from the source archive comment; it is not an independently verified Git checkout. `runtime.py` keeps the actual model/cache, graph/catalog and query I/O adapters; `mapping.py` reuses E1's strict exact canonical mapping. `corpus.py` and `source_policy.py` prevent held-out source and byte-identical PDF aliases entering the extraction corpus.

Install dependencies and the included source in an isolated environment:

```bash
python3.11 -m venv .venv-kats
.venv-kats/bin/python -m pip install -r experiments/kats_comparison/environment.lock.txt
.venv-kats/bin/python -m pip install --no-deps --no-build-isolation -e third_party/KATS
.venv-kats/bin/python -B -m unittest discover -s experiments/kats_comparison -p 'test_*.py' -v
```

The tests use temporary inputs and mocked API operations. The build/vector tests require the full dependencies above. `requirements-runtime.txt` records the active dependency ranges; `environment.lock.txt` records the source environment's pinned versions.

Fresh KATS ingestion needs legally obtained original PDFs and a local JSONL source manifest. They are external inputs. Set `KATS_PAPER_MANIFEST` to that manifest and `KATS_PAPER_ROOT` to the directory containing its `papers/` or `pdfs/` subdirectories. Each manifest row uses `paper_id` matching the retained source IDs, `source_root` (`papers` or `pdfs`) and a safe `relative_path`. Preparation fails explicitly on missing or overlapping sources; Cards and benchmark questions are not substituted for original papers.

From the repository root:

```bash
.venv-kats/bin/python experiments/kats_comparison/corpus.py
.venv-kats/bin/python experiments/kats_comparison/source_policy.py
.venv-kats/bin/python experiments/kats_comparison/corpus.py --cache .cache/kats/clean --source-policy .cache/kats/clean_source_policy.json
```

The alias-repair step requires actual byte-identical held-out PDF evidence. It is not applicable when no such collision exists; in that case use a fully validated original corpus rather than fabricating an alias sidecar.

Original-model variables are `OPENAI_API_KEY` and optional `OPENAI_BASE_URL`. An adapted setup uses `KATS_API_KEY`, `KATS_BASE_URL`, `KATS_CHAT_MODEL`, `KATS_QA_MODEL`, `KATS_EMBED_MODEL` and `KATS_EMBED_DIM`; disclose model substitutions in any new use. No credentials or original dispatch authorizations are supplied.

For a prepared complete clean corpus, set `PYTHONHASHSEED=20261110` before starting Python, then run the `build`, `catalog`, `dev`, `freeze`, `test` stages of `runtime.py` in order with `--cache .cache/kats/clean --execute`. Add `--allow-model-substitution` only when using adapted models. Use `--help` to inspect options. These inference stages can incur provider charges. Freeze records the current source and newly generated local input bytes; it makes no claim to certify an earlier run.

Score a newly generated DEV or TEST CSV with the original strict CSV parser and shared retrieval metric functions:

```bash
.venv-kats/bin/python experiments/kats_comparison/score.py --predictions .cache/kats/clean/formal/dev/kats_predictions.csv --output-dir runs/kats-dev-scores
```

A scoring CSV must include the entire admitted population for each supplied split. Canonical rank order, ambiguous/null slots, failed outputs and available depth are retained. Source PDFs, extracted graphs, embeddings, indexes, old rankings and result exports are not bundled.
