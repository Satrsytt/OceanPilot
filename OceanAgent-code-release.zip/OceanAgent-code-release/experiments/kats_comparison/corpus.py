"""Prepare original PDFs under the existing E1 source-visibility policy.

Only source identities from E1Retrieval are used. Card prose, task queries and
Gold annotations are never serialized into the KATS offline input directory.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sys
from typing import Any


def _digest(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _rows(path: Path) -> list[dict[str, Any]]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()
            if line.strip()]


def _visible_identity_policy(root: Path, snapshot: Path, agent_root: Path,
                             source_policy=None) -> dict:
    """Recompute the existing alias closure instead of trusting a stale audit."""
    path = (root / "experiments/paper_e1/scripts/retrieval.py" if source_policy is None
            else root / "experiments/kats_comparison/source_policy.py")
    spec = importlib.util.spec_from_file_location("kats_e1_source_policy", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot import existing E1 source policy: {path}")
    module = importlib.util.module_from_spec(spec)
    previous = sys.dont_write_bytecode
    try:
        sys.dont_write_bytecode = True
        spec.loader.exec_module(module)
        retrieval = (module.E1Retrieval(snapshot, agent_root) if source_policy is None
                     else module.CleanE1Retrieval(snapshot, agent_root, source_policy=source_policy))
    finally:
        sys.dont_write_bytecode = previous
    # Deliberately return identities and the audit only, never card content.
    return {
        "allowed_source_ids": sorted(retrieval.visible_source_ids),
        "allowed_source_group_ids": sorted(retrieval.visible_source_group_ids),
        "blocked_source_ids": sorted(retrieval.blocked_source_ids),
        "blocked_source_group_ids": sorted(retrieval.blocked_source_group_ids),
        "audit": retrieval.audit,
    }


def _pdf_path(record: dict, paper_roots: list[Path]) -> Path | None:
    collection = record.get("source_root", "")
    relative = Path(str(record.get("relative_path", "")).replace("\\", "/"))
    if collection not in {"papers", "pdfs"} or relative.is_absolute() or ".." in relative.parts:
        raise ValueError(f"Unsafe PDF manifest path for {record.get('paper_id')}")
    for paper_root in paper_roots:
        candidate = paper_root / collection / relative
        if candidate.is_file() and candidate.suffix.lower() == ".pdf":
            return candidate.resolve()
    return None


def _assert_disjoint_identities(policy: dict) -> None:
    for kind in ("source_ids", "source_group_ids"):
        overlap = set(policy[f"allowed_{kind}"]) & set(policy[f"blocked_{kind}"])
        if overlap:
            raise RuntimeError(f"Held-out {kind} in corpus policy: {sorted(overlap)}")


def prepare_corpus(root: Path, cache: Path, source_policy=None) -> dict:
    """Cache an auditable, deduplicated PDF input set; do not extract knowledge.

    ``source_coverage_complete`` and ``input_ready`` must both be true before
    any formal run. Missing, ambiguous or byte-identical held-out sources are
    reported explicitly rather than silently running a smaller corpus.
    """
    root, cache = Path(root).resolve(), Path(cache).resolve()
    config_path = root / "experiments/paper_e1/config.json"
    config = json.loads(config_path.read_text(encoding="utf-8"))
    clean_policy = None
    policy_path = None
    if source_policy is not None:
        if isinstance(source_policy, dict):
            clean_policy = source_policy
        else:
            policy_path = Path(source_policy).expanduser().resolve()
            clean_policy = json.loads(policy_path.read_text(encoding="utf-8"))
        if clean_policy.get("original_config_sha256") != _digest(config_path):
            raise ValueError("Clean source policy belongs to another original E1 configuration")
    snapshot = Path(config["knowledge_root"]).expanduser().resolve()
    agent_root = Path(config["agent_root"]).expanduser().resolve()
    legacy_root = Path(config["legacy_root"]).expanduser().resolve()
    # These are the only snapshot inputs read by the source policy. Do not
    # inspect query or Gold contents while preparing offline knowledge.
    policy_inputs = (
        "benchmark/splits/split_manifest.json", "benchmark/corpus/dataset_corpus.jsonl",
        "cards/problem_solution_cards.jsonl", "cards/usage_bundle_cards.jsonl",
        "cards/dataset_cards.jsonl",
    )
    fingerprints = {name: _digest(snapshot / name) for name in policy_inputs}
    for name, observed in fingerprints.items():
        expected = config.get("source_sha256", {}).get(name)
        if expected and expected != observed:
            raise RuntimeError(f"Frozen E1 source fingerprint changed: {name}")
    policy = (_visible_identity_policy(root, snapshot, agent_root) if clean_policy is None
              else _visible_identity_policy(root, snapshot, agent_root, source_policy=clean_policy))
    _assert_disjoint_identities(policy)
    allowed = set(policy["allowed_source_ids"])
    blocked = set(policy["blocked_source_ids"])
    manifest_path = Path(os.environ.get("KATS_PAPER_MANIFEST", str(legacy_root / "manifest/papers.jsonl"))).expanduser()
    manifest = _rows(manifest_path)
    by_source: dict[str, list[dict]] = {}
    for row in manifest:
        by_source.setdefault(row["paper_id"], []).append(row)
    paper_roots = list(dict.fromkeys(([Path(os.environ["KATS_PAPER_ROOT"]).expanduser()] if os.environ.get("KATS_PAPER_ROOT") else []) + [
        agent_root.parent / "paper", legacy_root.parent / "OceanAgent-main2.0/paper",
    ]))
    # Block duplicate PDF bytes too, even if their alternate paper ID is not
    # represented in the Card alias closure.
    blocked_hashes: dict[str, list[str]] = {}
    blocked_pdf_missing = []
    for source_id in sorted(blocked):
        records = by_source.get(source_id, [])
        found = False
        for record in records:
            pdf = _pdf_path(record, paper_roots)
            if pdf:
                blocked_hashes.setdefault(_digest(pdf), []).append(source_id)
                found = True
        if not found:
            blocked_pdf_missing.append(source_id)
    sources, missing = [], []
    primary_by_hash: dict[str, str] = {}
    for source_id in sorted(allowed):
        if not re.fullmatch(r"[A-Za-z0-9_.-]+", source_id):
            raise ValueError(f"Unsafe source identity: {source_id!r}")
        records = by_source.get(source_id, [])
        if len(records) != 1:
            missing.append({"source_id": source_id,
                            "reason": "missing_manifest_entry" if not records else "ambiguous_manifest_entry"})
            continue
        pdf = _pdf_path(records[0], paper_roots)
        if pdf is None:
            missing.append({"source_id": source_id, "reason": "pdf_not_found",
                            "relative_path": records[0].get("relative_path")})
            continue
        digest = _digest(pdf)
        if digest in blocked_hashes:
            missing.append({"source_id": source_id, "reason": "same_pdf_as_held_out_source",
                            "blocked_source_ids": blocked_hashes[digest], "pdf_sha256": digest})
            continue
        primary = primary_by_hash.setdefault(digest, source_id)
        sources.append({"source_id": source_id, "pdf_path": str(pdf),
                        "pdf_sha256": digest, "size_bytes": pdf.stat().st_size,
                        "input_pdf": str(cache / "corpus_input" / f"{primary}.pdf"),
                        "duplicate_of": None if primary == source_id else primary})
    input_dir = cache / "corpus_input"
    input_dir.mkdir(parents=True, exist_ok=True)
    unique_sources = [row for row in sources if row["duplicate_of"] is None]
    expected_names = {Path(row["input_pdf"]).name for row in unique_sources}
    unexpected = sorted(path.name for path in input_dir.iterdir() if path.name not in expected_names)
    for row in unique_sources:
        target, original = Path(row["input_pdf"]), Path(row["pdf_path"])
        if target.is_symlink():
            if target.resolve() != original:
                raise RuntimeError(f"Existing corpus symlink has a different target: {target}")
        elif target.exists():
            if not target.is_file() or _digest(target) != row["pdf_sha256"]:
                raise RuntimeError(f"Existing corpus file differs; refusing to overwrite: {target}")
        else:
            target.symlink_to(original)
    result = {
        "schema_version": "kats-original-pdf-corpus-v1",
        "policy": policy["audit"]["policy"], "policy_audit": policy["audit"],
        "input_dir": str(input_dir), "corpus_input": str(input_dir),
        "manifest_path": str(manifest_path), "manifest_sha256": _digest(manifest_path),
        "config_sha256": _digest(config_path), "snapshot": str(snapshot),
        "source_fingerprints": fingerprints,
        "allowed_source_ids": sorted(allowed), "blocked_source_ids": sorted(blocked),
        "expected_source_count": len(allowed), "available_source_count": len(sources),
        "unique_pdf_count": len(unique_sources), "blocked_source_count": len(blocked),
        "blocked_pdf_missing": blocked_pdf_missing,
        "source_coverage_complete": not missing and len(sources) == len(allowed),
        "input_ready": not missing and not unexpected and not blocked_pdf_missing,
        "missing_sources": missing, "unexpected_cached_entries": unexpected,
        "sources": sources,
        "offline_input_policy": "Original PDFs only; no Card prose, task queries or Gold supplied to KATS",
    }
    if clean_policy is not None:
        result.update(policy_id=clean_policy["policy_id"],
                      override_sha256=clean_policy["override_sha256"],
                      source_policy_fingerprint=clean_policy["policy_fingerprint"],
                      source_policy_path=str(policy_path) if policy_path else None,
                      source_policy_sha256=_digest(policy_path) if policy_path else None,
                      historical_reuse=clean_policy["historical_reuse"])
    destination = cache / "corpus_manifest.json"
    payload = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    if not destination.exists() or destination.read_text(encoding="utf-8") != payload:
        temporary = destination.with_suffix(".json.tmp")
        temporary.write_text(payload, encoding="utf-8")
        temporary.replace(destination)
    return result


if __name__ == "__main__":
    root = Path(__file__).resolve().parents[2]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache", type=Path, default=root / ".cache/kats")
    parser.add_argument("--source-policy", type=Path, help="Independent verified alias-policy sidecar")
    arguments = parser.parse_args()
    result = prepare_corpus(root, arguments.cache, source_policy=arguments.source_policy)
    print(json.dumps({key: result[key] for key in (
        "input_dir", "expected_source_count", "available_source_count", "unique_pdf_count",
        "source_coverage_complete", "input_ready", "missing_sources")}, ensure_ascii=False, indent=2))
