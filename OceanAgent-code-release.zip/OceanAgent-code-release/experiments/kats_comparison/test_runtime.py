"""Contract tests for offline-safe runtime routing and strict output parsing."""
import json
from pathlib import Path
from types import SimpleNamespace
import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
import threading
import time
import csv
import io
from contextlib import redirect_stdout
from unittest.mock import patch

from runtime import (APICache, Models, ensure_formal_ready, parse_ranked_answer,
                     QAAbstention, classify_qa_output, digest, redact, sha,
                     catalog_rollback, catalog_snapshot, smoke_queries,
                     validate_build, validate_dev_completion, vector_key,
                     DatasetMapper, resolve_candidate_entity, resolve_output_ranking,
                     cycle_safe_normalize, run_queries, reparse_saved_queries,
                     OUTPUT_MAPPING_POLICY, write_json)


class RuntimeTests(unittest.TestCase):
    def test_parse_official_highlighted_numbered_titles(self):
        answer = "Relevant products:\n1. **Dataset A** — details\n   Why relevant.\n2. **Dataset**: Dataset B\n"
        self.assertEqual(parse_ranked_answer(answer), ["Dataset A", "Dataset B"])
        self.assertEqual(parse_ranked_answer("### 1. **Product v2**\n"), ["Product v2"])

    def test_parse_failure_is_not_a_synthetic_ranking(self):
        for text in ("Sorry, I cannot find any related dataset", "2. **A**", "1. **A**\n3. **B**"):
            with self.assertRaises(ValueError):
                parse_ranked_answer(text)

    def test_final_numbered_block_replaces_explanatory_list_and_decodes_code(self):
        text = "1. **A**\n2. **B**\nFinal ranked answer:\n1. `canonical_b`\n2. `canonical_a`"
        self.assertEqual(parse_ranked_answer(text), ["canonical_b", "canonical_a"])

    def test_final_short_list_is_not_padded_with_an_empty_slot_explanation(self):
        text = "1. **A**\n2. **B**\nFinal selection:\n1. **B**\n2. *(No further datasets remain in context)*"
        self.assertEqual(parse_ranked_answer(text), ["B"])

    def test_explicit_single_recommendation_accepts_exactly_one_highlighted_name(self):
        self.assertEqual(parse_ranked_answer("Thus, the top and only relevant dataset is:\n**Data A**\nLink: example"), ["Data A"])
        self.assertEqual(parse_ranked_answer("Therefore, the only valid answer is:\n\n- **Data B**: description"), ["Data B"])
        with self.assertRaises(ValueError):
            parse_ranked_answer("The only valid answer is:\n- **Data A**\n- **Data B**")

    def test_qa_abstention_is_preserved_without_fabricated_ranking(self):
        answer = "None of the provided datasets are relevant to the user's task."
        self.assertEqual(classify_qa_output(answer), "abstained")
        with self.assertRaises(QAAbstention):
            parse_ranked_answer(answer)
        explanation = answer + "\n1. **Weather Data** only describes the unrelated context."
        with self.assertRaises(QAAbstention):
            parse_ranked_answer(explanation)

    def test_formal_is_blocked_by_source_or_model_mismatch(self):
        model = Models("private-key")
        with self.assertRaisesRegex(RuntimeError, "corpus"):
            ensure_formal_ready({"input_ready": False, "source_coverage_complete": True}, model)
        safe = {"input_ready": True, "source_coverage_complete": True}
        adapted = Models("private-key", chat_model="another-model")
        with self.assertRaisesRegex(RuntimeError, "original models"):
            ensure_formal_ready(safe, adapted)
        ensure_formal_ready(safe, adapted, allow_model_substitution=True)
        self.assertNotIn("private-key", json.dumps(model.public()))

    def test_cache_exact_requests_and_only_counts_network_tokens(self):
        class Response:
            def model_dump(self, **kwargs):
                return {"usage": {"prompt_tokens": 4, "total_tokens": 4}, "data": []}
        with tempfile.TemporaryDirectory() as tmp:
            cache = APICache(Path(tmp), Models("not-serialized"))
            request = {"model": "example", "input": ["public fixture"]}
            first = cache.call("embedding", request, Response)
            second = cache.call("embedding", request, lambda: self.fail("cache miss"))
            self.assertEqual(first, second)
            self.assertEqual(cache.summary()["tokens"]["total_tokens"], 4)
            self.assertEqual(cache.summary()["network_successes"], 1)
            self.assertEqual(cache.summary()["cache_hits"], 1)
            for path in Path(tmp).iterdir():
                self.assertNotIn("not-serialized", path.read_text())

    def test_smoke_keeps_both_existing_variants_and_never_selects_test(self):
        queries = [{"split": split, "task_id": task, "query_variant": variant}
                   for split, task in (("dev", "a"), ("test", "secret"), ("dev", "b"))
                   for variant in (1, 2)]
        self.assertEqual(smoke_queries(queries, count=1), queries[:2])

    def test_error_redacts_actual_key(self):
        self.assertNotIn("private", redact("error with private", ["private"]))

    def test_concurrent_identical_requests_are_charged_once(self):
        calls = []
        lock = threading.Lock()
        class Response:
            def model_dump(self, **kwargs):
                return {"usage": {"total_tokens": 4}}
        def invoke():
            with lock:
                calls.append(1)
            time.sleep(0.02)
            return Response()
        with tempfile.TemporaryDirectory() as tmp:
            cache = APICache(Path(tmp), Models("fixture"))
            with ThreadPoolExecutor(max_workers=6) as executor:
                list(executor.map(lambda _: cache.call("chat", {"model": "fixture"}, invoke), range(6)))
            self.assertEqual(len(calls), 1)
            self.assertEqual(cache.summary()["tokens"]["total_tokens"], 4)

    def test_malformed_judge_first_attempt_does_not_pin_later_retries(self):
        class Response:
            def __init__(self, value):
                self.value = value
            def model_dump(self, **kwargs):
                return {"choices": [{"message": {"content": self.value}}], "usage": {"total_tokens": 1}}
        with tempfile.TemporaryDirectory() as tmp:
            cache = APICache(Path(tmp), Models("fixture"))
            request = {"model": "fixture", "messages": [{"role": "user", "content": "fixture judge"}]}
            first = cache.call("chat", request, lambda: Response("malformed"), retry_attempt=0)
            retry = cache.call("chat", request, lambda: Response('{"is_same": true}'), retry_attempt=1)
            replay = cache.call("chat", request, lambda: self.fail("retry cache miss"), retry_attempt=1)
            self.assertNotEqual(first, retry)
            self.assertEqual(retry, replay)
            self.assertEqual(cache.summary()["network_successes"], 2)

    def test_catalog_rollback_restores_prefix_and_removes_partial_aliases(self):
        with tempfile.TemporaryDirectory() as tmp:
            directory = Path(tmp)
            core = directory / "core"
            core.mkdir()
            (core / "tiny_db.json").write_text("verified prefix")
            transaction = catalog_snapshot(core, directory, "fixture-id")
            (core / "tiny_db.json").write_text("partially mutated")
            (core / "aliases").mkdir()
            (core / "aliases/new.json").write_text("partial alias")
            catalog_rollback(core, directory, transaction)
            self.assertEqual((core / "tiny_db.json").read_text(), "verified prefix")
            self.assertFalse((core / "aliases/new.json").exists())

    def test_vector_cache_requires_complete_identical_input_and_model(self):
        original = Models("fixture")
        self.assertEqual(vector_key(original, "whole\ntext"), vector_key(original, "whole text"))
        self.assertNotEqual(vector_key(original, "whole text"), vector_key(original, "whole"))
        self.assertNotEqual(vector_key(original, "whole text"), vector_key(Models("fixture", embed_dim=2), "whole text"))

    def test_registered_canonical_identity_is_not_vetoed_by_shared_url(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "dataset_corpus.jsonl"
            data = [{"dataset_id": f"x-v{v}", "product_name": f"Product X v{v}",
                     "access": [{"url": "https://example.invalid/shared"}]} for v in (1, 2)]
            path.write_text("\n".join(map(json.dumps, data)))
            mapper = DatasetMapper(path, path)
            catalog = {"document_id": None, "title": "x-v1", "link": "https://example.invalid/shared"}
            self.assertEqual(resolve_candidate_entity(catalog, mapper)["canonical_dataset_id"], "x-v1")
            native = {"document_id": "fixture-paper", "title": "Product X v1", "link": catalog["link"]}
            self.assertEqual(resolve_candidate_entity(native, mapper)["mapping_status"], "ambiguous")

    def test_output_id_membership_wins_alias_collision_but_duplicates_stay_null(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "dataset_corpus.jsonl"
            path.write_text('\n'.join(map(json.dumps, [
                {"dataset_id": "x-v1", "product_name": "Version One"},
                {"dataset_id": "x-v2", "product_name": "Version Two", "aliases": ["x-v1"]}])))
            mapper = DatasetMapper(path, path)
            self.assertEqual(mapper.resolve("x-v1")["mapping_status"], "ambiguous")
            result = resolve_output_ranking(mapper, ["x-v1", "Version Two", "Version One", "unknown"])
            self.assertEqual([r["canonical_dataset_id"] for r in result], ["x-v1", "x-v2", None, None])
            self.assertEqual(result[2]["mapping_status"], "duplicate_canonical_id")

    def test_pre_freeze_reparse_preserves_model_body_without_any_engine(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            directory = root / "dev"
            corpus = root / "dataset_corpus.jsonl"
            corpus.write_text('\n'.join(map(json.dumps, [
                {"dataset_id": "x-v1", "product_name": "Version One"},
                {"dataset_id": "x-v2", "product_name": "Version Two", "aliases": ["x-v1"]}])))
            mapper = DatasetMapper(corpus, corpus)
            query = {"split": "dev", "task_id": "fixture", "query_id": "q", "query_variant": 1, "query": "Fixture"}
            old_config = {"execution": {"query_workers": 1}}
            body = "1. **x-v1**"
            old_ranking = [{"rank": 1, "raw_dataset_name": "x-v1", **mapper.resolve("x-v1")}]
            write_json(directory / "queries/q.json", {**query, "mode": "KATS-Adapted", "status": "success",
                "error": "", "raw_answer": body, "ranking": old_ranking, "configuration": old_config,
                "configuration_fingerprint": digest(old_config)})
            write_json(directory / "run_summary.json", {"queries": 1, "usage": {"fixture": True}})
            new_config = {**old_config, "output_mapping_policy": OUTPUT_MAPPING_POLICY}
            with redirect_stdout(io.StringIO()):
                summary = reparse_saved_queries([query], directory, mapper, new_config, "KATS-Adapted")
            outcome = json.loads((directory / "queries/q.json").read_text())
            self.assertEqual(outcome["raw_answer"], body)
            self.assertEqual(outcome["ranking"][0]["canonical_dataset_id"], "x-v1")
            self.assertIsNone(outcome["previous_normalization"]["ranking"][0]["canonical_dataset_id"])
            self.assertEqual(summary["io_reparse"]["new_model_requests"], 0)
            write_json(root / "frozen.json", {})
            with self.assertRaisesRegex(RuntimeError, "before freeze"):
                reparse_saved_queries([query], directory, mapper, new_config, "KATS-Adapted")

    def test_alias_cycle_guard_terminates_using_declared_live_representative(self):
        import networkx as nx
        graph = nx.Graph()
        graph.add_node("u2", type="dataset")
        aliases = {"argo": "u1", "u1": "u2", "u2": "u1"}
        events = []
        self.assertEqual(cycle_safe_normalize("Argo Data", aliases, graph, events.append), "u2")
        self.assertEqual(aliases["u2"], "u2")
        self.assertEqual(len(events), 1)
        self.assertEqual(events[0]["resolution_source"], "live_graph_node")
        self.assertEqual(cycle_safe_normalize("Argo Data", aliases, graph, events.append), "u2")
        self.assertEqual(len(events), 1)

    def test_query_workers_keep_capture_independent_ordered_and_resume_without_calls(self):
        lock = threading.Lock()
        counters = {"calls": 0, "active": 0, "peak": 0}
        class Searcher:
            def search(self, text, **kwargs):
                return [{"id": text, "document_id": "fixture-paper", "title": text.replace("Task", "Product")}]
        class Engine:
            def __init__(self):
                self.cfg, self.searcher = SimpleNamespace(api_key="fixture"), Searcher()
            def _get_searcher(self):
                return self.searcher
            def qa(self, text, **kwargs):
                with lock:
                    counters["calls"] += 1
                    counters["active"] += 1
                    counters["peak"] = max(counters["peak"], counters["active"])
                result = self.searcher.search(text, top_k_datasets=20)
                time.sleep(0.02)
                with lock:
                    counters["active"] -= 1
                return f"1. **{result[0]['title']}**"
        with tempfile.TemporaryDirectory() as tmp:
            directory = Path(tmp)
            corpus = directory / "dataset_corpus.jsonl"
            corpus.write_text("\n".join(json.dumps({"dataset_id": f"id{i}", "product_name": f"Product {i}"}) for i in range(8)))
            mapper = DatasetMapper(corpus, corpus)
            queries = [{"split": "dev", "task_id": f"fixture{i}", "query_id": f"q{i}",
                        "query_variant": 1, "query": f"Task {i}"} for i in range(8)]
            config = {"execution": {"query_workers": 3}}
            engine = Engine()
            with redirect_stdout(io.StringIO()):
                summary = run_queries(engine, queries, directory, mapper, config, "KATS-Adapted", engine_factory=Engine)
                run_queries(engine, queries, directory, mapper, config, "KATS-Adapted", engine_factory=Engine)
            self.assertEqual(counters["calls"], 8)
            self.assertGreater(counters["peak"], 1)
            self.assertEqual(summary["successful_queries"], 8)
            with (directory / "kats_predictions.csv").open() as handle:
                predictions = list(csv.DictReader(handle))
            self.assertEqual([row["query_id"] for row in predictions], [f"q{i}" for i in range(8)])
            for i in range(8):
                raw = json.loads((directory / "queries" / f"q{i}.json").read_text())
                self.assertEqual(raw["candidate_datasets"][0]["title"], f"Product {i}")
                self.assertEqual(raw["ranking"][0]["canonical_dataset_id"], f"id{i}")

    def test_freeze_rejects_partial_dev_or_configuration_change(self):
        config = {"model": "fixture"}
        queries = [{"split": "dev", "task_id": "a", "query_variant": v} for v in (1, 2)]
        complete = {"configuration_fingerprint": digest(config), "queries": 2,
                    "successful_queries": 2, "failed_queries": 0, "tasks": 1}
        validate_dev_completion(complete, queries, config)
        # A fully attempted population may contain genuine failed/abstained
        # outputs; their denominators must remain visible in later evaluation.
        validate_dev_completion({**complete, "successful_queries": 1, "failed_queries": 1}, queries, config)
        for partial in ({**complete, "failed_queries": 1}, {**complete, "queries": 1},
                        {**complete, "configuration_fingerprint": "changed"}):
            with self.assertRaisesRegex(RuntimeError, "Freeze blocked"):
                validate_dev_completion(partial, queries, config)


class BuildValidationTests(unittest.TestCase):
    """TinyDB/Parquet/FAISS fixtures, not experimental predictions or mock metrics."""
    def setUp(self):
        import numpy as np
        import pandas as pd
        from task_oriented_dataset_search.importer.db_importer import TinyDBImporter
        from task_oriented_dataset_search.embedding.indexer import FaissIndexer
        from tinydb import TinyDB
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.core, self.inputs = self.root / "core", self.root / "input"
        self.inputs.mkdir()
        (self.core / "extraction").mkdir(parents=True)
        self.pdf = self.inputs / "fixture.pdf"
        self.pdf.write_bytes(b"unit fixture document; not a scientific experiment")
        self.extract = self.core / "extraction" / (sha(self.pdf) + ".json")
        self.value = {"datasets_used": True, "datasets": [{"title": "Fixture Dataset",
            "description": "Fixture description", "link": "https://example.invalid/data",
            "task_description": "Fixture task", "task": ["fixture"]}]}
        self.extract.write_text(json.dumps(self.value))
        importer = TinyDBImporter(self.core / "tiny_db.json")
        importer.import_file(self.extract)
        importer.db.close()
        with TinyDB(self.core / "tiny_db.json") as db:
            for kind in ("tasks", "datasets"):
                data = db.table(kind).all()
                identity = data[0]["id"]
                index = FaissIndexer(2, str(self.core / f"faiss_{kind}.index"))
                int_id = index.hex_to_int64(identity)
                vector = np.asarray([[1.0, 0.0]], dtype="float32")
                index.add(np.asarray([int_id], dtype="int64"), vector)
                index.save()
                text = data[0]["task_description"] if kind == "tasks" else "Fixture Dataset Fixture description"
                pd.DataFrame([{"hex_id": identity, "int64_id": int_id, "embedding": vector[0],
                               "text": text}]).to_parquet(self.core / f"{kind}.parquet", index=False)
        for name in ("original_kg.graphml", "processed_kg.graphml", "tasks_kg.graphml"):
            (self.core / name).write_text("unit fixture graph artifact")
        (self.root / "configuration.json").write_text(json.dumps({"models": {"embed_dim": 2}}))

    def tearDown(self):
        self.tmp.cleanup()

    def test_complete_uuid_and_vector_artifacts_pass(self):
        result = validate_build(self.core, self.inputs)
        self.assertEqual(result["datasets"], 1)
        self.assertEqual(result["index_validation"]["tasks"],
                         {"faiss_ntotal": 1, "parquet_rows": 1, "dimension": 2})

    def test_unexpected_extraction_and_non_boolean_flag_fail(self):
        extra = self.core / "extraction" / ("f" * 64 + ".json")
        extra.write_text(json.dumps({"datasets_used": False, "datasets": []}))
        with self.assertRaisesRegex(RuntimeError, "Unexpected extraction"):
            validate_build(self.core, self.inputs)
        extra.unlink()
        for value in ("false", 0, False):
            # False accompanied by nonempty datasets is invalid too.
            self.extract.write_text(json.dumps({**self.value, "datasets_used": value}))
            with self.assertRaisesRegex(RuntimeError, "Invalid official extraction"):
                validate_build(self.core, self.inputs)

    def test_tinydb_mutation_and_index_dimension_fail(self):
        from tinydb import TinyDB
        with TinyDB(self.core / "tiny_db.json") as db:
            db.table("tasks").update({"task_description": "changed"})
        with self.assertRaisesRegex(RuntimeError, "TinyDB tasks differs"):
            validate_build(self.core, self.inputs)
        with TinyDB(self.core / "tiny_db.json") as db:
            db.table("tasks").update({"task_description": "Fixture task"})
        (self.root / "configuration.json").write_text(json.dumps({"models": {"embed_dim": 3}}))
        with self.assertRaisesRegex(RuntimeError, "dimension differs"):
            validate_build(self.core, self.inputs)
        import faiss
        (self.root / "configuration.json").write_text(json.dumps({"models": {"embed_dim": 2}}))
        index_path = self.core / "faiss_tasks.index"
        index = faiss.read_index(str(index_path))
        index.reset()
        faiss.write_index(index, str(index_path))
        with self.assertRaisesRegex(RuntimeError, "row count"):
            validate_build(self.core, self.inputs)

    def test_prefetch_preserves_official_dsu_and_exposes_unused_judge(self):
        import faiss
        import networkx as nx
        import numpy as np
        import pandas as pd
        from openai.types.chat import ChatCompletion
        from task_oriented_dataset_search.graph.builder import GraphBuilder
        from task_oriented_dataset_search.graph.dataset_merger import DatasetMerger
        from task_oriented_dataset_search.importer.db_importer import TinyDBImporter
        from task_oriented_dataset_search.utils.cache import CacheManager
        from tinydb import TinyDB
        from runtime import engine_for
        for label in ("B", "C"):
            paper = self.inputs / f"{label}.pdf"
            paper.write_bytes(f"fixture document {label}".encode())
            extraction = self.core / "extraction" / (sha(paper) + ".json")
            value = json.loads(json.dumps(self.value))
            value["datasets"][0]["title"] = f"Fixture {label}"
            extraction.write_text(json.dumps(value))
            importer = TinyDBImporter(self.core / "tiny_db.json")
            importer.import_file(extraction)
            importer.db.close()
        with TinyDB(self.core / "tiny_db.json") as db:
            entities = db.table("datasets").all()
        ids = np.array([int(e["id"], 16) & ((1 << 63) - 1) for e in entities], dtype="int64")
        vectors = np.array([[1, 0]] * 3, dtype="float32")
        index = faiss.IndexIDMap(faiss.IndexFlatIP(2))
        index.add_with_ids(vectors, ids)
        faiss.write_index(index, str(self.core / "faiss_datasets.index"))
        pd.DataFrame({"hex_id": [e["id"] for e in entities], "int64_id": ids,
                      "embedding": list(vectors)}).to_parquet(self.core / "datasets.parquet", index=False)
        original_graph = self.root / "basic.graphml"
        builder = GraphBuilder(str(self.core / "tiny_db.json"), str(original_graph))
        builder.build_basic_graph()
        builder.save_graph()
        model = Models("fixture", embed_dim=2)
        cache = APICache(self.root / "api", model)
        def reply(**kwargs):
            return ChatCompletion.model_validate({"id": "fixture", "object": "chat.completion", "created": 0,
                "model": "fixture", "choices": [{"index": 0, "finish_reason": "stop",
                    "message": {"role": "assistant", "content": '{"is_same": true}'}}],
                "usage": {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2}})
        fake_sdk = lambda **kwargs: SimpleNamespace(chat=SimpleNamespace(completions=SimpleNamespace(create=reply)))
        with patch("openai.OpenAI", fake_sdk):
            engine = engine_for(self.core, self.inputs, model, cache)
            from task_oriented_dataset_search import pipeline
            arguments = dict(db_path=str(self.core / "tiny_db.json"), graph_path=str(original_graph),
                dataset_faiss_path=str(self.core / "faiss_datasets.index"),
                dataset_parquet_path=str(self.core / "datasets.parquet"), llm_client=engine.llm_client,
                llm_retries=1)
            prefetched_path, baseline_path = self.root / "prefetched.graphml", self.root / "baseline.graphml"
            prefetched = pipeline.DatasetMerger(**arguments, graph_processed_path=str(prefetched_path),
                                                cache_manager=CacheManager(str(self.root / "prefetch_aliases")))
            prefetched.merge_datasets()
            prefetched.save_graph()
            baseline = DatasetMerger(**arguments, graph_processed_path=str(baseline_path),
                                     cache_manager=CacheManager(str(self.root / "baseline_aliases")))
            baseline.merge_datasets()
            baseline.save_graph()
        left, right = nx.read_graphml(prefetched_path), nx.read_graphml(baseline_path)
        self.assertEqual(dict(left.nodes(data=True)), dict(right.nodes(data=True)))
        self.assertEqual({frozenset(e) for e in left.edges()}, {frozenset(e) for e in right.edges()})
        audit = json.loads((self.root / "er_prefetch.jsonl").read_text().splitlines()[0])
        self.assertEqual((audit["prefetched_pairs"], audit["consumed_pairs"], audit["extra_prefetched_pairs"]), (3, 2, 1))
        prefetched.db.close()
        baseline.db.close()
        builder.db.close()


if __name__ == "__main__":
    unittest.main()
