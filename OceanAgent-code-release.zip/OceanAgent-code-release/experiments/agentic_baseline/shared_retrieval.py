"""Shared experiment-only metadata view; frozen benchmark files stay untouched.

Remove held-out source identity links from free metadata before both indexing
and projection. Canonical dataset/product identity values remain unchanged.
PSC/UBC permissions and the actual BM25 implementation are inherited from E1.
"""
from __future__ import annotations
import copy
import re
from typing import Any

from retrieval import E1Retrieval


class SharedRetrieval(E1Retrieval):
    def __init__(self, snapshot, agent_root=None):
        super().__init__(snapshot, agent_root)
        identities = self.blocked_source_ids | self.blocked_source_group_ids
        self.heldout_identity_pattern = re.compile(
            r'(?<![A-Za-z0-9])(?:' + '|'.join(re.escape(x) for x in sorted(identities, key=lambda x: (-len(x), x)))
            + r')(?![A-Za-z0-9])', re.IGNORECASE)
        counts = {'redacted_string_fields': 0, 'redacted_source_mentions': 0,
                  'corpus_cards_changed': 0, 'raw_dataset_cards_changed': 0}

        def scrub(value: Any, key: str = '') -> Any:
            if isinstance(value, dict):
                return {name: scrub(child, name) for name, child in value.items()}
            if isinstance(value, list):
                return [scrub(child, key) for child in value]
            if isinstance(value, str) and key not in {'dataset_id', 'product_id'}:
                redacted, n = self.heldout_identity_pattern.subn('source study', value)
                if n:
                    counts['redacted_string_fields'] += 1
                    counts['redacted_source_mentions'] += n
                return redacted
            return copy.deepcopy(value)

        corpus = []
        for original in self.corpus:
            clean = scrub(original)
            counts['corpus_cards_changed'] += int(clean != original)
            corpus.append(clean)
        dataset_cards = {}
        for identity, original in self.dataset_cards.items():
            clean = scrub(original)
            counts['raw_dataset_cards_changed'] += int(clean != original)
            dataset_cards[identity] = clean
        self.corpus = corpus
        self.by_id = {row['dataset_id']: row for row in corpus}
        self.dataset_cards = dataset_cards
        self._dataset_ranker = self.legacy.BM25([self.legacy.corpus_text(x) for x in corpus])
        self._requirement_index = None
        self.audit = {**self.audit,
            'policy': self.audit['policy'] + ';shared-heldout-source-metadata-redaction-v1',
            'source_metadata_redaction': {
                **counts, 'same_view_for': ['TAAR', 'OceanAgent'],
                'canonical_id_fields_preserved': ['dataset_id', 'product_id'],
                'canonical_dataset_ids_with_heldout_source_cues': sum(
                    bool(self.heldout_identity_pattern.search(key)) for key in self.by_id),
                'canonical_product_ids_with_heldout_source_cues': sum(
                    bool(self.heldout_identity_pattern.search(str(x.get('product_id') or ''))) for x in corpus),
                'original_files_modified': False,
                'limitation': 'Frozen canonical entity IDs retain source fragments; runtime query/task/source IDs are never sent to the model.',
            }}
