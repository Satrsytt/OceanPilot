/** Scoped TAAR/OceanAgent bridge. Existing experiment ledgers remain untouched.
 * Credentials are decrypted only inside this process and are never serialized.
 * Each SDK dispatch requires one durable, budgeted reservation in the JSONL log.
 */
import {createRequire} from 'node:module';
import {fileURLToPath, pathToFileURL} from 'node:url';
import {dirname, join, resolve} from 'node:path';
import {stat} from 'node:fs/promises';
import {appendFileSync, closeSync, existsSync, fsyncSync, mkdirSync, openSync,
        readFileSync, rmdirSync} from 'node:fs';
import readline from 'node:readline';
import {createHash, randomUUID} from 'node:crypto';
import {captureUsage} from '../paper_e1/scripts/e1_usage.mjs';

const here = dirname(fileURLToPath(import.meta.url));
const runtimeRoot = resolve(process.argv[2]);
const logs = join(here, 'logs');
const ledger = join(logs, 'model_requests.jsonl');
const ledgerLock = join(logs, '.model_ledger.lock');
const require = createRequire(join(runtimeRoot, 'package.json'));
const Database = require('better-sqlite3');
const {ModelSettingsRepository} = await import(pathToFileURL(join(runtimeRoot, 'dist/db/model-settings-repository.js')));
const {createSecretProtector} = await import(pathToFileURL(join(runtimeRoot, 'dist/security/platform-secret-protector.js')));
const {OceanModelService} = await import(pathToFileURL(join(runtimeRoot, 'dist/agent/model-service.js')));
const keyInfo = await stat(join(runtimeRoot, 'data/.credentials/master.key'));
if ((keyInfo.mode & 0o077) !== 0) throw Error('Credential file permissions invalid; bridge does not change them');
const db = new Database(join(runtimeRoot, 'data/ocean-agent.sqlite'), {readonly:true, fileMustExist:true});
db.pragma('query_only = ON');
const settings = new ModelSettingsRepository({raw:db}, createSecretProtector(runtimeRoot));
const service = await OceanModelService.create(settings);

const hash = value => createHash('sha256').update(value).digest('hex');
const readJSON = path => JSON.parse(readFileSync(path, 'utf8'));
const now = () => new Date().toISOString();
function safeError(error) {
  return String(error?.message ?? error).replace(/(?:sk-|Bearer\s+)[A-Za-z0-9_.-]{8,}/gi, '[REDACTED]').slice(0, 1200);
}
function publicModel(model, key) {
  return {key, id:model.id, provider:model.provider, name:model.name, api:model.api,
    baseUrl:model.baseUrl, contextWindow:model.contextWindow, maxTokens:model.maxTokens, reasoning:model.reasoning};
}
function denied(reason) { throw Error('AGENTIC_PAID_DISPATCH_DENIED: ' + reason); }

function scope(req, model) {
  const configPath = join(here, 'config.json');
  const configBytes = readFileSync(configPath);
  const config = JSON.parse(configBytes);
  const manifest = readJSON(join(here, 'run_manifest.json'));
  const binding = req.e1_binding;
  if (!binding || process.env.OCEAN_E1_GRANT_KIND !== 'formal' ||
      !process.env.OCEAN_E1_SCOPE_ID || binding.scope_id !== process.env.OCEAN_E1_SCOPE_ID ||
      binding.scope_id !== manifest.scope_id) denied('Missing exact experiment scope binding');
  if (manifest.schema_version !== 'agentic-baseline-run-v1') denied('Unknown manifest schema');
  const configSHA = hash(configBytes);
  if (binding.config_sha256 !== configSHA || manifest.config_sha256 !== configSHA) denied('Frozen config differs');
  if (resolve(config.agent_root) !== runtimeRoot) denied('Unexpected model runtime');
  if (!['TAAR', 'OceanAgent'].includes(binding.method) || !manifest.methods?.includes(binding.method))
    denied('Unknown method');
  if (!manifest.allowed_units?.some(unit => unit.method === binding.method && unit.query_id === binding.query_id))
    denied('Query/method outside finite population');
  const allowedKeys = manifest.allowed_units.map(x => JSON.stringify([x.method, x.query_id]));
  if (manifest.allowed_units.length !== 640 || new Set(allowedKeys).size !== 640 ||
      new Set(manifest.allowed_units.map(x => x.query_id)).size !== 320 ||
      manifest.allowed_units.some(x => !['TAAR', 'OceanAgent'].includes(x.method)))
    denied('Expected fixed 320-query population');
  if ((req.model ?? config.model) !== config.model) denied('Request model differs from configured model');
  if (config.temperature !== 0 || config.max_output_tokens_per_call !== 4096 || req.max_tokens !== 4096 ||
      config.max_llm_calls_per_unit !== 5 || config.max_tool_calls_per_unit !== 8 ||
      config.thinking?.type !== 'disabled' || config.reasoning_effort !== 'none' ||
      manifest.max_calls_per_unit !== 5 || manifest.max_concurrency !== 2 ||
      !Number.isInteger(manifest.max_calls) || manifest.max_calls > 3200 || manifest.max_calls < 1)
    denied('Unexpected scientific budgets or sampling configuration');
  if (![1, 2].includes(binding.attempt) || typeof binding.stage !== 'string' || !binding.stage)
    denied('Invalid explicit stage/attempt');
  if (!Number.isInteger(req.timeout_ms) || req.timeout_ms < 1 || req.timeout_ms > 120000)
    denied('Request timeout exceeds frozen bound');
  if (!req.context || JSON.stringify(req.context).length > config.max_prompt_chars)
    denied('Prompt exceeds frozen context bound');
  for (const [path, expected] of Object.entries(config.implementation_sha256 ?? {})) {
    if (hash(readFileSync(path)) !== expected) denied('Frozen implementation changed');
  }
  return {config, manifest, binding, configSHA};
}

async function withLedger(action) {
  mkdirSync(logs, {recursive:true});
  let locked = false;
  for (let attempt = 0; attempt < 80; attempt++) {
    try { mkdirSync(ledgerLock); locked = true; break; }
    catch (error) { if (error.code !== 'EEXIST') throw error; }
    await new Promise(resolve => setTimeout(resolve, 25));
  }
  if (!locked) denied('Ledger lock unavailable; preserve reservations for audit');
  try {
    const records = existsSync(ledger) ? readFileSync(ledger, 'utf8').split('\n').filter(Boolean).map(JSON.parse) : [];
    const append = record => {
      const fd = openSync(ledger, 'a', 0o600);
      try { appendFileSync(fd, JSON.stringify(record) + '\n'); fsyncSync(fd); }
      finally { closeSync(fd); }
    };
    return action(records, append);
  } finally { rmdirSync(ledgerLock); }
}

async function reserve(req, model, validated) {
  const {manifest, binding, configSHA} = validated;
  const requestSHA = hash(JSON.stringify({model:model.id, context:req.context, maxTokens:req.max_tokens,
    temperature:0, thinking:'disabled'}));
  return withLedger((records, append) => {
    const rows = records.filter(x => x.event === 'reserve' && x.scope_id === manifest.scope_id);
    const settlements = new Map(records.filter(x => x.event === 'settle').map(x => [x.request_id, x]));
    if (rows.length >= manifest.max_calls) denied('Total request cap reached');
    if (rows.filter(x => x.method === binding.method && x.query_id === binding.query_id).length >= 5)
      denied('Five-call per-query cap reached');
    if (rows.filter(x => !settlements.has(x.request_id)).length >= 2) denied('Concurrent request cap reached');
    const prior = rows.filter(x => x.method === binding.method && x.query_id === binding.query_id &&
      x.stage === binding.stage && x.request_sha256 === requestSHA);
    if (prior.length) {
      const settled = settlements.get(prior[0].request_id);
      const status = settled?.http_statuses?.at(-1)?.status;
      const transient = [408,409,425,429].includes(status) || status >= 500 ||
        /timeout|timed out|connection|transport|aborted|fetch failed/i.test(settled?.error ?? '');
      if (binding.attempt !== 2 || prior.length !== 1 || prior[0].attempt !== 1 || !settled || !transient)
        denied('Duplicate dispatch or retry without recorded transient failure');
    } else if (binding.attempt !== 1) denied('Retry without previous dispatch');
    const reservation = {event:'reserve', created_utc:now(), request_id:randomUUID(), ...binding,
      config_sha256:configSHA, request_sha256:requestSHA, model:publicModel(model, req.model),
      max_output_tokens:req.max_tokens, temperature:0, thinking:{type:'disabled'}, reasoning_effort:'none'};
    append(reservation);
    return reservation;
  });
}

async function handle(req) {
  const selected = req.model ?? 'deepseek::deepseek-flash';
  const model = service.resolveRunModel(selected);
  if (req.kind === 'info') return {ok:true, model:publicModel(model, selected),
    providers:settings.listProviders().map(x => ({providerId:x.providerId,
      configured:x.hasSavedCredential, enabledModelIds:x.enabledModelIds}))};
  if (req.kind !== 'complete') throw Error('Unknown bridge request kind');
  const validated = scope(req, model);
  const reservation = await reserve(req, model, validated);
  const start = performance.now(), statuses = [], provider = {};
  let dispatches = 0, capture = null, response = null, requestMode = null, error = null;
  const guardedFetch = async (input, init) => {
    if (dispatches++) throw Error('Hidden SDK retry blocked; one dispatch per durable reservation');
    const url = new URL(typeof input === 'string' ? input : input.url ?? String(input));
    if (url.origin !== new URL(model.baseUrl).origin) throw Error('Endpoint differs from the configured model');
    const result = await globalThis.fetch(input, init);
    statuses.push({status:result.status});
    capture = captureUsage(result.clone(), provider);
    return result;
  };
  try {
    response = await service.runtime.completeSimple(model, req.context, {temperature:0, maxTokens:4096,
      samplingParams:{thinking:{type:'disabled'}, reasoning_effort:'none'}, maxRetries:0,
      fetch:guardedFetch, cacheRetention:'short', signal:AbortSignal.timeout(req.timeout_ms),
      onPayload:body => { requestMode = {model:body.model, thinking:body.thinking,
        reasoning_effort:body.reasoning_effort, temperature:body.temperature, max_tokens:body.max_tokens,
        tool_n:body.tools?.length ?? 0, payload_sha256:hash(JSON.stringify(body))}; }});
    if (['error', 'aborted'].includes(response?.stopReason)) error = safeError(response.errorMessage ?? response.stopReason);
  } catch (failure) { error = safeError(failure); }
  finally { if (capture) await capture; }
  const settled = {event:'settle', settled_utc:now(), request_id:reservation.request_id,
    scope_id:reservation.scope_id, method:reservation.method, query_id:reservation.query_id,
    stage:reservation.stage, attempt:reservation.attempt, ok:!error, error, http_statuses:statuses,
    elapsed_ms:performance.now()-start, actual_http_dispatches:dispatches,
    request_mode:requestMode, provider_usage:provider.usage ?? null, provider_model:provider.model ?? null,
    provider_response_id:provider.response_id ?? null, provider_capture_error:provider.capture_error ?? null,
    sdk_usage:response?.usage ?? null};
  await withLedger((_records, append) => append(settled));
  return {ok:!error, ...(error ? {error} : {}), response, elapsed_ms:settled.elapsed_ms,
    http_statuses:statuses, request_mode:requestMode, provider_usage:settled.provider_usage,
    provider_model:settled.provider_model, provider_response_id:settled.provider_response_id,
    actual_http_dispatches:dispatches, budget_settlement:{request_id:reservation.request_id,
      ledger, counted_calls:1, cost_kind:'usage_record_only_no_invoice_or_price_estimate'}};
}

const rl = readline.createInterface({input:process.stdin, crlfDelay:Infinity});
for await (const line of rl) {
  if (!line.trim()) continue;
  let req;
  try { req = JSON.parse(line); const result = await handle(req); process.stdout.write(JSON.stringify({id:req.id, ...result})+'\n'); }
  catch (error) { process.stdout.write(JSON.stringify({id:req?.id, ok:false, error:safeError(error)})+'\n'); }
}
db.close();
