"""Offline contract tests; scripted responses are test fixtures, never results."""
from __future__ import annotations
import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import run_agentic as agent
from shared_retrieval import SharedRetrieval


def answer(text=None, calls=()):
    blocks = ([{'type': 'text', 'text': text}] if text is not None else []) + list(calls)
    return {'ok': True, 'http_statuses': [{'status': 200}], 'elapsed_ms': 1,
            'response': {'role': 'assistant', 'content': blocks, 'provider': 'fixture',
                         'model': 'fixture', 'stopReason': 'toolUse' if calls else 'stop',
                         'timestamp': 1, 'usage': {'input': 1, 'output': 1}}}


def tool(number, name='search_datasets', arguments=None):
    return {'type': 'toolCall', 'id': f'tool{number}', 'name': name,
            'arguments': arguments or {'query': 'additional observations', 'limit': 10}}


def ranking(ids):
    return json.dumps({'ranking': [{'dataset_id': x, 'reason': 'fixture'} for x in ids[:20]]})


class FixtureBridge:
    def __init__(self, responses):
        self.responses = list(responses)
        self.requests = []

    def request(self, request, timeout):
        self.requests.append(copy.deepcopy(request))
        if request['kind'] == 'info':
            return {'model': {'id': 'fixture', 'provider': 'fixture', 'reasoning': False}}
        if not self.responses:
            raise AssertionError('Unexpected completion dispatch')
        return self.responses.pop(0)

    def close(self):
        pass


class FixtureRetrieval:
    def __init__(self):
        self.corpus = [{'dataset_id': f'd{i:02d}', 'product_name': f'Product {i}'} for i in range(60)]
        self.by_id = {x['dataset_id']: x for x in self.corpus}
        self.audit = {'policy': 'fixture'}

    def search_datasets(self, query, limit):
        return [agent.compact_dataset(x) for x in self.corpus[30:30+limit]]

    def search_knowledge(self, query, card_type, limit):
        return [{'card_type': 'PSC', 'card_id': 'permitted'}]

    def get_bundle(self, bundle_id):
        if bundle_id != 'permitted':
            raise PermissionError('Held-out bundle')
        return {'usage_bundle_card': {'bundle_id': bundle_id}}


class AgentProtocolTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.patcher = patch.object(agent, 'ROOT', self.root)
        self.patcher.start()
        self.addCleanup(self.patcher.stop)
        self.config = agent.load(agent.E1 / 'config.json')
        self.config['implementation_sha256'] = {}  # Test fixtures have no historical run manifest.
        (self.root / 'config.json').write_text(json.dumps(self.config))
        self.retrieval = FixtureRetrieval()
        self.ids = list(self.retrieval.by_id)
        self.query = {'task_id': 'heldout_task_fixture', 'source_group_id': 'heldout_source_fixture',
                      'query_id': 'fixture_q', 'query_variant': 1, 'split': 'dev',
                      'query': 'Retrieve observations for scientific analysis.'}
        self.initial = {self.query['query_id']: {'ids': self.ids[:30]}}
        self.compiler = {'system': 'compiler fixture', 'user_template': 'QUESTION', 'marker': 'QUESTION',
                         'schema': {'type': 'object'}, 'validate': lambda value: None,
                         'reject_ids': lambda value, ids: None, 'source_sha256': 'fixture',
                         'schema_sha256': 'fixture', 'prompt_sha256': 'fixture'}

    def runner(self, responses):
        bridge = FixtureBridge(responses)
        runner = agent.AgentRunner(self.config, self.retrieval, self.initial,
                                  bridge_factory=lambda: bridge, compiler=self.compiler)
        self.addCleanup(runner.close)
        return runner, bridge

    def test_taar_raw_query_no_compiler_and_unrestricted_expansion(self):
        runner, bridge = self.runner([answer(calls=[tool(1)]), answer(ranking(self.ids[30:]))])
        row = runner.run_unit('TAAR', self.query)
        self.assertEqual((row['status'], row['llm_calls'], row['tool_calls']), ('success', 2, 1))
        self.assertEqual(row['ranking'], self.ids[30:50])
        self.assertNotIn('task_spec', row)
        complete = [x for x in bridge.requests if x['kind'] == 'complete']
        payload = json.loads(complete[0]['context']['messages'][0]['content'])
        self.assertEqual(set(payload), {'research_question', 'initial_dataset_candidates'})
        self.assertEqual([x['dataset_id'] for x in payload['initial_dataset_candidates']], self.ids[:30])
        serialized = json.dumps([x['context'] for x in complete])
        self.assertNotIn('heldout_task_fixture', serialized)
        self.assertNotIn('heldout_source_fixture', serialized)
        self.assertNotIn('acceptable_dataset_ids', serialized)

    def test_ocean_compiler_counts_and_receives_same_initial_order(self):
        runner, bridge = self.runner([answer('{"research_goal":"fixture"}'), answer(ranking(self.ids))])
        row = runner.run_unit('OceanAgent', self.query)
        self.assertEqual((row['status'], row['llm_calls']), ('success', 2))
        requests = [x for x in bridge.requests if x['kind'] == 'complete']
        payload = json.loads(requests[1]['context']['messages'][0]['content'])
        self.assertIn('scientific_task_spec', payload)
        self.assertEqual([x['dataset_id'] for x in payload['initial_dataset_candidates']], self.ids[:30])
        self.assertEqual(row['evidence_audit']['initial_candidate_ids'], self.ids[:30])
        self.assertEqual(row['stages'][0]['stage'], 'task_compiler')

    def test_fifth_completion_reserved_for_final_output(self):
        runner, bridge = self.runner([answer(calls=[tool(i)]) for i in range(4)] + [answer(ranking(self.ids))])
        row = runner.run_unit('TAAR', self.query)
        self.assertEqual((row['status'], row['llm_calls'], row['tool_calls']), ('success', 5, 4))
        last = [x for x in bridge.requests if x['kind'] == 'complete'][-1]
        self.assertNotIn('tools', last['context'])

    def test_eighth_tool_limit_denies_overflow(self):
        runner, bridge = self.runner([answer(calls=[tool(i) for i in range(9)]), answer(ranking(self.ids))])
        row = runner.run_unit('TAAR', self.query)
        self.assertEqual((row['status'], row['tool_calls'], len(row['tool_trace'])), ('success', 8, 8))
        last = [x for x in bridge.requests if x['kind'] == 'complete'][-1]
        self.assertNotIn('tools', last['context'])

    def test_submission_counts_as_tool_operation(self):
        submitted = tool(1, 'submit_dataset_ranking', json.loads(ranking(self.ids)))
        runner, _ = self.runner([answer(calls=[submitted])])
        row = runner.run_unit('TAAR', self.query)
        self.assertEqual((row['status'], row['llm_calls'], row['tool_calls']), ('success', 1, 1))
        self.assertEqual(row['ranking'], self.ids[:20])

    def test_network_retry_and_format_repair_consume_llm_budget(self):
        failed = {'ok': False, 'error': 'temporary', 'http_statuses': [{'status': 503}]}
        runner, _ = self.runner([failed, answer('{"ranking":[]}'), answer(ranking(self.ids))])
        row = runner.run_unit('TAAR', self.query)
        self.assertEqual((row['status'], row['llm_calls']), ('success', 3))
        self.assertEqual(row['retry_counts']['network'], 1)
        self.assertEqual(row['retry_counts']['format_repair'], 1)

    def test_unknown_tool_cannot_open_reference_files(self):
        runner, _ = self.runner([])
        _, error, accepted = runner._execute_tool(tool(1, 'read_file', {'path': 'benchmark/gold/dataset_gold.jsonl'}))
        self.assertTrue(error)
        self.assertIsNone(accepted)
        _, error, _ = runner._execute_tool(tool(2, 'get_bundle', {'bundle_id': 'heldout'}))
        self.assertTrue(error)

    def test_resume_preserves_real_failure_without_paid_replay(self):
        runner, bridge = self.runner([answer('{"ranking":[]}'), answer('{"ranking":[]}')])
        row = runner.run_unit('TAAR', self.query)
        self.assertEqual(row['status'], 'failed')
        count = len(bridge.requests)
        self.assertEqual(runner.run_unit('TAAR', self.query), row)
        self.assertEqual(len(bridge.requests), count)


class FrozenRetrievalBoundaryTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.config = agent.load(agent.E1 / 'config.json')
        cls.retrieval = SharedRetrieval(cls.config['knowledge_root'], cls.config['agent_root'])

    def test_all_split_source_identities_disjoint(self):
        manifest = agent.load(Path(self.config['knowledge_root']) / 'benchmark/splits/split_manifest.json')['splits']
        for left, right in [('train', 'dev'), ('train', 'test'), ('dev', 'test')]:
            for field in ('source_group_ids', 'source_ids'):
                self.assertFalse(set(manifest[left][field]) & set(manifest[right][field]))

    def test_bm25_ignores_raw_source_quotes_and_gold_associations(self):
        card = self.retrieval.corpus[0]
        changed = copy.deepcopy(card)
        changed.update(official_evidence=[{'source_id': 'heldout', 'quote': 'SECRET_ANSWER'}],
                       ownership='SECRET_ANSWER', gold_dataset_ids=['SECRET_ANSWER'])
        self.assertEqual(self.retrieval.legacy.corpus_text(card), self.retrieval.legacy.corpus_text(changed))
        self.assertEqual(agent.compact_dataset(card), agent.compact_dataset(changed))

    def test_all_product_projections_omit_source_labels(self):
        forbidden = {'official_evidence', 'sources', 'source_id', 'paper_id', 'source_group_id',
                     'gold_dataset_ids', 'acceptable_dataset_ids', 'requirements', 'valid_routes'}
        def keys(value):
            if isinstance(value, dict):
                return set(value) | set().union(*(keys(x) for x in value.values()))
            if isinstance(value, list):
                return set().union(*(keys(x) for x in value))
            return set()
        for card in self.retrieval.corpus:
            self.assertFalse(keys(agent.compact_dataset(card)) & forbidden)

    def test_heldout_source_cues_scrubbed_except_canonical_identity_fields(self):
        def scan(value, key=''):
            if isinstance(value, dict):
                return any(scan(child, field) for field, child in value.items())
            if isinstance(value, list):
                return any(scan(child, key) for child in value)
            return (isinstance(value, str) and key not in {'dataset_id', 'product_id'}
                    and bool(self.retrieval.heldout_identity_pattern.search(value)))
        for card in self.retrieval.corpus:
            self.assertFalse(scan(card))
            self.assertFalse(scan(agent.compact_dataset(card)))
            self.assertFalse(scan(json.loads(self.retrieval.legacy.corpus_text(card))))
        for card in self.retrieval.dataset_cards.values():
            self.assertFalse(scan(card))
        audit = self.retrieval.audit['source_metadata_redaction']
        self.assertEqual(audit['canonical_dataset_ids_with_heldout_source_cues'], 620)
        self.assertGreater(audit['redacted_string_fields'], 0)
        original = agent.base.read_jsonl(Path(self.config['knowledge_root']) / 'benchmark/corpus/dataset_corpus.jsonl')
        self.assertEqual([(x['dataset_id'], x['product_id']) for x in original],
                         [(x['dataset_id'], x['product_id']) for x in self.retrieval.corpus])

    def test_heldout_bundles_denied_for_both_protocols(self):
        self.assertEqual(len(self.retrieval.corpus), 2260)
        self.assertEqual(self.retrieval.audit['visible_psc_count'], 485)
        self.assertEqual(self.retrieval.audit['blocked_psc_count'], 163)
        self.assertFalse(self.retrieval.visible_source_ids & self.retrieval.blocked_source_ids)
        for bundle in self.retrieval._blocked_ubc_ids:
            with self.assertRaises(PermissionError):
                self.retrieval.get_bundle(bundle)

    def test_real_search_reaches_beyond_initial_top30(self):
        initial = set(self.retrieval.bm25('sea surface temperature and salinity', 30))
        extra = self.retrieval.search_datasets('underwater image coral segmentation', 20)
        self.assertTrue(set(x['dataset_id'] for x in extra) - initial)


if __name__ == '__main__':
    unittest.main()
