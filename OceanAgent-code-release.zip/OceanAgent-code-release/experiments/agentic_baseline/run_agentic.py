#!/usr/bin/env python3
"""Frozen, gold-isolated TAAR/OceanAgent experiment, resumable without paid replays.

Run --prepare, --smoke, then --formal. --all performs all stages in that order.
Scorers run as a separate process after inference workers have closed.
"""
from __future__ import annotations
import argparse
import concurrent.futures
import copy
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from collections import Counter, defaultdict

ROOT = Path(__file__).resolve().parent
E1 = ROOT.parent / 'paper_e1'
sys.path.insert(0, str(E1 / 'scripts'))
import run as base
from retrieval import compact_dataset
from shared_retrieval import SharedRetrieval

METHODS = ('TAAR', 'OceanAgent')
PROMPT_TAAR = (
    'You are a scientific dataset retrieval agent. Understand the research question and autonomously '
    'plan searches, inspect available evidence, compare datasets, and recommend a ranked set of resources. '
    'Use the retrieval tools when useful to find resources beyond the initial shortlist. You may reformulate '
    'queries, investigate complementary observations, quality control and validation resources, and revise '
    'your choices as evidence arrives. Judge scientific relevance and practical suitability using your own '
    'reasoning. All policy-admitted PSC/UBC and the entire DatasetCard catalog are searchable. '
    'Only canonical DatasetCard IDs are valid recommendations. Finish with submit_dataset_ranking or '
    'the final JSON contract. ' + base.RANKING_CONTRACT)
PROMPT_OCEAN = (
    'You are OceanAgent performing scientific dataset recommendation. Use the generated ScientificTaskSpec '
    'and the available in-memory retrieval tools to inspect evidence, refine observations, quality-control '
    'and validation coverage, and choose a scientifically sufficient dataset bundle. Retrieve additional '
    'evidence when useful. Only canonical DatasetCard IDs are valid recommendations. '
    'Finish with submit_dataset_ranking or the final JSON contract. ' + base.RANKING_CONTRACT)


def load(path): return json.loads(Path(path).read_text())
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(path, value): base.atomic_json(Path(path), value)
def population(): return base.read_jsonl(E1 / 'runtime_queries.jsonl')


class AgentRunner(base.E1Runner):
    def __init__(self, config, retrieval, initial, **kwargs):
        super().__init__(ROOT, config, retrieval, **kwargs)
        self.initial = initial
        self.bridge_factory = kwargs.get('bridge_factory') or (lambda: base.BridgeClient(
            Path(config['agent_root']), ROOT / 'runtime_bridge.mjs'))

    def _complete(self, state, *args, **kwargs):
        try:
            return super()._complete(state, *args, **kwargs)
        finally:
            # A crash after dispatch preserves paid-attempt evidence. Resume never
            # reruns a partially executed unit; it records the incomplete output.
            save(ROOT / 'cache' / 'partial' / state['row']['method'].lower() /
                 (state['row']['query_id'] + '.json'), state['row'])

    def _agent(self, state, query):
        row = state['row']
        ids = list(self.initial[row['query_id']]['ids'])
        candidates = [compact_dataset(self.retrieval.by_id[key]) for key in ids]
        row['evidence_audit'] = {'initial_candidate_ids': ids,
            'initial_candidate_sha256': base.sha_json(ids),
            'visibility_policy': self.retrieval.audit['policy'],
            'input': 'raw_query_only', 'gold_access': False}
        payload = {'research_question': query, 'initial_dataset_candidates': candidates}
        if row['method'] == 'OceanAgent':
            payload['scientific_task_spec'] = self._compile(state, query)
            system = PROMPT_OCEAN
            row['components'] = ['existing_TaskCompiler_prompt_schema', 'shared_raw_query_BM25_Top30',
                                 'existing_native_tool_loop']
        else:
            system = PROMPT_TAAR
            row['components'] = ['generic_scientific_retrieval_prompt', 'shared_raw_query_BM25_Top30',
                                 'existing_native_tool_loop']
        messages = [base.user_message(json.dumps(payload, ensure_ascii=False, sort_keys=True))]
        tools = base.tool_definitions()
        while True:
            final = (row['llm_calls'] >= self.config['max_llm_calls_per_unit'] - 1
                     or row['tool_calls'] >= self.config['max_tool_calls_per_unit'])
            if final:
                messages.append(base.user_message('The retrieval budget is complete. Return your final ranking now. '
                                                   + base.RANKING_CONTRACT))
            response = self._complete(state, system, messages, tools=None if final else tools,
                                      stage='agent_final' if final else 'agent_tool_loop')
            blocks = response.get('content', [])
            calls = [x for x in blocks if isinstance(x, dict) and x.get('type') == 'toolCall'] if isinstance(blocks, list) else []
            if not calls:
                try:
                    return base.validate_ranking(base.parse_json_text(base.assistant_text(response)), self.canonical)
                except (ValueError, TypeError, KeyError) as exc:
                    if (row['retry_counts']['format_repair'] >= self.config['format_repair_attempts']
                            or row['llm_calls'] >= self.config['max_llm_calls_per_unit']):
                        raise base.UnitFailure('Invalid final ranking: ' + base.safe_text(exc)) from None
                    row['retry_counts']['format_repair'] += 1
                    self._repair_history(state, system, messages, response,
                        'Repair the final JSON only. ' + base.safe_text(exc) + ' ' + base.RANKING_CONTRACT,
                        tools=None if final else tools)
                    continue
            messages.append(base.visible_assistant(response))
            self._fit_tool_history(state, system, messages, tools, reserve=base.FINAL_HISTORY_RESERVE_CHARS)
            if final:
                raise base.UnitFailure('Agent issued tools after the final-output boundary')
            submitted = None
            for idx, call in enumerate(calls):
                if row['tool_calls'] >= self.config['max_tool_calls_per_unit']:
                    output, error = {'error': 'Tool call budget exhausted; return final JSON'}, True
                else:
                    row['tool_calls'] += 1
                    output, error, ranking = self._execute_tool(call)
                    if call.get('name') == 'submit_dataset_ranking' and error:
                        if row['retry_counts']['format_repair'] >= self.config['format_repair_attempts']:
                            raise base.UnitFailure('Invalid ranking submission after repair budget exhausted')
                        row['retry_counts']['format_repair'] += 1
                    if ranking is not None: submitted = ranking
                    row['tool_trace'].append({'tool': call.get('name'), 'arguments': call.get('arguments'),
                                               'is_error': error, 'result': output})
                call_id = str(call.get('id', ''))
                state.setdefault('tool_outputs', {})[call_id] = copy.deepcopy(output)
                available = (self.config['max_prompt_chars'] - base.context_chars(system, messages, tools)
                             - base.FINAL_HISTORY_RESERVE_CHARS - 512 * (len(calls) - idx))
                budget = max(256, min(base.MAX_TOOL_RESULT_CHARS, available // max(1, len(calls) - idx)))
                projected, projection = base.project_tool_output(output, budget)
                row.setdefault('context_projections', []).append({'stage': 'tool_return', 'tool_call_id': call_id, **projection})
                messages.append({'role': 'toolResult', 'toolCallId': call_id, 'toolName': str(call.get('name', '')),
                    'content': [{'type': 'text', 'text': json.dumps(projected, ensure_ascii=False)}],
                    'isError': error, 'timestamp': int(time.time() * 1000)})
            if submitted is not None: return submitted

    def run_unit(self, method, query, *, resume=True):
        path = self.cache_path(method, query['query_id'])
        if path.exists():
            row = load(path)
            if row['config_sha256'] != self.config_sha: raise ValueError('Frozen config drift')
            return row
        partial = ROOT / 'cache' / 'partial' / method.lower() / (query['query_id'] + '.json')
        if partial.exists():
            row = load(partial)
            if row['config_sha256'] != self.config_sha: raise ValueError('Partial checkpoint config drift')
            row.update(status='failed', ranking=[], error='Interrupted unit retained; no paid replay permitted')
            save(path, row)
            return row
        start = time.monotonic()
        row = {'schema_version': self.config['schema_version'], 'method': method,
            **{key: query[key] for key in ('split', 'task_id', 'query_id', 'query_variant', 'query')},
            'status': 'failed', 'ranking': [], 'available_depth': 20, 'config_sha256': self.config_sha,
            'model': self.config['model'], 'model_actual': None, 'usage': {}, 'llm_calls': 0, 'tool_calls': 0,
            'raw_responses': [], 'request_sha256': [], 'evidence_audit': {}, 'tool_trace': [], 'stages': [],
            'components': [], 'implementation_sha256': self.config['implementation_sha256'],
            'started_utc': base.utc_now(), 'finished_utc': None, 'error': None,
            'retry_counts': {'network': 0, 'format_repair': 0, 'unit': 0}}
        state = {'row': row, 'clock': start}
        try:
            if method not in METHODS: raise base.UnitFailure('Unknown agentic method')
            ranking = self._agent(state, query['query'])
            if len(ranking) != 20 or len(set(ranking)) != 20 or not set(ranking) <= self.canonical:
                raise base.UnitFailure('Invalid canonical Top20 contract')
            self._remaining(state)
            row.update(status='success', ranking=ranking)
        except base.UnitFailure as exc:
            row.update(status=exc.status, error=str(exc))
        except Exception as exc:
            row.update(status='failed', error=f'{type(exc).__name__}: {base.safe_text(exc)}')
        finally:
            row.update(elapsed_seconds=time.monotonic()-start, finished_utc=base.utc_now())
            save(path, row)
        return row


def prepare():
    config = load(E1 / 'config.json')
    # No Benchmark Gold parser/import in this process. Only validate immutable bytes.
    for rel, expected in config['source_sha256'].items():
        if sha(Path(config['knowledge_root']) / rel) != expected: raise ValueError('Frozen source changed: ' + rel)
    config.update(schema_version='agentic-baseline-v1', methods=list(METHODS), concurrency=2,
                  initial_candidate_policy='raw_query_BM25_shared_ordered_Top30',
                  source_e1_config_sha256=sha(E1 / 'config.json'),
                  prompt_taar_sha256=base.sha_json(PROMPT_TAAR), prompt_ocean_sha256=base.sha_json(PROMPT_OCEAN))
    files = [Path(__file__), ROOT / 'shared_retrieval.py', ROOT / 'runtime_bridge.mjs', E1 / 'scripts/run.py', E1 / 'scripts/retrieval.py']
    config['implementation_sha256'] = {str(p): sha(p) for p in files if p.exists()}
    if (ROOT / 'config.json').exists():
        previous = load(ROOT / 'config.json')
        if config != previous: raise ValueError('Configuration or inference code drift; refuse mixed run')
    else: save(ROOT / 'config.json', config)
    queries = population()
    assert len(queries) == 320 and Counter(q['split'] for q in queries) == {'dev': 102, 'test': 218}
    assert all(set(q) == {'task_id', 'source_group_id', 'query_id', 'query_variant', 'split', 'query'} for q in queries)
    retrieval = SharedRetrieval(config['knowledge_root'], agent_root=config['agent_root'])
    cache = {}
    for q in queries:
        ids = retrieval.bm25(q['query'], 30)
        independent = [x['dataset_id'] for x in retrieval.search_datasets(q['query'], limit=30)]
        assert ids == independent and len(ids) == len(set(ids)) == 30
        cache[q['query_id']] = {'ids': ids, 'query_sha256': base.sha_json(q['query']), 'ordered_sha256': base.sha_json(ids)}
    cache_path = ROOT / 'cache' / 'initial_candidates.json'
    if cache_path.exists() and load(cache_path) != cache: raise ValueError('BM25 cache drift')
    if not cache_path.exists(): save(cache_path, cache)
    # Both inference protocols consume these exact same ordered lists.
    schema = base.tool_definitions()
    for t in schema:
        assert not any(x in json.dumps(t).lower() for x in ('gold', 'reference_label'))
    preflight = {'created_utc': base.utc_now(), 'queries_checked': len(cache), 'initial_order_matches': True,
        'same_initial_candidates_by_construction': True, 'candidate_cache_sha256': sha(cache_path),
        'runtime_query_sha256': sha(E1 / 'runtime_queries.jsonl'), 'query_fields_allowlisted': True,
        'tool_schema_sha256': base.sha_json(schema), 'knowledge_audit': retrieval.audit,
        'old_ocean_initial_policy': 'ScientificTaskSpec_BM25; incompatible with raw_query_Top30; paired rerun required',
        'gold_isolation': 'No evaluator imported; runtime query fields allowlisted; tools expose product projection and heldout-filtered PSC/UBC only',
        'historical_gold_files_hashed_only': True}
    save(ROOT / 'preflight.json', preflight)
    # Smoke diversity selection uses query text alone, never reference requirements.
    domains = [('image', ('image', 'plankton')), ('physical', ('circulation', 'temperature', 'salinity')),
               ('biogeochemical', ('carbon', 'chlorophyll', 'oxygen')), ('climate', ('climate', 'warming', 'trend')),
               ('hazard', ('cyclone', 'wave', 'extreme', 'tide'))]
    chosen = []
    for label, words in domains:
        q = next(q for q in queries if q['split'] == 'dev' and q['task_id'] not in chosen
                 and any(w in q['query'].lower() for w in words))
        chosen.append(q['task_id'])
    manifest_path = ROOT / 'run_manifest.json'
    if not manifest_path.exists():
        save(manifest_path, {'schema_version': 'agentic-baseline-run-v1', 'scope_id': 'retrieval-' + sha(ROOT/'config.json')[:12],
            'config_sha256': sha(ROOT/'config.json'), 'created_utc': base.utc_now(), 'status': 'prepared',
            'methods': list(METHODS), 'allowed_units': [{'method': m, 'query_id': q['query_id']} for m in METHODS for q in queries],
            'max_calls_per_unit': 5, 'max_calls': 3200, 'max_concurrency': 2, 'smoke_tasks': chosen,
            'model': config['model'], 'unit_timeout_seconds': 300})
    return config, retrieval, cache, load(manifest_path)


def execute(config, retrieval, initial, manifest, stage):
    queries = population()
    if stage == 'smoke': queries = [q for q in queries if q['task_id'] in manifest['smoke_tasks']]
    blocker = base.Blocker()
    os.environ['OCEAN_E1_SCOPE_ID'] = manifest['scope_id']
    os.environ['OCEAN_E1_GRANT_KIND'] = 'formal'
    pending = [(m, q) for q in queries for m in METHODS]
    def unit(item):
        method, query = item
        runner = AgentRunner(config, retrieval, initial, blocker=blocker)
        try: return runner.run_unit(method, query)
        finally: runner.close()
    # Bounded batches stop on a persistent provider/configuration blocker without
    # generating hundreds of artificial failed-query records.
    manifest['status'] = stage + '_running'; save(ROOT/'run_manifest.json', manifest)
    completed = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        for off in range(0, len(pending), 2):
            futures = [pool.submit(unit, item) for item in pending[off:off+2]]
            for f in futures:
                row = f.result(); completed.append(row)
                print(json.dumps({k: row[k] for k in ('method','split','query_id','status','llm_calls','tool_calls','error')}), flush=True)
            systemic = [r for r in completed[-2:] if r['error'] and (
                base.is_systemic({'error': r['error']}) or any(w in r['error'].lower() for w in
                    ('not found', 'credential', 'eacces', 'eperm', 'enotfound', 'enetwork', 'fetch failed', 'network access', 'bridge stopped')))]
            if blocker.reason or systemic:
                manifest.update(status='blocked', blocker=blocker.reason or systemic[0]['error'], blocked_stage=stage)
                break
        else: manifest['status'] = stage + '_complete'
    manifest.update(updated_utc=base.utc_now())
    manifest['observed_units'] = len(list((ROOT/'cache/units').glob('*/*.json')))
    save(ROOT/'run_manifest.json', manifest)
    if stage == 'smoke':
        save(ROOT/'smoke.json', {'planned_tasks': 5, 'planned_queries_per_method': 10,
            'observed_units': len(completed), 'valid_outputs': sum(r['status']=='success' for r in completed),
            'budget_adherence': all(r['llm_calls']<=5 and r['tool_calls']<=8 for r in completed),
            'initial_order_matches': all(r.get('evidence_audit',{}).get('initial_candidate_ids') == initial[r['query_id']]['ids'] for r in completed),
            'status': manifest['status'], 'blocker': manifest.get('blocker')})
    return manifest


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--prepare', action='store_true')
    ap.add_argument('--smoke', action='store_true'); ap.add_argument('--formal', action='store_true')
    ap.add_argument('--all', action='store_true')
    ap.add_argument('--execute', action='store_true', help='Required before model/API execution')
    args = ap.parse_args()
    if (args.smoke or args.formal or args.all) and not args.execute:
        ap.error('--execute is required for inference stages')
    ROOT.mkdir(exist_ok=True)
    with (ROOT/'cache.lock').open('w') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        config, retrieval, initial, manifest = prepare()
        print(json.dumps({'preflight': 'passed', 'queries':len(initial), 'scope_id':manifest['scope_id']}), flush=True)
        if args.smoke or args.all: manifest = execute(config, retrieval, initial, manifest, 'smoke')
        if args.formal or args.all:
            smoke = load(ROOT/'smoke.json') if (ROOT/'smoke.json').exists() else {}
            if not (smoke.get('observed_units') == 20 and smoke.get('budget_adherence')
                    and smoke.get('initial_order_matches') and smoke.get('valid_outputs', 0) > 0):
                manifest.update(status='blocked', blocker=manifest.get('blocker', 'Smoke requires all 20 paired attempts, valid output, initial-order and budget checks before formal dispatch'))
                save(ROOT/'run_manifest.json',manifest)
            elif manifest['status'] != 'blocked': execute(config, retrieval, initial, manifest, 'formal')

if __name__ == '__main__': main()
