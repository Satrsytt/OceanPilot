#!/usr/bin/env python3
"""Execute the frozen E1 inference population without opening benchmark Gold.

Real model requests require --execute. Unit caches are final records: --resume
preserves both successes and failures; --retry-failed explicitly retains and
retries previous failed/unavailable attempts. All inference data enter through
runtime_queries.jsonl, the allowed retrieval adapter, and the frozen config.
"""
from __future__ import annotations

import argparse
import concurrent.futures
import copy
import hashlib
import importlib.util
import json
import os
import re
import select
import subprocess
import sys
import tempfile
import threading
import time
import unicodedata
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

ROOT = Path(__file__).resolve().parents[1]
METHODS = ("BM25 Retrieval", "Dense Retrieval", "Direct LLM", "Flat RAG Agent",
           "StructuredRAG", "GraphRAG", "OceanAgent")
FINAL_STATUSES = {"success", "failed", "unavailable"}
SECRET_PATTERN = re.compile(r"(?:sk-|Bearer\s+)[A-Za-z0-9_.-]{8,}", re.I)


def safe_text(value: Any) -> str:
    return SECRET_PATTERN.sub("[REDACTED]", str(value))[:1600]


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha_json(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                     separators=(",", ":")).encode()).hexdigest()


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    rows = []
    with path.open(encoding="utf-8") as handle:
        for number, line in enumerate(handle, 1):
            if not line.strip():
                continue
            value = json.loads(line)
            if not isinstance(value, dict):
                raise ValueError(f"Expected JSON object at {path}:{number}")
            rows.append(value)
    return rows


def atomic_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, name = tempfile.mkstemp(prefix=".e1-", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            json.dump(value, handle, ensure_ascii=False, sort_keys=True)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(name, path)
    finally:
        if os.path.exists(name):
            os.unlink(name)


def parse_json_text(text: str) -> Any:
    """Accept plain JSON or one surrounding Markdown fence, never partial JSON."""
    value = text.strip()
    if value.startswith("```"):
        match = re.fullmatch(r"```(?:json)?\s*\n?(.*?)\n?```", value, re.S | re.I)
        if not match:
            raise ValueError("Malformed JSON fence")
        value = match.group(1).strip()
    return json.loads(value)


def assistant_text(message: Mapping[str, Any]) -> str:
    content = message.get("content", [])
    if isinstance(content, str):
        return content
    return "\n".join(str(block.get("text", "")) for block in content
                     if isinstance(block, dict) and block.get("type") == "text")


def user_message(text: str) -> dict[str, Any]:
    return {"role": "user", "content": text, "timestamp": int(time.time() * 1000)}


# Engineering context limits apply uniformly; scientific retrieval order is unchanged.
FINAL_HISTORY_RESERVE_CHARS = 4096
MAX_TOOL_RESULT_CHARS = 8000


def context_chars(system: str, messages: Sequence[Mapping[str, Any]], tools: Any = None) -> int:
    value = {"systemPrompt": system, "messages": messages}
    if tools:
        value["tools"] = tools
    return len(json.dumps(value, ensure_ascii=False))


def visible_assistant(message: Mapping[str, Any], *, text_limit: int | None = None) -> dict[str, Any]:
    """Native history keeps visible text/tool calls; raw responses retain thinking."""
    result = {key: copy.deepcopy(value) for key, value in message.items() if key != "content"}
    content = message.get("content", [])
    if isinstance(content, str):
        content = [{"type": "text", "text": content}]
    blocks = []
    for block in content:
        if not isinstance(block, dict) or block.get("type") not in {"text", "toolCall"}:
            continue
        block = copy.deepcopy(block)
        if block.get("type") == "text" and text_limit is not None:
            block["text"] = str(block.get("text", ""))[:text_limit]
        blocks.append(block)
    result["content"] = blocks
    return result


def project_tool_output(value: Any, budget: int) -> tuple[Any, dict[str, Any]]:
    """Top records and bounded prose; IDs and retained variable roles stay intact.

    The budget counts JSON encoded inside a native text block, including escaped
    quotes. Full returns are stored independently in tool_trace.
    """
    original_sha = sha_json(value)
    def size(item: Any) -> int:
        return len(json.dumps(json.dumps(item, ensure_ascii=False), ensure_ascii=False))
    if size(value) <= budget:
        return value, {"truncated_to_budget": False, "original_sha256": original_sha,
                       "encoded_chars": size(value), "budget_chars": budget}
    def compact(item: Any, chars: int, items: int, key: str = "") -> Any:
        if isinstance(item, str):
            # Identifiers must never become invalid prefixes. Retained variables
            # keep their names, measurement units and scientific role labels.
            protected = key.endswith("_id") or key.endswith("_ids") or key in {
                "role", "name", "raw_name", "unit", "measurement_or_unit", "dataset_id"}
            return item if protected else item[:chars]
        if isinstance(item, Mapping):
            return {str(k): compact(v, chars, items, str(k)) for k, v in item.items()}
        if isinstance(item, (list, tuple)):
            return [compact(v, chars, items, key) for v in item[:items]]
        return item if item is None or isinstance(item, (bool, int, float)) else str(item)[:chars]
    for chars, items in ((240, 10), (160, 7), (100, 5), (60, 3), (40, 2), (24, 1)):
        projected = compact(value, chars, items)
        wrapper = {"truncated_to_budget": True, "original_sha256": original_sha,
                   "projection": {"string_chars": chars, "top_records_per_list": items}, "result": projected}
        if isinstance(value, list):
            wrapper["original_records"] = len(value)
            wrapper["returned_records"] = len(projected)
        if size(wrapper) <= budget:
            return wrapper, {"truncated_to_budget": True, "original_sha256": original_sha,
                             "encoded_chars": size(wrapper), "budget_chars": budget,
                             "string_chars": chars, "top_records_per_list": items,
                             "original_records": len(value) if isinstance(value, list) else None,
                             "returned_records": len(projected) if isinstance(projected, list) else None}
    # No partial JSON and no partial canonical IDs are ever sent. A tool result
    # too large even for one complete projected record reports the omission.
    omitted = {"truncated_to_budget": True, "original_sha256": original_sha,
               "returned_records": 0, "result": [], "note": "No complete record fits remaining conversation budget"}
    return omitted, {"truncated_to_budget": True, "original_sha256": original_sha,
                     "encoded_chars": size(omitted), "budget_chars": budget, "returned_records": 0}


def add_numeric(target: dict[str, Any], source: Mapping[str, Any]) -> None:
    for key, value in source.items():
        if isinstance(value, Mapping):
            child = target.setdefault(key, {})
            if isinstance(child, dict):
                add_numeric(child, value)
        elif isinstance(value, (int, float)) and not isinstance(value, bool):
            target[key] = target.get(key, 0) + value


class UnitFailure(Exception):
    def __init__(self, message: str, *, status: str = "failed", systemic: bool = False):
        super().__init__(safe_text(message))
        self.status = status
        self.systemic = systemic


class PaidDispatchHalt(BaseException):
    """Abort without writing a failed unit when a global cost guard denies dispatch."""


class BridgeClient:
    """One persistent native Pi SDK bridge per worker; stderr cannot reveal secrets."""
    def __init__(self, agent_root: Path, bridge_path: Path | None = None):
        self.agent_root = Path(agent_root)
        self.bridge_path = bridge_path or Path(__file__).with_name("runtime_bridge.mjs")
        self.process: subprocess.Popen[str] | None = None
        self.sequence = 0

    def _start(self) -> None:
        if self.process is None or self.process.poll() is not None:
            self.close()
            self.process = subprocess.Popen(
                ["node", str(self.bridge_path), str(self.agent_root)],
                stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                text=True, encoding="utf-8", bufsize=1,
                env={**os.environ, "OCEAN_COST_GROUP": "E1"},
            )

    def request(self, payload: Mapping[str, Any], timeout: float) -> dict[str, Any]:
        binding = payload.get("e1_binding") or {}
        scoped = (os.environ.get("OCEAN_E1_SCOPE_ID") and binding.get("scope_id") == os.environ.get("OCEAN_E1_SCOPE_ID"))
        if payload.get("kind") == "complete" and (ROOT.parent / "STOP_PAID_DISPATCH").exists() and not scoped:
            raise PaidDispatchHalt("Paid model dispatch paused by experiments/STOP_PAID_DISPATCH")
        self._start()
        assert self.process and self.process.stdin and self.process.stdout
        self.sequence += 1
        request = {"id": self.sequence, **payload}
        try:
            self.process.stdin.write(json.dumps(request, ensure_ascii=False) + "\n")
            self.process.stdin.flush()
            ready, _, _ = select.select([self.process.stdout], [], [], max(0.01, timeout))
            if not ready:
                self.close()
                raise UnitFailure("Native model bridge exceeded request timeout")
            line = self.process.stdout.readline()
            if not line:
                self.close()
                raise UnitFailure("Native model bridge stopped without a response")
            result = json.loads(line)
            if result.get("ok") is False and any(x in str(result.get("error", "")) for x in ("Paid model dispatch paused", "PAID_DISPATCH_DENIED")):
                raise PaidDispatchHalt(result["error"])
            if not isinstance(result, dict) or result.get("id") != self.sequence:
                self.close()
                raise UnitFailure("Native model bridge returned an invalid response binding")
            return result
        except (OSError, ValueError) as exc:
            self.close()
            raise UnitFailure(f"Native model bridge transport error: {safe_text(exc)}") from None

    def close(self) -> None:
        process, self.process = self.process, None
        if process is not None:
            if process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=2)
            for handle in (process.stdin, process.stdout):
                if handle:
                    handle.close()


class Blocker:
    def __init__(self) -> None:
        self.lock = threading.Lock()
        self.reason: str | None = None

    def set(self, reason: str) -> None:
        with self.lock:
            if self.reason is None:
                self.reason = safe_text(reason)


def is_systemic(result: Mapping[str, Any]) -> bool:
    statuses = result.get("http_statuses", [])
    if any((entry.get("status") if isinstance(entry, dict) else entry) in (401, 402)
           for entry in statuses):
        return True
    return bool(re.search(r"\b(?:401|402)\b|insufficient[_ ](?:balance|quota)|payment required|invalid api key|unauthorized",
                          str(result.get("error", "")), re.I))


def load_compiler(agent_root: Path) -> dict[str, Any]:
    """Capture the original pure prompt builder; never invoke its model client."""
    path = agent_root / "experiments/agent_e1_taskcompiler/run_experiment.py"
    spec = importlib.util.spec_from_file_location("paper_e1_original_compiler", path)
    if spec is None or spec.loader is None:
        raise ValueError("Original TaskCompiler helper is unavailable")
    module = importlib.util.module_from_spec(spec)
    old = sys.dont_write_bytecode
    try:
        sys.dont_write_bytecode = True
        spec.loader.exec_module(module)
    finally:
        sys.dont_write_bytecode = old
    schema_path = path.parent / "schemas/scientific_task_spec.schema.json"
    schema = json.loads(schema_path.read_text(encoding="utf-8"))
    captured: dict[str, Any] = {}
    def capture(_common: Any, **kwargs: Any) -> tuple[dict, str, dict]:
        captured.update(kwargs)
        return {}, "", {}
    module.call_json_with_retry = capture
    marker = "E1_QUERY_PLACEHOLDER_9841"
    module.compile_task_spec(None, query=marker, schema=schema, model_config={})
    messages = captured["messages"]
    return {"system": messages[0]["content"], "user_template": messages[1]["content"],
            "marker": marker, "schema": schema, "validate": module.validate_task_spec,
            "reject_ids": module.reject_known_dataset_ids,
            "source_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "schema_sha256": hashlib.sha256(schema_path.read_bytes()).hexdigest(),
            "prompt_sha256": sha_json(messages)}


def exact_key(value: str) -> str:
    return unicodedata.normalize("NFKC", value).strip().casefold()


class ExactMapper:
    """Post-generation exact mapping, with ambiguity and duplicate ranks retained."""
    def __init__(self, corpus: Sequence[Mapping[str, Any]]):
        self.index: dict[str, set[str]] = {}
        self.canonical = {str(card["dataset_id"]) for card in corpus}
        for card in corpus:
            dataset_id = str(card["dataset_id"])
            values = [dataset_id, card.get("product_id"), card.get("product_name"), card.get("name")]
            aliases = card.get("aliases", [])
            if isinstance(aliases, list):
                values.extend(aliases)
            for access in card.get("access", []) if isinstance(card.get("access"), list) else []:
                if isinstance(access, dict):
                    values.append(access.get("url"))
            for value in values:
                if isinstance(value, str) and value.strip() and exact_key(value) not in {"unresolved", "unknown", "not_reported"}:
                    self.index.setdefault(exact_key(value), set()).add(dataset_id)

    def map(self, records: Sequence[Mapping[str, Any]]) -> tuple[list[str | None], list[dict[str, Any]]]:
        ranking: list[str | None] = []
        audit = []
        seen: set[str] = set()
        for rank, record in enumerate(records, 1):
            matched: set[str] = set()
            signals = []
            for field in ("product_id", "name", "url"):
                value = record.get(field)
                ids = self.index.get(exact_key(value), set()) if isinstance(value, str) else set()
                if ids:
                    matched.update(ids)
                signals.append({"field": field, "value": value, "exact_matches": sorted(ids)})
            chosen = next(iter(matched)) if len(matched) == 1 else None
            resolution = "exact_unique" if chosen else ("ambiguous" if matched else "unmapped")
            if chosen in seen:
                chosen, resolution = None, "duplicate_canonical_id"
            if chosen:
                seen.add(chosen)
            ranking.append(chosen)
            audit.append({"rank": rank, "signals": signals, "candidate_ids": sorted(matched),
                          "dataset_id": chosen, "resolution": resolution})
        return ranking, audit


def validate_ranking(value: Any, canonical: set[str], candidates: set[str] | None = None) -> list[str]:
    if not isinstance(value, dict) or set(value) != {"ranking"} or not isinstance(value["ranking"], list):
        raise ValueError("Output must contain only a ranking array")
    if len(value["ranking"]) != 20:
        raise ValueError("ranking must have exactly 20 records")
    ranking = []
    for record in value["ranking"]:
        if (not isinstance(record, dict) or set(record) != {"dataset_id", "reason"}
                or not isinstance(record["dataset_id"], str)
                or not isinstance(record["reason"], str) or not record["reason"].strip()):
            raise ValueError("Each ranking record must contain dataset_id and a nonempty reason")
        dataset_id = record["dataset_id"]
        if dataset_id not in canonical or (candidates is not None and dataset_id not in candidates):
            raise ValueError("ranking contains an ID outside the permitted candidate set")
        ranking.append(dataset_id)
    if len(set(ranking)) != 20:
        raise ValueError("ranking must have 20 unique canonical IDs")
    return ranking


def validate_direct(value: Any) -> list[dict[str, Any]]:
    if not isinstance(value, dict) or set(value) != {"ranking"} or not isinstance(value["ranking"], list):
        raise ValueError("Output must contain only a ranking array")
    records = value["ranking"]
    if len(records) != 20:
        raise ValueError("ranking must contain exactly 20 products")
    for record in records:
        if not isinstance(record, dict) or set(record) != {"product_id", "name", "url"}:
            raise ValueError("Each product must contain product_id, name, and url")
        if any(item is not None and not isinstance(item, str) for item in record.values()):
            raise ValueError("Product fields must be string or null")
        if not any(isinstance(item, str) and item.strip() for item in record.values()):
            raise ValueError("Each product needs at least one nonempty identifying field")
    return records


RANKING_CONTRACT = ('Return only valid JSON with this exact shape: '
                    '{"ranking":[{"dataset_id":"canonical ID","reason":"brief relevance reason"}]}. '
                    'The ranking must contain exactly 20 unique canonical dataset IDs, in descending relevance. ')
DIRECT_CONTRACT = ('Return only valid JSON with this exact shape: '
                   '{"ranking":[{"product_id":"product identifier or null","name":"product name or null",'
                   '"url":"official product URL or null"}]}. Return exactly 20 products in descending relevance. '
                   'Use actual JSON null when a field is unknown. Do not invent identifiers or URLs. ')


def tool_definitions() -> list[dict[str, Any]]:
    def obj(properties: dict, required: list[str]) -> dict:
        return {"type": "object", "properties": properties, "required": required, "additionalProperties": False}
    return [
        {"name": "search_datasets", "description": "Search the canonical DatasetCard catalog with query text.",
         "parameters": obj({"query": {"type": "string"}, "limit": {"type": "integer", "minimum": 1, "maximum": 20}}, ["query"])},
        {"name": "search_knowledge", "description": "Search policy-admitted PSC/UBC and DatasetCard evidence.",
         "parameters": obj({"query": {"type": "string"}, "card_type": {"type": "string", "enum": ["all", "PSC", "UBC", "DatasetCard"]}, "limit": {"type": "integer", "minimum": 1, "maximum": 10}}, ["query"])},
        {"name": "get_bundle", "description": "Read a policy-admitted usage bundle by its bundle ID.",
         "parameters": obj({"bundle_id": {"type": "string"}}, ["bundle_id"])},
        {"name": "submit_dataset_ranking", "description": "Submit exactly 20 unique canonical dataset IDs with brief reasons.",
         "parameters": obj({"ranking": {"type": "array", "minItems": 20, "maxItems": 20,
             "items": obj({"dataset_id": {"type": "string"}, "reason": {"type": "string"}}, ["dataset_id", "reason"])}}, ["ranking"])},
    ]


class E1Runner:
    def __init__(self, root: Path, config: dict[str, Any], retrieval: Any, *,
                 bridge_factory: Callable[[], Any] | None = None, blocker: Blocker | None = None,
                 compiler: dict[str, Any] | None = None):
        self.root, self.config, self.retrieval = Path(root), config, retrieval
        self.config_sha = hashlib.sha256((self.root / "config.json").read_bytes()).hexdigest()
        self.canonical = set(retrieval.by_id)
        self.mapper = ExactMapper(retrieval.corpus)
        self.bridge_factory = bridge_factory or (lambda: BridgeClient(Path(config["agent_root"])))
        self.bridge: Any = None
        self.actual_model: Any = None
        self.blocker = blocker or Blocker()
        self.compiler = compiler
        self.implementation_sha256 = {}
        for filename in ("run.py", "retrieval.py", "runtime_bridge.mjs"):
            source = Path(__file__).with_name(filename)
            self.implementation_sha256[filename] = hashlib.sha256(source.read_bytes()).hexdigest() if source.is_file() else None

    def close(self) -> None:
        if self.bridge is not None:
            self.bridge.close()

    def cache_path(self, method: str, query_id: str) -> Path:
        slug = re.sub(r"[^a-z0-9]+", "_", method.casefold()).strip("_")
        if not re.fullmatch(r"[A-Za-z0-9_-]+", query_id):
            raise ValueError("Unsafe query identifier")
        return self.root / "cache/units" / slug / f"{query_id}.json"

    def _remaining(self, state: dict[str, Any]) -> float:
        remaining = float(self.config["unit_timeout_seconds"]) - (time.monotonic() - state["clock"])
        if remaining <= 0:
            raise UnitFailure("Unit wall-clock budget exhausted")
        return remaining

    def _model(self, state: dict[str, Any]) -> None:
        if self.blocker.reason:
            raise UnitFailure(self.blocker.reason, status="unavailable", systemic=True)
        if self.bridge is None:
            self.bridge = self.bridge_factory()
        if self.actual_model is None:
            result = self.bridge.request({"kind": "info", "model": self.config["model"]},
                                         min(15, self._remaining(state)))
            if result.get("ok") is False or not isinstance(result.get("model"), dict):
                reason = safe_text(result.get("error", "Configured model unavailable"))
                if is_systemic(result):
                    self.blocker.set(reason)
                raise UnitFailure(reason, status="unavailable", systemic=is_systemic(result))
            # Persist the selected public model configuration, never provider credentials.
            self.actual_model = result["model"]
        state["row"]["model_actual"] = copy.deepcopy(self.actual_model)

    def _complete(self, state: dict[str, Any], system: str, messages: list[dict[str, Any]],
                  *, tools: list[dict[str, Any]] | None = None, stage: str) -> dict[str, Any]:
        self._model(state)
        row = state["row"]
        self._fit_tool_history(state, system, messages, tools)
        context = {"systemPrompt": system, "messages": messages}
        if tools:
            context["tools"] = tools
        prompt_chars = len(json.dumps(context, ensure_ascii=False))
        if prompt_chars > self.config["max_prompt_chars"]:
            raise UnitFailure(f"Prompt exceeds frozen max_prompt_chars ({prompt_chars})")
        for attempt in range(int(self.config["network_attempts"])):
            if self.blocker.reason:
                raise UnitFailure(self.blocker.reason, status="unavailable", systemic=True)
            if row["llm_calls"] >= self.config["max_llm_calls_per_unit"]:
                raise UnitFailure("LLM call budget exhausted")
            remaining = self._remaining(state)
            timeout = min(float(self.config["request_timeout_seconds"]), remaining)
            request = {"kind": "complete", "model": self.config["model"], "context": context,
                       "max_tokens": self.config["max_output_tokens_per_call"],
                       "timeout_ms": max(1, int(timeout * 1000))}
            scope_id = os.environ.get("OCEAN_E1_SCOPE_ID")
            if scope_id:
                request["e1_binding"] = {"scope_id": scope_id, "method": row["method"],
                    "query_id": row["query_id"], "stage": stage, "attempt": attempt + 1,
                    "config_sha256": self.config_sha}
            digest = sha_json(request)
            row["request_sha256"].append(digest)
            row["llm_calls"] += 1
            if attempt:
                row["retry_counts"]["network"] += 1
            try:
                result = self.bridge.request(request, min(timeout + 2, self._remaining(state)))
            except UnitFailure as exc:
                result = {"ok": False, "error": str(exc)}
            public = {key: value for key, value in result.items() if key in
                      ("ok", "response", "elapsed_ms", "http_statuses", "error", "request_mode",
                       "provider_usage", "provider_model", "budget_settlement", "actual_http_dispatches")}
            if "error" in public:
                public["error"] = safe_text(public["error"])
            row["raw_responses"].append({"stage": stage, "network_attempt": attempt + 1,
                                         "request_sha256": digest, **public})
            response = result.get("response")
            if isinstance(response, dict) and isinstance(response.get("usage"), dict):
                add_numeric(row["usage"], response["usage"])
            row["stages"].append({"stage": stage, "call": row["llm_calls"],
                                   "request_sha256": digest, "prompt_chars": prompt_chars,
                                   "ok": bool(result.get("ok")), "elapsed_ms": result.get("elapsed_ms")})
            if result.get("ok") and isinstance(response, dict):
                return response
            error = safe_text(result.get("error", "Native model request failed"))
            if is_systemic(result):
                self.blocker.set(error)
                raise UnitFailure(error, status="unavailable", systemic=True)
            # Schema/tool parameter errors are deterministic and must not consume a network retry.
            transient = not result.get("http_statuses") or any(
                (entry.get("status", 0) if isinstance(entry, dict) else entry) in (408, 409, 425, 429)
                or (entry.get("status", 0) if isinstance(entry, dict) else entry) >= 500
                for entry in result.get("http_statuses", []))
            if scope_id and os.environ.get("OCEAN_E1_GRANT_KIND") != "formal":
                # A transport failure may already be billed. The scoped trial
                # retries only explicit HTTP429, never an ambiguous lost reply.
                transient = any(entry.get("status") == 429 for entry in result.get("http_statuses", []) if isinstance(entry, dict))
            if not transient or attempt + 1 >= self.config["network_attempts"]:
                raise UnitFailure(error)
            if scope_id:
                time.sleep(min(2 ** attempt, 4, max(0, self._remaining(state) - .01)))
        raise UnitFailure("Native model request attempts exhausted")

    def _fit_tool_history(self, state: dict[str, Any], system: str, messages: list[dict[str, Any]],
                          tools: Any = None, reserve: int = 0) -> None:
        limit = int(self.config["max_prompt_chars"]) - reserve
        for message in messages:
            current = context_chars(system, messages, tools)
            if current <= limit:
                break
            if message.get("role") != "toolResult":
                continue
            source = state.get("tool_outputs", {}).get(message.get("toolCallId"))
            if source is None:
                continue
            old_text = message.get("content", [{}])[0].get("text", "")
            old_cost = len(json.dumps(old_text, ensure_ascii=False))
            budget = max(256, old_cost - (current - limit) - 64)
            projected, audit = project_tool_output(source, budget)
            message["content"] = [{"type": "text", "text": json.dumps(projected, ensure_ascii=False)}]
            state["row"].setdefault("context_projections", []).append(
                {"stage": "history_rebudget", "tool_call_id": message.get("toolCallId"), **audit})

    def _repair_history(self, state: dict[str, Any], system: str, messages: list[dict[str, Any]],
                        response: Mapping[str, Any], error: str, tools: Any = None) -> None:
        repair = user_message(error)
        visible = visible_assistant(response)
        # Reserve the next repair instruction before measuring visible output.
        available = int(self.config["max_prompt_chars"]) - context_chars(system, messages + [repair], tools) - 1024
        text = assistant_text(visible)
        visible = visible_assistant(response, text_limit=max(0, available // 2))
        # This is a format repair, so only visible text is replayed, never tool
        # calls or thinking; the original unmodified message stays in raw_responses.
        visible["content"] = [{"type": "text", "text": assistant_text(visible)}] if text else []
        if assistant_text(visible).strip():
            messages.append(visible)
        messages.append(repair)
        self._fit_tool_history(state, system, messages, tools)
        state["row"].setdefault("context_projections", []).append({"stage": "format_repair_history",
            "original_response_sha256": sha_json(response), "thinking_replayed": False,
            "visible_text_chars": len(text), "replayed_text_chars": len(assistant_text(visible))})

    def _json_call(self, state: dict[str, Any], system: str, text: str,
                   validator: Callable[[Any], Any], *, stage: str) -> Any:
        messages = [user_message(text)]
        while True:
            response = self._complete(state, system, messages, stage=stage)
            try:
                parsed = parse_json_text(assistant_text(response))
                return validator(parsed)
            except (ValueError, TypeError, KeyError) as exc:
                if state["row"]["retry_counts"]["format_repair"] >= self.config["format_repair_attempts"]:
                    raise UnitFailure(f"Invalid {stage} output: {safe_text(exc)}") from None
                state["row"]["retry_counts"]["format_repair"] += 1
                self._repair_history(state, system, messages, response,
                    "Repair the JSON format only. " + safe_text(exc) + " Follow the original output contract exactly.")

    def _compile(self, state: dict[str, Any], query: str) -> dict[str, Any]:
        if self.compiler is None:
            self.compiler = load_compiler(Path(self.config["agent_root"]))
        compiler = self.compiler
        def validate(value: Any) -> dict[str, Any]:
            if not isinstance(value, dict):
                raise ValueError("ScientificTaskSpec must be an object")
            compiler["validate"](value)
            compiler["reject_ids"](value, self.canonical)
            return value
        text = compiler["user_template"].replace(compiler["marker"], query)
        text += "\nReturn only JSON conforming to ScientificTaskSpec:\n" + json.dumps(compiler["schema"], ensure_ascii=False)
        value = self._json_call(state, compiler["system"], text, validate, stage="task_compiler")
        state["row"]["task_spec"] = value
        state["row"]["evidence_audit"]["task_compiler"] = {
            "source_sha256": compiler["source_sha256"], "schema_sha256": compiler["schema_sha256"], "prompt_sha256": compiler["prompt_sha256"],
            "input": "natural_query_only", "dataset_agnostic_validation": True}
        return value

    def _ocean(self, state: dict[str, Any], query: str) -> list[str]:
        task_spec = self._compile(state, query)
        candidates = self.retrieval.requirement_candidates(task_spec, pool_size=self.config["candidate_pool_size"])
        initial_ids = [str(card["dataset_id"]) for card in candidates]
        state["row"]["evidence_audit"]["initial_candidate_ids"] = initial_ids
        state["row"]["components"] = ["existing_TaskCompiler_prompt_schema", "legacy_requirement_candidates",
                                          "policy_filtered_in_memory_retrieval_tools", "native_Pi_SDK_tool_loop"]
        system = ("You are OceanAgent performing scientific dataset recommendation. Use the generated ScientificTaskSpec "
                  "and the available in-memory retrieval tools to inspect evidence, refine observations, quality-control "
                  "and validation coverage, and choose a scientifically sufficient dataset bundle. Retrieve additional "
                  "evidence when useful. Only canonical DatasetCard IDs are valid recommendations. "
                  "Finish with submit_dataset_ranking or the final JSON contract. " + RANKING_CONTRACT)
        messages = [user_message(json.dumps({"research_question": query, "scientific_task_spec": task_spec,
                     "initial_requirement_candidates": candidates}, ensure_ascii=False, sort_keys=True))]
        tools = tool_definitions()
        while True:
            # Reserve the last remaining call for an explicit final JSON answer.
            final = (state["row"]["llm_calls"] >= self.config["max_llm_calls_per_unit"] - 1
                     or state["row"]["tool_calls"] >= self.config["max_tool_calls_per_unit"])
            if final:
                messages.append(user_message("The retrieval budget is complete. Return your final ranking now. " + RANKING_CONTRACT))
            response = self._complete(state, system, messages, tools=None if final else tools,
                                      stage="agent_final" if final else "agent_tool_loop")
            blocks = response.get("content", [])
            calls = [block for block in blocks if isinstance(block, dict) and block.get("type") == "toolCall"] if isinstance(blocks, list) else []
            if not calls:
                try:
                    return validate_ranking(parse_json_text(assistant_text(response)), self.canonical)
                except (ValueError, TypeError, KeyError) as exc:
                    if (state["row"]["retry_counts"]["format_repair"] >= self.config["format_repair_attempts"]
                            or state["row"]["llm_calls"] >= self.config["max_llm_calls_per_unit"]):
                        raise UnitFailure(f"Invalid OceanAgent final ranking: {safe_text(exc)}") from None
                    state["row"]["retry_counts"]["format_repair"] += 1
                    self._repair_history(state, system, messages, response,
                        "Repair the final JSON only. " + safe_text(exc) + " " + RANKING_CONTRACT,
                        tools=None if final else tools)
                    continue
            messages.append(visible_assistant(response))
            self._fit_tool_history(state, system, messages, tools, reserve=FINAL_HISTORY_RESERVE_CHARS)
            if final:
                raise UnitFailure("OceanAgent issued tools after the final-output boundary")
            submitted: list[str] | None = None
            for call_index, call in enumerate(calls):
                if state["row"]["tool_calls"] >= self.config["max_tool_calls_per_unit"]:
                    output, error = {"error": "Tool call budget exhausted; return final JSON"}, True
                else:
                    state["row"]["tool_calls"] += 1
                    output, error, ranking = self._execute_tool(call)
                    if call.get("name") == "submit_dataset_ranking" and error:
                        if state["row"]["retry_counts"]["format_repair"] >= self.config["format_repair_attempts"]:
                            raise UnitFailure("Invalid ranking submission after the format repair budget was exhausted")
                        state["row"]["retry_counts"]["format_repair"] += 1
                    if ranking is not None:
                        submitted = ranking
                    state["row"]["tool_trace"].append({"tool": call.get("name"), "arguments": call.get("arguments"),
                        "is_error": error, "result": output})
                call_id = str(call.get("id", ""))
                state.setdefault("tool_outputs", {})[call_id] = copy.deepcopy(output)
                available = (int(self.config["max_prompt_chars"]) - context_chars(system, messages, tools)
                             - FINAL_HISTORY_RESERVE_CHARS - 512 * (len(calls) - call_index))
                budget = max(256, min(MAX_TOOL_RESULT_CHARS, available // max(1, len(calls) - call_index)))
                projected, projection = project_tool_output(output, budget)
                state["row"].setdefault("context_projections", []).append(
                    {"stage": "tool_return", "tool_call_id": call_id, **projection})
                messages.append({"role": "toolResult", "toolCallId": call_id,
                    "toolName": str(call.get("name", "")), "content": [{"type": "text", "text": json.dumps(projected, ensure_ascii=False)}],
                    "isError": error, "timestamp": int(time.time() * 1000)})
            if submitted is not None:
                return submitted

    def _execute_tool(self, call: Mapping[str, Any]) -> tuple[Any, bool, list[str] | None]:
        name, args = call.get("name"), call.get("arguments")
        try:
            if not isinstance(args, dict):
                raise ValueError("Tool arguments must be a JSON object")
            if name == "submit_dataset_ranking":
                ranking = validate_ranking(args, self.canonical)
                return {"accepted": True, "ranking": ranking}, False, ranking
            if name == "search_datasets":
                if set(args) - {"query", "limit"} or not isinstance(args.get("query"), str):
                    raise ValueError("search_datasets requires a query string")
                limit = args.get("limit", 10)
                if not isinstance(limit, int) or isinstance(limit, bool) or not 1 <= limit <= 20:
                    raise ValueError("search_datasets limit must be 1..20")
                return self.retrieval.search_datasets(args["query"], limit=limit), False, None
            if name == "search_knowledge":
                if set(args) - {"query", "card_type", "limit"} or not isinstance(args.get("query"), str):
                    raise ValueError("search_knowledge requires a query string")
                limit, card_type = args.get("limit", 5), args.get("card_type", "all")
                if not isinstance(limit, int) or isinstance(limit, bool) or not 1 <= limit <= 10 or card_type not in {"all", "PSC", "UBC", "DatasetCard"}:
                    raise ValueError("Invalid search_knowledge card_type or limit")
                return self.retrieval.search_knowledge(args["query"], card_type=card_type, limit=limit), False, None
            if name == "get_bundle":
                if set(args) != {"bundle_id"} or not isinstance(args["bundle_id"], str):
                    raise ValueError("get_bundle requires only bundle_id")
                return self.retrieval.get_bundle(args["bundle_id"]), False, None
            raise ValueError("Tool is not in the E1 retrieval allowlist")
        except (ValueError, KeyError, TypeError, PermissionError) as exc:
            return {"error": safe_text(exc)}, True, None

    def _dense(self, query_id: str) -> tuple[list[str], dict[str, Any]]:
        path = self.root / "cache/dense_rankings.json"
        if not path.is_file():
            raise UnitFailure("Actual dense ranking cache is unavailable", status="unavailable")
        value = json.loads(path.read_text(encoding="utf-8"))
        metadata: dict[str, Any] = {"cache_sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
        if isinstance(value, dict):
            if isinstance(value.get("metadata"), dict):
                metadata["embedding_metadata"] = value["metadata"]
            metadata.update({key: value[key] for key in ("model", "embedding_model", "backend", "schema_version") if key in value})
            records = value.get("rankings", value.get("queries", value))
        else:
            records = value
        if isinstance(records, list):
            item = next((row for row in records if isinstance(row, dict) and row.get("query_id") == query_id), None)
        elif isinstance(records, dict):
            item = records.get(query_id)
        else:
            item = None
        if isinstance(item, dict):
            if item.get("status", "success") != "success":
                raise UnitFailure(safe_text(item.get("error", "Actual dense query unavailable")), status="unavailable")
            ranking = item.get("ranking", item.get("dataset_ids"))
            metadata["query_audit"] = {key: item[key] for key in ("elapsed_seconds", "elapsed_ms", "query_encoding_ms", "ranking_ms", "request_sha256", "embedding_usage", "model", "embedding_fingerprint") if key in item}
        else:
            ranking = item
        if isinstance(ranking, list):
            ranking = [record.get("dataset_id") if isinstance(record, dict) else record for record in ranking[:20]]
        if (not isinstance(ranking, list) or len(ranking) != 20 or any(x not in self.canonical for x in ranking)
                or len(set(ranking)) != 20):
            raise UnitFailure("Actual dense cache has no valid 20-ID ranking for this query", status="unavailable")
        return ranking, metadata

    def run_unit(self, method: str, query: Mapping[str, Any], *, resume: bool = False,
                 retry_failed: bool = False) -> dict[str, Any]:
        path = self.cache_path(method, str(query["query_id"]))
        previous = None
        if path.is_file():
            previous = json.loads(path.read_text(encoding="utf-8"))
            if previous.get("config_sha256") != self.config_sha:
                raise ValueError(f"Cached unit has a different frozen config: {path}")
            if not resume:
                raise ValueError(f"Final unit exists; use --resume to preserve it: {path}")
            if not retry_failed or previous.get("status") == "success":
                return previous
        start = time.monotonic()
        row: dict[str, Any] = {
            "schema_version": self.config["schema_version"], "method": method,
            **{key: query[key] for key in ("split", "task_id", "query_id", "query_variant", "query")},
            "status": "failed", "ranking": [], "available_depth": 20,
            "config_sha256": self.config_sha, "config": copy.deepcopy(self.config),
            "model": self.config["model"], "model_actual": None, "usage": {},
            "elapsed_seconds": 0.0, "llm_calls": 0, "tool_calls": 0,
            "raw_responses": [], "request_sha256": [], "evidence_audit": {}, "tool_trace": [], "stages": [],
            "components": [], "implementation_sha256": copy.deepcopy(self.implementation_sha256), "started_utc": utc_now(), "finished_utc": None, "error": None,
            "retry_counts": {"network": 0, "format_repair": 0, "unit": 0}, "attempts": [],
        }
        if previous is not None:
            row["attempts"] = previous.get("attempts", []) + [{key: value for key, value in previous.items() if key != "attempts"}]
            row["retry_counts"]["unit"] = len(row["attempts"])
        state = {"row": row, "clock": start}
        try:
            if method not in METHODS:
                raise UnitFailure("Unknown E1 method")
            if method == "BM25 Retrieval":
                ranked = self.retrieval.bm25(str(query["query"]), k=20)
                ranking = [str(item["dataset_id"]) if isinstance(item, dict) else str(item) for item in ranked]
                row["components"] = ["legacy_BM25_corpus_retrieval"]
                row["evidence_audit"] = {"candidate_ids": ranking, "query_input": "natural_query_only"}
            elif method == "Dense Retrieval":
                ranking, audit = self._dense(str(query["query_id"]))
                row["components"] = ["actual_embedding_cosine_retrieval_cache"]
                row["evidence_audit"] = audit
            elif method == "Direct LLM":
                row["components"] = ["native_Pi_SDK_direct_generation", "post_generation_exact_canonical_mapping"]
                records = self._json_call(state, "Recommend existing marine datasets for the user's research question. " + DIRECT_CONTRACT,
                                         "Research question:\n" + str(query["query"]), validate_direct, stage="direct_generation")
                ranking, audit = self.mapper.map(records)
                row["mapping_audit"] = audit
                row["mapping_coverage"] = {"mapped": sum(item is not None for item in ranking), "total": 20,
                                            "fraction": sum(item is not None for item in ranking) / 20,
                                            "resolutions": dict(Counter(item["resolution"] for item in audit))}
                row["evidence_audit"] = {"retrieval_used": False, "catalog_shortlist_in_prompt": False,
                                           "mapping": "post_generation_exact_only_no_rank_promotion"}
            elif method in {"Flat RAG Agent", "StructuredRAG", "GraphRAG"}:
                context = self.retrieval.fixed_context(str(query["query"]), method=method,
                                pool_size=self.config["candidate_pool_size"], context_cards=self.config["context_cards"])
                row["evidence_audit"] = context["audit"]
                row["evidence_audit"]["candidate_ids"] = context["candidate_ids"]
                row["components"] = ["method_specific_frozen_retrieval_context", "native_Pi_SDK_single_ranking_stage"]
                payload = {"research_question": query["query"], "candidate_dataset_cards": context["candidates"],
                           "evidence": context["evidence"]}
                ranking = self._json_call(state, "Rank supplied datasets for the user's research question using the supplied evidence. "
                                         + RANKING_CONTRACT + "Use only IDs from candidate_dataset_cards.",
                                         json.dumps(payload, ensure_ascii=False, sort_keys=True),
                                         lambda value: validate_ranking(value, self.canonical, set(context["candidate_ids"])), stage="fixed_context_rank")
            else:
                ranking = self._ocean(state, str(query["query"]))
            if (len(ranking) != 20 or any(item is not None and item not in self.canonical for item in ranking)
                    or len([item for item in ranking if item is not None]) != len(set(item for item in ranking if item is not None))):
                raise UnitFailure("Final ranking violates the canonical 20-slot output contract")
            self._remaining(state)
            row["ranking"], row["status"] = ranking, "success"
        except UnitFailure as exc:
            row["status"], row["error"] = exc.status, str(exc)
        except Exception as exc:
            row["status"], row["error"] = "failed", f"{type(exc).__name__}: {safe_text(exc)}"
        row["elapsed_seconds"] = time.monotonic() - start
        row["finished_utc"] = utc_now()
        atomic_json(path, row)
        return row


def consolidate(root: Path, config_sha: str, queries: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    population = {(row["split"], row["query_id"]) for row in queries}
    rows, seen = [], set()
    for path in sorted((root / "cache/units").glob("*/*.json")):
        row = json.loads(path.read_text(encoding="utf-8"))
        key = (row.get("method"), row.get("split"), row.get("query_id"))
        if row.get("config_sha256") != config_sha or key[0] not in METHODS or key[1:] not in population:
            raise ValueError(f"Unit cache is outside frozen configuration/population: {path}")
        if key in seen or row.get("status") not in FINAL_STATUSES:
            raise ValueError(f"Duplicate or unfinished unit cache: {path}")
        seen.add(key)
        rows.append(row)
    method_order = {method: index for index, method in enumerate(METHODS)}
    query_order = {(row["split"], row["query_id"]): index for index, row in enumerate(queries)}
    rows.sort(key=lambda row: (method_order[row["method"]], query_order[row["split"], row["query_id"]]))
    target = root / "e1_predictions.jsonl"
    descriptor, name = tempfile.mkstemp(prefix=".predictions-", suffix=".tmp", dir=root)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            for row in rows:
                handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(name, target)
    finally:
        if os.path.exists(name):
            os.unlink(name)
    return rows


def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--methods", action="append", help="Repeat or comma-separate frozen method names")
    parser.add_argument("--split", choices=("dev", "test", "both"), default="both")
    parser.add_argument("--limit", type=int)
    parser.add_argument("--query-id", action="append", default=[])
    parser.add_argument("--workers", type=int)
    parser.add_argument("--output-dir", type=Path, help="Write new unit outputs outside the source directory")
    parser.add_argument("--execute", action="store_true", help="Required acknowledgement before real execution")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--retry-failed", action="store_true", help="With --resume, retry failed/unavailable units and retain attempts")
    return parser.parse_args(argv)


def main(argv: Sequence[str] | None = None) -> int:
    args = parse_args(argv)
    config = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))
    config_sha = hashlib.sha256((ROOT / "config.json").read_bytes()).hexdigest()
    all_queries = read_jsonl(ROOT / "runtime_queries.jsonl")
    query_keys = [(row["split"], row["query_id"]) for row in all_queries]
    if len(all_queries) != config["runtime_queries"] or len(set(query_keys)) != len(all_queries):
        raise ValueError("Frozen runtime population count or unique query binding mismatch")
    if tuple(config["methods"]) != METHODS:
        raise ValueError("Frozen methods differ from runner contract")
    methods = [item.strip() for group in (args.methods or list(METHODS)) for item in group.split(",")]
    if len(set(methods)) != len(methods) or any(method not in METHODS for method in methods):
        raise ValueError("Methods must be unique frozen E1 method names")
    if args.retry_failed and not args.resume:
        raise ValueError("--retry-failed requires --resume")
    if args.limit is not None and args.limit < 1:
        raise ValueError("--limit must be positive")
    workers = args.workers if args.workers is not None else config["concurrency"]
    if workers < 1:
        raise ValueError("--workers must be positive")
    requested_ids = {item for group in args.query_id for item in group.split(",")}
    if requested_ids - {row["query_id"] for row in all_queries}:
        raise ValueError("--query-id is outside the frozen runtime population")
    selected = [row for row in all_queries if (args.split == "both" or row["split"] == args.split)
                and (not requested_ids or row["query_id"] in requested_ids)]
    if args.limit is not None:
        selected = selected[:args.limit]
    if not selected:
        raise ValueError("No frozen queries selected")
    if not args.execute:
        print(json.dumps({"execute": False, "selected_queries": len(selected), "methods": methods,
                          "selected_units": len(selected) * len(methods), "workers": workers,
                          "config_sha256": config_sha, "expected_full_units": config["runtime_queries"] * len(METHODS)}))
        return 0
    if (ROOT.parent / "STOP_PAID_DISPATCH").exists():
        raise RuntimeError("Paid model dispatch paused by experiments/STOP_PAID_DISPATCH")
    output_root = args.output_dir.resolve() if args.output_dir else ROOT
    output_root.mkdir(parents=True, exist_ok=True)
    output_config = output_root / "config.json"
    source_config_bytes = (ROOT / "config.json").read_bytes()
    if output_config.exists() and output_config.read_bytes() != source_config_bytes:
        raise ValueError("Output directory has another configuration")
    if not output_config.exists():
        output_config.write_bytes(source_config_bytes)
    # Import only the inference adapter; evaluator and Gold files are never imported.
    script_dir = str(Path(__file__).resolve().parent)
    if script_dir not in sys.path:
        sys.path.insert(0, script_dir)
    from retrieval import E1Retrieval
    retrieval = E1Retrieval(Path(config["knowledge_root"]), agent_root=Path(config["agent_root"]))
    compiler = load_compiler(Path(config["agent_root"])) if "OceanAgent" in methods else None
    blocker, local, runners, runners_lock = Blocker(), threading.local(), [], threading.Lock()
    def run(item: tuple[str, dict[str, Any]]) -> dict[str, Any]:
        if not hasattr(local, "runner"):
            local.runner = E1Runner(output_root, config, retrieval, blocker=blocker, compiler=compiler)
            with runners_lock:
                runners.append(local.runner)
        return local.runner.run_unit(item[0], item[1], resume=args.resume, retry_failed=args.retry_failed)
    # Preflight existing caches before any real call, preventing accidental overwrite.
    probe = E1Runner(output_root, config, retrieval, blocker=blocker, compiler=compiler)
    work = [(method, query) for method in methods for query in selected]
    for method, query in work:
        path = probe.cache_path(method, query["query_id"])
        if path.is_file():
            row = json.loads(path.read_text(encoding="utf-8"))
            if not args.resume or row.get("config_sha256") != config_sha:
                raise ValueError(f"Existing final cache requires matching config and --resume: {path}")
    completed = Counter()
    try:
        with concurrent.futures.ThreadPoolExecutor(max_workers=workers, thread_name_prefix="e1") as executor:
            futures = [executor.submit(run, item) for item in work]
            for future in concurrent.futures.as_completed(futures):
                row = future.result()
                completed[row["status"]] += 1
                if sum(completed.values()) % 25 == 0:
                    consolidate(output_root, config_sha, all_queries)
                print(json.dumps({"method": row["method"], "query_id": row["query_id"],
                                  "status": row["status"], "llm_calls": row["llm_calls"],
                                  "tool_calls": row["tool_calls"], "elapsed_seconds": round(row["elapsed_seconds"], 3),
                                  "error": row["error"]}, ensure_ascii=False), flush=True)
    finally:
        for runner in runners:
            runner.close()
        consolidate(output_root, config_sha, all_queries)
    print(json.dumps({"completed": dict(completed), "systemic_blocker": blocker.reason,
                      "prediction_file": str(output_root / "e1_predictions.jsonl")}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (ValueError, OSError, json.JSONDecodeError) as error:
        print(safe_text(error), file=sys.stderr)
        raise SystemExit(2)
