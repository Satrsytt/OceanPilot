"""Small numerical and integrity tests, with no benchmark supervision."""
import json
from pathlib import Path
import unittest

import numpy as np

from dense_retrieval import CORPUS_FIELDS, corpus_text, mean_pool, normalize, sha256_file, top_k


class DenseMathTests(unittest.TestCase):
    def test_masked_mean_and_normalized_cosine(self):
        hidden = np.array([[[3., 0.], [0., 4.], [100., 100.]]], dtype=np.float32)
        pooled = mean_pool(hidden, np.array([[1, 1, 0]], dtype=np.int64))
        np.testing.assert_allclose(pooled, [[0.6, 0.8]], atol=1e-6)
        documents = normalize(np.array([[3., 4.], [0., 7.], [-3., -4.]], dtype=np.float32))
        scores = documents @ pooled[0]
        ids, values = top_k(["same", "vertical", "opposite"], scores, 3)
        self.assertEqual(ids, ["same", "vertical", "opposite"])
        np.testing.assert_allclose(values, [1., 0.8, -1.], atol=1e-6)

    def test_ties_and_top_k_integrity(self):
        ids, values = top_k(["z", "b", "a", "c"], np.array([0., 1., 1., -1.]), 2)
        self.assertEqual(ids, ["a", "b"])
        self.assertEqual(values, [1., 1.])
        with self.assertRaises(ValueError):
            top_k(["a"], np.array([float("nan")]), 1)
        with self.assertRaises(ValueError):
            normalize(np.zeros((1, 3)))

    def test_serializer_excludes_other_fields(self):
        row = {"dataset_id": "ocean", "description": "海洋", "private": "excluded"}
        actual = json.loads(corpus_text(row))
        self.assertEqual(set(actual), set(CORPUS_FIELDS))
        self.assertEqual(actual["description"], "海洋")
        self.assertNotIn("private", actual)
        self.assertIsNone(actual["provider"])




if __name__ == "__main__":
    unittest.main()
