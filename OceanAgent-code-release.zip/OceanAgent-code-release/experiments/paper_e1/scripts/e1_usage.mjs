/** Consume a cloned response locally; never dispatch a request or retain text. */
export async function captureUsage(response, record) {
  const accept = value => {
    if (typeof value?.model === 'string') record.model = value.model;
    if (typeof value?.id === 'string') record.response_id = value.id;
    if (value?.usage && typeof value.usage === 'object') {
      const raw = value.usage, usage = {};
      for (const key of ['prompt_tokens','completion_tokens','total_tokens','prompt_cache_hit_tokens','prompt_cache_miss_tokens'])
        if (Number.isInteger(raw[key]) && raw[key] >= 0) usage[key] = raw[key];
      for (const [key, field] of [['prompt_tokens_details','cached_tokens'],['completion_tokens_details','reasoning_tokens']])
        if (Number.isInteger(raw[key]?.[field]) && raw[key][field] >= 0) usage[key] = {[field]:raw[key][field]};
      record.usage = usage;
    }
  };
  try {
    if (!(response.headers.get('content-type') || '').includes('text/event-stream')) {
      accept(await response.json()); return;
    }
    const reader = response.body.getReader(), decoder = new TextDecoder(); let pending = '';
    while (true) {
      const {value, done} = await reader.read();
      pending += decoder.decode(value, {stream:!done});
      const lines = pending.split('\n'); pending = lines.pop() || '';
      for (const line of lines) if (line.startsWith('data:') && line.slice(5).trim() !== '[DONE]') {
        try { accept(JSON.parse(line.slice(5))); } catch {}
      }
      if (pending.length > 1024 * 1024) throw Error('provider capture line exceeds bound');
      if (done) break;
    }
  } catch (e) { record.capture_error = String(e?.name || 'capture_error'); }
}
