"""Inference-runner contract tests. All model requests are mocks."""
from __future__ import annotations

import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

SPEC = importlib.util.spec_from_file_location("paper_e1_run_tested", Path(__file__).with_name("run.py"))
run = importlib.util.module_from_spec(SPEC)
assert SPEC and SPEC.loader
SPEC.loader.exec_module(run)


def assistant(text=None, calls=None):
    blocks = [{"type": "text", "text": text}] if text is not None else []
    blocks.extend(calls or [])
    return {"role": "assistant", "content": blocks, "api": "openai-completions",
            "provider": "mock", "model": "mock-model", "stopReason": "toolUse" if calls else "stop",
            "usage": {"input": 3, "output": 2, "cacheRead": 1, "cost": {"total": 0.01}}, "timestamp": 1}


def result(message):
    return {"ok": True, "response": message, "elapsed_ms": 5, "http_statuses": [{"status": 200}]}


def ranking(ids):
    return {"ranking": [{"dataset_id": item, "reason": "matches observations"} for item in ids[:20]]}


class MockBridge:
    def __init__(self, responses):
        self.responses = list(responses)
        self.requests = []
        self.closed = False

    def request(self, payload, timeout):
        self.requests.append(copy.deepcopy(payload))
        if payload["kind"] == "info":
            return {"model": {"id": "mock-model", "provider": "mock", "reasoning": False}}
        if not self.responses:
            raise AssertionError("Unexpected model call")
        return self.responses.pop(0)

    def close(self):
        self.closed = True


class MockRetrieval:
    def __init__(self):
        self.corpus = [{"dataset_id": f"d{i:02d}", "product_id": f"p{i:02d}",
                        "product_name": f"Product {i}", "aliases": [f"alias {i}"],
                        "access": [{"url": f"https://example.org/{i}"}]} for i in range(30)]
        self.by_id = {row["dataset_id"]: row for row in self.corpus}
        self.calls = []
        self.audit = {"policy": "test-policy"}

    def bm25(self, query, k=20):
        self.calls.append(("bm25", query, k))
        return list(self.by_id)[:k]

    def fixed_context(self, query, method, pool_size, context_cards):
        self.calls.append(("fixed", query, method))
        return {"candidate_ids": list(self.by_id), "candidates": self.corpus,
                "evidence": {"method": method}, "audit": {"method": method}}

    def requirement_candidates(self, task_spec, pool_size):
        self.calls.append(("requirements", task_spec))
        return self.corpus[:pool_size]

    def search_datasets(self, query, limit):
        self.calls.append(("search_datasets", query))
        return self.corpus[:limit]

    def search_knowledge(self, query, card_type, limit):
        self.calls.append(("search_knowledge", query, card_type))
        return [{"card_type": "PSC", "card_id": "allowed"}]

    def get_bundle(self, bundle_id):
        self.calls.append(("get_bundle", bundle_id))
        if bundle_id == "blocked":
            raise PermissionError("Blocked source")
        return {"bundle_id": bundle_id}


class RunnerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.config = json.loads((run.ROOT / "config.json").read_text())
        (self.root / "config.json").write_text(json.dumps(self.config))
        self.retrieval = MockRetrieval()
        self.ids = list(self.retrieval.by_id)
        self.query = {"task_id": "hidden_task", "source_group_id": "hidden_source",
                      "query_id": "q1", "query_variant": 1, "split": "dev", "query": "marine image analysis"}
        self.compiler = {"system": "original compiler", "user_template": "Research question:\nMARKER",
                         "marker": "MARKER", "schema": {"type": "object"}, "validate": lambda value: None,
                         "reject_ids": lambda value, ids: None, "source_sha256": "source", "schema_sha256": "schema",
                         "prompt_sha256": "prompt"}

    def runner(self, responses=(), **kwargs):
        bridge = MockBridge(responses)
        runner = run.E1Runner(self.root, self.config, self.retrieval, bridge_factory=lambda: bridge,
                              compiler=self.compiler, **kwargs)
        self.addCleanup(runner.close)
        return runner, bridge

    def test_fenced_json_is_complete_not_partial(self):
        self.assertEqual(run.parse_json_text('```json\n{"x":1}\n```'), {"x": 1})
        for text in ('prefix {"x":1}', '```json\n{}\n``` trailing', '{} {}'):
            with self.assertRaises((ValueError, json.JSONDecodeError)):
                run.parse_json_text(text)

    def test_bm25_no_model_and_resume_preserves_failure_or_success(self):
        runner, bridge = self.runner()
        first = runner.run_unit("BM25 Retrieval", self.query)
        self.assertEqual((first["status"], first["ranking"], first["llm_calls"]), ("success", self.ids[:20], 0))
        self.assertFalse(bridge.requests)
        resumed = runner.run_unit("BM25 Retrieval", self.query, resume=True)
        self.assertEqual(first, resumed)
        self.assertEqual(len(self.retrieval.calls), 1)
        with self.assertRaises(ValueError):
            runner.run_unit("BM25 Retrieval", self.query)

    def test_direct_is_catalog_free_and_mapping_preserves_null_positions(self):
        records = [{"product_id": f"p{i:02d}", "name": None, "url": None} for i in range(20)]
        records[1]["product_id"] = "not-in-corpus"
        records[2]["product_id"] = "p00"  # duplicate remains at rank 3 as null
        records[3]["product_id"] = None
        records[3]["name"] = "Product 4"
        records[3]["url"] = "https://example.org/5"  # conflicting exact fields
        runner, bridge = self.runner([result(assistant(json.dumps({"ranking": records})))])
        row = runner.run_unit("Direct LLM", self.query)
        self.assertEqual(row["status"], "success")
        self.assertEqual(row["ranking"][:5], ["d00", None, None, None, "d04"])
        self.assertEqual(row["mapping_coverage"]["mapped"], 17)
        self.assertEqual(row["mapping_audit"][2]["resolution"], "duplicate_canonical_id")
        self.assertFalse(self.retrieval.calls)
        context = next(request["context"] for request in bridge.requests if request["kind"] == "complete")
        serialized = json.dumps(context)
        self.assertNotIn("d00", serialized)
        self.assertNotIn("hidden_task", serialized)
        self.assertNotIn("hidden_source", serialized)
        self.assertEqual(row["usage"]["input"], 3)
        self.assertEqual(row["usage"]["cost"]["total"], 0.01)

    def test_alias_ambiguity_never_promotes(self):
        corpus = [{"dataset_id": "a", "aliases": ["same"]}, {"dataset_id": "b", "aliases": ["same"]}]
        mapper = run.ExactMapper(corpus)
        ranking_out, audit = mapper.map([{"name": "same"}, {"product_id": "a"}, {"name": "SAME"}])
        self.assertEqual(ranking_out, [None, "a", None])
        self.assertEqual(audit[0]["resolution"], "ambiguous")

    def test_each_fixed_method_uses_its_context_and_same_output_contract(self):
        for index, method in enumerate(("Flat RAG Agent", "StructuredRAG", "GraphRAG")):
            query = {**self.query, "query_id": f"fixed{index}"}
            runner, bridge = self.runner([result(assistant(json.dumps(ranking(self.ids))))])
            row = runner.run_unit(method, query)
            self.assertEqual(row["status"], "success")
            self.assertEqual(row["llm_calls"], 1)
            request = [item for item in bridge.requests if item["kind"] == "complete"][0]
            self.assertNotIn("tools", request["context"])
            self.assertIn(method, request["context"]["messages"][0]["content"])
            self.assertIn(run.RANKING_CONTRACT, request["context"]["systemPrompt"])

    def test_schema_failure_one_repair_only_and_attempt_history(self):
        bad = result(assistant('{"ranking":[]}'))
        runner, bridge = self.runner([bad, bad])
        row = runner.run_unit("Flat RAG Agent", self.query)
        self.assertEqual((row["status"], row["llm_calls"], row["retry_counts"]["format_repair"]), ("failed", 2, 1))
        self.assertEqual(runner.run_unit("Flat RAG Agent", self.query, resume=True), row)
        bridge.responses.append(result(assistant(json.dumps(ranking(self.ids)))))
        retried = runner.run_unit("Flat RAG Agent", self.query, resume=True, retry_failed=True)
        self.assertEqual(retried["status"], "success")
        self.assertEqual(retried["attempts"][0]["status"], "failed")
        self.assertEqual(retried["retry_counts"]["unit"], 1)

    def test_network_retry_two_attempts_aggregate_usage(self):
        runner, bridge = self.runner([
            {"ok": False, "error": "temporary failure", "http_statuses": [{"status": 503}]},
            result(assistant(json.dumps(ranking(self.ids))))])
        row = runner.run_unit("StructuredRAG", self.query)
        self.assertEqual(row["status"], "success")
        self.assertEqual((row["llm_calls"], row["retry_counts"]["network"]), (2, 1))
        self.assertEqual(len(row["request_sha256"]), 2)

    def test_deterministic_400_not_retried(self):
        runner, bridge = self.runner([{"ok": False, "error": "bad schema", "http_statuses": [{"status": 400}]}])
        row = runner.run_unit("GraphRAG", self.query)
        self.assertEqual((row["status"], row["llm_calls"]), ("failed", 1))

    def test_systemic_402_marks_remaining_llm_units_unavailable(self):
        runner, bridge = self.runner([{"ok": False, "error": "402 payment required", "http_statuses": [{"status": 402}]}])
        row = runner.run_unit("StructuredRAG", self.query)
        self.assertEqual((row["status"], row["llm_calls"]), ("unavailable", 1))
        next_row = runner.run_unit("Direct LLM", {**self.query, "query_id": "q2"})
        self.assertEqual((next_row["status"], next_row["llm_calls"]), ("unavailable", 0))
        bm25 = runner.run_unit("BM25 Retrieval", {**self.query, "query_id": "q3"})
        self.assertEqual(bm25["status"], "success")

    def test_ocean_compiler_query_only_native_tools_and_submit(self):
        calls = [{"type": "toolCall", "id": "tool1", "name": "search_datasets", "arguments": {"query": "marine images", "limit": 5}},
                 {"type": "toolCall", "id": "tool2", "name": "get_bundle", "arguments": {"bundle_id": "blocked"}}]
        submit = {"type": "toolCall", "id": "submit", "name": "submit_dataset_ranking", "arguments": ranking(self.ids)}
        runner, bridge = self.runner([result(assistant('{"research_goal":"images"}')), result(assistant(calls=calls)),
                                      result(assistant(calls=[submit]))])
        row = runner.run_unit("OceanAgent", self.query)
        self.assertEqual(row["status"], "success")
        self.assertEqual((row["llm_calls"], row["tool_calls"]), (3, 3))
        requests = [item for item in bridge.requests if item["kind"] == "complete"]
        serialized_compile = json.dumps(requests[0]["context"])
        self.assertNotIn("hidden_task", serialized_compile)
        self.assertNotIn("d00", serialized_compile)
        self.assertIn("original compiler", serialized_compile)
        self.assertEqual(requests[2]["context"]["messages"][-1]["role"], "toolResult")
        self.assertTrue(requests[2]["context"]["messages"][-1]["isError"])
        self.assertIn("native_Pi_SDK_tool_loop", row["components"])
        schema = next(item for item in requests[1]["context"]["tools"] if item["name"] == "submit_dataset_ranking")
        self.assertIsInstance(schema["parameters"]["properties"]["ranking"]["items"], dict)

    def test_ocean_reserves_fifth_call_for_forced_text_final(self):
        responses = [result(assistant('{}'))]
        for i in range(3):
            responses.append(result(assistant(calls=[{"type": "toolCall", "id": str(i), "name": "search_datasets", "arguments": {"query": "images"}}])))
        responses.append(result(assistant(json.dumps(ranking(self.ids)))))
        runner, bridge = self.runner(responses)
        row = runner.run_unit("OceanAgent", self.query)
        self.assertEqual((row["status"], row["llm_calls"]), ("success", 5))
        requests = [item for item in bridge.requests if item["kind"] == "complete"]
        self.assertNotIn("tools", requests[-1]["context"])
        self.assertIn("final ranking now", requests[-1]["context"]["messages"][-1]["content"])

    def test_ocean_tool_cap_preserves_final_call(self):
        calls = [{"type": "toolCall", "id": str(i), "name": "search_datasets", "arguments": {"query": "images"}} for i in range(10)]
        runner, bridge = self.runner([result(assistant('{}')), result(assistant(calls=calls)),
                                      result(assistant(json.dumps(ranking(self.ids))))])
        row = runner.run_unit("OceanAgent", self.query)
        self.assertEqual((row["status"], row["tool_calls"]), ("success", 8))
        self.assertEqual(len([item for item in self.retrieval.calls if item[0] == "search_datasets"]), 8)
        last = [item for item in bridge.requests if item["kind"] == "complete"][-1]
        self.assertNotIn("tools", last["context"])

    def test_dense_wrapper_actual_ids_and_audit_no_calls(self):
        cache = self.root / "cache/dense_rankings.json"
        cache.parent.mkdir(parents=True)
        cache.write_text(json.dumps({"metadata": {"model": {"model_id": "actual-embedding"}},
            "rankings": {"q1": {"ranking": self.ids[:20], "elapsed_ms": 20, "embedding_fingerprint": "fingerprint"}}}))
        runner, bridge = self.runner()
        row = runner.run_unit("Dense Retrieval", self.query)
        self.assertEqual(row["status"], "success")
        self.assertEqual(row["ranking"], self.ids[:20])
        self.assertEqual(row["evidence_audit"]["embedding_metadata"]["model"]["model_id"], "actual-embedding")
        self.assertFalse(bridge.requests)

    def test_fixed_repair_drops_thinking_and_bounds_visible_json_history(self):
        original = self.retrieval.fixed_context
        def large_context(*args, **kwargs):
            context = original(*args, **kwargs)
            context["evidence"] = {"passage": "x" * 42000}
            return context
        self.retrieval.fixed_context = large_context
        bad = assistant("invalid JSON " + "z" * 18000)
        bad["content"].insert(0, {"type": "thinking", "thinking": "private" * 25000})
        first = result(bad)
        first["request_mode"] = {"thinking": "disabled", "reasoning_effort": "none"}
        runner, bridge = self.runner([first, result(assistant(json.dumps(ranking(self.ids))))])
        row = runner.run_unit("Flat RAG Agent", self.query)
        self.assertEqual(row["status"], "success")
        calls = [item for item in bridge.requests if item["kind"] == "complete"]
        for call in calls:
            self.assertLessEqual(len(json.dumps(call["context"], ensure_ascii=False)), self.config["max_prompt_chars"])
        history = calls[1]["context"]["messages"][1]
        self.assertTrue(all(item["type"] == "text" for item in history["content"]))
        self.assertNotIn("private", json.dumps(history))
        self.assertEqual(row["raw_responses"][0]["response"]["content"][0]["type"], "thinking")
        self.assertEqual(row["raw_responses"][0]["request_mode"]["thinking"], "disabled")
        projection = row["context_projections"][-1]
        self.assertLess(projection["replayed_text_chars"], projection["visible_text_chars"])

    def test_oversized_tool_returns_fit_conversation_full_trace_retained(self):
        large_cards = []
        for i in range(20):
            large_cards.append({"dataset_id": self.ids[i], "description": 'quoted "passage" ' * 600,
                "role": "independent_validation", "fields": [{"name": "chlorophyll_concentration", "unit": "mg m-3",
                "description": "variable description " * 100} for _ in range(5)]})
        self.retrieval.requirement_candidates = lambda spec, pool_size: [
            {**card, "description": "initial " * 120} for card in self.retrieval.corpus]
        self.retrieval.search_datasets = lambda query, limit: copy.deepcopy(large_cards[:limit])
        self.retrieval.search_knowledge = lambda query, card_type, limit: copy.deepcopy(large_cards[:limit])
        responses = [result(assistant('{}'))]
        for i in range(3):
            responses.append(result(assistant(calls=[
                {"type": "toolCall", "id": f"d{i}", "name": "search_datasets", "arguments": {"query": "images", "limit": 20}},
                {"type": "toolCall", "id": f"k{i}", "name": "search_knowledge", "arguments": {"query": "images", "limit": 10}}])))
        responses.append(result(assistant(json.dumps(ranking(self.ids)))))
        runner, bridge = self.runner(responses)
        row = runner.run_unit("OceanAgent", self.query)
        self.assertEqual((row["status"], row["llm_calls"], row["tool_calls"]), ("success", 5, 6))
        calls = [item for item in bridge.requests if item["kind"] == "complete"]
        for call in calls:
            self.assertLessEqual(len(json.dumps(call["context"], ensure_ascii=False)), self.config["max_prompt_chars"])
        self.assertGreater(len(json.dumps(row["tool_trace"], ensure_ascii=False)), 100000)
        self.assertEqual(row["tool_trace"][0]["result"][0]["description"], large_cards[0]["description"])
        self.assertTrue(any(item["truncated_to_budget"] for item in row["context_projections"]))
        tool_results = [message for call in calls for message in call["context"]["messages"] if message["role"] == "toolResult"]
        self.assertTrue(any(json.loads(message["content"][0]["text"]).get("truncated_to_budget")
                            for message in tool_results if isinstance(json.loads(message["content"][0]["text"]), dict)))

    def test_projection_preserves_full_ids_roles_and_variable_names(self):
        dataset_id = "canonical_dataset_" + "version_and_scope_" * 4
        payload = [{"dataset_id": dataset_id, "role": "independent_validation",
                    "fields": [{"name": "a_long_scientific_variable_name", "unit": "kg m-3", "description": "detail" * 1000}],
                    "description": "details" * 10000} for _ in range(20)]
        projected, audit = run.project_tool_output(payload, 2200)
        self.assertTrue(audit["truncated_to_budget"])
        self.assertEqual(projected["result"][0]["dataset_id"], dataset_id)
        self.assertEqual(projected["result"][0]["role"], "independent_validation")
        self.assertEqual(projected["result"][0]["fields"][0]["name"], "a_long_scientific_variable_name")
        self.assertLessEqual(len(json.dumps(json.dumps(projected, ensure_ascii=False), ensure_ascii=False)), 2200)

    def test_consolidation_unique_atomic_and_config_bound(self):
        runner, _ = self.runner()
        runner.run_unit("BM25 Retrieval", self.query)
        runner.run_unit("BM25 Retrieval", self.query, resume=True)
        rows = run.consolidate(self.root, runner.config_sha, [self.query])
        self.assertEqual(len(rows), 1)
        lines = (self.root / "e1_predictions.jsonl").read_text().splitlines()
        self.assertEqual(len(lines), 1)
        self.assertEqual(json.loads(lines[0])["implementation_sha256"]["run.py"], hashlib.sha256(Path(run.__file__).read_bytes()).hexdigest())

    def test_budget_exhaustion_fails_without_unbounded_calls(self):
        self.config["max_llm_calls_per_unit"] = 1
        (self.root / "config.json").write_text(json.dumps(self.config))
        runner, _ = self.runner([result(assistant("bad JSON"))])
        row = runner.run_unit("StructuredRAG", self.query)
        self.assertEqual((row["status"], row["llm_calls"]), ("failed", 1))
        self.assertIn("budget", row["error"])


if __name__ == "__main__":
    unittest.main()
