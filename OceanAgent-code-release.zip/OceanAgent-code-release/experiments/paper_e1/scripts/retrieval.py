"""Read-only E1 retrieval over the frozen snapshot; no model or label access.

The three fixed contexts reuse the original six-method runner's actual
``structured_context`` function.  The historical ``structured_ocean_agent``
name denotes StructuredRAG here.  Its graph branch traverses dataset co-usage
through *all visible bundles*.  Direct LLM deliberately has no entry point.

Legacy artifact: benchmark/baselines/__pycache__/run_baseline.cpython-311.pyc
SHA256: 542dcf8cb901386be4ecf0c7ac2d7a6d62207e1f2b5d998ddf2a32924fe37fc5
Run this module with Python 3.11.  Imports and retrieval never call a model.
"""
from __future__ import annotations

from collections import Counter, defaultdict
import copy
import hashlib
import importlib.machinery
import importlib.util
import json
from pathlib import Path
import sys
import threading
from types import ModuleType
from typing import Any, Mapping, Sequence


LEGACY_ROOT = Path(__file__).resolve().parents[3] / "benchmark/legacy"
LEGACY_RELATIVE_PATH = "benchmark/baselines/__pycache__/run_baseline.cpython-311.pyc"
LEGACY_SHA256 = "542dcf8cb901386be4ecf0c7ac2d7a6d62207e1f2b5d998ddf2a32924fe37fc5"
POLICY = "train-plus-unambiguous-auxiliary; dev-and-test-blocked-for-both-cohorts-v1"
METHODS = {
    "Flat RAG Agent": "flat_rag", "flat_rag": "flat_rag",
    "StructuredRAG": "structured_ocean_agent",
    "structured_ocean_agent": "structured_ocean_agent",
    "GraphRAG": "graph_rag", "graph_rag": "graph_rag",
}


def _sha(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                    separators=(",", ":")).encode()).hexdigest()


def _rows(path: Path) -> list[dict[str, Any]]:
    result = []
    with path.open(encoding="utf-8") as handle:
        for number, line in enumerate(handle, 1):
            if not line.strip():
                continue
            item = json.loads(line)
            if not isinstance(item, dict):
                raise ValueError(f"Expected object at {path}:{number}")
            result.append(item)
    return result


def _index(rows: Sequence[Mapping[str, Any]], key: str) -> dict[str, dict[str, Any]]:
    indexed: dict[str, dict[str, Any]] = {}
    for row in rows:
        identity = row.get(key)
        if not isinstance(identity, str) or not identity or identity in indexed:
            raise ValueError(f"Empty or duplicate {key}: {identity!r}")
        indexed[identity] = dict(row)
    return indexed


def _module(path: Path, name: str, *, bytecode: bool = False) -> ModuleType:
    if bytecode:
        loader = importlib.machinery.SourcelessFileLoader(name, str(path))
        spec = importlib.util.spec_from_loader(name, loader)
    else:
        spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load retrieval implementation: {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    previous = sys.dont_write_bytecode
    try:
        sys.dont_write_bytecode = True
        spec.loader.exec_module(module)
    finally:
        sys.dont_write_bytecode = previous
    return module


def _source_values(value: Any, keys: set[str]) -> set[str]:
    if isinstance(value, Mapping):
        values = {str(item) for key, item in value.items()
                  if key in keys and isinstance(item, str) and item}
        for item in value.values():
            values.update(_source_values(item, keys))
        return values
    if isinstance(value, list):
        return set().union(*(_source_values(item, keys) for item in value)) if value else set()
    return set()


def _text(value: Any, limit: int = 300) -> str:
    return str(value or "")[:limit]


def _compact(value: Any, *, chars: int = 240, items: int = 5, depth: int = 4) -> Any:
    """Bound nested content before serialization, preserving identifiers intact."""
    if isinstance(value, str):
        return value[:chars]
    if isinstance(value, Mapping):
        if depth <= 0:
            return {}
        return {str(key): (item if str(key).endswith("_id") and isinstance(item, str)
                           else _compact(item, chars=chars, items=items, depth=depth - 1))
                for key, item in list(value.items())[:18]}
    if isinstance(value, (list, tuple)):
        return [_compact(item, chars=chars, items=items, depth=depth - 1)
                for item in value[:items]] if depth > 0 else []
    return value if value is None or isinstance(value, (bool, int, float)) else _text(value, chars)


def _bounded_projection(value: dict[str, Any], budget: int) -> dict[str, Any]:
    """Reduce projected fields/lists in stages; never slice serialized JSON."""
    if len(json.dumps(value, ensure_ascii=False)) <= budget:
        return value
    for chars, items in ((180, 3), (120, 2), (80, 1), (50, 1)):
        projected = _compact(value, chars=chars, items=items, depth=7)
        if len(json.dumps(projected, ensure_ascii=False)) <= budget:
            return projected
    return projected


def compact_dataset(card: Mapping[str, Any]) -> dict[str, Any]:
    coverage = card.get("coverage") or {}
    resolution = card.get("resolution") or {}
    fields = card.get("variables") or card.get("fields") or []
    return _bounded_projection({
        "dataset_id": str(card["dataset_id"]),
        "name": _text(card.get("product_name") or card.get("name"), 180),
        "description": _text(card.get("description"), 320),
        "aliases": [_text(x, 100) for x in (card.get("aliases") or [])[:3]],
        "provider": _text(card.get("provider"), 120),
        "coverage": {axis: _text(card.get(f"{axis}_coverage") or coverage.get(axis), 140)
                     for axis in ("spatial", "temporal", "vertical")},
        "resolution": {axis: _text(card.get(f"{axis}_resolution") or resolution.get(axis), 90)
                       for axis in ("spatial", "temporal", "vertical")},
        "fields": [{"name": _text(field.get("raw_name") or field.get("name"), 80),
                    "description": _text(field.get("description"), 100),
                    "unit": _text(field.get("unit"), 50)}
                   for field in fields[:4] if isinstance(field, Mapping)],
    }, 1100)


def _compact_psc(card: Mapping[str, Any]) -> dict[str, Any]:
    return _bounded_projection({"card_type": "PSC", "card_id": card["card_id"],
            "paper_id": card["paper_id"],
            "source_group_id": card.get("source_group_id") or card["paper_id"],
            "bundle_id": card["bundle_id"],
            "problem": _text(card.get("problem"), 450),
            "solution_summary": _text(card.get("solution_summary"), 550),
            "research_field": _compact(card.get("research_field")),
            "evidence": _compact(card.get("evidence") or [], chars=240, items=1)}, 1100)


def _compact_ubc(card: Mapping[str, Any]) -> dict[str, Any]:
    usages = []
    for usage in (card.get("data_usages") or [])[:4]:
        if not isinstance(usage, Mapping):
            continue
        usages.append({key: (usage[key] if key.endswith("_id") else
                             _compact(usage[key], chars=120, items=3))
                       for key in ("usage_id", "dataset_id", "role", "fields", "subset",
                                   "preprocessing", "quality_control") if key in usage})
    # Evidence arrays inside each step/relation can dominate a context.  Keep
    # the reported operations and links as separate fields; PSCs retain a
    # bounded supporting quote.  This is a card projection, not a text cutoff.
    fields_by_kind = {
        "steps": ("step_id", "action", "input_usage_ids", "depends_on_step_ids", "output", "inference_status"),
        "data_relations": ("from_usage_id", "to_usage_id", "relation", "alignment", "reason"),
        "validation": ("metric", "target", "criterion", "limitations", "result"),
    }
    result = {"card_type": "UBC", "bundle_id": card["bundle_id"], "data_usages": usages}
    for kind, keys in fields_by_kind.items():
        rows = card.get(kind) or []
        rows = rows if isinstance(rows, list) else [rows]
        result[kind] = [{key: (row[key] if key.endswith("_id") else
                              _compact(row[key], chars=140, items=3))
                         for key in keys if key in row}
                        for row in rows[:(4 if kind == "steps" else 2)] if isinstance(row, Mapping)]
    result["projection_counts"] = {"data_usages": len(card.get("data_usages") or []),
                                   "steps": len(card.get("steps") or [])}
    return _bounded_projection(result, 2400)


class E1Retrieval:
    """A cohort-independent, held-out-blocked knowledge view.

    Only ``cards/*.jsonl``, DatasetCorpus and the split identity manifest are
    read.  Split query rows and evaluation labels never enter this component.
    Public search methods return detached compact copies of permitted cards.
    """

    def __init__(self, snapshot: str | Path, agent_root: str | Path | None = None):
        if sys.version_info[:2] != (3, 11):
            raise RuntimeError("The frozen legacy retrieval bytecode requires Python 3.11")
        self.snapshot = Path(snapshot).expanduser().resolve()
        self.agent_root = (Path(agent_root).expanduser().resolve() if agent_root else
                           self.snapshot.parent.parent)
        pyc = LEGACY_ROOT / LEGACY_RELATIVE_PATH
        digest = hashlib.sha256(pyc.read_bytes()).hexdigest()
        if digest != LEGACY_SHA256:
            raise RuntimeError("Frozen legacy retrieval bytecode checksum mismatch")
        if str(LEGACY_ROOT) not in sys.path:
            sys.path.insert(0, str(LEGACY_ROOT))
        self.legacy = _module(pyc, "paper_e1_legacy_retrieval", bytecode=True)
        self.corpus = _rows(self.snapshot / "benchmark/corpus/dataset_corpus.jsonl")
        self.by_id = _index(self.corpus, "dataset_id")
        self.dataset_ids = list(self.by_id)
        self.dataset_cards = _index(_rows(self.snapshot / "cards/dataset_cards.jsonl"), "dataset_id")
        if self.by_id.keys() != self.dataset_cards.keys():
            raise ValueError("DatasetCard and DatasetCorpus identities differ")
        self._dataset_ranker = self.legacy.BM25([self.legacy.corpus_text(x) for x in self.corpus])
        self._build_visible_view()
        self._psc_rows = list(self.visible_psc.values())
        self._ubc_rows = list(self.visible_ubc.values())
        self._psc_ranker = self.legacy.BM25([json.dumps(x, ensure_ascii=False, sort_keys=True)
                                           for x in self._psc_rows])
        self._ubc_ranker = self.legacy.BM25([json.dumps(x, ensure_ascii=False, sort_keys=True)
                                           for x in self._ubc_rows])
        self._requirement_index = None
        self._requirement_lock = threading.Lock()

    def _build_visible_view(self) -> None:
        manifest_path = self.snapshot / "benchmark/splits/split_manifest.json"
        splits = json.loads(manifest_path.read_text(encoding="utf-8"))["splits"]
        groups, sources = {}, {}
        for split in ("train", "dev", "test"):
            groups[split] = set(splits[split]["source_group_ids"])
            sources[split] = set(splits[split]["source_ids"])
            if not groups[split] or not sources[split]:
                raise ValueError(f"Missing source identities for {split}")
        for left, right in (("train", "dev"), ("train", "test"), ("dev", "test")):
            if groups[left] & groups[right] or sources[left] & sources[right]:
                raise ValueError("Source identity manifest has overlapping splits")
        all_psc = _index(_rows(self.snapshot / "cards/problem_solution_cards.jsonl"), "card_id")
        all_ubc = _index(_rows(self.snapshot / "cards/usage_bundle_cards.jsonl"), "bundle_id")
        blocked_groups = groups["dev"] | groups["test"]
        blocked_sources = sources["dev"] | sources["test"]
        # Close source/group aliases from the frozen cards, blocking either
        # identity even when an alternative alias was absent from the manifest.
        changed = True
        while changed:
            old = (len(blocked_groups), len(blocked_sources))
            for card in all_psc.values():
                group = str(card.get("source_group_id") or card.get("paper_id") or "")
                paper = str(card.get("paper_id") or "")
                if group in blocked_groups or paper in blocked_sources:
                    if group:
                        blocked_groups.add(group)
                    if paper:
                        blocked_sources.add(paper)
            changed = old != (len(blocked_groups), len(blocked_sources))
        self.blocked_source_group_ids = frozenset(blocked_groups)
        self.blocked_source_ids = frozenset(blocked_sources)
        known_groups = set().union(*groups.values())
        known_sources = set().union(*sources.values())
        provisional = {}
        denied_reasons: Counter[str] = Counter()
        owners: dict[str, list[str]] = defaultdict(list)
        for identity, card in all_psc.items():
            group = str(card.get("source_group_id") or card.get("paper_id") or "")
            paper = str(card.get("paper_id") or "")
            bundle = str(card.get("bundle_id") or "")
            owners[bundle].append(identity)
            nested_sources = _source_values(card, {"paper_id", "source_id"})
            nested_groups = _source_values(card, {"source_group_id"})
            if (nested_sources & blocked_sources or nested_groups & blocked_groups):
                denied_reasons["held_out_source"] += 1
            elif (not group or not paper or not bundle or
                  paper.casefold() in {"unresolved", "unknown", "none"}):
                denied_reasons["ambiguous_identity"] += 1
            elif ((group in groups["train"] and paper in sources["train"]) or
                  (group not in known_groups and paper not in known_sources)):
                provisional[identity] = card
            else:
                denied_reasons["ambiguous_split_identity"] += 1
        self.visible_ubc = {}
        for bundle, owner_ids in owners.items():
            card = all_ubc.get(bundle)
            if (card is not None and all(owner in provisional for owner in owner_ids)
                    and not (_source_values(card, {"paper_id", "source_id"}) & blocked_sources)
                    and not (_source_values(card, {"source_group_id"}) & blocked_groups)):
                self.visible_ubc[bundle] = card
        self.visible_psc = {key: value for key, value in provisional.items()
                            if value["bundle_id"] in self.visible_ubc}
        denied_reasons["denied_or_missing_linked_bundle"] += len(provisional) - len(self.visible_psc)
        self._blocked_psc_ids = frozenset(all_psc.keys() - self.visible_psc.keys())
        self._blocked_ubc_ids = frozenset(all_ubc.keys() - self.visible_ubc.keys())
        visible_groups = {str(x.get("source_group_id") or x["paper_id"])
                          for x in self.visible_psc.values()}
        visible_sources = {str(x["paper_id"]) for x in self.visible_psc.values()}
        self.visible_source_group_ids = frozenset(visible_groups)
        self.visible_source_ids = frozenset(visible_sources)
        if visible_groups & blocked_groups or visible_sources & blocked_sources:
            raise RuntimeError("Held-out source entered the visible knowledge view")
        paths = ("benchmark/corpus/dataset_corpus.jsonl", "cards/dataset_cards.jsonl",
                 "cards/problem_solution_cards.jsonl", "cards/usage_bundle_cards.jsonl",
                 "benchmark/splits/split_manifest.json")
        self.audit = {
            "policy": POLICY, "legacy_pyc_sha256": LEGACY_SHA256,
            "dataset_corpus_count": len(self.corpus),
            "visible_dataset_card_count": len(self.dataset_cards),
            "visible_psc_count": len(self.visible_psc), "blocked_psc_count": len(self._blocked_psc_ids),
            "visible_ubc_count": len(self.visible_ubc), "blocked_ubc_count": len(self._blocked_ubc_ids),
            "visible_source_group_count": len(visible_groups),
            "blocked_source_group_count": len(blocked_groups),
            "visible_source_count": len(visible_sources), "blocked_source_count": len(blocked_sources),
            "auxiliary_source_group_count": len(visible_groups - known_groups),
            "visible_source_group_ids": sorted(visible_groups),
            "blocked_source_group_ids": sorted(blocked_groups),
            "visible_source_ids": sorted(visible_sources), "blocked_source_ids": sorted(blocked_sources),
            "visible_psc_ids_sha256": _sha(sorted(self.visible_psc)),
            "visible_ubc_ids_sha256": _sha(sorted(self.visible_ubc)),
            "denied_psc_reasons": dict(denied_reasons),
            "input_sha256": {p: hashlib.sha256((self.snapshot / p).read_bytes()).hexdigest()
                             for p in paths},
            "blocked_knowledge_detected": False,
        }

    def bm25(self, query: str, k: int = 20) -> list[str]:
        return self.legacy.ranked_ids(self.dataset_ids, self._dataset_ranker.scores(query))[:max(0, k)]

    def search_datasets(self, query: str, limit: int = 10) -> list[dict[str, Any]]:
        return [compact_dataset(self.by_id[key]) for key in self.bm25(query, limit)]

    def search_knowledge(self, query: str, card_type: str = "all", limit: int = 5) -> list[dict[str, Any]]:
        aliases = {"psc": "PSC", "problemsolutioncard": "PSC", "problem_solution": "PSC",
                   "problem_solution_card": "PSC", "ubc": "UBC", "usagebundlecard": "UBC",
                   "usage_bundle": "UBC", "usage_bundle_card": "UBC", "dataset": "DatasetCard",
                   "datasetcard": "DatasetCard", "dataset_card": "DatasetCard", "all": "all"}
        kind = aliases.get(card_type.casefold())
        if kind is None:
            raise ValueError(f"Unknown card_type: {card_type}")
        hits = []
        if kind in {"PSC", "all"}:
            for card, score in zip(self._psc_rows, self._psc_ranker.scores(query)):
                hits.append((score, "PSC", card["card_id"], card))
        if kind in {"UBC", "all"}:
            for card, score in zip(self._ubc_rows, self._ubc_ranker.scores(query)):
                hits.append((score, "UBC", card["bundle_id"], card))
        if kind in {"DatasetCard", "all"}:
            for card, score in zip(self.corpus, self._dataset_ranker.scores(query)):
                hits.append((score, "DatasetCard", card["dataset_id"], card))
        hits.sort(key=lambda item: (-item[0], item[1], item[2]))
        return [(_compact_psc(card) if kind == "PSC" else _compact_ubc(card) if kind == "UBC"
                 else {"card_type": "DatasetCard", **compact_dataset(card)})
                for _, kind, _, card in hits[:max(0, limit)]]

    def get_bundle(self, bundle_id: str) -> dict[str, Any]:
        card = self.visible_ubc.get(bundle_id)
        if card is None:
            raise PermissionError("UsageBundleCard is unknown or outside the permitted source view")
        linked = list(dict.fromkeys(str(x.get("dataset_id") or "")
                                    for x in card.get("data_usages") or [] if isinstance(x, Mapping)))
        canonical = [key for key in linked if key in self.by_id]
        owners = [x for x in self.visible_psc.values() if x["bundle_id"] == bundle_id]
        return {"usage_bundle_card": _compact_ubc(card),
                # Use the same frozen public product facts as catalog search.
                # Raw source cards can encode coverage/resolution as prose;
                # their canonical DatasetCorpus counterparts normalize these
                # fields and omit source-paper quotations. Do not expose raw
                # paper-scoped source fields via the exact-link tool.
                "linked_dataset_cards": [compact_dataset(self.by_id[key]) for key in canonical],
                "audit": {"bundle_id": bundle_id, "dataset_ids": canonical,
                          "unresolved_dataset_ids": [key for key in linked if key and key not in self.by_id],
                          "psc_ids": [x["card_id"] for x in owners],
                          "source_group_ids": sorted({x.get("source_group_id") or x["paper_id"] for x in owners}),
                          "blocked_knowledge_detected": False}}

    def _evidence_ids(self, context: Mapping[str, Any]) -> dict[str, list[str]]:
        psc = [str(x["card_id"]) for x in context.get("retrieved_problem_solution_cards", [])]
        psc += [str(x["card_id"]) for x in context.get("retrieved_flat_cards", [])]
        bundle = [str(x["bundle_id"]) for x in context.get("exactly_expanded_usage_bundle_cards", [])]
        bundle += [str(self.visible_psc[key]["bundle_id"]) for key in psc]
        sources = set()
        for key in psc:
            if key not in self.visible_psc:
                raise RuntimeError("Legacy retrieval returned a blocked PSC")
            sources.add(str(self.visible_psc[key]["paper_id"]))
        for path in context.get("graph_paths", []):
            bundle.extend(str(x) for x in path.get("bundle_ids", []))
            sources.update(str(x) for x in path.get("paper_ids", []))
        if any(key not in self.visible_ubc for key in bundle) or sources & self.blocked_source_ids:
            raise RuntimeError("Legacy retrieval returned a blocked bundle or graph source")
        dataset = [str(x["dataset_id"]) for field in ("retrieved_dataset_cards", "exactly_expanded_dataset_cards")
                   for x in context.get(field, [])]
        for path in context.get("graph_paths", []):
            dataset.extend([str(path["from_dataset_id"]), str(path["to_dataset_id"])])
        return {"psc_ids": list(dict.fromkeys(psc)), "ubc_ids": list(dict.fromkeys(bundle)),
                "dataset_ids": list(dict.fromkeys(dataset)), "source_ids": sorted(sources)}

    def _compact_context(self, context: Mapping[str, Any]) -> dict[str, Any]:
        evidence = {key: value for key, value in context.items() if not isinstance(value, list)}
        for key, value in context.items():
            if not isinstance(value, list):
                continue
            if key == "retrieved_flat_cards":
                evidence[key] = [{"source_id": item["source_id"], "card_id": item["card_id"],
                                  "text": json.dumps({"problem": _compact_psc(self.visible_psc[item["card_id"]]),
                                                      "usage_bundle": _compact_ubc(self.visible_ubc[
                                                          self.visible_psc[item["card_id"]]["bundle_id"]])},
                                                     ensure_ascii=False, sort_keys=True)} for item in value]
            elif "problem_solution" in key:
                evidence[key] = [_compact_psc(item) for item in value]
            elif "usage_bundle" in key:
                evidence[key] = [_compact_ubc(item) for item in value]
            elif "dataset_cards" in key:
                evidence[key] = [compact_dataset(item) for item in value]
            elif key == "graph_paths":
                evidence[key] = copy.deepcopy(value)
        return evidence

    def fixed_context(self, query: str, method: str, pool_size: int = 30,
                      context_cards: int = 5) -> dict[str, Any]:
        legacy_method = METHODS.get(method)
        if legacy_method is None:
            raise ValueError("fixed_context supports Flat RAG Agent, StructuredRAG and GraphRAG only")
        pool_size = min(max(0, pool_size), 30)
        context_cards = min(max(0, context_cards), 5)
        context = self.legacy.structured_context(
            query, legacy_method, self.corpus, self._dataset_ranker, self.dataset_ids,
            self._psc_rows, self._ubc_rows, context_cards)
        evidence_ids = self._evidence_ids(context)
        lexical = self.bm25(query, pool_size)
        # Expand exact visible links before compacting the evidence.  RRF gives
        # a linked card a genuine route into the bounded candidate pool instead
        # of truncating [lexical_30 + linked] back to the lexical-only shortlist.
        linked = []
        for key in evidence_ids["ubc_ids"]:
            linked.extend(str(x.get("dataset_id") or "")
                          for x in self.visible_ubc[key].get("data_usages") or []
                          if isinstance(x, Mapping))
        linked = list(dict.fromkeys(key for key in linked if key in self.by_id))
        graph = list(dict.fromkeys(str(x["to_dataset_id"]) for x in context.get("graph_paths", [])
                                   if x["to_dataset_id"] in self.by_id))
        ranks = [lexical, linked] + ([graph] if legacy_method == "graph_rag" else [])
        fused: dict[str, float] = defaultdict(float)
        for ranking in ranks:
            for rank, key in enumerate(ranking, 1):
                fused[key] += 1.0 / (60 + rank)
        candidate_ids = sorted(fused, key=lambda key: (-fused[key], key))[:pool_size]
        audit = {**copy.deepcopy(self.audit), "method": method, "legacy_method": legacy_method,
                 "candidate_fusion": "deterministic-rrf-k60-lexical-exactlinks-graph",
                 "candidate_ids": candidate_ids, "lexical_candidate_ids": lexical,
                 "linked_candidate_ids": linked, "graph_candidate_ids": graph,
                 "linked_additions": [key for key in candidate_ids if key not in lexical],
                 "evidence_ids": evidence_ids, "evidence_sha256": _sha(context)}
        return {"candidate_ids": candidate_ids,
                "candidates": [compact_dataset(self.by_id[key]) for key in candidate_ids],
                "evidence": self._compact_context(context), "audit": audit}

    def requirement_candidates(self, task_spec: Mapping[str, Any], pool_size: int = 30) -> list[dict[str, Any]]:
        """Reuse E1's existing task-spec-to-query conversion and metadata BM25."""
        if self._requirement_index is None:
            with self._requirement_lock:
                if self._requirement_index is None:
                    path = self.agent_root / "experiments/agent_e1_taskcompiler/run_experiment.py"
                    self._requirement_module = _module(path, "paper_e1_existing_task_spec_retrieval")
                    self._requirement_index = self._requirement_module.BM25Index(self.corpus, k1=1.5, b=0.75)
        if not isinstance(task_spec, Mapping):
            raise TypeError("task_spec must be an object")
        retrieval_text = "\n".join(self._requirement_module.flatten_strings(dict(task_spec)))
        if not retrieval_text.strip():
            raise ValueError("task_spec contains no retrievable text")
        cards = self._requirement_index.search(retrieval_text, min(max(0, pool_size), 30))
        return [compact_dataset(self.by_id[str(card["dataset_id"])]) for card in cards]
