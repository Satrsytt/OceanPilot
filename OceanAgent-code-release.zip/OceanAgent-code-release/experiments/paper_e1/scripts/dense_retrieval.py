#!/usr/bin/env python3
"""Frozen E1 dense baseline: pretrained MiniLM ONNX inference, never training.

Install the small CPU runtime in a temporary environment (not in the repository):
    python3.11 -m venv /private/tmp/oceanagent-e1-dense-venv
    /private/tmp/oceanagent-e1-dense-venv/bin/python -m pip install \
        numpy onnxruntime tokenizers huggingface-hub
Then run this script with that Python. To reproduce an existing run, pass the
model revision recorded in cache/dense_metadata.json using --revision.
Only config.json, runtime_queries.jsonl and the frozen dataset corpus are read
as benchmark data. The legacy bytecode is inspected for its pure text serializer;
the legacy module, its imports, and its main function are never executed.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import marshal
import os
from pathlib import Path
import platform
import sys
import time
import types
from typing import Any

import numpy as np

MODEL_ID = "sentence-transformers/all-MiniLM-L6-v2"
MODEL_FILES = (
    "onnx/model.onnx", "tokenizer.json", "tokenizer_config.json", "config.json",
    "sentence_bert_config.json", "1_Pooling/config.json", "modules.json",
    "special_tokens_map.json",
)
CORPUS_FIELDS = (
    "dataset_id", "product_name", "official_version", "provider", "variables",
    "spatial_coverage", "temporal_coverage", "spatial_resolution",
    "temporal_resolution", "aliases", "description",
)
LEGACY_PYC_SHA256 = "542dcf8cb901386be4ecf0c7ac2d7a6d62207e1f2b5d998ddf2a32924fe37fc5"
MAX_LENGTH = 256
DIMENSION = 384


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def fingerprint(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                     separators=(",", ":")).encode()).hexdigest()


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    with path.open(encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def write_json(path: Path, value: Any) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, ensure_ascii=False,
                                    allow_nan=False) + "\n", encoding="utf-8")
    temporary.replace(path)


def corpus_text(row: dict[str, Any]) -> str:
    """Literal recovery of the legacy serializer; no supervision fields."""
    return json.dumps({key: row.get(key) for key in CORPUS_FIELDS},
                      ensure_ascii=False, sort_keys=True)


def legacy_serializer(config: dict[str, Any]):
    pyc = Path(config["legacy_root"]) / "benchmark/baselines/__pycache__/run_baseline.cpython-311.pyc"
    details: dict[str, Any] = {"path": str(pyc), "expected_sha256": LEGACY_PYC_SHA256,
                               "serializer_fields": list(CORPUS_FIELDS)}
    if not pyc.exists():
        details["source"] = "literal recovery; legacy bytecode unavailable"
        return corpus_text, details
    digest = sha256_file(pyc)
    details["sha256"] = digest
    if digest != LEGACY_PYC_SHA256:
        raise ValueError("Legacy bytecode changed; review serializer before use")
    if sys.version_info[:2] != (3, 11):
        details["source"] = "literal recovery; bytecode requires Python 3.11"
        return corpus_text, details
    code = marshal.loads(pyc.read_bytes()[16:])
    candidates = [c for c in code.co_consts
                  if isinstance(c, types.CodeType) and c.co_name == "corpus_text"]
    if len(candidates) != 1 or candidates[0].co_names != ("json", "dumps"):
        raise ValueError("Unexpected legacy corpus_text bytecode")
    recovered = types.FunctionType(candidates[0], {"json": json, "__builtins__": {}},
                                   "legacy_corpus_text")
    details["source"] = "isolated corpus_text function from verified CPython 3.11 bytecode"
    return recovered, details


def normalize(vectors: np.ndarray) -> np.ndarray:
    vectors = np.asarray(vectors, dtype=np.float32)
    norms = np.linalg.norm(vectors, axis=1, keepdims=True)
    if not np.isfinite(vectors).all() or (norms <= 0).any():
        raise ValueError("Non-finite or zero embedding")
    return np.asarray(vectors / norms, dtype=np.float32)


def mean_pool(hidden: np.ndarray, attention_mask: np.ndarray) -> np.ndarray:
    mask = attention_mask.astype(np.float32)[..., None]
    pooled = (hidden * mask).sum(axis=1) / np.maximum(mask.sum(axis=1), 1e-9)
    return normalize(pooled)


def top_k(ids: list[str], scores: np.ndarray, k: int) -> tuple[list[str], list[float]]:
    scores = np.asarray(scores)
    if scores.shape != (len(ids),) or not np.isfinite(scores).all():
        raise ValueError("Invalid cosine scores")
    # Exactly the old ranked_ids rule: descending score, ascending ID for ties.
    order = sorted(range(len(ids)), key=lambda index: (-float(scores[index]), ids[index]))[:k]
    return [ids[index] for index in order], [float(scores[index]) for index in order]


class MiniLMEncoder:
    def __init__(self, model_dir: Path, threads: int):
        import onnxruntime as ort
        from tokenizers import Tokenizer

        self.tokenizer = Tokenizer.from_file(str(model_dir / "tokenizer.json"))
        self.tokenizer.enable_truncation(max_length=MAX_LENGTH, direction="right")
        self.tokenizer.enable_padding(direction="right", pad_id=0, pad_type_id=0,
                                      pad_token="[PAD]")
        options = ort.SessionOptions()
        options.intra_op_num_threads = threads
        options.inter_op_num_threads = 1
        options.execution_mode = ort.ExecutionMode.ORT_SEQUENTIAL
        self.session = ort.InferenceSession(str(model_dir / "onnx/model.onnx"),
                                           sess_options=options,
                                           providers=["CPUExecutionProvider"])
        self.input_names = [i.name for i in self.session.get_inputs()]
        self.output_names = [o.name for o in self.session.get_outputs()]

    def encode(self, texts: list[str]) -> np.ndarray:
        # SentenceTransformer's Transformer.tokenize strips leading/trailing spaces.
        encoded = self.tokenizer.encode_batch([str(text).strip() for text in texts])
        arrays = {
            "input_ids": np.asarray([item.ids for item in encoded], dtype=np.int64),
            "attention_mask": np.asarray([item.attention_mask for item in encoded], dtype=np.int64),
            "token_type_ids": np.asarray([item.type_ids for item in encoded], dtype=np.int64),
        }
        outputs = self.session.run(None, {name: arrays[name] for name in self.input_names})
        hidden = outputs[0]
        if hidden.ndim != 3 or hidden.shape[-1] != DIMENSION:
            raise ValueError(f"Unexpected ONNX token embedding shape: {hidden.shape}")
        return mean_pool(hidden, arrays["attention_mask"])


def obtain_model(model_cache: Path, revision: str) -> tuple[Path, dict[str, Any]]:
    # All downloaded model/runtime data stay outside the experiment/repository.
    os.environ["HF_HOME"] = str(model_cache / "hf_home")
    os.environ["HF_HUB_DISABLE_XET"] = "1"
    os.environ["HF_HUB_DISABLE_TELEMETRY"] = "1"
    os.environ["TOKENIZERS_PARALLELISM"] = "false"
    from huggingface_hub import HfApi, snapshot_download

    api = HfApi(token=False)
    info = api.model_info(MODEL_ID, revision=revision)
    actual_revision = info.sha
    path = Path(snapshot_download(MODEL_ID, revision=actual_revision,
                                 allow_patterns=list(MODEL_FILES), token=False,
                                 cache_dir=str(model_cache / "hub")))
    hashes = {name: sha256_file(path / name) for name in MODEL_FILES}
    sentence_config = json.loads((path / "sentence_bert_config.json").read_text())
    pooling = json.loads((path / "1_Pooling/config.json").read_text())
    if sentence_config["max_seq_length"] != MAX_LENGTH:
        raise ValueError("Unexpected official model maximum sequence length")
    if not pooling.get("pooling_mode_mean_tokens") or any(
        pooling.get(key, False) for key in (
            "pooling_mode_cls_token", "pooling_mode_max_tokens",
            "pooling_mode_mean_sqrt_len_tokens", "pooling_mode_weightedmean_tokens",
            "pooling_mode_lasttoken")):
        raise ValueError("Unexpected official model pooling configuration")
    return path, {"model_id": MODEL_ID, "revision": actual_revision,
                  "source": f"https://huggingface.co/{MODEL_ID}/tree/{actual_revision}",
                  "files_sha256": hashes, "model_cache_path": str(path)}


def assert_embeddings(vectors: np.ndarray, count: int) -> None:
    if vectors.shape != (count, DIMENSION) or vectors.dtype != np.float32:
        raise ValueError(f"Unexpected cached embedding shape/dtype: {vectors.shape}/{vectors.dtype}")
    if not np.isfinite(vectors).all() or not np.allclose(
        np.linalg.norm(vectors, axis=1), 1.0, atol=2e-6):
        raise ValueError("Embeddings must be finite and L2 normalized")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--experiment-dir", type=Path,
                        default=Path(__file__).resolve().parents[1])
    parser.add_argument("--model-cache", type=Path,
                        default=Path(".cache/minilm-model"))
    parser.add_argument("--revision", default="1110a243fdf4706b3f48f1d95db1a4f5529b4d41")
    parser.add_argument("--batch-size", type=int, default=16)
    parser.add_argument("--threads", type=int, default=4)
    parser.add_argument("--force-embeddings", action="store_true")
    args = parser.parse_args()
    total_start = time.perf_counter()
    root = args.experiment_dir.resolve()
    config_path = root / "config.json"
    config = json.loads(config_path.read_text())
    corpus_path = Path(config["knowledge_root"]) / "benchmark/corpus/dataset_corpus.jsonl"
    queries_path = root / "runtime_queries.jsonl"
    corpus_sha = sha256_file(corpus_path)
    if corpus_sha != config["source_sha256"]["benchmark/corpus/dataset_corpus.jsonl"]:
        raise ValueError("Frozen corpus hash mismatch")
    corpus = read_jsonl(corpus_path)
    queries = read_jsonl(queries_path)
    ids = [str(row["dataset_id"]) for row in corpus]
    query_ids = [str(row["query_id"]) for row in queries]
    if len(ids) != config["candidate_count"] or len(set(ids)) != len(ids):
        raise ValueError("Corpus count or ID uniqueness mismatch")
    if len(queries) != config["runtime_queries"] or len(set(query_ids)) != len(queries):
        raise ValueError("Runtime query count or ID uniqueness mismatch")
    serializer, serializer_details = legacy_serializer(config)
    documents = [serializer(row) for row in corpus]
    if documents != [corpus_text(row) for row in corpus]:
        raise ValueError("Literal recovery differs from legacy corpus_text")
    query_texts = [row["query"] for row in queries]
    if not all(isinstance(text, str) and text.strip() for text in query_texts):
        raise ValueError("Empty runtime query")

    model_start = time.perf_counter()
    model_dir, model_details = obtain_model(args.model_cache, args.revision)
    versions = {name: importlib.metadata.version(name) for name in
                ("numpy", "onnxruntime", "tokenizers", "huggingface-hub")}
    inference_config = {
        "backend": "onnxruntime", "providers": ["CPUExecutionProvider"],
        "model_file": "onnx/model.onnx", "weight_precision": "float32, unquantized",
        "dimension": DIMENSION, "max_seq_length": MAX_LENGTH,
        "truncation": "right", "padding": "right, longest in batch, [PAD] ID 0",
        "pooling": "attention-mask-weighted mean of final token embeddings",
        "normalize_embeddings": True, "similarity": "L2-normalized dot product (cosine)",
        "corpus_batch_size": args.batch_size, "query_batch_size": 1,
        "intra_op_threads": args.threads, "inter_op_threads": 1,
        "query_preprocessing": "str(text).strip(), no query/document prompt",
        "tie_break": "dataset_id ascending after score descending",
        "training": False, "knowledge_rebuild": False,
    }
    source_details = {
        "corpus_path": str(corpus_path), "corpus_sha256": corpus_sha,
        "runtime_queries_path": str(queries_path), "runtime_queries_sha256": sha256_file(queries_path),
        "config_sha256": sha256_file(config_path),
        "corpus_texts_sha256": fingerprint(documents),
        "query_texts_sha256": fingerprint(query_texts),
        "corpus_count": len(ids), "query_count": len(query_ids),
    }
    embedding_fingerprint = fingerprint({
        "model_id": MODEL_ID, "revision": model_details["revision"],
        "model_file_hashes": model_details["files_sha256"],
        "inference_config": inference_config, "versions": versions,
        "source": source_details, "serializer": serializer_details,
    })
    cache = root / "cache"
    cache.mkdir(exist_ok=True)
    corpus_vectors_path = cache / "dense_corpus_embeddings.npy"
    query_vectors_path = cache / "dense_query_embeddings.npy"
    embedding_meta_path = cache / "dense_embeddings_metadata.json"
    encoder = MiniLMEncoder(model_dir, args.threads)
    model_setup_ms = (time.perf_counter() - model_start) * 1000
    can_reuse = False
    if (not args.force_embeddings and embedding_meta_path.exists()
            and corpus_vectors_path.exists() and query_vectors_path.exists()):
        previous = json.loads(embedding_meta_path.read_text())
        can_reuse = (previous.get("embedding_fingerprint") == embedding_fingerprint
                     and previous["corpus_embeddings_sha256"] == sha256_file(corpus_vectors_path)
                     and previous["query_embeddings_sha256"] == sha256_file(query_vectors_path))
    if can_reuse:
        document_vectors = np.load(corpus_vectors_path, allow_pickle=False)
        query_vectors = np.load(query_vectors_path, allow_pickle=False)
        embedding_meta = previous
        print("Reusing verified pretrained inference embeddings", flush=True)
    else:
        corpus_start = time.perf_counter()
        chunks = []
        for start in range(0, len(documents), args.batch_size):
            chunks.append(encoder.encode(documents[start:start + args.batch_size]))
            if start % (args.batch_size * 20) == 0:
                print(f"Corpus inference {min(start + args.batch_size, len(documents))}/{len(documents)}", flush=True)
        document_vectors = np.concatenate(chunks, axis=0)
        corpus_elapsed_ms = (time.perf_counter() - corpus_start) * 1000
        chunks, query_encode_ms = [], []
        for index, text in enumerate(query_texts):
            started = time.perf_counter()
            chunks.append(encoder.encode([text]))
            query_encode_ms.append((time.perf_counter() - started) * 1000)
            if index % 50 == 0:
                print(f"Query inference {index + 1}/{len(query_texts)}", flush=True)
        query_vectors = np.concatenate(chunks, axis=0)
        assert_embeddings(document_vectors, len(ids))
        assert_embeddings(query_vectors, len(query_ids))
        np.save(corpus_vectors_path, document_vectors, allow_pickle=False)
        np.save(query_vectors_path, query_vectors, allow_pickle=False)
        embedding_meta = {
            "schema_version": "paper-e1-dense-embeddings-v1",
            "created_utc": datetime.now(timezone.utc).isoformat(),
            "embedding_fingerprint": embedding_fingerprint,
            "corpus_embeddings_sha256": sha256_file(corpus_vectors_path),
            "query_embeddings_sha256": sha256_file(query_vectors_path),
            "corpus_encoding_elapsed_ms": corpus_elapsed_ms,
            "query_encoding_elapsed_ms": query_encode_ms,
            "corpus_ids": ids, "query_ids": query_ids,
            "model": model_details, "source": source_details,
            "serializer": serializer_details, "inference_config": inference_config,
            "runtime_versions": versions,
        }
        write_json(embedding_meta_path, embedding_meta)
    assert_embeddings(document_vectors, len(ids))
    assert_embeddings(query_vectors, len(query_ids))
    rankings = {}
    query_encode_ms = embedding_meta["query_encoding_elapsed_ms"]
    for index, (query_id, vector) in enumerate(zip(query_ids, query_vectors)):
        started = time.perf_counter()
        scores = document_vectors @ vector
        ranking, top_scores = top_k(ids, scores, max(config["top_k"]))
        ranking_ms = (time.perf_counter() - started) * 1000
        if len(ranking) != 20 or len(set(ranking)) != 20:
            raise ValueError("Expected 20 unique ranked corpus IDs")
        rankings[query_id] = {
            "ranking": ranking, "scores": top_scores, "model": MODEL_ID,
            "embedding_fingerprint": embedding_fingerprint,
            "elapsed_ms": query_encode_ms[index] + ranking_ms,
            "query_encoding_ms": query_encode_ms[index], "ranking_ms": ranking_ms,
        }
    rankings_path = cache / "dense_rankings.json"
    write_json(rankings_path, {
        "metadata": {
            "schema_version": "paper-e1-dense-v1", "model": model_details,
            "source": source_details, "serializer": serializer_details,
            "inference_config": inference_config, "runtime_versions": versions,
            "embedding_fingerprint": embedding_fingerprint,
            "counts": {"corpus": len(ids), "queries": len(query_ids), "top_k": 20},
        },
        "rankings": rankings,
    })
    metadata = {
        "schema_version": "paper-e1-dense-v1", "status": "completed",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "source": source_details, "serializer": serializer_details,
        "model": model_details, "inference_config": inference_config,
        "runtime_versions": versions,
        "python_version": sys.version, "platform": platform.platform(),
        "machine": platform.machine(), "embedding_fingerprint": embedding_fingerprint,
        "embedding_cache_reused": can_reuse,
        "corpus_embeddings_sha256": sha256_file(corpus_vectors_path),
        "query_embeddings_sha256": sha256_file(query_vectors_path),
        "rankings_sha256": sha256_file(rankings_path),
        "script_sha256": sha256_file(Path(__file__)),
        "model_setup_elapsed_ms": model_setup_ms,
        "corpus_encoding_elapsed_ms": embedding_meta["corpus_encoding_elapsed_ms"],
        "query_encoding_total_ms": sum(query_encode_ms),
        "run_wall_elapsed_ms": (time.perf_counter() - total_start) * 1000,
        "elapsed_ms_definition": "one query tokenization + ONNX inference + pooling/normalization + full-corpus cosine scores and deterministic top-20; excludes shared corpus encoding, model loading/download, and file IO",
        "data_access_policy": "Only frozen public dataset corpus and inference-only runtime query text; no gold, private PSC/UBC, training, tuning, or knowledge rebuild",
        "counts": {"corpus": len(ids), "queries": len(query_ids), "rankings": len(rankings), "top_k": 20},
    }
    write_json(cache / "dense_metadata.json", metadata)
    print(json.dumps({"status": "completed", "rankings": str(rankings_path),
                      "counts": metadata["counts"], "revision": model_details["revision"],
                      "embedding_fingerprint": embedding_fingerprint}, indent=2), flush=True)


if __name__ == "__main__":
    main()
