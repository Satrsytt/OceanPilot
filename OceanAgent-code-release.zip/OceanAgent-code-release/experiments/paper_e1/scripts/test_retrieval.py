"""Offline integration checks against the frozen E1 cards and split identities."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json
import unittest

from retrieval import E1Retrieval, LEGACY_SHA256, POLICY, compact_dataset


EXPERIMENT = Path(__file__).resolve().parents[1]
CONFIG = json.loads((EXPERIMENT / "config.json").read_text(encoding="utf-8"))


class RetrievalIsolationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.retrieval = E1Retrieval(CONFIG["knowledge_root"], CONFIG["agent_root"])

    def test_frozen_visibility_and_canonical_search(self):
        retriever = self.retrieval
        self.assertEqual(len(retriever.corpus), 2260)
        self.assertEqual(retriever.audit["legacy_pyc_sha256"], LEGACY_SHA256)
        self.assertEqual(retriever.audit["visible_psc_count"], 485)
        self.assertEqual(retriever.audit["visible_ubc_count"], 485)
        self.assertEqual(retriever.audit["blocked_psc_count"], 163)
        self.assertEqual(retriever.audit["blocked_ubc_count"], 163)
        self.assertEqual(retriever.audit["auxiliary_source_group_count"], 104)
        self.assertFalse(retriever.visible_source_group_ids & retriever.blocked_source_group_ids)
        self.assertFalse(retriever.visible_source_ids & retriever.blocked_source_ids)
        ranking = retriever.bm25("sea surface temperature salinity satellite", 20)
        self.assertEqual(len(set(ranking)), 20)
        self.assertTrue(set(ranking) <= retriever.by_id.keys())
        # A DatasetCorpus card sourced from Test remains globally visible.
        self.assertIn("3dmotraj_dataset__paper_0279_unresolved", retriever.by_id)

    def test_blocked_cards_and_linked_expansion_denied(self):
        retriever = self.retrieval
        for bundle_id in retriever._blocked_ubc_ids:
            with self.assertRaises(PermissionError):
                retriever.get_bundle(bundle_id)
        for kind in ("PSC", "UBC", "all"):
            hits = retriever.search_knowledge("paper_0054 segmentation", kind, 10000)
            for card in hits:
                if card["card_type"] == "PSC":
                    self.assertIn(card["card_id"], retriever.visible_psc)
                    self.assertNotIn(card["source_group_id"], retriever.blocked_source_group_ids)
                elif card["card_type"] == "UBC":
                    self.assertIn(card["bundle_id"], retriever.visible_ubc)
        allowed_id = next(iter(retriever.visible_ubc))
        bundle = retriever.get_bundle(allowed_id)
        self.assertEqual(bundle["usage_bundle_card"]["bundle_id"], allowed_id)
        self.assertTrue(set(bundle["audit"]["dataset_ids"]) <= retriever.by_id.keys())

    def test_fixed_methods_use_visible_links_and_real_graph_paths(self):
        retriever = self.retrieval
        query = "sea surface temperature satellite salinity validation"
        expected_shapes = {
            "Flat RAG Agent": "retrieved_flat_cards",
            "StructuredRAG": "exactly_expanded_usage_bundle_cards",
            "GraphRAG": "graph_paths",
        }
        for method, field in expected_shapes.items():
            result = retriever.fixed_context(query, method)
            self.assertEqual(len(result["candidate_ids"]), 30)
            self.assertEqual(len(set(result["candidate_ids"])), 30)
            self.assertEqual([x["dataset_id"] for x in result["candidates"]], result["candidate_ids"])
            self.assertTrue(set(result["candidate_ids"]) <= retriever.by_id.keys())
            self.assertIn(field, result["evidence"])
            model_payload = {key: value for key, value in result.items() if key != "audit"}
            self.assertLess(len(json.dumps(model_payload, ensure_ascii=False)), 55000)
            evidence_ids = result["audit"]["evidence_ids"]
            self.assertTrue(set(evidence_ids["psc_ids"]) <= retriever.visible_psc.keys())
            self.assertTrue(set(evidence_ids["ubc_ids"]) <= retriever.visible_ubc.keys())
            self.assertFalse(set(evidence_ids["source_ids"]) & retriever.blocked_source_ids)
            if method == "GraphRAG":
                paths = result["evidence"]["graph_paths"]
                self.assertTrue(paths)
                self.assertEqual(result["evidence"]["graph_traversal"], "Dataset-USES-Paper-USES-Dataset")
                for path in paths:
                    self.assertGreater(path["support_count"], 0)
                    for bundle_id in path["bundle_ids"]:
                        datasets = {x["dataset_id"] for x in retriever.visible_ubc[bundle_id]["data_usages"]}
                        self.assertIn(path["from_dataset_id"], datasets)
                        self.assertIn(path["to_dataset_id"], datasets)
                    self.assertFalse(set(path["paper_ids"]) & retriever.blocked_source_ids)
        with self.assertRaises(ValueError):
            retriever.fixed_context(query, "Direct LLM")

    def test_requirement_candidates_reuse_existing_metadata_index(self):
        task_spec = {
            "research_goal": "Compare sea surface temperature products",
            "variables": [{"name": "sea surface temperature", "role": "target"}],
            "spatial_scope": "Southern Ocean", "temporal_scope": "2005 to 2020",
        }
        with ThreadPoolExecutor(max_workers=3) as pool:
            results = list(pool.map(self.retrieval.requirement_candidates, [task_spec] * 3))
        self.assertEqual(results[0], results[1])
        self.assertEqual(results[1], results[2])
        cards = results[0]
        self.assertEqual(len(cards), 30)
        self.assertEqual(len({x["dataset_id"] for x in cards}), 30)
        self.assertTrue(all(x["dataset_id"] in self.retrieval.by_id for x in cards))

    def test_all_linked_cards_use_public_corpus_projection_without_source_quotes(self):
        retriever = self.retrieval
        # Audit the entire public candidate space, including the 540 raw cards
        # whose prose coverage/resolution cannot support mapping-style access.
        projected = {key: compact_dataset(card) for key, card in retriever.by_id.items()}
        self.assertEqual(len(projected), 2260)
        raw_incompatible = {key for key, card in retriever.dataset_cards.items()
                            if isinstance(card.get("coverage"), str) or isinstance(card.get("resolution"), str)}
        self.assertEqual(len(raw_incompatible), 540)

        def quoted_fields(value):
            if isinstance(value, dict):
                return {key for key in value if key in {"sources", "official_evidence"}} | set().union(
                    *(quoted_fields(child) for child in value.values()))
            if isinstance(value, list):
                return set().union(*(quoted_fields(child) for child in value))
            return set()

        self.assertFalse(quoted_fields(list(projected.values())))
        linked_incompatible = set()
        for bundle_id in retriever.visible_ubc:
            bundle = retriever.get_bundle(bundle_id)
            cards = bundle["linked_dataset_cards"]
            self.assertEqual(cards, [projected[key] for key in bundle["audit"]["dataset_ids"]])
            self.assertFalse(quoted_fields(cards))
            self.assertFalse(set(bundle["audit"]["source_group_ids"]) & retriever.blocked_source_group_ids)
            linked_incompatible.update(set(bundle["audit"]["dataset_ids"]) & raw_incompatible)
        self.assertTrue(linked_incompatible)
        self.assertEqual(retriever.audit["policy"], POLICY)



if __name__ == "__main__":
    unittest.main()
