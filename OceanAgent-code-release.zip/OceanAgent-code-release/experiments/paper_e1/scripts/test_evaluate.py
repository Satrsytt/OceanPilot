"""Targeted E1 semantics tests; no inference or changes to frozen artifacts."""
from __future__ import annotations

import copy
import csv
import importlib.util
import math
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("paper_e1_evaluator_under_test", HERE / "evaluate.py")
e = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = e
SPEC.loader.exec_module(e)
FROZEN_ROOT = Path("benchmark/knowledge_snapshot")


def requirements():
    return [{"requirement_id": "r1", "weight": 2, "acceptable_dataset_ids": ["a", "b"]},
            {"requirement_id": "r2", "weight": 1, "acceptable_dataset_ids": ["c"]}]


def routes():
    return {"valid_routes": [{"route_id": "v1", "covers_requirement_ids": ["r1", "r2"], "dataset_groups": [["a"], ["c"]]},
                             {"route_id": "v2", "covers_requirement_ids": ["r1"], "dataset_groups": [["b"]]}]}


def gold_fixture():
    queries = {(split, f"{split}q{i}"): {"task_id": f"{split}t1", "query_id": f"{split}q{i}"}
               for split in ("dev", "test") for i in (1, 2)}
    qids = [q for _, q in queries]
    return e.Gold(queries, {q: ["a", "c"] for q in qids}, {q: ["a", "b", "c"] for q in qids},
                  {q: {"requirements": requirements()} for q in qids if q.startswith("dev")},
                  {q: routes() for q in qids if q.startswith("dev")}, {"a", "b", "c", "d"})


def prediction(query="devq1", method="OceanAgent", status="success", depth=20, ranking=None):
    split = "dev" if query.startswith("dev") else "test"
    return {"method": method, "split": split, "task_id": f"{split}t1", "query_id": query,
            "status": status, "ranking": ["a", "c"] if ranking is None else ranking,
            "available_depth": depth}


def simple_alpha(ranking, reqs, *, alpha):
    """Test double only; production always imports both existing functions."""
    seen, score = {}, 0
    for rank, dataset in enumerate(ranking, 1):
        gain = 0
        for req in reqs:
            if dataset in req["acceptable_dataset_ids"]:
                rid = req["requirement_id"]
                gain += req["weight"] * (1 - alpha) ** seen.get(rid, 0)
                seen[rid] = seen.get(rid, 0) + 1
        score += gain / math.log2(rank + 1)
    return score


def simple_ideal(reqs, *, alpha, top_k):
    return simple_alpha(["a", "c", "b"][:top_k], reqs, alpha=alpha)


class RouteTests(unittest.TestCase):
    def test_route_mean_is_unweighted_and_max_over_routes(self):
        result, reason = e.route_metrics(["a"], requirements(), routes())
        self.assertEqual(result, {"TRC": 1.0, "SCC": .5, "CSA": 1.0})
        self.assertEqual(reason, "")
        one = {"valid_routes": [routes()["valid_routes"][0]]}
        self.assertEqual(e.route_metrics(["a"], requirements(), one)[0]["TRC"], .5)

    def test_same_requirement_sets_share_coverage_even_with_different_groups(self):
        reqs = [{"requirement_id": "semantic", "weight": 2, "acceptable_dataset_ids": ["nuscenes", "semantickitti"]}]
        row = {"valid_routes": [{"route_id": "nu", "covers_requirement_ids": ["semantic"], "dataset_groups": [["nuscenes"]]},
                                {"route_id": "ki", "covers_requirement_ids": ["semantic"], "dataset_groups": [["semantickitti"]]}]}
        self.assertEqual(e.route_metrics(["nuscenes"], reqs, row)[0], {"TRC": 1.0, "SCC": 1.0, "CSA": 1.0})

    def test_unknown_requirement_invalidates_route_set(self):
        row = routes()
        row["valid_routes"][1]["covers_requirement_ids"] = ["unknown"]
        result, reason = e.route_metrics(["a", "c"], requirements(), row)
        self.assertEqual(result, {"TRC": None, "SCC": None, "CSA": None})
        self.assertEqual(reason, "invalid_routes")

    def test_missing_and_empty_routes_are_null(self):
        for row in (None, {"valid_routes": []}):
            self.assertTrue(all(v is None for v in e.route_metrics(["a"], requirements(), row)[0].values()))

    def test_no_hit_is_observed_zero(self):
        self.assertEqual(e.route_metrics([None, "d"], requirements(), routes())[0], {"TRC": 0.0, "SCC": 0.0, "CSA": 0.0})


class PredictionAndMetricTests(unittest.TestCase):
    def setUp(self):
        self.gold = gold_fixture()

    def test_null_preserves_rank_for_mrr_and_map(self):
        p = prediction(ranking=[None, "a", None, "c"])
        e.index_predictions([p], self.gold)
        metrics = e.fidelity_metrics(p["ranking"], ["a", "c"], 20)
        self.assertEqual(metrics, {"Recall": 1, "MRR": .5, "MAP": .5})

    def test_map_denominator_is_all_relevant(self):
        self.assertEqual(e.fidelity_metrics(["a"], ["a", "b", "c"], 20)["MAP"], 1 / 3)

    def test_alias_is_never_fuzzy_matched(self):
        with self.assertRaisesRegex(ValueError, "canonical"):
            e.index_predictions([prediction(ranking=["Alias A"])], self.gold)
        self.assertEqual(e.route_metrics(["Alias A"], requirements(), routes())[0]["TRC"], 0)

    def test_duplicates_rejected_but_multiple_nulls_allowed(self):
        e.index_predictions([prediction(ranking=[None, None, "a"])], self.gold)
        with self.assertRaisesRegex(ValueError, "Duplicate nonnull"):
            e.index_predictions([prediction(ranking=["a", "a"])], self.gold)

    def test_prediction_duplicate_and_source_group_mismatch_rejected(self):
        with self.assertRaisesRegex(ValueError, "Duplicate prediction"):
            e.index_predictions([prediction(), prediction()], self.gold)
        p = prediction()
        p["task_id"] = "incorrect"
        with self.assertRaisesRegex(ValueError, "source_group_id"):
            e.index_predictions([p], self.gold)

    def test_unadmitted_query_rejected(self):
        with self.assertRaisesRegex(ValueError, "outside admitted"):
            e.index_predictions([prediction(query="devq3")], self.gold)

    def test_status_and_depth_are_only_observation_gates(self):
        self.assertEqual(e.prediction_reason(None, 5), "missing_prediction")
        self.assertEqual(e.prediction_reason(prediction(status="failed"), 5), "failed")
        self.assertEqual(e.prediction_reason(prediction(status="unavailable"), 5), "unavailable")
        self.assertEqual(e.prediction_reason(prediction(depth=10), 20), "insufficient_depth")
        self.assertEqual(e.prediction_reason(prediction(ranking=[]), 20), "")

    def test_historical_top10_does_not_become_top20(self):
        indexed = e.index_predictions([prediction(depth=10)], self.gold)
        rows = e.query_metrics(indexed, self.gold, (simple_alpha, simple_ideal))
        own = {(r["metric"], r["k"]): r for r in rows if r["method"] == "OceanAgent" and r["query_id"] == "devq1"}
        self.assertEqual(own["Recall", 10]["value"], 1)
        for key in (("Recall", 20), ("MRR", 20), ("MAP", 20), ("TRC", 20)):
            self.assertIsNone(own[key]["value"])
            self.assertEqual(own[key]["reason"], "insufficient_depth")

    def test_failed_rankings_do_not_score(self):
        indexed = e.index_predictions([prediction(status="failed")], self.gold)
        rows = e.query_metrics(indexed, self.gold, (simple_alpha, simple_ideal))
        self.assertTrue(all(r["value"] is None for r in rows))

    def test_invalid_routes_explicit_without_zero_imputation(self):
        self.gold.routes["devq1"] = {"valid_routes": []}
        indexed = e.index_predictions([prediction()], self.gold)
        rows = e.query_metrics(indexed, self.gold, (simple_alpha, simple_ideal))
        own = [r for r in rows if r["method"] == "OceanAgent" and r["query_id"] == "devq1"]
        route_rows = [r for r in own if r["metric"] in ("TRC", "SCC", "CSA")]
        self.assertTrue(all(r["value"] is None and r["invalid_routes_count"] == 1 for r in route_rows))
        self.assertTrue(all(r["value"] is not None for r in own if r["metric"] == "alpha_nDCG"))


class AggregationAndStatisticsTests(unittest.TestCase):
    def test_missing_half_task_has_null_task_mean(self):
        g = gold_fixture()
        qrows = e.query_metrics(e.index_predictions([prediction()], g), g, (simple_alpha, simple_ideal))
        tasks, summaries = e.aggregate(qrows)
        task = next(r for r in tasks if r["split"] == "dev" and r["method"] == "OceanAgent" and r["metric"] == "Recall" and r["k"] == 10)
        summary = next(r for r in summaries if r["split"] == "dev" and r["method"] == "OceanAgent" and r["metric"] == "Recall" and r["k"] == 10)
        self.assertIsNone(task["value"])
        self.assertEqual((task["valid_count"], task["missing_count"]), (1, 1))
        self.assertIsNone(summary["value"])
        self.assertEqual(summary["query_mean"], 1)

    def test_task_sign_flip_supports_half_csa(self):
        result = e.paired_inference([.5, .5], seed=42, resamples=2000)
        self.assertEqual(result["delta"], .5)
        self.assertEqual((result["ci_low"], result["ci_high"]), (.5, .5))
        self.assertEqual(result["p_value"], .5)
        self.assertEqual(result["randomization"], "exact_task_sign_flip")

    def test_bootstrap_is_deterministic_and_missing_stays_null(self):
        self.assertEqual(e.paired_inference([.2, -.3, .7], seed=18), e.paired_inference([.2, -.3, .7], seed=18))
        self.assertIsNone(e.paired_inference([], seed=18)["p_value"])

    def test_holm_includes_planned_unobserved_comparisons(self):
        rows = [{"family": "a", "p_value": .01}, {"family": "a", "p_value": .04},
                {"family": "a", "p_value": None}, {"family": "b", "p_value": .01}]
        e.apply_holm(rows)
        self.assertEqual([r["p_holm"] for r in rows], [.03, .08, None, .01])
        self.assertEqual(rows[0]["family_size"], 3)

    def test_pairing_uses_only_same_complete_observed_tasks(self):
        base = {"split": "dev", "reference": "core", "metric": "Recall", "k": 10}
        rows = [{**base, "method": "OceanAgent", "task_id": "a", "value": 1},
                {**base, "method": "OceanAgent", "task_id": "b", "value": .5},
                {**base, "method": "BM25 Retrieval", "task_id": "a", "value": .2},
                {**base, "method": "BM25 Retrieval", "task_id": "b", "value": None}]
        stats = e.paired_statistics(rows)
        bm25 = next(r for r in stats if r["baseline"] == "BM25 Retrieval")
        self.assertEqual((bm25["n_pairs"], bm25["missing_pair_tasks"]), (1, 1))
        self.assertEqual(bm25["delta"], .8)
        self.assertEqual(bm25["oceanagent_paired_mean"], 1)

    def test_spearman_ties_and_constant_vectors(self):
        self.assertEqual(e.average_ranks([1, 1, 3]), [1.5, 1.5, 3])
        self.assertIsNone(e.correlation([1, 1], [0, 1]))
        self.assertAlmostEqual(e.correlation([0, 1, 2], [2, 1, 0]), -1)

    def test_csa_quadrant_requires_one_at_task_level(self):
        rows = [{"split": "dev", "reference": reference, "method": "OceanAgent", "task_id": "t", "metric": metric, "k": 10, "value": value}
                for reference, metric, value in (("core", "Recall", .5), ("requirements", "CSA", .5), ("requirements", "TRC", .5))]
        analysis = e.additional_analysis([], rows)
        sts = next(r for r in analysis if r["analysis"] == "fixed_threshold_quadrants" and r["method"] == "OceanAgent"
                   and r["metric_y"] == "CSA@10" and r["statistic"] == "fidelity_high/adequacy_low")
        trc = next(r for r in analysis if r["analysis"] == "fixed_threshold_quadrants" and r["method"] == "OceanAgent"
                   and r["metric_y"] == "TRC@10" and r["statistic"] == "fidelity_high/adequacy_high")
        self.assertEqual(sts["value"], 1)
        self.assertEqual(trc["value"], 1)

    def test_full_output_schema_and_fixed_family_sizes(self):
        g = gold_fixture()
        predictions = [prediction(query=q) for _, q in g.queries]
        results = e.evaluate(predictions, g, (simple_alpha, simple_ideal))
        expected = {"dev/core/fidelity_recall": 18, "dev/core/fidelity_ranking": 12,
                    "dev/requirements/adequacy_routes": 54, "dev/requirements/adequacy_alpha": 18,
                    "test/core/fidelity_recall": 18, "test/all/fidelity_recall": 18}
        for family, size in expected.items():
            self.assertEqual(next(r for r in results["paired_statistics"] if r["family"] == family)["family_size"], size)
        with tempfile.TemporaryDirectory() as directory:
            files = e.write_outputs(results, Path(directory))
            self.assertEqual(len(files), 4)
            with (Path(directory) / "e1_results.csv").open() as handle:
                written = list(csv.DictReader(handle))
            self.assertEqual({r["level"] for r in written}, {"query", "task", "summary"})
            self.assertTrue(any(r["value"] == "" for r in written))
            self.assertIn("MRR@20", (Path(directory) / "e1_paper_tables.tex").read_text())


@unittest.skipUnless(FROZEN_ROOT.exists(), "Frozen local snapshot unavailable")
class FrozenIntegrationTests(unittest.TestCase):
    def test_frozen_population_and_imported_alpha(self):
        gold = e.load_gold(FROZEN_ROOT)
        for split, expected in e.EXPECTED_COUNTS.items():
            rows = [row for (name, _), row in gold.queries.items() if name == split]
            self.assertEqual((len({r["task_id"] for r in rows}), len(rows)), expected)
        alpha, ideal = e.load_alpha_helpers(FROZEN_ROOT)
        self.assertAlmostEqual(alpha([None, "a", "c"], requirements(), alpha=.5), 2 / math.log2(3) + .5)
        self.assertGreater(ideal(requirements(), alpha=.5, top_k=20), 0)
        self.assertTrue(alpha.__module__.startswith("paper_e1_frozen"))


class PaperTablePresentationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        gold = gold_fixture()
        predictions = [prediction(query=q) for _, q in gold.queries]
        cls.results = e.evaluate(predictions, gold, (simple_alpha, simple_ideal))

    def test_all_tables_use_balanced_ieee_full_width_wrappers(self):
        text = e.paper_tables(self.results["summaries"], self.results["paired_statistics"])
        self.assertEqual(text.count(r"\begin{table*}[t]"), 8)
        self.assertEqual(text.count(r"\end{table*}"), 8)
        self.assertEqual(text.count(r"\resizebox{\textwidth}{!}{"), 8)
        self.assertEqual(text.count(r"\begin{tabular}"), text.count(r"\end{tabular}"))
        self.assertEqual(text.count("{"), text.count("}"))
        self.assertNotIn(r"\begin{table}[", text)

    def test_primary_table_separates_cohorts_and_keeps_seven_methods(self):
        text = e.paper_tables(self.results["summaries"])
        main = text.split("% MAIN TABLE:", 1)[1].split("% SUPPLEMENTARY TABLE 1", 1)[0]
        self.assertIn("Test core: 109 tasks / 218 queries", main)
        self.assertIn("Dev: 51 tasks / 102 queries", main)
        self.assertIn(r"\multicolumn{3}{c|}", main)
        self.assertIn(r"\multicolumn{4}{c}", main)
        self.assertIn(r"R@10 & MRR@20 & MAP@20 & TRC@10 & SCC@10 & CSA@10 & $\alpha$nDCG@10", main)
        self.assertIn("no pooled mean is computed", main)
        self.assertNotIn("160 tasks", main)
        for method in e.METHODS:
            self.assertEqual(sum(line.startswith(method + " & ") for line in main.splitlines()), 1)
        self.assertEqual(text.count("% SUPPLEMENTARY TABLE "), 6)

    def test_paired_table_only_formats_existing_estimates_and_nulls(self):
        before = copy.deepcopy(self.results)
        text = e.paper_tables(self.results["summaries"], self.results["paired_statistics"])
        paired = text.split("% PAIRED TABLE:", 1)[1]
        self.assertIn("Test core R@10", paired)
        self.assertIn("Dev TRC@10", paired)
        self.assertIn("Dev CSA@10", paired)
        self.assertIn(r"$p_{\mathrm{Holm}}$", paired)
        self.assertIn("0 & NA & NA", paired)
        self.assertIn("NA [0/1]", text)
        self.assertNotIn("pending", text.lower())
        self.assertEqual(self.results, before)


if __name__ == "__main__":
    unittest.main()
