"""Gold-isolated E1 evaluation. Only this process opens query/Gold files.

CSV nulls are empty cells. Primary means use complete two-query source tasks;
query means are descriptive and never impute an unobserved query. Ranking nulls
are observed nonhits and retain their rank. No aliases are resolved here.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.util
import itertools
import json
import math
import random
import sys
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from statistics import mean
from typing import Any, Callable, Mapping, Sequence

METHODS = ("BM25 Retrieval", "Dense Retrieval", "Direct LLM", "Flat RAG Agent",
           "StructuredRAG", "GraphRAG", "OceanAgent")
KS = (5, 10, 20)
ALPHA = 0.5
RESAMPLES = 2000
SEED = 20261030
EXPECTED_COUNTS = {"test": (109, 218), "dev": (51, 102)}
Rank = Sequence[str | None]


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    rows = []
    with path.open(encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, 1):
            if not line.strip():
                continue
            row = json.loads(line)
            if not isinstance(row, dict):
                raise ValueError(f"Expected object at {path}:{line_number}")
            rows.append(row)
    return rows


def unique_index(rows: Sequence[Mapping[str, Any]], label: str) -> dict[str, dict[str, Any]]:
    result = {}
    for row in rows:
        key = row.get("query_id")
        if not isinstance(key, str) or not key or key in result:
            raise ValueError(f"Empty or duplicate query_id in {label}: {key!r}")
        result[key] = dict(row)
    return result


@dataclass
class Gold:
    queries: dict[tuple[str, str], dict[str, Any]]
    core: dict[str, list[str]]
    all_datasets: dict[str, list[str]]
    requirements: dict[str, dict[str, Any]]
    routes: dict[str, dict[str, Any]]
    canonical_ids: set[str]


def load_gold(knowledge_root: Path, *, enforce_counts: bool = True) -> Gold:
    """Select Test in full and the Dev Requirement/Route Gold intersection."""
    benchmark = Path(knowledge_root) / "benchmark"
    requirements = unique_index(read_jsonl(benchmark / "gold/task_requirement_gold.jsonl"), "requirements")
    routes = unique_index(read_jsonl(benchmark / "gold/valid_route_gold.jsonl"), "routes")
    dataset = unique_index(read_jsonl(benchmark / "gold/dataset_gold.jsonl"), "dataset Gold")
    usage = unique_index(read_jsonl(benchmark / "gold/paper_usage_gold.jsonl"), "paper-usage Gold")
    queries = {}
    for split in ("dev", "test"):
        split_rows = unique_index(read_jsonl(benchmark / f"splits/{split}.jsonl"), split)
        for query_id, row in split_rows.items():
            if split == "dev" and not (query_id in requirements and query_id in routes):
                continue
            task_id = row.get("source_group_id")
            if not isinstance(task_id, str) or not task_id:
                raise ValueError(f"Missing source_group_id for {query_id}")
            if query_id not in dataset or query_id not in usage:
                raise ValueError(f"Missing independent fidelity Gold for {query_id}")
            queries[split, query_id] = {"task_id": task_id, "query_id": query_id}
        selected = [row for (name, _), row in queries.items() if name == split]
        sizes = Counter(row["task_id"] for row in selected)
        if any(count != 2 for count in sizes.values()):
            raise ValueError(f"{split} must have exactly two admitted queries per source task")
        if enforce_counts and (len(sizes), len(selected)) != EXPECTED_COUNTS[split]:
            raise ValueError(f"Frozen {split} count mismatch: {(len(sizes), len(selected))}")
    canonical = {row["dataset_id"] for row in read_jsonl(benchmark / "corpus/dataset_corpus.jsonl")}
    core = {q: row["gold_dataset_ids"] for q, row in dataset.items()}
    # paper_usage_gold names its complete usage set gold_dataset_ids.
    all_datasets = {q: row["gold_dataset_ids"] for q, row in usage.items()}
    for (_, query_id) in queries:
        for label, ids in (("core", core[query_id]), ("all", all_datasets[query_id])):
            if not isinstance(ids, list) or not ids or any(x not in canonical for x in ids):
                raise ValueError(f"Invalid {label} Gold for {query_id}")
    return Gold(queries, core, all_datasets, requirements, routes, canonical)


def load_alpha_helpers(knowledge_root: Path) -> tuple[Callable, Callable]:
    """Import the frozen convention from the existing experiment, read-only."""
    experiment = Path(__file__).resolve().parents[3] / "oceanagent/experiments/agent_e1_taskcompiler"
    config = json.loads((experiment / "experiment_config.json").read_text(encoding="utf-8"))
    if config.get("alpha_ndcg") != ALPHA:
        raise ValueError("Existing frozen alpha_ndcg must equal 0.5")
    path = experiment / "evaluate_experiment.py"
    spec = importlib.util.spec_from_file_location("paper_e1_frozen_alpha_helpers", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot import alpha helpers: {path}")
    module = importlib.util.module_from_spec(spec)
    previous = sys.dont_write_bytecode
    try:
        sys.dont_write_bytecode = True
        spec.loader.exec_module(module)
    finally:
        sys.dont_write_bytecode = previous
    return module.alpha_dcg, module.ideal_alpha_dcg


def index_predictions(rows: Sequence[Mapping[str, Any]], gold: Gold, *, methods: Sequence[str] = METHODS) -> dict[tuple[str, str, str], dict[str, Any]]:
    indexed = {}
    for row in rows:
        method, split, query_id = row.get("method"), row.get("split"), row.get("query_id")
        key = (method, split, query_id)
        if method not in methods or split not in ("dev", "test") or not isinstance(query_id, str):
            raise ValueError(f"Invalid prediction identity: {key}")
        if (split, query_id) not in gold.queries:
            raise ValueError(f"Prediction is outside admitted E1 population: {key}")
        if key in indexed:
            raise ValueError(f"Duplicate prediction: {key}")
        if row.get("task_id") != gold.queries[split, query_id]["task_id"]:
            raise ValueError(f"task_id must equal source_group_id: {key}")
        if row.get("status") not in ("success", "failed", "unavailable"):
            raise ValueError(f"Invalid status: {key}")
        ranking = row.get("ranking")
        if not isinstance(ranking, list) or any(x is not None and (not isinstance(x, str) or x not in gold.canonical_ids) for x in ranking):
            raise ValueError(f"Ranking must contain canonical dataset IDs or null: {key}")
        nonnull = [x for x in ranking if x is not None]
        if len(nonnull) != len(set(nonnull)):
            raise ValueError(f"Duplicate nonnull ranking IDs: {key}")
        depth = row.get("available_depth")
        if not isinstance(depth, int) or isinstance(depth, bool) or depth < 0 or len(ranking) > depth:
            raise ValueError(f"Invalid available_depth: {key}")
        indexed[key] = dict(row)
    return indexed


def prediction_reason(prediction: Mapping[str, Any] | None, k: int) -> str:
    if prediction is None:
        return "missing_prediction"
    if prediction["status"] != "success":
        return prediction["status"]
    if prediction["available_depth"] < k:
        return "insufficient_depth"
    return ""


def fidelity_metrics(ranking: Rank, relevant: Sequence[str], k: int) -> dict[str, float | None]:
    gold = set(relevant)
    if not gold:
        return {"Recall": None, "MRR": None, "MAP": None}
    ranked = ranking[:k]
    hits = [i for i, dataset in enumerate(ranked, 1) if dataset in gold]
    return {"Recall": len(hits) / len(gold), "MRR": 1 / hits[0] if hits else 0.0,
            "MAP": sum(j / rank for j, rank in enumerate(hits, 1)) / len(gold)}


def validate_requirements(row: Mapping[str, Any] | None, canonical_ids: set[str]) -> tuple[list[dict[str, Any]], str]:
    if row is None:
        return [], "missing_requirements"
    requirements = row.get("requirements")
    if not isinstance(requirements, list) or not requirements:
        return [], "invalid_requirements"
    ids = []
    for item in requirements:
        if not isinstance(item, dict):
            return [], "invalid_requirements"
        rid, acceptable, weight = item.get("requirement_id"), item.get("acceptable_dataset_ids"), item.get("weight")
        if (not isinstance(rid, str) or not rid or not isinstance(acceptable, list) or not acceptable
                or any(x not in canonical_ids for x in acceptable)
                or not isinstance(weight, (int, float)) or isinstance(weight, bool)
                or not math.isfinite(weight) or weight <= 0):
            return [], "invalid_requirements"
        ids.append(rid)
    if len(ids) != len(set(ids)):
        return [], "invalid_requirements"
    return requirements, ""


def route_metrics(ranking: Rank, requirements: Sequence[Mapping[str, Any]], route_row: Mapping[str, Any] | None) -> tuple[dict[str, float | None], str]:
    """Literal paper formula; dataset_groups does not enter Cov(v).

    Alternative routes sharing covered requirement IDs therefore share coverage,
    even if dataset_groups differ. Unknown IDs invalidate the whole route set.
    """
    null = {"TRC": None, "SCC": None, "CSA": None}
    if route_row is None:
        return null, "missing_routes"
    routes = route_row.get("valid_routes")
    if not isinstance(routes, list) or not routes:
        return null, "invalid_routes"
    by_id = {item["requirement_id"]: item for item in requirements}
    predicted = set(ranking)
    coverages, route_ids = [], []
    for route in routes:
        if not isinstance(route, dict):
            return null, "invalid_routes"
        ids = route.get("covers_requirement_ids")
        route_id = route.get("route_id")
        if (not isinstance(route_id, str) or not route_id or route_id in route_ids
                or not isinstance(ids, list) or not ids
                or any(not isinstance(x, str) or x not in by_id for x in ids)
                or len(ids) != len(set(ids))):
            return null, "invalid_routes"
        route_ids.append(route_id)
        coverages.append(sum(bool(predicted.intersection(by_id[rid]["acceptable_dataset_ids"])) for rid in ids) / len(ids))
    scc = sum(coverage == 1.0 for coverage in coverages) / len(coverages)
    return {"TRC": max(coverages), "SCC": scc, "CSA": float(scc > 0)}, ""


def metric_specifications(split: str, *, all_ranking_cutoffs: bool = False) -> list[tuple[str, str, int]]:
    references = ("core", "all") if split == "test" else ("core",)
    specs = [(reference, "Recall", k) for reference in references for k in KS]
    specs += [(reference, metric, k) for reference in references for metric in ("MRR", "MAP")
              for k in (KS if all_ranking_cutoffs else (20,))]
    if split == "dev":
        specs += [("requirements", metric, k) for metric in ("TRC", "SCC", "CSA", "alpha_nDCG") for k in KS]
    return specs


def query_metrics(predictions: Mapping, gold: Gold, alpha_helpers: tuple[Callable, Callable], *,
                  methods: Sequence[str] = METHODS, all_ranking_cutoffs: bool = False) -> list[dict[str, Any]]:
    dcg, ideal_dcg = alpha_helpers
    results = []
    for (split, query_id), query in sorted(gold.queries.items()):
        requirements, req_reason = validate_requirements(gold.requirements.get(query_id), gold.canonical_ids)
        for method in methods:
            prediction = predictions.get((method, split, query_id))
            ranking = prediction["ranking"] if prediction else []
            for reference, metric, k in metric_specifications(split, all_ranking_cutoffs=all_ranking_cutoffs):
                value, reason = None, prediction_reason(prediction, k)
                invalid_routes = 0
                if not reason:
                    if reference in ("core", "all"):
                        relevant = gold.core[query_id] if reference == "core" else gold.all_datasets[query_id]
                        value = fidelity_metrics(ranking, relevant, k)[metric]
                        if value is None:
                            reason = "missing_fidelity_gold"
                    elif req_reason:
                        reason = req_reason
                    elif metric == "alpha_nDCG":
                        ideal = ideal_dcg(requirements, alpha=ALPHA, top_k=k)
                        value = dcg(ranking[:k], requirements, alpha=ALPHA) / ideal if ideal > 0 else None
                        if value is None:
                            reason = "zero_alpha_ideal"
                    else:
                        route_values, reason = route_metrics(ranking[:k], requirements, gold.routes.get(query_id))
                        value = route_values[metric]
                        invalid_routes = int(reason in ("missing_routes", "invalid_routes"))
                # Route validity is a Gold property, also disclose it when predictions are missing.
                if reference == "requirements" and metric in ("TRC", "SCC", "CSA") and not req_reason:
                    _, gold_route_reason = route_metrics([], requirements, gold.routes.get(query_id))
                    invalid_routes = int(bool(gold_route_reason))
                results.append({"level": "query", "split": split, "reference": reference,
                                "method": method, "task_id": query["task_id"], "query_id": query_id,
                                "metric": metric, "k": k, "value": value, "reason": reason,
                                "valid_count": int(value is not None), "missing_count": int(value is None),
                                "total_count": 1, "invalid_routes_count": invalid_routes})
    return results


def aggregate(query_rows: Sequence[Mapping[str, Any]]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    groups = defaultdict(list)
    for row in query_rows:
        key = tuple(row[name] for name in ("split", "reference", "method", "metric", "k", "task_id"))
        groups[key].append(row)
    tasks = []
    for (split, reference, method, metric, k, task_id), rows in sorted(groups.items()):
        values = [row["value"] for row in rows if row["value"] is not None]
        complete = len(rows) == 2 and len(values) == 2
        tasks.append({"level": "task", "split": split, "reference": reference, "method": method,
                      "task_id": task_id, "query_id": "", "metric": metric, "k": k,
                      "value": mean(values) if complete else None,
                      "reason": "" if complete else "incomplete_two_query_task",
                      "valid_count": len(values), "missing_count": 2 - len(values), "total_count": 2,
                      "invalid_routes_count": sum(row["invalid_routes_count"] for row in rows)})
    summary_groups = defaultdict(list)
    query_groups = defaultdict(list)
    for rows, destination in ((tasks, summary_groups), (query_rows, query_groups)):
        for row in rows:
            destination[tuple(row[name] for name in ("split", "reference", "method", "metric", "k"))].append(row)
    summaries = []
    for (split, reference, method, metric, k), rows in sorted(summary_groups.items()):
        values = [row["value"] for row in rows if row["value"] is not None]
        qrows = query_groups[split, reference, method, metric, k]
        qvalues = [row["value"] for row in qrows if row["value"] is not None]
        summaries.append({"level": "summary", "split": split, "reference": reference, "method": method,
                          "task_id": "", "query_id": "", "metric": metric, "k": k,
                          "value": mean(values) if values else None, "reason": "" if values else "no_complete_tasks",
                          "valid_count": len(values), "missing_count": len(rows) - len(values), "total_count": len(rows),
                          "valid_query_count": len(qvalues), "missing_query_count": len(qrows) - len(qvalues),
                          "total_query_count": len(qrows), "query_mean": mean(qvalues) if qvalues else None,
                          "invalid_routes_count": sum(row["invalid_routes_count"] for row in qrows),
                          "reason_counts": json.dumps(dict(sorted(Counter(row["reason"] for row in qrows if row["reason"]).items())), sort_keys=True)})
    return tasks, summaries


def stable_seed(*labels: Any) -> int:
    return SEED + int(hashlib.sha256(json.dumps(labels).encode()).hexdigest()[:12], 16)


def percentile(sorted_values: Sequence[float], probability: float) -> float:
    position = (len(sorted_values) - 1) * probability
    lo, hi = math.floor(position), math.ceil(position)
    return sorted_values[lo] + (sorted_values[hi] - sorted_values[lo]) * (position - lo)


def paired_inference(deltas: Sequence[float], *, seed: int, resamples: int = RESAMPLES) -> dict[str, Any]:
    if not deltas:
        return {"delta": None, "ci_low": None, "ci_high": None, "p_value": None,
                "randomization": "unobserved", "randomization_draws": 0}
    rng = random.Random(seed)
    n = len(deltas)
    bootstrap = sorted(sum(deltas[rng.randrange(n)] for _ in range(n)) / n for _ in range(resamples))
    observed = abs(sum(deltas))
    nonzero = [value for value in deltas if value != 0]
    if len(nonzero) <= int(math.log2(resamples)):
        draws = 2 ** len(nonzero)
        extreme = sum(abs(sum(sign * value for sign, value in zip(signs, nonzero))) >= observed - 1e-12
                      for signs in itertools.product((-1, 1), repeat=len(nonzero)))
        p_value, mode = extreme / draws, "exact_task_sign_flip"
    else:
        draws = resamples
        extreme = sum(abs(sum(value if rng.randrange(2) else -value for value in nonzero)) >= observed - 1e-12
                      for _ in range(draws))
        p_value, mode = (extreme + 1) / (draws + 1), "monte_carlo_task_sign_flip_plus_one"
    return {"delta": mean(deltas), "ci_low": percentile(bootstrap, .025),
            "ci_high": percentile(bootstrap, .975), "p_value": p_value,
            "randomization": mode, "randomization_draws": draws}


def apply_holm(rows: list[dict[str, Any]]) -> None:
    families = defaultdict(list)
    for row in rows:
        families[row["family"]].append(row)
    for family in families.values():
        # Every planned hypothesis contributes to m, including unobserved ones.
        observed = sorted((row for row in family if row["p_value"] is not None), key=lambda row: row["p_value"])
        running = 0.0
        for i, row in enumerate(observed):
            running = max(running, min(1.0, (len(family) - i) * row["p_value"]))
            row["p_holm"] = running
        for row in family:
            row["family_size"] = len(family)
            row.setdefault("p_holm", None)


def paired_statistics(task_rows: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    grouped = defaultdict(dict)
    for row in task_rows:
        grouped[tuple(row[name] for name in ("split", "reference", "metric", "k"))][row["method"], row["task_id"]] = row["value"]
    results = []
    for (split, reference, metric, k), data in sorted(grouped.items()):
        tasks = sorted({task for _, task in data})
        family_type = ("fidelity_recall" if metric == "Recall" else "fidelity_ranking" if metric in ("MRR", "MAP")
                       else "adequacy_alpha" if metric == "alpha_nDCG" else "adequacy_routes")
        for baseline in METHODS[:-1]:
            pairs = [(data.get(("OceanAgent", task)), data.get((baseline, task))) for task in tasks]
            observed = [(a, b) for a, b in pairs if a is not None and b is not None]
            row = {"split": split, "reference": reference, "metric": metric, "k": k,
                   "method": "OceanAgent", "baseline": baseline, "n_pairs": len(observed),
                   "total_tasks": len(tasks), "missing_pair_tasks": len(tasks) - len(observed),
                   "oceanagent_valid_tasks": sum(a is not None for a, _ in pairs),
                   "baseline_valid_tasks": sum(b is not None for _, b in pairs),
                   "oceanagent_paired_mean": mean(a for a, _ in observed) if observed else None,
                   "baseline_paired_mean": mean(b for _, b in observed) if observed else None,
                   "family": f"{split}/{reference}/{family_type}", "bootstrap_resamples": RESAMPLES,
                   "confidence": .95, "seed": stable_seed(split, reference, metric, k, baseline)}
            row.update(paired_inference([a - b for a, b in observed], seed=row["seed"]))
            results.append(row)
    apply_holm(results)
    return results


def correlation(x: Sequence[float], y: Sequence[float]) -> float | None:
    if len(x) < 2:
        return None
    mx, my = mean(x), mean(y)
    xx, yy = sum((v - mx) ** 2 for v in x), sum((v - my) ** 2 for v in y)
    if xx == 0 or yy == 0:
        return None
    return sum((a - mx) * (b - my) for a, b in zip(x, y)) / math.sqrt(xx * yy)


def average_ranks(values: Sequence[float]) -> list[float]:
    result = [0.0] * len(values)
    ordered = sorted(range(len(values)), key=lambda i: values[i])
    start = 0
    while start < len(ordered):
        end = start + 1
        while end < len(ordered) and values[ordered[end]] == values[ordered[start]]:
            end += 1
        for position in range(start, end):
            result[ordered[position]] = (start + 1 + end) / 2
        start = end
    return result


def additional_analysis(query_rows: Sequence[Mapping[str, Any]], task_rows: Sequence[Mapping[str, Any]], *,
                        methods: Sequence[str] = METHODS) -> list[dict[str, Any]]:
    results, grouped = [], defaultdict(list)
    for row in query_rows:
        if row["k"] == 10 and (row["metric"] == "Recall" or (row["split"] == "dev" and row["metric"] in ("TRC", "CSA"))):
            grouped[tuple(row[name] for name in ("split", "reference", "method", "metric", "task_id"))].append(row)
    robustness_groups = defaultdict(list)
    for (split, reference, method, metric, task_id), rows in sorted(grouped.items()):
        values = [row["value"] for row in rows if row["value"] is not None]
        value = abs(values[0] - values[1]) if len(rows) == len(values) == 2 else None
        statistic = "CSA10_flip" if metric == "CSA" else f"absolute_delta_{metric}10"
        result = {"analysis": "within_task_robustness", "level": "task", "split": split, "reference": reference,
                  "method": method, "task_id": task_id, "statistic": statistic, "value": value,
                  "valid_count": int(value is not None), "missing_count": int(value is None), "total_count": 1}
        results.append(result)
        robustness_groups[split, reference, method, statistic].append(value)
    for (split, reference, method, statistic), values in sorted(robustness_groups.items()):
        valid = [v for v in values if v is not None]
        results.append({"analysis": "within_task_robustness", "level": "summary", "split": split, "reference": reference,
                        "method": method, "statistic": statistic, "value": mean(valid) if valid else None,
                        "valid_count": len(valid), "missing_count": len(values) - len(valid), "total_count": len(values)})
    lookup = {(row["method"], row["task_id"], row["reference"], row["metric"]): row["value"]
              for row in task_rows if row["split"] == "dev" and row["k"] == 10}
    tasks = sorted({row["task_id"] for row in task_rows if row["split"] == "dev"})
    for method in methods:
        for adequacy in ("TRC", "SCC", "CSA", "alpha_nDCG"):
            pairs = [(lookup.get((method, task, "core", "Recall")), lookup.get((method, task, "requirements", adequacy))) for task in tasks]
            valid = [(x, y) for x, y in pairs if x is not None and y is not None]
            x, y = [x for x, _ in valid], [y for _, y in valid]
            common = {"level": "summary", "split": "dev", "reference": "core_vs_requirements", "method": method,
                      "metric_x": "Recall@10", "metric_y": f"{adequacy}@10", "valid_count": len(valid),
                      "missing_count": len(tasks) - len(valid), "total_count": len(tasks)}
            for statistic, a, b in (("Pearson", x, y), ("Spearman", average_ranks(x), average_ranks(y))):
                value = correlation(a, b)
                results.append({**common, "analysis": "fidelity_adequacy_correlation", "statistic": statistic,
                                "value": value, "reason": "" if value is not None else "insufficient_pairs_or_constant_vector"})
            if adequacy in ("TRC", "CSA"):
                counts = Counter(("high" if a >= .5 else "low", "high" if (b >= .5 if adequacy == "TRC" else b == 1) else "low") for a, b in valid)
                for fidelity, science in itertools.product(("low", "high"), repeat=2):
                    count = counts[fidelity, science]
                    results.append({**common, "analysis": "fixed_threshold_quadrants", "statistic": f"fidelity_{fidelity}/adequacy_{science}",
                                    "value": count / len(valid) if valid else None, "count": count,
                                    "x_threshold": "Recall@10 >= 0.5", "y_threshold": "TRC@10 >= 0.5" if adequacy == "TRC" else "CSA@10 == 1"})
    return results


def evaluate(prediction_rows: Sequence[Mapping[str, Any]], gold: Gold, alpha_helpers: tuple[Callable, Callable]) -> dict[str, Any]:
    predictions = index_predictions(prediction_rows, gold)
    queries = query_metrics(predictions, gold, alpha_helpers)
    tasks, summaries = aggregate(queries)
    return {"query_rows": queries, "task_rows": tasks, "summaries": summaries,
            "paired_statistics": paired_statistics(tasks), "additional_analysis": additional_analysis(queries, tasks)}


def write_csv(path: Path, rows: Sequence[Mapping[str, Any]]) -> None:
    columns = list(dict.fromkeys(key for row in rows for key in row))
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns)
        writer.writeheader()
        writer.writerows(rows)


def tex_escape(value: str) -> str:
    return value.replace("_", r"\_").replace("&", r"\&").replace("%", r"\%")


def paper_tables(summaries: Sequence[Mapping[str, Any]], paired: Sequence[Mapping[str, Any]] | None = None) -> str:
    """Render IEEE two-column table fragments without changing any estimates."""
    lookup = {(row["split"], row["reference"], row["method"], row["metric"], row["k"]): row for row in summaries}

    def header(metric: str, k: int) -> str:
        label = {"Recall": "R", "alpha_nDCG": r"$\alpha$nDCG"}.get(metric, metric)
        return f"{label}@{k}"

    def cell(split: str, reference: str, method: str, metric: str, k: int) -> str:
        row = lookup[split, reference, method, metric, k]
        number = f"{row['value']:.3f}" if row["value"] is not None else "NA"
        return number + f" [{row['valid_count']}/{row['total_count']}]"

    def begin_table(columns: str) -> list[str]:
        return [r"\begin{table*}[t]", r"\centering", r"\small", r"\resizebox{\textwidth}{!}{",
                r"\begin{tabular}{" + columns + "}", r"\hline"]

    def end_table(caption: str, label: str) -> list[str]:
        return [r"\hline", r"\end{tabular}", "}", r"\caption{" + tex_escape(caption) + "}",
                r"\label{" + label + "}", r"\end{table*}", ""]

    lines = ["% E1 generated tables. Values are complete-source-task macro means; [n/N] is valid/expected tasks.",
             "% MRR@20 and MAP@20 use only observed depth >=20. Missing values are NA.",
             "% alpha=.5; Gold weights; existing greedy ideal over acceptable IDs, lexicographic ties.",
             "% Route coverage uses covers_requirement_ids and global acceptable_dataset_ids; dataset_groups is not used.",
             "% MAIN TABLE: the two cohorts are displayed together and never pooled."]
    primary = [("test", "core", "Recall", 10), ("test", "core", "MRR", 20), ("test", "core", "MAP", 20),
               ("dev", "requirements", "TRC", 10), ("dev", "requirements", "SCC", 10),
               ("dev", "requirements", "CSA", 10), ("dev", "requirements", "alpha_nDCG", 10)]
    lines += begin_table("lccc|cccc")
    lines += [r" & \multicolumn{3}{c|}{Test core: 109 tasks / 218 queries} & \multicolumn{4}{c}{Dev: 51 tasks / 102 queries} \\",
              r"\cline{2-4}\cline{5-8}", "Method & " + " & ".join(header(metric, k) for _, _, metric, k in primary) + r" \\", r"\hline"]
    for method in METHODS:
        lines.append(tex_escape(method) + " & " + " & ".join(cell(split, reference, method, metric, k) for split, reference, metric, k in primary) + r" \\")
    lines += end_table("E1 primary results. Test core fidelity (109 source tasks, 218 queries) and Dev scientific adequacy (51 source tasks, 102 queries) use separate cohorts; no pooled mean is computed. Values are complete two-query task macro means, with valid/expected task counts in brackets. MRR and MAP use ranking@20.", "tab:e1-main")

    tables = [(split, reference, [("Recall", k) for k in KS] + [("MRR", 20), ("MAP", 20)])
              for split, reference in (("test", "core"), ("test", "all"), ("dev", "core"))]
    tables += [("dev", "requirements", [(metric, k) for metric in ("TRC", "SCC", "CSA", "alpha_nDCG")]) for k in KS]
    for index, (split, reference, metrics) in enumerate(tables, 1):
        tasks, queries = EXPECTED_COUNTS[split]
        caption = f"E1 supplementary {split.capitalize()} {reference} ({tasks} source tasks, {queries} queries); complete two-query task macro means with valid/expected tasks in brackets. MRR/MAP use ranking@20."
        lines += [f"% SUPPLEMENTARY TABLE {index}"] + begin_table("l" + "c" * len(metrics))
        lines += ["Method & " + " & ".join(header(metric, k) for metric, k in metrics) + r" \\", r"\hline"]
        for method in METHODS:
            lines.append(tex_escape(method) + " & " + " & ".join(cell(split, reference, method, metric, k) for metric, k in metrics) + r" \\")
        lines += end_table(caption, f"tab:e1-supplement-{index}")

    if paired is not None:
        paired_lookup = {(row["split"], row["reference"], row["baseline"], row["metric"], row["k"]): row for row in paired}
        comparisons = [("test", "core", "Recall", 10), ("dev", "requirements", "TRC", 10), ("dev", "requirements", "CSA", 10)]
        lines += ["% PAIRED TABLE: the existing task-paired estimates and corrected p values are only formatted here."]
        lines += begin_table("lccc|ccc|ccc")
        lines += [r" & \multicolumn{3}{c|}{Test core R@10} & \multicolumn{3}{c|}{Dev TRC@10} & \multicolumn{3}{c}{Dev CSA@10} \\",
                  r"\cline{2-4}\cline{5-7}\cline{8-10}",
                  "Baseline & " + " & ".join([r"$n$ & $\Delta$ [95\% CI] & $p_{\mathrm{Holm}}$"] * 3) + r" \\", r"\hline"]
        for baseline in METHODS[:-1]:
            cells = []
            for split, reference, metric, k in comparisons:
                row = paired_lookup.get((split, reference, baseline, metric, k))
                if row is None:
                    cells += ["0", "NA", "NA"]
                    continue
                delta = row["delta"]
                estimate = (f"{delta:+.3f} [{row['ci_low']:+.3f}, {row['ci_high']:+.3f}]" if delta is not None else "NA")
                p = row["p_holm"]
                p_label = "NA" if p is None else (r"$<0.001$" if p < .001 else f"{p:.3f}")
                cells += [str(row["n_pairs"]), estimate, p_label]
            lines.append(tex_escape(baseline) + " & " + " & ".join(cells) + r" \\")
        lines += end_table("E1 paired comparisons: OceanAgent minus each baseline on the same observed complete source tasks. Each cohort is analyzed separately. n is the paired task count; intervals use 2000 task bootstrap resamples. p values use task sign-flip randomization and the prespecified Holm families.", "tab:e1-paired")
    return "\n".join(lines)


def write_outputs(results: Mapping[str, Any], output_dir: Path) -> list[str]:
    output_dir.mkdir(parents=True, exist_ok=True)
    write_csv(output_dir / "e1_results.csv", results["query_rows"] + results["task_rows"] + results["summaries"])
    write_csv(output_dir / "e1_paired_statistics.csv", results["paired_statistics"])
    write_csv(output_dir / "e1_additional_analysis.csv", results["additional_analysis"])
    (output_dir / "e1_paper_tables.tex").write_text(paper_tables(results["summaries"], results["paired_statistics"]), encoding="utf-8")
    return [str(output_dir / name) for name in ("e1_results.csv", "e1_paired_statistics.csv", "e1_additional_analysis.csv", "e1_paper_tables.tex")]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--predictions", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--knowledge-root", type=Path, required=True)
    parser.add_argument("--method", action="append", help="Score the supplied retrieval method(s) with the existing metric functions")
    args = parser.parse_args()
    gold = load_gold(args.knowledge_root)
    rows = read_jsonl(args.predictions)
    if args.method:
        methods = tuple(args.method)
        if len(set(methods)) != len(methods):
            raise ValueError("Methods must be unique")
        predictions = index_predictions(rows, gold, methods=methods)
        query_rows = query_metrics(predictions, gold, load_alpha_helpers(args.knowledge_root),
                                   methods=methods, all_ranking_cutoffs=True)
        task_rows, summaries = aggregate(query_rows)
        results = {"query_rows": query_rows, "task_rows": task_rows, "summaries": summaries}
        args.output_dir.mkdir(parents=True, exist_ok=True)
        target = args.output_dir / "retrieval_metrics.csv"
        write_csv(target, query_rows + task_rows + summaries)
        files = [str(target)]
    else:
        results = evaluate(rows, gold, load_alpha_helpers(args.knowledge_root))
        files = write_outputs(results, args.output_dir)
    print(json.dumps({"files": files, "prediction_rows": len(rows), "query_metric_rows": len(results["query_rows"]),
                      "task_metric_rows": len(results["task_rows"]), "summary_rows": len(results["summaries"]),
                      "alpha": ALPHA, "bootstrap_resamples": RESAMPLES,
                      "observed_summaries": [row for row in results["summaries"] if row["valid_count"]]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
