/** Read-only model settings bridge. Secrets stay in this process and never reach stdout. */
import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
import {join,resolve} from 'node:path';
import {stat} from 'node:fs/promises';
import readline from 'node:readline';
import {createHash} from 'node:crypto';
import {captureUsage} from './e1_usage.mjs';
const root=resolve(process.argv[2]);
const require=createRequire(join(root,'package.json'));
const Database=require('better-sqlite3');
const {ModelSettingsRepository}=await import(pathToFileURL(join(root,'dist/db/model-settings-repository.js')));
const {createSecretProtector}=await import(pathToFileURL(join(root,'dist/security/platform-secret-protector.js')));
const {OceanModelService}=await import(pathToFileURL(join(root,'dist/agent/model-service.js')));
const keyInfo=await stat(join(root,'data/.credentials/master.key'));
if ((keyInfo.mode&0o077)!==0) throw Error('credential file permissions invalid; bridge will not change them');
const db=new Database(join(root,'data/ocean-agent.sqlite'),{readonly:true,fileMustExist:true});db.pragma('query_only = ON');
const settings=new ModelSettingsRepository({raw:db},createSecretProtector(root));
const service=await OceanModelService.create(settings);
function safeError(e){return String(e?.message??e).replace(/(?:sk-|Bearer\s+)[A-Za-z0-9_.-]{8,}/g,'[REDACTED]').slice(0,1200);}
async function handle(req){
 const selected=req.model??'deepseek::deepseek-flash';
 const model=service.resolveRunModel(selected);
 if(req.kind==='info'){
  const providers=settings.listProviders().map(x=>({providerId:x.providerId,configured:x.hasSavedCredential,enabledModelIds:x.enabledModelIds}));
  const embedding=db.prepare("SELECT value FROM app_settings WHERE key='embedding_model_settings'").get();
  return {model:{key:selected,id:model.id,provider:model.provider,name:model.name,api:model.api,baseUrl:model.baseUrl,contextWindow:model.contextWindow,maxTokens:model.maxTokens,reasoning:model.reasoning},providers,embedding:embedding?JSON.parse(embedding.value):null};
 }
 if(req.kind!=='complete')throw Error('unknown bridge request kind');
 if(!Number.isInteger(req.max_tokens)||req.max_tokens<1||req.max_tokens>4096)throw Error('Invalid per-call output-token bound');
 if(!Number.isInteger(req.timeout_ms)||req.timeout_ms<1||req.timeout_ms>120000)throw Error('Invalid request timeout');
 const start=performance.now();const statuses=[];let requestMode=null;let response;
 const provider={};let capture=null;let dispatches=0;
 const guardedFetch=async(input,init)=>{
   if(dispatches++)throw Error('Hidden SDK retry blocked; one dispatch per explicit runner attempt');
   const url=new URL(typeof input==='string'?input:input.url??String(input));
   if(url.origin!==new URL(model.baseUrl).origin)throw Error('Endpoint differs from the configured model');
   const result=await globalThis.fetch(input,init);
   statuses.push({status:result.status});capture=captureUsage(result.clone(),provider);return result;
 };
 try{response=await service.runtime.completeSimple(model,req.context,{temperature:0,maxTokens:req.max_tokens??4096,
   samplingParams:{thinking:{type:'disabled'},reasoning_effort:'none'},
   maxRetries:0,fetch:guardedFetch,
   cacheRetention:'short',signal:AbortSignal.timeout(req.timeout_ms??120000),
   onPayload:body=>{requestMode={model:body.model,thinking:body.thinking,reasoning_effort:body.reasoning_effort,temperature:body.temperature,max_tokens:body.max_tokens,tool_n:body.tools?.length??0,payload_sha256:createHash('sha256').update(JSON.stringify(body)).digest('hex')};},
   });
 }finally{if(capture)await capture;}
 const accounting={provider_usage:provider.usage??null,provider_model:provider.model??null,provider_response_id:provider.response_id??null,actual_http_dispatches:dispatches};
 if(['error','aborted'].includes(response.stopReason))return {ok:false,error:safeError(response.errorMessage??response.stopReason),response,elapsed_ms:performance.now()-start,http_statuses:statuses,request_mode:requestMode,...accounting};
 return {ok:true,response,elapsed_ms:performance.now()-start,http_statuses:statuses,request_mode:requestMode,...accounting};
}
const rl=readline.createInterface({input:process.stdin,crlfDelay:Infinity});
for await(const line of rl){if(!line.trim())continue;let req;try{req=JSON.parse(line);const result=await handle(req);process.stdout.write(JSON.stringify({id:req.id,...result})+'\n');}catch(e){process.stdout.write(JSON.stringify({id:req?.id,ok:false,error:safeError(e)})+'\n');}}
db.close();
